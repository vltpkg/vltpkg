var global = globalThis;
import {Buffer} from "node:buffer";
import {setTimeout as _vlt_setTimeout,clearTimeout as _vlt_clearTimeout,setImmediate as _vlt_setImmediate,clearImmediate as _vlt_clearImmediate,setInterval as _vlt_setInterval,clearInterval as _vlt_clearInterval} from "node:timers";
globalThis.setTimeout = _vlt_setTimeout;
globalThis.clearTimeout = _vlt_clearTimeout;
globalThis.setImmediate = _vlt_setImmediate;
globalThis.clearImmediate = _vlt_clearImmediate;
globalThis.setInterval = _vlt_setInterval;
globalThis.clearInterval = _vlt_clearInterval;
import {createRequire as _vlt_createRequire} from "node:module";
var require = _vlt_createRequire(import.meta.filename);
import {
  AbortError,
  SecurityArchive,
  pRetry
} from "./chunk-K4X2TU3S.js";
import {
  init
} from "./chunk-VVTZN4QQ.js";
import {
  Monorepo,
  PackageJson,
  minimatch,
  platformCheck
} from "./chunk-Z76BQOEV.js";
import {
  rimraf
} from "./chunk-BGQCUUCA.js";
import {
  Spec,
  Spec2,
  asDepID,
  defaultGitHostArchives,
  defaultGitHosts,
  defaultJsrRegistries,
  defaultRegistries,
  defaultRegistry,
  defaultRegistryName,
  defaultScopeRegistries,
  getId,
  getOptions,
  gitHostWebsites,
  graphRun,
  hydrate,
  hydrate2,
  hydrateTuple,
  isPackageNameConfused,
  joinDepIDTuple,
  joinExtra,
  splitDepID,
  splitExtra
} from "./chunk-FEV5BCW7.js";
import {
  promiseSpawn
} from "./chunk-VCSVHRCS.js";
import {
  graphStep
} from "./chunk-JLJKOF75.js";
import {
  Version,
  asError,
  asManifest,
  asNormalizedManifest,
  assertRecordStringString,
  compare,
  dependencyTypes,
  eq,
  expandNormalizedManifestSymbols,
  fastSplit,
  gt,
  gte,
  intersects,
  isObject,
  isRecordStringString,
  longDependencyTypes,
  lt,
  lte,
  major,
  minor,
  neq,
  normalizeManifest,
  parse,
  parseRange,
  patch,
  satisfies,
  shortDependencyTypes
} from "./chunk-KXBF4HVG.js";
import {
  load,
  walkUp
} from "./chunk-HTOTG4TS.js";
import {
  XDG
} from "./chunk-XNLSTHDK.js";
import {
  error,
  typeError
} from "./chunk-WZWDS3W4.js";
import {
  __commonJS,
  __require,
  __toESM
} from "./chunk-PZLD7RTK.js";

// ../../node_modules/.vlt/~npm~isexe@2.0.0/node_modules/isexe/windows.js
var require_windows = __commonJS({
  "../../node_modules/.vlt/~npm~isexe@2.0.0/node_modules/isexe/windows.js"(exports, module) {
    module.exports = isexe;
    isexe.sync = sync;
    var fs2 = __require("node:fs");
    function checkPathExt(path2, options) {
      var pathext = options.pathExt !== void 0 ? options.pathExt : process.env.PATHEXT;
      if (!pathext) {
        return true;
      }
      pathext = pathext.split(";");
      if (pathext.indexOf("") !== -1) {
        return true;
      }
      for (var i = 0; i < pathext.length; i++) {
        var p = pathext[i].toLowerCase();
        if (p && path2.substr(-p.length).toLowerCase() === p) {
          return true;
        }
      }
      return false;
    }
    function checkStat(stat3, path2, options) {
      if (!stat3.isSymbolicLink() && !stat3.isFile()) {
        return false;
      }
      return checkPathExt(path2, options);
    }
    function isexe(path2, options, cb) {
      fs2.stat(path2, function(er, stat3) {
        cb(er, er ? false : checkStat(stat3, path2, options));
      });
    }
    function sync(path2, options) {
      return checkStat(fs2.statSync(path2), path2, options);
    }
  }
});

// ../../node_modules/.vlt/~npm~isexe@2.0.0/node_modules/isexe/mode.js
var require_mode = __commonJS({
  "../../node_modules/.vlt/~npm~isexe@2.0.0/node_modules/isexe/mode.js"(exports, module) {
    module.exports = isexe;
    isexe.sync = sync;
    var fs2 = __require("node:fs");
    function isexe(path2, options, cb) {
      fs2.stat(path2, function(er, stat3) {
        cb(er, er ? false : checkStat(stat3, options));
      });
    }
    function sync(path2, options) {
      return checkStat(fs2.statSync(path2), options);
    }
    function checkStat(stat3, options) {
      return stat3.isFile() && checkMode(stat3, options);
    }
    function checkMode(stat3, options) {
      var mod = stat3.mode;
      var uid = stat3.uid;
      var gid = stat3.gid;
      var myUid = options.uid !== void 0 ? options.uid : process.getuid && process.getuid();
      var myGid = options.gid !== void 0 ? options.gid : process.getgid && process.getgid();
      var u = parseInt("100", 8);
      var g = parseInt("010", 8);
      var o = parseInt("001", 8);
      var ug = u | g;
      var ret = mod & o || mod & g && gid === myGid || mod & u && uid === myUid || mod & ug && myUid === 0;
      return ret;
    }
  }
});

// ../../node_modules/.vlt/~npm~isexe@2.0.0/node_modules/isexe/index.js
var require_isexe = __commonJS({
  "../../node_modules/.vlt/~npm~isexe@2.0.0/node_modules/isexe/index.js"(exports, module) {
    var fs2 = __require("node:fs");
    var core;
    if (process.platform === "win32" || global.TESTING_WINDOWS) {
      core = require_windows();
    } else {
      core = require_mode();
    }
    module.exports = isexe;
    isexe.sync = sync;
    function isexe(path2, options, cb) {
      if (typeof options === "function") {
        cb = options;
        options = {};
      }
      if (!cb) {
        if (typeof Promise !== "function") {
          throw new TypeError("callback not provided");
        }
        return new Promise(function(resolve12, reject) {
          isexe(path2, options || {}, function(er, is2) {
            if (er) {
              reject(er);
            } else {
              resolve12(is2);
            }
          });
        });
      }
      core(path2, options || {}, function(er, is2) {
        if (er) {
          if (er.code === "EACCES" || options && options.ignoreErrors) {
            er = null;
            is2 = false;
          }
        }
        cb(er, is2);
      });
    }
    function sync(path2, options) {
      try {
        return core.sync(path2, options || {});
      } catch (er) {
        if (options && options.ignoreErrors || er.code === "EACCES") {
          return false;
        } else {
          throw er;
        }
      }
    }
  }
});

// ../../node_modules/.vlt/~npm~which@2.0.2/node_modules/which/which.js
var require_which = __commonJS({
  "../../node_modules/.vlt/~npm~which@2.0.2/node_modules/which/which.js"(exports, module) {
    var isWindows = process.platform === "win32" || process.env.OSTYPE === "cygwin" || process.env.OSTYPE === "msys";
    var path2 = __require("node:path");
    var COLON = isWindows ? ";" : ":";
    var isexe = require_isexe();
    var getNotFoundError = (cmd) => Object.assign(new Error(`not found: ${cmd}`), { code: "ENOENT" });
    var getPathInfo = (cmd, opt) => {
      const colon = opt.colon || COLON;
      const pathEnv = cmd.match(/\//) || isWindows && cmd.match(/\\/) ? [""] : [
        // windows always checks the cwd first
        ...isWindows ? [process.cwd()] : [],
        ...(opt.path || process.env.PATH || /* istanbul ignore next: very unusual */
        "").split(colon)
      ];
      const pathExtExe = isWindows ? opt.pathExt || process.env.PATHEXT || ".EXE;.CMD;.BAT;.COM" : "";
      const pathExt = isWindows ? pathExtExe.split(colon) : [""];
      if (isWindows) {
        if (cmd.indexOf(".") !== -1 && pathExt[0] !== "")
          pathExt.unshift("");
      }
      return {
        pathEnv,
        pathExt,
        pathExtExe
      };
    };
    var which = (cmd, opt, cb) => {
      if (typeof opt === "function") {
        cb = opt;
        opt = {};
      }
      if (!opt)
        opt = {};
      const { pathEnv, pathExt, pathExtExe } = getPathInfo(cmd, opt);
      const found = [];
      const step = (i) => new Promise((resolve12, reject) => {
        if (i === pathEnv.length)
          return opt.all && found.length ? resolve12(found) : reject(getNotFoundError(cmd));
        const ppRaw = pathEnv[i];
        const pathPart = /^".*"$/.test(ppRaw) ? ppRaw.slice(1, -1) : ppRaw;
        const pCmd = path2.join(pathPart, cmd);
        const p = !pathPart && /^\.[\\\/]/.test(cmd) ? cmd.slice(0, 2) + pCmd : pCmd;
        resolve12(subStep(p, i, 0));
      });
      const subStep = (p, i, ii) => new Promise((resolve12, reject) => {
        if (ii === pathExt.length)
          return resolve12(step(i + 1));
        const ext = pathExt[ii];
        isexe(p + ext, { pathExt: pathExtExe }, (er, is2) => {
          if (!er && is2) {
            if (opt.all)
              found.push(p + ext);
            else
              return resolve12(p + ext);
          }
          return resolve12(subStep(p, i, ii + 1));
        });
      });
      return cb ? step(0).then((res) => cb(null, res), cb) : step(0);
    };
    var whichSync = (cmd, opt) => {
      opt = opt || {};
      const { pathEnv, pathExt, pathExtExe } = getPathInfo(cmd, opt);
      const found = [];
      for (let i = 0; i < pathEnv.length; i++) {
        const ppRaw = pathEnv[i];
        const pathPart = /^".*"$/.test(ppRaw) ? ppRaw.slice(1, -1) : ppRaw;
        const pCmd = path2.join(pathPart, cmd);
        const p = !pathPart && /^\.[\\\/]/.test(cmd) ? cmd.slice(0, 2) + pCmd : pCmd;
        for (let j = 0; j < pathExt.length; j++) {
          const cur = p + pathExt[j];
          try {
            const is2 = isexe.sync(cur, { pathExt: pathExtExe });
            if (is2) {
              if (opt.all)
                found.push(cur);
              else
                return cur;
            }
          } catch (ex) {
          }
        }
      }
      if (opt.all && found.length)
        return found;
      if (opt.nothrow)
        return null;
      throw getNotFoundError(cmd);
    };
    module.exports = which;
    which.sync = whichSync;
  }
});

// ../../node_modules/.vlt/~npm~path-key@3.1.1/node_modules/path-key/index.js
var require_path_key = __commonJS({
  "../../node_modules/.vlt/~npm~path-key@3.1.1/node_modules/path-key/index.js"(exports, module) {
    "use strict";
    var pathKey = (options = {}) => {
      const environment = options.env || process.env;
      const platform = options.platform || process.platform;
      if (platform !== "win32") {
        return "PATH";
      }
      return Object.keys(environment).reverse().find((key) => key.toUpperCase() === "PATH") || "Path";
    };
    module.exports = pathKey;
    module.exports.default = pathKey;
  }
});

// ../../node_modules/.vlt/~npm~cross-spawn@7.0.6/node_modules/cross-spawn/lib/util/resolveCommand.js
var require_resolveCommand = __commonJS({
  "../../node_modules/.vlt/~npm~cross-spawn@7.0.6/node_modules/cross-spawn/lib/util/resolveCommand.js"(exports, module) {
    "use strict";
    var path2 = __require("node:path");
    var which = require_which();
    var getPathKey = require_path_key();
    function resolveCommandAttempt(parsed, withoutPathExt) {
      const env2 = parsed.options.env || process.env;
      const cwd = process.cwd();
      const hasCustomCwd = parsed.options.cwd != null;
      const shouldSwitchCwd = hasCustomCwd && process.chdir !== void 0 && !process.chdir.disabled;
      if (shouldSwitchCwd) {
        try {
          process.chdir(parsed.options.cwd);
        } catch (err) {
        }
      }
      let resolved;
      try {
        resolved = which.sync(parsed.command, {
          path: env2[getPathKey({ env: env2 })],
          pathExt: withoutPathExt ? path2.delimiter : void 0
        });
      } catch (e) {
      } finally {
        if (shouldSwitchCwd) {
          process.chdir(cwd);
        }
      }
      if (resolved) {
        resolved = path2.resolve(hasCustomCwd ? parsed.options.cwd : "", resolved);
      }
      return resolved;
    }
    function resolveCommand(parsed) {
      return resolveCommandAttempt(parsed) || resolveCommandAttempt(parsed, true);
    }
    module.exports = resolveCommand;
  }
});

// ../../node_modules/.vlt/~npm~cross-spawn@7.0.6/node_modules/cross-spawn/lib/util/escape.js
var require_escape = __commonJS({
  "../../node_modules/.vlt/~npm~cross-spawn@7.0.6/node_modules/cross-spawn/lib/util/escape.js"(exports, module) {
    "use strict";
    var metaCharsRegExp = /([()\][%!^"`<>&|;, *?])/g;
    function escapeCommand(arg) {
      arg = arg.replace(metaCharsRegExp, "^$1");
      return arg;
    }
    function escapeArgument(arg, doubleEscapeMetaChars) {
      arg = `${arg}`;
      arg = arg.replace(/(?=(\\+?)?)\1"/g, '$1$1\\"');
      arg = arg.replace(/(?=(\\+?)?)\1$/, "$1$1");
      arg = `"${arg}"`;
      arg = arg.replace(metaCharsRegExp, "^$1");
      if (doubleEscapeMetaChars) {
        arg = arg.replace(metaCharsRegExp, "^$1");
      }
      return arg;
    }
    module.exports.command = escapeCommand;
    module.exports.argument = escapeArgument;
  }
});

// ../../node_modules/.vlt/~npm~shebang-regex@3.0.0/node_modules/shebang-regex/index.js
var require_shebang_regex = __commonJS({
  "../../node_modules/.vlt/~npm~shebang-regex@3.0.0/node_modules/shebang-regex/index.js"(exports, module) {
    "use strict";
    module.exports = /^#!(.*)/;
  }
});

// ../../node_modules/.vlt/~npm~shebang-command@2.0.0/node_modules/shebang-command/index.js
var require_shebang_command = __commonJS({
  "../../node_modules/.vlt/~npm~shebang-command@2.0.0/node_modules/shebang-command/index.js"(exports, module) {
    "use strict";
    var shebangRegex = require_shebang_regex();
    module.exports = (string = "") => {
      const match = string.match(shebangRegex);
      if (!match) {
        return null;
      }
      const [path2, argument] = match[0].replace(/#! ?/, "").split(" ");
      const binary = path2.split("/").pop();
      if (binary === "env") {
        return argument;
      }
      return argument ? `${binary} ${argument}` : binary;
    };
  }
});

// ../../node_modules/.vlt/~npm~cross-spawn@7.0.6/node_modules/cross-spawn/lib/util/readShebang.js
var require_readShebang = __commonJS({
  "../../node_modules/.vlt/~npm~cross-spawn@7.0.6/node_modules/cross-spawn/lib/util/readShebang.js"(exports, module) {
    "use strict";
    var fs2 = __require("node:fs");
    var shebangCommand = require_shebang_command();
    function readShebang(command) {
      const size = 150;
      const buffer = Buffer.alloc(size);
      let fd;
      try {
        fd = fs2.openSync(command, "r");
        fs2.readSync(fd, buffer, 0, size, 0);
        fs2.closeSync(fd);
      } catch (e) {
      }
      return shebangCommand(buffer.toString());
    }
    module.exports = readShebang;
  }
});

// ../../node_modules/.vlt/~npm~cross-spawn@7.0.6/node_modules/cross-spawn/lib/parse.js
var require_parse = __commonJS({
  "../../node_modules/.vlt/~npm~cross-spawn@7.0.6/node_modules/cross-spawn/lib/parse.js"(exports, module) {
    "use strict";
    var path2 = __require("node:path");
    var resolveCommand = require_resolveCommand();
    var escape = require_escape();
    var readShebang = require_readShebang();
    var isWin = process.platform === "win32";
    var isExecutableRegExp = /\.(?:com|exe)$/i;
    var isCmdShimRegExp = /node_modules[\\/].bin[\\/][^\\/]+\.cmd$/i;
    function detectShebang(parsed) {
      parsed.file = resolveCommand(parsed);
      const shebang = parsed.file && readShebang(parsed.file);
      if (shebang) {
        parsed.args.unshift(parsed.file);
        parsed.command = shebang;
        return resolveCommand(parsed);
      }
      return parsed.file;
    }
    function parseNonShell(parsed) {
      if (!isWin) {
        return parsed;
      }
      const commandFile = detectShebang(parsed);
      const needsShell = !isExecutableRegExp.test(commandFile);
      if (parsed.options.forceShell || needsShell) {
        const needsDoubleEscapeMetaChars = isCmdShimRegExp.test(commandFile);
        parsed.command = path2.normalize(parsed.command);
        parsed.command = escape.command(parsed.command);
        parsed.args = parsed.args.map((arg) => escape.argument(arg, needsDoubleEscapeMetaChars));
        const shellCommand = [parsed.command].concat(parsed.args).join(" ");
        parsed.args = ["/d", "/s", "/c", `"${shellCommand}"`];
        parsed.command = process.env.comspec || "cmd.exe";
        parsed.options.windowsVerbatimArguments = true;
      }
      return parsed;
    }
    function parse3(command, args, options) {
      if (args && !Array.isArray(args)) {
        options = args;
        args = null;
      }
      args = args ? args.slice(0) : [];
      options = Object.assign({}, options);
      const parsed = {
        command,
        args,
        options,
        file: void 0,
        original: {
          command,
          args
        }
      };
      return options.shell ? parsed : parseNonShell(parsed);
    }
    module.exports = parse3;
  }
});

// ../../node_modules/.vlt/~npm~cross-spawn@7.0.6/node_modules/cross-spawn/lib/enoent.js
var require_enoent = __commonJS({
  "../../node_modules/.vlt/~npm~cross-spawn@7.0.6/node_modules/cross-spawn/lib/enoent.js"(exports, module) {
    "use strict";
    var isWin = process.platform === "win32";
    function notFoundError(original, syscall) {
      return Object.assign(new Error(`${syscall} ${original.command} ENOENT`), {
        code: "ENOENT",
        errno: "ENOENT",
        syscall: `${syscall} ${original.command}`,
        path: original.command,
        spawnargs: original.args
      });
    }
    function hookChildProcess(cp, parsed) {
      if (!isWin) {
        return;
      }
      const originalEmit = cp.emit;
      cp.emit = function(name, arg1) {
        if (name === "exit") {
          const err = verifyENOENT(arg1, parsed);
          if (err) {
            return originalEmit.call(cp, "error", err);
          }
        }
        return originalEmit.apply(cp, arguments);
      };
    }
    function verifyENOENT(status, parsed) {
      if (isWin && status === 1 && !parsed.file) {
        return notFoundError(parsed.original, "spawn");
      }
      return null;
    }
    function verifyENOENTSync(status, parsed) {
      if (isWin && status === 1 && !parsed.file) {
        return notFoundError(parsed.original, "spawnSync");
      }
      return null;
    }
    module.exports = {
      hookChildProcess,
      verifyENOENT,
      verifyENOENTSync,
      notFoundError
    };
  }
});

// ../../node_modules/.vlt/~npm~cross-spawn@7.0.6/node_modules/cross-spawn/index.js
var require_cross_spawn = __commonJS({
  "../../node_modules/.vlt/~npm~cross-spawn@7.0.6/node_modules/cross-spawn/index.js"(exports, module) {
    "use strict";
    var cp = __require("node:child_process");
    var parse3 = require_parse();
    var enoent = require_enoent();
    function spawn4(command, args, options) {
      const parsed = parse3(command, args, options);
      const spawned = cp.spawn(parsed.command, parsed.args, parsed.options);
      enoent.hookChildProcess(spawned, parsed);
      return spawned;
    }
    function spawnSync(command, args, options) {
      const parsed = parse3(command, args, options);
      const result = cp.spawnSync(parsed.command, parsed.args, parsed.options);
      result.error = result.error || enoent.verifyENOENTSync(result.status, parsed);
      return result;
    }
    module.exports = spawn4;
    module.exports.spawn = spawn4;
    module.exports.sync = spawnSync;
    module.exports._parse = parse3;
    module.exports._enoent = enoent;
  }
});

// ../../node_modules/.vlt/~npm~postcss-selector-parser@7.1.1/node_modules/postcss-selector-parser/dist/util/unesc.js
var require_unesc = __commonJS({
  "../../node_modules/.vlt/~npm~postcss-selector-parser@7.1.1/node_modules/postcss-selector-parser/dist/util/unesc.js"(exports, module) {
    "use strict";
    exports.__esModule = true;
    exports["default"] = unesc;
    function gobbleHex(str) {
      var lower = str.toLowerCase();
      var hex = "";
      var spaceTerminated = false;
      for (var i = 0; i < 6 && lower[i] !== void 0; i++) {
        var code = lower.charCodeAt(i);
        var valid = code >= 97 && code <= 102 || code >= 48 && code <= 57;
        spaceTerminated = code === 32;
        if (!valid) {
          break;
        }
        hex += lower[i];
      }
      if (hex.length === 0) {
        return void 0;
      }
      var codePoint = parseInt(hex, 16);
      var isSurrogate = codePoint >= 55296 && codePoint <= 57343;
      if (isSurrogate || codePoint === 0 || codePoint > 1114111) {
        return ["\uFFFD", hex.length + (spaceTerminated ? 1 : 0)];
      }
      return [String.fromCodePoint(codePoint), hex.length + (spaceTerminated ? 1 : 0)];
    }
    var CONTAINS_ESCAPE = /\\/;
    function unesc(str) {
      var needToProcess = CONTAINS_ESCAPE.test(str);
      if (!needToProcess) {
        return str;
      }
      var ret = "";
      for (var i = 0; i < str.length; i++) {
        if (str[i] === "\\") {
          var gobbled = gobbleHex(str.slice(i + 1, i + 7));
          if (gobbled !== void 0) {
            ret += gobbled[0];
            i += gobbled[1];
            continue;
          }
          if (str[i + 1] === "\\") {
            ret += "\\";
            i++;
            continue;
          }
          if (str.length === i + 1) {
            ret += str[i];
          }
          continue;
        }
        ret += str[i];
      }
      return ret;
    }
    module.exports = exports.default;
  }
});

// ../../node_modules/.vlt/~npm~postcss-selector-parser@7.1.1/node_modules/postcss-selector-parser/dist/util/getProp.js
var require_getProp = __commonJS({
  "../../node_modules/.vlt/~npm~postcss-selector-parser@7.1.1/node_modules/postcss-selector-parser/dist/util/getProp.js"(exports, module) {
    "use strict";
    exports.__esModule = true;
    exports["default"] = getProp;
    function getProp(obj) {
      for (var _len = arguments.length, props = new Array(_len > 1 ? _len - 1 : 0), _key = 1; _key < _len; _key++) {
        props[_key - 1] = arguments[_key];
      }
      while (props.length > 0) {
        var prop = props.shift();
        if (!obj[prop]) {
          return void 0;
        }
        obj = obj[prop];
      }
      return obj;
    }
    module.exports = exports.default;
  }
});

// ../../node_modules/.vlt/~npm~postcss-selector-parser@7.1.1/node_modules/postcss-selector-parser/dist/util/ensureObject.js
var require_ensureObject = __commonJS({
  "../../node_modules/.vlt/~npm~postcss-selector-parser@7.1.1/node_modules/postcss-selector-parser/dist/util/ensureObject.js"(exports, module) {
    "use strict";
    exports.__esModule = true;
    exports["default"] = ensureObject;
    function ensureObject(obj) {
      for (var _len = arguments.length, props = new Array(_len > 1 ? _len - 1 : 0), _key = 1; _key < _len; _key++) {
        props[_key - 1] = arguments[_key];
      }
      while (props.length > 0) {
        var prop = props.shift();
        if (!obj[prop]) {
          obj[prop] = {};
        }
        obj = obj[prop];
      }
    }
    module.exports = exports.default;
  }
});

// ../../node_modules/.vlt/~npm~postcss-selector-parser@7.1.1/node_modules/postcss-selector-parser/dist/util/stripComments.js
var require_stripComments = __commonJS({
  "../../node_modules/.vlt/~npm~postcss-selector-parser@7.1.1/node_modules/postcss-selector-parser/dist/util/stripComments.js"(exports, module) {
    "use strict";
    exports.__esModule = true;
    exports["default"] = stripComments;
    function stripComments(str) {
      var s = "";
      var commentStart = str.indexOf("/*");
      var lastEnd = 0;
      while (commentStart >= 0) {
        s = s + str.slice(lastEnd, commentStart);
        var commentEnd = str.indexOf("*/", commentStart + 2);
        if (commentEnd < 0) {
          return s;
        }
        lastEnd = commentEnd + 2;
        commentStart = str.indexOf("/*", lastEnd);
      }
      s = s + str.slice(lastEnd);
      return s;
    }
    module.exports = exports.default;
  }
});

// ../../node_modules/.vlt/~npm~postcss-selector-parser@7.1.1/node_modules/postcss-selector-parser/dist/util/index.js
var require_util = __commonJS({
  "../../node_modules/.vlt/~npm~postcss-selector-parser@7.1.1/node_modules/postcss-selector-parser/dist/util/index.js"(exports) {
    "use strict";
    exports.__esModule = true;
    exports.unesc = exports.stripComments = exports.getProp = exports.ensureObject = void 0;
    var _unesc = _interopRequireDefault(require_unesc());
    exports.unesc = _unesc["default"];
    var _getProp = _interopRequireDefault(require_getProp());
    exports.getProp = _getProp["default"];
    var _ensureObject = _interopRequireDefault(require_ensureObject());
    exports.ensureObject = _ensureObject["default"];
    var _stripComments = _interopRequireDefault(require_stripComments());
    exports.stripComments = _stripComments["default"];
    function _interopRequireDefault(obj) {
      return obj && obj.__esModule ? obj : { "default": obj };
    }
  }
});

// ../../node_modules/.vlt/~npm~postcss-selector-parser@7.1.1/node_modules/postcss-selector-parser/dist/selectors/node.js
var require_node = __commonJS({
  "../../node_modules/.vlt/~npm~postcss-selector-parser@7.1.1/node_modules/postcss-selector-parser/dist/selectors/node.js"(exports, module) {
    "use strict";
    exports.__esModule = true;
    exports["default"] = void 0;
    var _util = require_util();
    function _defineProperties(target, props) {
      for (var i = 0; i < props.length; i++) {
        var descriptor = props[i];
        descriptor.enumerable = descriptor.enumerable || false;
        descriptor.configurable = true;
        if ("value" in descriptor) descriptor.writable = true;
        Object.defineProperty(target, descriptor.key, descriptor);
      }
    }
    function _createClass(Constructor, protoProps, staticProps) {
      if (protoProps) _defineProperties(Constructor.prototype, protoProps);
      if (staticProps) _defineProperties(Constructor, staticProps);
      Object.defineProperty(Constructor, "prototype", { writable: false });
      return Constructor;
    }
    var cloneNode = function cloneNode2(obj, parent) {
      if (typeof obj !== "object" || obj === null) {
        return obj;
      }
      var cloned = new obj.constructor();
      for (var i in obj) {
        if (!obj.hasOwnProperty(i)) {
          continue;
        }
        var value = obj[i];
        var type2 = typeof value;
        if (i === "parent" && type2 === "object") {
          if (parent) {
            cloned[i] = parent;
          }
        } else if (value instanceof Array) {
          cloned[i] = value.map(function(j) {
            return cloneNode2(j, cloned);
          });
        } else {
          cloned[i] = cloneNode2(value, cloned);
        }
      }
      return cloned;
    };
    var Node2 = /* @__PURE__ */ (function() {
      function Node3(opts) {
        if (opts === void 0) {
          opts = {};
        }
        Object.assign(this, opts);
        this.spaces = this.spaces || {};
        this.spaces.before = this.spaces.before || "";
        this.spaces.after = this.spaces.after || "";
      }
      var _proto = Node3.prototype;
      _proto.remove = function remove() {
        if (this.parent) {
          this.parent.removeChild(this);
        }
        this.parent = void 0;
        return this;
      };
      _proto.replaceWith = function replaceWith() {
        if (this.parent) {
          for (var index in arguments) {
            this.parent.insertBefore(this, arguments[index]);
          }
          this.remove();
        }
        return this;
      };
      _proto.next = function next() {
        return this.parent.at(this.parent.index(this) + 1);
      };
      _proto.prev = function prev() {
        return this.parent.at(this.parent.index(this) - 1);
      };
      _proto.clone = function clone(overrides) {
        if (overrides === void 0) {
          overrides = {};
        }
        var cloned = cloneNode(this);
        for (var name in overrides) {
          cloned[name] = overrides[name];
        }
        return cloned;
      };
      _proto.appendToPropertyAndEscape = function appendToPropertyAndEscape(name, value, valueEscaped) {
        if (!this.raws) {
          this.raws = {};
        }
        var originalValue = this[name];
        var originalEscaped = this.raws[name];
        this[name] = originalValue + value;
        if (originalEscaped || valueEscaped !== value) {
          this.raws[name] = (originalEscaped || originalValue) + valueEscaped;
        } else {
          delete this.raws[name];
        }
      };
      _proto.setPropertyAndEscape = function setPropertyAndEscape(name, value, valueEscaped) {
        if (!this.raws) {
          this.raws = {};
        }
        this[name] = value;
        this.raws[name] = valueEscaped;
      };
      _proto.setPropertyWithoutEscape = function setPropertyWithoutEscape(name, value) {
        this[name] = value;
        if (this.raws) {
          delete this.raws[name];
        }
      };
      _proto.isAtPosition = function isAtPosition(line, column) {
        if (this.source && this.source.start && this.source.end) {
          if (this.source.start.line > line) {
            return false;
          }
          if (this.source.end.line < line) {
            return false;
          }
          if (this.source.start.line === line && this.source.start.column > column) {
            return false;
          }
          if (this.source.end.line === line && this.source.end.column < column) {
            return false;
          }
          return true;
        }
        return void 0;
      };
      _proto.stringifyProperty = function stringifyProperty(name) {
        return this.raws && this.raws[name] || this[name];
      };
      _proto.valueToString = function valueToString() {
        return String(this.stringifyProperty("value"));
      };
      _proto.toString = function toString() {
        return [this.rawSpaceBefore, this.valueToString(), this.rawSpaceAfter].join("");
      };
      _createClass(Node3, [{
        key: "rawSpaceBefore",
        get: function get() {
          var rawSpace = this.raws && this.raws.spaces && this.raws.spaces.before;
          if (rawSpace === void 0) {
            rawSpace = this.spaces && this.spaces.before;
          }
          return rawSpace || "";
        },
        set: function set(raw) {
          (0, _util.ensureObject)(this, "raws", "spaces");
          this.raws.spaces.before = raw;
        }
      }, {
        key: "rawSpaceAfter",
        get: function get() {
          var rawSpace = this.raws && this.raws.spaces && this.raws.spaces.after;
          if (rawSpace === void 0) {
            rawSpace = this.spaces.after;
          }
          return rawSpace || "";
        },
        set: function set(raw) {
          (0, _util.ensureObject)(this, "raws", "spaces");
          this.raws.spaces.after = raw;
        }
      }]);
      return Node3;
    })();
    exports["default"] = Node2;
    module.exports = exports.default;
  }
});

// ../../node_modules/.vlt/~npm~postcss-selector-parser@7.1.1/node_modules/postcss-selector-parser/dist/selectors/types.js
var require_types = __commonJS({
  "../../node_modules/.vlt/~npm~postcss-selector-parser@7.1.1/node_modules/postcss-selector-parser/dist/selectors/types.js"(exports) {
    "use strict";
    exports.__esModule = true;
    exports.UNIVERSAL = exports.TAG = exports.STRING = exports.SELECTOR = exports.ROOT = exports.PSEUDO = exports.NESTING = exports.ID = exports.COMMENT = exports.COMBINATOR = exports.CLASS = exports.ATTRIBUTE = void 0;
    var TAG = "tag";
    exports.TAG = TAG;
    var STRING = "string";
    exports.STRING = STRING;
    var SELECTOR = "selector";
    exports.SELECTOR = SELECTOR;
    var ROOT = "root";
    exports.ROOT = ROOT;
    var PSEUDO = "pseudo";
    exports.PSEUDO = PSEUDO;
    var NESTING = "nesting";
    exports.NESTING = NESTING;
    var ID = "id";
    exports.ID = ID;
    var COMMENT = "comment";
    exports.COMMENT = COMMENT;
    var COMBINATOR = "combinator";
    exports.COMBINATOR = COMBINATOR;
    var CLASS = "class";
    exports.CLASS = CLASS;
    var ATTRIBUTE = "attribute";
    exports.ATTRIBUTE = ATTRIBUTE;
    var UNIVERSAL = "universal";
    exports.UNIVERSAL = UNIVERSAL;
  }
});

// ../../node_modules/.vlt/~npm~postcss-selector-parser@7.1.1/node_modules/postcss-selector-parser/dist/selectors/container.js
var require_container = __commonJS({
  "../../node_modules/.vlt/~npm~postcss-selector-parser@7.1.1/node_modules/postcss-selector-parser/dist/selectors/container.js"(exports, module) {
    "use strict";
    exports.__esModule = true;
    exports["default"] = void 0;
    var _node = _interopRequireDefault(require_node());
    var types = _interopRequireWildcard(require_types());
    function _getRequireWildcardCache(nodeInterop) {
      if (typeof WeakMap !== "function") return null;
      var cacheBabelInterop = /* @__PURE__ */ new WeakMap();
      var cacheNodeInterop = /* @__PURE__ */ new WeakMap();
      return (_getRequireWildcardCache = function _getRequireWildcardCache2(nodeInterop2) {
        return nodeInterop2 ? cacheNodeInterop : cacheBabelInterop;
      })(nodeInterop);
    }
    function _interopRequireWildcard(obj, nodeInterop) {
      if (!nodeInterop && obj && obj.__esModule) {
        return obj;
      }
      if (obj === null || typeof obj !== "object" && typeof obj !== "function") {
        return { "default": obj };
      }
      var cache = _getRequireWildcardCache(nodeInterop);
      if (cache && cache.has(obj)) {
        return cache.get(obj);
      }
      var newObj = {};
      var hasPropertyDescriptor = Object.defineProperty && Object.getOwnPropertyDescriptor;
      for (var key in obj) {
        if (key !== "default" && Object.prototype.hasOwnProperty.call(obj, key)) {
          var desc = hasPropertyDescriptor ? Object.getOwnPropertyDescriptor(obj, key) : null;
          if (desc && (desc.get || desc.set)) {
            Object.defineProperty(newObj, key, desc);
          } else {
            newObj[key] = obj[key];
          }
        }
      }
      newObj["default"] = obj;
      if (cache) {
        cache.set(obj, newObj);
      }
      return newObj;
    }
    function _interopRequireDefault(obj) {
      return obj && obj.__esModule ? obj : { "default": obj };
    }
    function _createForOfIteratorHelperLoose(o, allowArrayLike) {
      var it = typeof Symbol !== "undefined" && o[Symbol.iterator] || o["@@iterator"];
      if (it) return (it = it.call(o)).next.bind(it);
      if (Array.isArray(o) || (it = _unsupportedIterableToArray(o)) || allowArrayLike && o && typeof o.length === "number") {
        if (it) o = it;
        var i = 0;
        return function() {
          if (i >= o.length) return { done: true };
          return { done: false, value: o[i++] };
        };
      }
      throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
    }
    function _unsupportedIterableToArray(o, minLen) {
      if (!o) return;
      if (typeof o === "string") return _arrayLikeToArray(o, minLen);
      var n = Object.prototype.toString.call(o).slice(8, -1);
      if (n === "Object" && o.constructor) n = o.constructor.name;
      if (n === "Map" || n === "Set") return Array.from(o);
      if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen);
    }
    function _arrayLikeToArray(arr, len) {
      if (len == null || len > arr.length) len = arr.length;
      for (var i = 0, arr2 = new Array(len); i < len; i++) {
        arr2[i] = arr[i];
      }
      return arr2;
    }
    function _defineProperties(target, props) {
      for (var i = 0; i < props.length; i++) {
        var descriptor = props[i];
        descriptor.enumerable = descriptor.enumerable || false;
        descriptor.configurable = true;
        if ("value" in descriptor) descriptor.writable = true;
        Object.defineProperty(target, descriptor.key, descriptor);
      }
    }
    function _createClass(Constructor, protoProps, staticProps) {
      if (protoProps) _defineProperties(Constructor.prototype, protoProps);
      if (staticProps) _defineProperties(Constructor, staticProps);
      Object.defineProperty(Constructor, "prototype", { writable: false });
      return Constructor;
    }
    function _inheritsLoose(subClass, superClass) {
      subClass.prototype = Object.create(superClass.prototype);
      subClass.prototype.constructor = subClass;
      _setPrototypeOf(subClass, superClass);
    }
    function _setPrototypeOf(o, p) {
      _setPrototypeOf = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function _setPrototypeOf2(o2, p2) {
        o2.__proto__ = p2;
        return o2;
      };
      return _setPrototypeOf(o, p);
    }
    var Container = /* @__PURE__ */ (function(_Node) {
      _inheritsLoose(Container2, _Node);
      function Container2(opts) {
        var _this;
        _this = _Node.call(this, opts) || this;
        if (!_this.nodes) {
          _this.nodes = [];
        }
        return _this;
      }
      var _proto = Container2.prototype;
      _proto.append = function append(selector) {
        selector.parent = this;
        this.nodes.push(selector);
        return this;
      };
      _proto.prepend = function prepend(selector) {
        selector.parent = this;
        this.nodes.unshift(selector);
        for (var id2 in this.indexes) {
          this.indexes[id2]++;
        }
        return this;
      };
      _proto.at = function at(index) {
        return this.nodes[index];
      };
      _proto.index = function index(child) {
        if (typeof child === "number") {
          return child;
        }
        return this.nodes.indexOf(child);
      };
      _proto.removeChild = function removeChild(child) {
        child = this.index(child);
        this.at(child).parent = void 0;
        this.nodes.splice(child, 1);
        var index;
        for (var id2 in this.indexes) {
          index = this.indexes[id2];
          if (index >= child) {
            this.indexes[id2] = index - 1;
          }
        }
        return this;
      };
      _proto.removeAll = function removeAll() {
        for (var _iterator = _createForOfIteratorHelperLoose(this.nodes), _step; !(_step = _iterator()).done; ) {
          var node = _step.value;
          node.parent = void 0;
        }
        this.nodes = [];
        return this;
      };
      _proto.empty = function empty2() {
        return this.removeAll();
      };
      _proto.insertAfter = function insertAfter(oldNode, newNode) {
        var _this$nodes;
        newNode.parent = this;
        var oldIndex = this.index(oldNode);
        var resetNode = [];
        for (var i = 2; i < arguments.length; i++) {
          resetNode.push(arguments[i]);
        }
        (_this$nodes = this.nodes).splice.apply(_this$nodes, [oldIndex + 1, 0, newNode].concat(resetNode));
        newNode.parent = this;
        var index;
        for (var id2 in this.indexes) {
          index = this.indexes[id2];
          if (oldIndex < index) {
            this.indexes[id2] = index + arguments.length - 1;
          }
        }
        return this;
      };
      _proto.insertBefore = function insertBefore(oldNode, newNode) {
        var _this$nodes2;
        newNode.parent = this;
        var oldIndex = this.index(oldNode);
        var resetNode = [];
        for (var i = 2; i < arguments.length; i++) {
          resetNode.push(arguments[i]);
        }
        (_this$nodes2 = this.nodes).splice.apply(_this$nodes2, [oldIndex, 0, newNode].concat(resetNode));
        newNode.parent = this;
        var index;
        for (var id2 in this.indexes) {
          index = this.indexes[id2];
          if (index >= oldIndex) {
            this.indexes[id2] = index + arguments.length - 1;
          }
        }
        return this;
      };
      _proto._findChildAtPosition = function _findChildAtPosition(line, col) {
        var found = void 0;
        this.each(function(node) {
          if (node.atPosition) {
            var foundChild = node.atPosition(line, col);
            if (foundChild) {
              found = foundChild;
              return false;
            }
          } else if (node.isAtPosition(line, col)) {
            found = node;
            return false;
          }
        });
        return found;
      };
      _proto.atPosition = function atPosition(line, col) {
        if (this.isAtPosition(line, col)) {
          return this._findChildAtPosition(line, col) || this;
        } else {
          return void 0;
        }
      };
      _proto._inferEndPosition = function _inferEndPosition() {
        if (this.last && this.last.source && this.last.source.end) {
          this.source = this.source || {};
          this.source.end = this.source.end || {};
          Object.assign(this.source.end, this.last.source.end);
        }
      };
      _proto.each = function each(callback) {
        if (!this.lastEach) {
          this.lastEach = 0;
        }
        if (!this.indexes) {
          this.indexes = {};
        }
        this.lastEach++;
        var id2 = this.lastEach;
        this.indexes[id2] = 0;
        if (!this.length) {
          return void 0;
        }
        var index, result;
        while (this.indexes[id2] < this.length) {
          index = this.indexes[id2];
          result = callback(this.at(index), index);
          if (result === false) {
            break;
          }
          this.indexes[id2] += 1;
        }
        delete this.indexes[id2];
        if (result === false) {
          return false;
        }
      };
      _proto.walk = function walk2(callback) {
        return this.each(function(node, i) {
          var result = callback(node, i);
          if (result !== false && node.length) {
            result = node.walk(callback);
          }
          if (result === false) {
            return false;
          }
        });
      };
      _proto.walkAttributes = function walkAttributes(callback) {
        var _this2 = this;
        return this.walk(function(selector) {
          if (selector.type === types.ATTRIBUTE) {
            return callback.call(_this2, selector);
          }
        });
      };
      _proto.walkClasses = function walkClasses(callback) {
        var _this3 = this;
        return this.walk(function(selector) {
          if (selector.type === types.CLASS) {
            return callback.call(_this3, selector);
          }
        });
      };
      _proto.walkCombinators = function walkCombinators(callback) {
        var _this4 = this;
        return this.walk(function(selector) {
          if (selector.type === types.COMBINATOR) {
            return callback.call(_this4, selector);
          }
        });
      };
      _proto.walkComments = function walkComments(callback) {
        var _this5 = this;
        return this.walk(function(selector) {
          if (selector.type === types.COMMENT) {
            return callback.call(_this5, selector);
          }
        });
      };
      _proto.walkIds = function walkIds(callback) {
        var _this6 = this;
        return this.walk(function(selector) {
          if (selector.type === types.ID) {
            return callback.call(_this6, selector);
          }
        });
      };
      _proto.walkNesting = function walkNesting(callback) {
        var _this7 = this;
        return this.walk(function(selector) {
          if (selector.type === types.NESTING) {
            return callback.call(_this7, selector);
          }
        });
      };
      _proto.walkPseudos = function walkPseudos(callback) {
        var _this8 = this;
        return this.walk(function(selector) {
          if (selector.type === types.PSEUDO) {
            return callback.call(_this8, selector);
          }
        });
      };
      _proto.walkTags = function walkTags(callback) {
        var _this9 = this;
        return this.walk(function(selector) {
          if (selector.type === types.TAG) {
            return callback.call(_this9, selector);
          }
        });
      };
      _proto.walkUniversals = function walkUniversals(callback) {
        var _this10 = this;
        return this.walk(function(selector) {
          if (selector.type === types.UNIVERSAL) {
            return callback.call(_this10, selector);
          }
        });
      };
      _proto.split = function split(callback) {
        var _this11 = this;
        var current = [];
        return this.reduce(function(memo, node, index) {
          var split2 = callback.call(_this11, node);
          current.push(node);
          if (split2) {
            memo.push(current);
            current = [];
          } else if (index === _this11.length - 1) {
            memo.push(current);
          }
          return memo;
        }, []);
      };
      _proto.map = function map(callback) {
        return this.nodes.map(callback);
      };
      _proto.reduce = function reduce(callback, memo) {
        return this.nodes.reduce(callback, memo);
      };
      _proto.every = function every(callback) {
        return this.nodes.every(callback);
      };
      _proto.some = function some(callback) {
        return this.nodes.some(callback);
      };
      _proto.filter = function filter(callback) {
        return this.nodes.filter(callback);
      };
      _proto.sort = function sort(callback) {
        return this.nodes.sort(callback);
      };
      _proto.toString = function toString() {
        return this.map(String).join("");
      };
      _createClass(Container2, [{
        key: "first",
        get: function get() {
          return this.at(0);
        }
      }, {
        key: "last",
        get: function get() {
          return this.at(this.length - 1);
        }
      }, {
        key: "length",
        get: function get() {
          return this.nodes.length;
        }
      }]);
      return Container2;
    })(_node["default"]);
    exports["default"] = Container;
    module.exports = exports.default;
  }
});

// ../../node_modules/.vlt/~npm~postcss-selector-parser@7.1.1/node_modules/postcss-selector-parser/dist/selectors/root.js
var require_root = __commonJS({
  "../../node_modules/.vlt/~npm~postcss-selector-parser@7.1.1/node_modules/postcss-selector-parser/dist/selectors/root.js"(exports, module) {
    "use strict";
    exports.__esModule = true;
    exports["default"] = void 0;
    var _container = _interopRequireDefault(require_container());
    var _types = require_types();
    function _interopRequireDefault(obj) {
      return obj && obj.__esModule ? obj : { "default": obj };
    }
    function _defineProperties(target, props) {
      for (var i = 0; i < props.length; i++) {
        var descriptor = props[i];
        descriptor.enumerable = descriptor.enumerable || false;
        descriptor.configurable = true;
        if ("value" in descriptor) descriptor.writable = true;
        Object.defineProperty(target, descriptor.key, descriptor);
      }
    }
    function _createClass(Constructor, protoProps, staticProps) {
      if (protoProps) _defineProperties(Constructor.prototype, protoProps);
      if (staticProps) _defineProperties(Constructor, staticProps);
      Object.defineProperty(Constructor, "prototype", { writable: false });
      return Constructor;
    }
    function _inheritsLoose(subClass, superClass) {
      subClass.prototype = Object.create(superClass.prototype);
      subClass.prototype.constructor = subClass;
      _setPrototypeOf(subClass, superClass);
    }
    function _setPrototypeOf(o, p) {
      _setPrototypeOf = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function _setPrototypeOf2(o2, p2) {
        o2.__proto__ = p2;
        return o2;
      };
      return _setPrototypeOf(o, p);
    }
    var Root = /* @__PURE__ */ (function(_Container) {
      _inheritsLoose(Root2, _Container);
      function Root2(opts) {
        var _this;
        _this = _Container.call(this, opts) || this;
        _this.type = _types.ROOT;
        return _this;
      }
      var _proto = Root2.prototype;
      _proto.toString = function toString() {
        var str = this.reduce(function(memo, selector) {
          memo.push(String(selector));
          return memo;
        }, []).join(",");
        return this.trailingComma ? str + "," : str;
      };
      _proto.error = function error2(message, options) {
        if (this._error) {
          return this._error(message, options);
        } else {
          return new Error(message);
        }
      };
      _createClass(Root2, [{
        key: "errorGenerator",
        set: function set(handler) {
          this._error = handler;
        }
      }]);
      return Root2;
    })(_container["default"]);
    exports["default"] = Root;
    module.exports = exports.default;
  }
});

// ../../node_modules/.vlt/~npm~postcss-selector-parser@7.1.1/node_modules/postcss-selector-parser/dist/selectors/selector.js
var require_selector = __commonJS({
  "../../node_modules/.vlt/~npm~postcss-selector-parser@7.1.1/node_modules/postcss-selector-parser/dist/selectors/selector.js"(exports, module) {
    "use strict";
    exports.__esModule = true;
    exports["default"] = void 0;
    var _container = _interopRequireDefault(require_container());
    var _types = require_types();
    function _interopRequireDefault(obj) {
      return obj && obj.__esModule ? obj : { "default": obj };
    }
    function _inheritsLoose(subClass, superClass) {
      subClass.prototype = Object.create(superClass.prototype);
      subClass.prototype.constructor = subClass;
      _setPrototypeOf(subClass, superClass);
    }
    function _setPrototypeOf(o, p) {
      _setPrototypeOf = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function _setPrototypeOf2(o2, p2) {
        o2.__proto__ = p2;
        return o2;
      };
      return _setPrototypeOf(o, p);
    }
    var Selector = /* @__PURE__ */ (function(_Container) {
      _inheritsLoose(Selector2, _Container);
      function Selector2(opts) {
        var _this;
        _this = _Container.call(this, opts) || this;
        _this.type = _types.SELECTOR;
        return _this;
      }
      return Selector2;
    })(_container["default"]);
    exports["default"] = Selector;
    module.exports = exports.default;
  }
});

// ../../node_modules/.vlt/~npm~cssesc@3.0.0/node_modules/cssesc/cssesc.js
var require_cssesc = __commonJS({
  "../../node_modules/.vlt/~npm~cssesc@3.0.0/node_modules/cssesc/cssesc.js"(exports, module) {
    "use strict";
    var object = {};
    var hasOwnProperty = object.hasOwnProperty;
    var merge = function merge2(options, defaults) {
      if (!options) {
        return defaults;
      }
      var result = {};
      for (var key in defaults) {
        result[key] = hasOwnProperty.call(options, key) ? options[key] : defaults[key];
      }
      return result;
    };
    var regexAnySingleEscape = /[ -,\.\/:-@\[-\^`\{-~]/;
    var regexSingleEscape = /[ -,\.\/:-@\[\]\^`\{-~]/;
    var regexExcessiveSpaces = /(^|\\+)?(\\[A-F0-9]{1,6})\x20(?![a-fA-F0-9\x20])/g;
    var cssesc = function cssesc2(string, options) {
      options = merge(options, cssesc2.options);
      if (options.quotes != "single" && options.quotes != "double") {
        options.quotes = "single";
      }
      var quote = options.quotes == "double" ? '"' : "'";
      var isIdentifier = options.isIdentifier;
      var firstChar = string.charAt(0);
      var output = "";
      var counter = 0;
      var length = string.length;
      while (counter < length) {
        var character = string.charAt(counter++);
        var codePoint = character.charCodeAt();
        var value = void 0;
        if (codePoint < 32 || codePoint > 126) {
          if (codePoint >= 55296 && codePoint <= 56319 && counter < length) {
            var extra = string.charCodeAt(counter++);
            if ((extra & 64512) == 56320) {
              codePoint = ((codePoint & 1023) << 10) + (extra & 1023) + 65536;
            } else {
              counter--;
            }
          }
          value = "\\" + codePoint.toString(16).toUpperCase() + " ";
        } else {
          if (options.escapeEverything) {
            if (regexAnySingleEscape.test(character)) {
              value = "\\" + character;
            } else {
              value = "\\" + codePoint.toString(16).toUpperCase() + " ";
            }
          } else if (/[\t\n\f\r\x0B]/.test(character)) {
            value = "\\" + codePoint.toString(16).toUpperCase() + " ";
          } else if (character == "\\" || !isIdentifier && (character == '"' && quote == character || character == "'" && quote == character) || isIdentifier && regexSingleEscape.test(character)) {
            value = "\\" + character;
          } else {
            value = character;
          }
        }
        output += value;
      }
      if (isIdentifier) {
        if (/^-[-\d]/.test(output)) {
          output = "\\-" + output.slice(1);
        } else if (/\d/.test(firstChar)) {
          output = "\\3" + firstChar + " " + output.slice(1);
        }
      }
      output = output.replace(regexExcessiveSpaces, function($0, $1, $2) {
        if ($1 && $1.length % 2) {
          return $0;
        }
        return ($1 || "") + $2;
      });
      if (!isIdentifier && options.wrap) {
        return quote + output + quote;
      }
      return output;
    };
    cssesc.options = {
      "escapeEverything": false,
      "isIdentifier": false,
      "quotes": "single",
      "wrap": false
    };
    cssesc.version = "3.0.0";
    module.exports = cssesc;
  }
});

// ../../node_modules/.vlt/~npm~postcss-selector-parser@7.1.1/node_modules/postcss-selector-parser/dist/selectors/className.js
var require_className = __commonJS({
  "../../node_modules/.vlt/~npm~postcss-selector-parser@7.1.1/node_modules/postcss-selector-parser/dist/selectors/className.js"(exports, module) {
    "use strict";
    exports.__esModule = true;
    exports["default"] = void 0;
    var _cssesc = _interopRequireDefault(require_cssesc());
    var _util = require_util();
    var _node = _interopRequireDefault(require_node());
    var _types = require_types();
    function _interopRequireDefault(obj) {
      return obj && obj.__esModule ? obj : { "default": obj };
    }
    function _defineProperties(target, props) {
      for (var i = 0; i < props.length; i++) {
        var descriptor = props[i];
        descriptor.enumerable = descriptor.enumerable || false;
        descriptor.configurable = true;
        if ("value" in descriptor) descriptor.writable = true;
        Object.defineProperty(target, descriptor.key, descriptor);
      }
    }
    function _createClass(Constructor, protoProps, staticProps) {
      if (protoProps) _defineProperties(Constructor.prototype, protoProps);
      if (staticProps) _defineProperties(Constructor, staticProps);
      Object.defineProperty(Constructor, "prototype", { writable: false });
      return Constructor;
    }
    function _inheritsLoose(subClass, superClass) {
      subClass.prototype = Object.create(superClass.prototype);
      subClass.prototype.constructor = subClass;
      _setPrototypeOf(subClass, superClass);
    }
    function _setPrototypeOf(o, p) {
      _setPrototypeOf = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function _setPrototypeOf2(o2, p2) {
        o2.__proto__ = p2;
        return o2;
      };
      return _setPrototypeOf(o, p);
    }
    var ClassName = /* @__PURE__ */ (function(_Node) {
      _inheritsLoose(ClassName2, _Node);
      function ClassName2(opts) {
        var _this;
        _this = _Node.call(this, opts) || this;
        _this.type = _types.CLASS;
        _this._constructed = true;
        return _this;
      }
      var _proto = ClassName2.prototype;
      _proto.valueToString = function valueToString() {
        return "." + _Node.prototype.valueToString.call(this);
      };
      _createClass(ClassName2, [{
        key: "value",
        get: function get() {
          return this._value;
        },
        set: function set(v) {
          if (this._constructed) {
            var escaped = (0, _cssesc["default"])(v, {
              isIdentifier: true
            });
            if (escaped !== v) {
              (0, _util.ensureObject)(this, "raws");
              this.raws.value = escaped;
            } else if (this.raws) {
              delete this.raws.value;
            }
          }
          this._value = v;
        }
      }]);
      return ClassName2;
    })(_node["default"]);
    exports["default"] = ClassName;
    module.exports = exports.default;
  }
});

// ../../node_modules/.vlt/~npm~postcss-selector-parser@7.1.1/node_modules/postcss-selector-parser/dist/selectors/comment.js
var require_comment = __commonJS({
  "../../node_modules/.vlt/~npm~postcss-selector-parser@7.1.1/node_modules/postcss-selector-parser/dist/selectors/comment.js"(exports, module) {
    "use strict";
    exports.__esModule = true;
    exports["default"] = void 0;
    var _node = _interopRequireDefault(require_node());
    var _types = require_types();
    function _interopRequireDefault(obj) {
      return obj && obj.__esModule ? obj : { "default": obj };
    }
    function _inheritsLoose(subClass, superClass) {
      subClass.prototype = Object.create(superClass.prototype);
      subClass.prototype.constructor = subClass;
      _setPrototypeOf(subClass, superClass);
    }
    function _setPrototypeOf(o, p) {
      _setPrototypeOf = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function _setPrototypeOf2(o2, p2) {
        o2.__proto__ = p2;
        return o2;
      };
      return _setPrototypeOf(o, p);
    }
    var Comment = /* @__PURE__ */ (function(_Node) {
      _inheritsLoose(Comment2, _Node);
      function Comment2(opts) {
        var _this;
        _this = _Node.call(this, opts) || this;
        _this.type = _types.COMMENT;
        return _this;
      }
      return Comment2;
    })(_node["default"]);
    exports["default"] = Comment;
    module.exports = exports.default;
  }
});

// ../../node_modules/.vlt/~npm~postcss-selector-parser@7.1.1/node_modules/postcss-selector-parser/dist/selectors/id.js
var require_id = __commonJS({
  "../../node_modules/.vlt/~npm~postcss-selector-parser@7.1.1/node_modules/postcss-selector-parser/dist/selectors/id.js"(exports, module) {
    "use strict";
    exports.__esModule = true;
    exports["default"] = void 0;
    var _node = _interopRequireDefault(require_node());
    var _types = require_types();
    function _interopRequireDefault(obj) {
      return obj && obj.__esModule ? obj : { "default": obj };
    }
    function _inheritsLoose(subClass, superClass) {
      subClass.prototype = Object.create(superClass.prototype);
      subClass.prototype.constructor = subClass;
      _setPrototypeOf(subClass, superClass);
    }
    function _setPrototypeOf(o, p) {
      _setPrototypeOf = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function _setPrototypeOf2(o2, p2) {
        o2.__proto__ = p2;
        return o2;
      };
      return _setPrototypeOf(o, p);
    }
    var ID = /* @__PURE__ */ (function(_Node) {
      _inheritsLoose(ID2, _Node);
      function ID2(opts) {
        var _this;
        _this = _Node.call(this, opts) || this;
        _this.type = _types.ID;
        return _this;
      }
      var _proto = ID2.prototype;
      _proto.valueToString = function valueToString() {
        return "#" + _Node.prototype.valueToString.call(this);
      };
      return ID2;
    })(_node["default"]);
    exports["default"] = ID;
    module.exports = exports.default;
  }
});

// ../../node_modules/.vlt/~npm~postcss-selector-parser@7.1.1/node_modules/postcss-selector-parser/dist/selectors/namespace.js
var require_namespace = __commonJS({
  "../../node_modules/.vlt/~npm~postcss-selector-parser@7.1.1/node_modules/postcss-selector-parser/dist/selectors/namespace.js"(exports, module) {
    "use strict";
    exports.__esModule = true;
    exports["default"] = void 0;
    var _cssesc = _interopRequireDefault(require_cssesc());
    var _util = require_util();
    var _node = _interopRequireDefault(require_node());
    function _interopRequireDefault(obj) {
      return obj && obj.__esModule ? obj : { "default": obj };
    }
    function _defineProperties(target, props) {
      for (var i = 0; i < props.length; i++) {
        var descriptor = props[i];
        descriptor.enumerable = descriptor.enumerable || false;
        descriptor.configurable = true;
        if ("value" in descriptor) descriptor.writable = true;
        Object.defineProperty(target, descriptor.key, descriptor);
      }
    }
    function _createClass(Constructor, protoProps, staticProps) {
      if (protoProps) _defineProperties(Constructor.prototype, protoProps);
      if (staticProps) _defineProperties(Constructor, staticProps);
      Object.defineProperty(Constructor, "prototype", { writable: false });
      return Constructor;
    }
    function _inheritsLoose(subClass, superClass) {
      subClass.prototype = Object.create(superClass.prototype);
      subClass.prototype.constructor = subClass;
      _setPrototypeOf(subClass, superClass);
    }
    function _setPrototypeOf(o, p) {
      _setPrototypeOf = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function _setPrototypeOf2(o2, p2) {
        o2.__proto__ = p2;
        return o2;
      };
      return _setPrototypeOf(o, p);
    }
    var Namespace = /* @__PURE__ */ (function(_Node) {
      _inheritsLoose(Namespace2, _Node);
      function Namespace2() {
        return _Node.apply(this, arguments) || this;
      }
      var _proto = Namespace2.prototype;
      _proto.qualifiedName = function qualifiedName(value) {
        if (this.namespace) {
          return this.namespaceString + "|" + value;
        } else {
          return value;
        }
      };
      _proto.valueToString = function valueToString() {
        return this.qualifiedName(_Node.prototype.valueToString.call(this));
      };
      _createClass(Namespace2, [{
        key: "namespace",
        get: function get() {
          return this._namespace;
        },
        set: function set(namespace) {
          if (namespace === true || namespace === "*" || namespace === "&") {
            this._namespace = namespace;
            if (this.raws) {
              delete this.raws.namespace;
            }
            return;
          }
          var escaped = (0, _cssesc["default"])(namespace, {
            isIdentifier: true
          });
          this._namespace = namespace;
          if (escaped !== namespace) {
            (0, _util.ensureObject)(this, "raws");
            this.raws.namespace = escaped;
          } else if (this.raws) {
            delete this.raws.namespace;
          }
        }
      }, {
        key: "ns",
        get: function get() {
          return this._namespace;
        },
        set: function set(namespace) {
          this.namespace = namespace;
        }
      }, {
        key: "namespaceString",
        get: function get() {
          if (this.namespace) {
            var ns = this.stringifyProperty("namespace");
            if (ns === true) {
              return "";
            } else {
              return ns;
            }
          } else {
            return "";
          }
        }
      }]);
      return Namespace2;
    })(_node["default"]);
    exports["default"] = Namespace;
    module.exports = exports.default;
  }
});

// ../../node_modules/.vlt/~npm~postcss-selector-parser@7.1.1/node_modules/postcss-selector-parser/dist/selectors/tag.js
var require_tag = __commonJS({
  "../../node_modules/.vlt/~npm~postcss-selector-parser@7.1.1/node_modules/postcss-selector-parser/dist/selectors/tag.js"(exports, module) {
    "use strict";
    exports.__esModule = true;
    exports["default"] = void 0;
    var _namespace = _interopRequireDefault(require_namespace());
    var _types = require_types();
    function _interopRequireDefault(obj) {
      return obj && obj.__esModule ? obj : { "default": obj };
    }
    function _inheritsLoose(subClass, superClass) {
      subClass.prototype = Object.create(superClass.prototype);
      subClass.prototype.constructor = subClass;
      _setPrototypeOf(subClass, superClass);
    }
    function _setPrototypeOf(o, p) {
      _setPrototypeOf = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function _setPrototypeOf2(o2, p2) {
        o2.__proto__ = p2;
        return o2;
      };
      return _setPrototypeOf(o, p);
    }
    var Tag = /* @__PURE__ */ (function(_Namespace) {
      _inheritsLoose(Tag2, _Namespace);
      function Tag2(opts) {
        var _this;
        _this = _Namespace.call(this, opts) || this;
        _this.type = _types.TAG;
        return _this;
      }
      return Tag2;
    })(_namespace["default"]);
    exports["default"] = Tag;
    module.exports = exports.default;
  }
});

// ../../node_modules/.vlt/~npm~postcss-selector-parser@7.1.1/node_modules/postcss-selector-parser/dist/selectors/string.js
var require_string = __commonJS({
  "../../node_modules/.vlt/~npm~postcss-selector-parser@7.1.1/node_modules/postcss-selector-parser/dist/selectors/string.js"(exports, module) {
    "use strict";
    exports.__esModule = true;
    exports["default"] = void 0;
    var _node = _interopRequireDefault(require_node());
    var _types = require_types();
    function _interopRequireDefault(obj) {
      return obj && obj.__esModule ? obj : { "default": obj };
    }
    function _inheritsLoose(subClass, superClass) {
      subClass.prototype = Object.create(superClass.prototype);
      subClass.prototype.constructor = subClass;
      _setPrototypeOf(subClass, superClass);
    }
    function _setPrototypeOf(o, p) {
      _setPrototypeOf = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function _setPrototypeOf2(o2, p2) {
        o2.__proto__ = p2;
        return o2;
      };
      return _setPrototypeOf(o, p);
    }
    var String2 = /* @__PURE__ */ (function(_Node) {
      _inheritsLoose(String3, _Node);
      function String3(opts) {
        var _this;
        _this = _Node.call(this, opts) || this;
        _this.type = _types.STRING;
        return _this;
      }
      return String3;
    })(_node["default"]);
    exports["default"] = String2;
    module.exports = exports.default;
  }
});

// ../../node_modules/.vlt/~npm~postcss-selector-parser@7.1.1/node_modules/postcss-selector-parser/dist/selectors/pseudo.js
var require_pseudo = __commonJS({
  "../../node_modules/.vlt/~npm~postcss-selector-parser@7.1.1/node_modules/postcss-selector-parser/dist/selectors/pseudo.js"(exports, module) {
    "use strict";
    exports.__esModule = true;
    exports["default"] = void 0;
    var _container = _interopRequireDefault(require_container());
    var _types = require_types();
    function _interopRequireDefault(obj) {
      return obj && obj.__esModule ? obj : { "default": obj };
    }
    function _inheritsLoose(subClass, superClass) {
      subClass.prototype = Object.create(superClass.prototype);
      subClass.prototype.constructor = subClass;
      _setPrototypeOf(subClass, superClass);
    }
    function _setPrototypeOf(o, p) {
      _setPrototypeOf = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function _setPrototypeOf2(o2, p2) {
        o2.__proto__ = p2;
        return o2;
      };
      return _setPrototypeOf(o, p);
    }
    var Pseudo = /* @__PURE__ */ (function(_Container) {
      _inheritsLoose(Pseudo2, _Container);
      function Pseudo2(opts) {
        var _this;
        _this = _Container.call(this, opts) || this;
        _this.type = _types.PSEUDO;
        return _this;
      }
      var _proto = Pseudo2.prototype;
      _proto.toString = function toString() {
        var params = this.length ? "(" + this.map(String).join(",") + ")" : "";
        return [this.rawSpaceBefore, this.stringifyProperty("value"), params, this.rawSpaceAfter].join("");
      };
      return Pseudo2;
    })(_container["default"]);
    exports["default"] = Pseudo;
    module.exports = exports.default;
  }
});

// ../../node_modules/.vlt/~npm~util-deprecate@1.0.2/node_modules/util-deprecate/node.js
var require_node2 = __commonJS({
  "../../node_modules/.vlt/~npm~util-deprecate@1.0.2/node_modules/util-deprecate/node.js"(exports, module) {
    module.exports = __require("node:util").deprecate;
  }
});

// ../../node_modules/.vlt/~npm~postcss-selector-parser@7.1.1/node_modules/postcss-selector-parser/dist/selectors/attribute.js
var require_attribute = __commonJS({
  "../../node_modules/.vlt/~npm~postcss-selector-parser@7.1.1/node_modules/postcss-selector-parser/dist/selectors/attribute.js"(exports) {
    "use strict";
    exports.__esModule = true;
    exports["default"] = void 0;
    exports.unescapeValue = unescapeValue;
    var _cssesc = _interopRequireDefault(require_cssesc());
    var _unesc = _interopRequireDefault(require_unesc());
    var _namespace = _interopRequireDefault(require_namespace());
    var _types = require_types();
    var _CSSESC_QUOTE_OPTIONS;
    function _interopRequireDefault(obj) {
      return obj && obj.__esModule ? obj : { "default": obj };
    }
    function _defineProperties(target, props) {
      for (var i = 0; i < props.length; i++) {
        var descriptor = props[i];
        descriptor.enumerable = descriptor.enumerable || false;
        descriptor.configurable = true;
        if ("value" in descriptor) descriptor.writable = true;
        Object.defineProperty(target, descriptor.key, descriptor);
      }
    }
    function _createClass(Constructor, protoProps, staticProps) {
      if (protoProps) _defineProperties(Constructor.prototype, protoProps);
      if (staticProps) _defineProperties(Constructor, staticProps);
      Object.defineProperty(Constructor, "prototype", { writable: false });
      return Constructor;
    }
    function _inheritsLoose(subClass, superClass) {
      subClass.prototype = Object.create(superClass.prototype);
      subClass.prototype.constructor = subClass;
      _setPrototypeOf(subClass, superClass);
    }
    function _setPrototypeOf(o, p) {
      _setPrototypeOf = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function _setPrototypeOf2(o2, p2) {
        o2.__proto__ = p2;
        return o2;
      };
      return _setPrototypeOf(o, p);
    }
    var deprecate = require_node2();
    var WRAPPED_IN_QUOTES = /^('|")([^]*)\1$/;
    var warnOfDeprecatedValueAssignment = deprecate(function() {
    }, "Assigning an attribute a value containing characters that might need to be escaped is deprecated. Call attribute.setValue() instead.");
    var warnOfDeprecatedQuotedAssignment = deprecate(function() {
    }, "Assigning attr.quoted is deprecated and has no effect. Assign to attr.quoteMark instead.");
    var warnOfDeprecatedConstructor = deprecate(function() {
    }, "Constructing an Attribute selector with a value without specifying quoteMark is deprecated. Note: The value should be unescaped now.");
    function unescapeValue(value) {
      var deprecatedUsage = false;
      var quoteMark = null;
      var unescaped = value;
      var m = unescaped.match(WRAPPED_IN_QUOTES);
      if (m) {
        quoteMark = m[1];
        unescaped = m[2];
      }
      unescaped = (0, _unesc["default"])(unescaped);
      if (unescaped !== value) {
        deprecatedUsage = true;
      }
      return {
        deprecatedUsage,
        unescaped,
        quoteMark
      };
    }
    function handleDeprecatedContructorOpts(opts) {
      if (opts.quoteMark !== void 0) {
        return opts;
      }
      if (opts.value === void 0) {
        return opts;
      }
      warnOfDeprecatedConstructor();
      var _unescapeValue = unescapeValue(opts.value), quoteMark = _unescapeValue.quoteMark, unescaped = _unescapeValue.unescaped;
      if (!opts.raws) {
        opts.raws = {};
      }
      if (opts.raws.value === void 0) {
        opts.raws.value = opts.value;
      }
      opts.value = unescaped;
      opts.quoteMark = quoteMark;
      return opts;
    }
    var Attribute = /* @__PURE__ */ (function(_Namespace) {
      _inheritsLoose(Attribute2, _Namespace);
      function Attribute2(opts) {
        var _this;
        if (opts === void 0) {
          opts = {};
        }
        _this = _Namespace.call(this, handleDeprecatedContructorOpts(opts)) || this;
        _this.type = _types.ATTRIBUTE;
        _this.raws = _this.raws || {};
        Object.defineProperty(_this.raws, "unquoted", {
          get: deprecate(function() {
            return _this.value;
          }, "attr.raws.unquoted is deprecated. Call attr.value instead."),
          set: deprecate(function() {
            return _this.value;
          }, "Setting attr.raws.unquoted is deprecated and has no effect. attr.value is unescaped by default now.")
        });
        _this._constructed = true;
        return _this;
      }
      var _proto = Attribute2.prototype;
      _proto.getQuotedValue = function getQuotedValue(options) {
        if (options === void 0) {
          options = {};
        }
        var quoteMark = this._determineQuoteMark(options);
        var cssescopts = CSSESC_QUOTE_OPTIONS[quoteMark];
        var escaped = (0, _cssesc["default"])(this._value, cssescopts);
        return escaped;
      };
      _proto._determineQuoteMark = function _determineQuoteMark(options) {
        return options.smart ? this.smartQuoteMark(options) : this.preferredQuoteMark(options);
      };
      _proto.setValue = function setValue(value, options) {
        if (options === void 0) {
          options = {};
        }
        this._value = value;
        this._quoteMark = this._determineQuoteMark(options);
        this._syncRawValue();
      };
      _proto.smartQuoteMark = function smartQuoteMark(options) {
        var v = this.value;
        var numSingleQuotes = v.replace(/[^']/g, "").length;
        var numDoubleQuotes = v.replace(/[^"]/g, "").length;
        if (numSingleQuotes + numDoubleQuotes === 0) {
          var escaped = (0, _cssesc["default"])(v, {
            isIdentifier: true
          });
          if (escaped === v) {
            return Attribute2.NO_QUOTE;
          } else {
            var pref = this.preferredQuoteMark(options);
            if (pref === Attribute2.NO_QUOTE) {
              var quote = this.quoteMark || options.quoteMark || Attribute2.DOUBLE_QUOTE;
              var opts = CSSESC_QUOTE_OPTIONS[quote];
              var quoteValue = (0, _cssesc["default"])(v, opts);
              if (quoteValue.length < escaped.length) {
                return quote;
              }
            }
            return pref;
          }
        } else if (numDoubleQuotes === numSingleQuotes) {
          return this.preferredQuoteMark(options);
        } else if (numDoubleQuotes < numSingleQuotes) {
          return Attribute2.DOUBLE_QUOTE;
        } else {
          return Attribute2.SINGLE_QUOTE;
        }
      };
      _proto.preferredQuoteMark = function preferredQuoteMark(options) {
        var quoteMark = options.preferCurrentQuoteMark ? this.quoteMark : options.quoteMark;
        if (quoteMark === void 0) {
          quoteMark = options.preferCurrentQuoteMark ? options.quoteMark : this.quoteMark;
        }
        if (quoteMark === void 0) {
          quoteMark = Attribute2.DOUBLE_QUOTE;
        }
        return quoteMark;
      };
      _proto._syncRawValue = function _syncRawValue() {
        var rawValue = (0, _cssesc["default"])(this._value, CSSESC_QUOTE_OPTIONS[this.quoteMark]);
        if (rawValue === this._value) {
          if (this.raws) {
            delete this.raws.value;
          }
        } else {
          this.raws.value = rawValue;
        }
      };
      _proto._handleEscapes = function _handleEscapes(prop, value) {
        if (this._constructed) {
          var escaped = (0, _cssesc["default"])(value, {
            isIdentifier: true
          });
          if (escaped !== value) {
            this.raws[prop] = escaped;
          } else {
            delete this.raws[prop];
          }
        }
      };
      _proto._spacesFor = function _spacesFor(name) {
        var attrSpaces = {
          before: "",
          after: ""
        };
        var spaces = this.spaces[name] || {};
        var rawSpaces = this.raws.spaces && this.raws.spaces[name] || {};
        return Object.assign(attrSpaces, spaces, rawSpaces);
      };
      _proto._stringFor = function _stringFor(name, spaceName, concat) {
        if (spaceName === void 0) {
          spaceName = name;
        }
        if (concat === void 0) {
          concat = defaultAttrConcat;
        }
        var attrSpaces = this._spacesFor(spaceName);
        return concat(this.stringifyProperty(name), attrSpaces);
      };
      _proto.offsetOf = function offsetOf(name) {
        var count = 1;
        var attributeSpaces = this._spacesFor("attribute");
        count += attributeSpaces.before.length;
        if (name === "namespace" || name === "ns") {
          return this.namespace ? count : -1;
        }
        if (name === "attributeNS") {
          return count;
        }
        count += this.namespaceString.length;
        if (this.namespace) {
          count += 1;
        }
        if (name === "attribute") {
          return count;
        }
        count += this.stringifyProperty("attribute").length;
        count += attributeSpaces.after.length;
        var operatorSpaces = this._spacesFor("operator");
        count += operatorSpaces.before.length;
        var operator = this.stringifyProperty("operator");
        if (name === "operator") {
          return operator ? count : -1;
        }
        count += operator.length;
        count += operatorSpaces.after.length;
        var valueSpaces = this._spacesFor("value");
        count += valueSpaces.before.length;
        var value = this.stringifyProperty("value");
        if (name === "value") {
          return value ? count : -1;
        }
        count += value.length;
        count += valueSpaces.after.length;
        var insensitiveSpaces = this._spacesFor("insensitive");
        count += insensitiveSpaces.before.length;
        if (name === "insensitive") {
          return this.insensitive ? count : -1;
        }
        return -1;
      };
      _proto.toString = function toString() {
        var _this2 = this;
        var selector = [this.rawSpaceBefore, "["];
        selector.push(this._stringFor("qualifiedAttribute", "attribute"));
        if (this.operator && (this.value || this.value === "")) {
          selector.push(this._stringFor("operator"));
          selector.push(this._stringFor("value"));
          selector.push(this._stringFor("insensitiveFlag", "insensitive", function(attrValue, attrSpaces) {
            if (attrValue.length > 0 && !_this2.quoted && attrSpaces.before.length === 0 && !(_this2.spaces.value && _this2.spaces.value.after)) {
              attrSpaces.before = " ";
            }
            return defaultAttrConcat(attrValue, attrSpaces);
          }));
        }
        selector.push("]");
        selector.push(this.rawSpaceAfter);
        return selector.join("");
      };
      _createClass(Attribute2, [{
        key: "quoted",
        get: function get() {
          var qm = this.quoteMark;
          return qm === "'" || qm === '"';
        },
        set: function set(value) {
          warnOfDeprecatedQuotedAssignment();
        }
        /**
         * returns a single (`'`) or double (`"`) quote character if the value is quoted.
         * returns `null` if the value is not quoted.
         * returns `undefined` if the quotation state is unknown (this can happen when
         * the attribute is constructed without specifying a quote mark.)
         */
      }, {
        key: "quoteMark",
        get: function get() {
          return this._quoteMark;
        },
        set: function set(quoteMark) {
          if (!this._constructed) {
            this._quoteMark = quoteMark;
            return;
          }
          if (this._quoteMark !== quoteMark) {
            this._quoteMark = quoteMark;
            this._syncRawValue();
          }
        }
      }, {
        key: "qualifiedAttribute",
        get: function get() {
          return this.qualifiedName(this.raws.attribute || this.attribute);
        }
      }, {
        key: "insensitiveFlag",
        get: function get() {
          return this.insensitive ? "i" : "";
        }
      }, {
        key: "value",
        get: function get() {
          return this._value;
        },
        set: (
          /**
           * Before 3.0, the value had to be set to an escaped value including any wrapped
           * quote marks. In 3.0, the semantics of `Attribute.value` changed so that the value
           * is unescaped during parsing and any quote marks are removed.
           *
           * Because the ambiguity of this semantic change, if you set `attr.value = newValue`,
           * a deprecation warning is raised when the new value contains any characters that would
           * require escaping (including if it contains wrapped quotes).
           *
           * Instead, you should call `attr.setValue(newValue, opts)` and pass options that describe
           * how the new value is quoted.
           */
          function set(v) {
            if (this._constructed) {
              var _unescapeValue2 = unescapeValue(v), deprecatedUsage = _unescapeValue2.deprecatedUsage, unescaped = _unescapeValue2.unescaped, quoteMark = _unescapeValue2.quoteMark;
              if (deprecatedUsage) {
                warnOfDeprecatedValueAssignment();
              }
              if (unescaped === this._value && quoteMark === this._quoteMark) {
                return;
              }
              this._value = unescaped;
              this._quoteMark = quoteMark;
              this._syncRawValue();
            } else {
              this._value = v;
            }
          }
        )
      }, {
        key: "insensitive",
        get: function get() {
          return this._insensitive;
        },
        set: function set(insensitive) {
          if (!insensitive) {
            this._insensitive = false;
            if (this.raws && (this.raws.insensitiveFlag === "I" || this.raws.insensitiveFlag === "i")) {
              this.raws.insensitiveFlag = void 0;
            }
          }
          this._insensitive = insensitive;
        }
      }, {
        key: "attribute",
        get: function get() {
          return this._attribute;
        },
        set: function set(name) {
          this._handleEscapes("attribute", name);
          this._attribute = name;
        }
      }]);
      return Attribute2;
    })(_namespace["default"]);
    exports["default"] = Attribute;
    Attribute.NO_QUOTE = null;
    Attribute.SINGLE_QUOTE = "'";
    Attribute.DOUBLE_QUOTE = '"';
    var CSSESC_QUOTE_OPTIONS = (_CSSESC_QUOTE_OPTIONS = {
      "'": {
        quotes: "single",
        wrap: true
      },
      '"': {
        quotes: "double",
        wrap: true
      }
    }, _CSSESC_QUOTE_OPTIONS[null] = {
      isIdentifier: true
    }, _CSSESC_QUOTE_OPTIONS);
    function defaultAttrConcat(attrValue, attrSpaces) {
      return "" + attrSpaces.before + attrValue + attrSpaces.after;
    }
  }
});

// ../../node_modules/.vlt/~npm~postcss-selector-parser@7.1.1/node_modules/postcss-selector-parser/dist/selectors/universal.js
var require_universal = __commonJS({
  "../../node_modules/.vlt/~npm~postcss-selector-parser@7.1.1/node_modules/postcss-selector-parser/dist/selectors/universal.js"(exports, module) {
    "use strict";
    exports.__esModule = true;
    exports["default"] = void 0;
    var _namespace = _interopRequireDefault(require_namespace());
    var _types = require_types();
    function _interopRequireDefault(obj) {
      return obj && obj.__esModule ? obj : { "default": obj };
    }
    function _inheritsLoose(subClass, superClass) {
      subClass.prototype = Object.create(superClass.prototype);
      subClass.prototype.constructor = subClass;
      _setPrototypeOf(subClass, superClass);
    }
    function _setPrototypeOf(o, p) {
      _setPrototypeOf = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function _setPrototypeOf2(o2, p2) {
        o2.__proto__ = p2;
        return o2;
      };
      return _setPrototypeOf(o, p);
    }
    var Universal = /* @__PURE__ */ (function(_Namespace) {
      _inheritsLoose(Universal2, _Namespace);
      function Universal2(opts) {
        var _this;
        _this = _Namespace.call(this, opts) || this;
        _this.type = _types.UNIVERSAL;
        _this.value = "*";
        return _this;
      }
      return Universal2;
    })(_namespace["default"]);
    exports["default"] = Universal;
    module.exports = exports.default;
  }
});

// ../../node_modules/.vlt/~npm~postcss-selector-parser@7.1.1/node_modules/postcss-selector-parser/dist/selectors/combinator.js
var require_combinator = __commonJS({
  "../../node_modules/.vlt/~npm~postcss-selector-parser@7.1.1/node_modules/postcss-selector-parser/dist/selectors/combinator.js"(exports, module) {
    "use strict";
    exports.__esModule = true;
    exports["default"] = void 0;
    var _node = _interopRequireDefault(require_node());
    var _types = require_types();
    function _interopRequireDefault(obj) {
      return obj && obj.__esModule ? obj : { "default": obj };
    }
    function _inheritsLoose(subClass, superClass) {
      subClass.prototype = Object.create(superClass.prototype);
      subClass.prototype.constructor = subClass;
      _setPrototypeOf(subClass, superClass);
    }
    function _setPrototypeOf(o, p) {
      _setPrototypeOf = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function _setPrototypeOf2(o2, p2) {
        o2.__proto__ = p2;
        return o2;
      };
      return _setPrototypeOf(o, p);
    }
    var Combinator = /* @__PURE__ */ (function(_Node) {
      _inheritsLoose(Combinator2, _Node);
      function Combinator2(opts) {
        var _this;
        _this = _Node.call(this, opts) || this;
        _this.type = _types.COMBINATOR;
        return _this;
      }
      return Combinator2;
    })(_node["default"]);
    exports["default"] = Combinator;
    module.exports = exports.default;
  }
});

// ../../node_modules/.vlt/~npm~postcss-selector-parser@7.1.1/node_modules/postcss-selector-parser/dist/selectors/nesting.js
var require_nesting = __commonJS({
  "../../node_modules/.vlt/~npm~postcss-selector-parser@7.1.1/node_modules/postcss-selector-parser/dist/selectors/nesting.js"(exports, module) {
    "use strict";
    exports.__esModule = true;
    exports["default"] = void 0;
    var _node = _interopRequireDefault(require_node());
    var _types = require_types();
    function _interopRequireDefault(obj) {
      return obj && obj.__esModule ? obj : { "default": obj };
    }
    function _inheritsLoose(subClass, superClass) {
      subClass.prototype = Object.create(superClass.prototype);
      subClass.prototype.constructor = subClass;
      _setPrototypeOf(subClass, superClass);
    }
    function _setPrototypeOf(o, p) {
      _setPrototypeOf = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function _setPrototypeOf2(o2, p2) {
        o2.__proto__ = p2;
        return o2;
      };
      return _setPrototypeOf(o, p);
    }
    var Nesting = /* @__PURE__ */ (function(_Node) {
      _inheritsLoose(Nesting2, _Node);
      function Nesting2(opts) {
        var _this;
        _this = _Node.call(this, opts) || this;
        _this.type = _types.NESTING;
        _this.value = "&";
        return _this;
      }
      return Nesting2;
    })(_node["default"]);
    exports["default"] = Nesting;
    module.exports = exports.default;
  }
});

// ../../node_modules/.vlt/~npm~postcss-selector-parser@7.1.1/node_modules/postcss-selector-parser/dist/sortAscending.js
var require_sortAscending = __commonJS({
  "../../node_modules/.vlt/~npm~postcss-selector-parser@7.1.1/node_modules/postcss-selector-parser/dist/sortAscending.js"(exports, module) {
    "use strict";
    exports.__esModule = true;
    exports["default"] = sortAscending;
    function sortAscending(list) {
      return list.sort(function(a, b) {
        return a - b;
      });
    }
    module.exports = exports.default;
  }
});

// ../../node_modules/.vlt/~npm~postcss-selector-parser@7.1.1/node_modules/postcss-selector-parser/dist/tokenTypes.js
var require_tokenTypes = __commonJS({
  "../../node_modules/.vlt/~npm~postcss-selector-parser@7.1.1/node_modules/postcss-selector-parser/dist/tokenTypes.js"(exports) {
    "use strict";
    exports.__esModule = true;
    exports.word = exports.tilde = exports.tab = exports.str = exports.space = exports.slash = exports.singleQuote = exports.semicolon = exports.plus = exports.pipe = exports.openSquare = exports.openParenthesis = exports.newline = exports.greaterThan = exports.feed = exports.equals = exports.doubleQuote = exports.dollar = exports.cr = exports.comment = exports.comma = exports.combinator = exports.colon = exports.closeSquare = exports.closeParenthesis = exports.caret = exports.bang = exports.backslash = exports.at = exports.asterisk = exports.ampersand = void 0;
    var ampersand = 38;
    exports.ampersand = ampersand;
    var asterisk = 42;
    exports.asterisk = asterisk;
    var at = 64;
    exports.at = at;
    var comma = 44;
    exports.comma = comma;
    var colon = 58;
    exports.colon = colon;
    var semicolon = 59;
    exports.semicolon = semicolon;
    var openParenthesis = 40;
    exports.openParenthesis = openParenthesis;
    var closeParenthesis = 41;
    exports.closeParenthesis = closeParenthesis;
    var openSquare = 91;
    exports.openSquare = openSquare;
    var closeSquare = 93;
    exports.closeSquare = closeSquare;
    var dollar = 36;
    exports.dollar = dollar;
    var tilde = 126;
    exports.tilde = tilde;
    var caret = 94;
    exports.caret = caret;
    var plus = 43;
    exports.plus = plus;
    var equals = 61;
    exports.equals = equals;
    var pipe = 124;
    exports.pipe = pipe;
    var greaterThan = 62;
    exports.greaterThan = greaterThan;
    var space = 32;
    exports.space = space;
    var singleQuote = 39;
    exports.singleQuote = singleQuote;
    var doubleQuote = 34;
    exports.doubleQuote = doubleQuote;
    var slash = 47;
    exports.slash = slash;
    var bang = 33;
    exports.bang = bang;
    var backslash = 92;
    exports.backslash = backslash;
    var cr = 13;
    exports.cr = cr;
    var feed = 12;
    exports.feed = feed;
    var newline = 10;
    exports.newline = newline;
    var tab = 9;
    exports.tab = tab;
    var str = singleQuote;
    exports.str = str;
    var comment = -1;
    exports.comment = comment;
    var word = -2;
    exports.word = word;
    var combinator2 = -3;
    exports.combinator = combinator2;
  }
});

// ../../node_modules/.vlt/~npm~postcss-selector-parser@7.1.1/node_modules/postcss-selector-parser/dist/tokenize.js
var require_tokenize = __commonJS({
  "../../node_modules/.vlt/~npm~postcss-selector-parser@7.1.1/node_modules/postcss-selector-parser/dist/tokenize.js"(exports) {
    "use strict";
    exports.__esModule = true;
    exports.FIELDS = void 0;
    exports["default"] = tokenize;
    var t = _interopRequireWildcard(require_tokenTypes());
    var _unescapable;
    var _wordDelimiters;
    function _getRequireWildcardCache(nodeInterop) {
      if (typeof WeakMap !== "function") return null;
      var cacheBabelInterop = /* @__PURE__ */ new WeakMap();
      var cacheNodeInterop = /* @__PURE__ */ new WeakMap();
      return (_getRequireWildcardCache = function _getRequireWildcardCache2(nodeInterop2) {
        return nodeInterop2 ? cacheNodeInterop : cacheBabelInterop;
      })(nodeInterop);
    }
    function _interopRequireWildcard(obj, nodeInterop) {
      if (!nodeInterop && obj && obj.__esModule) {
        return obj;
      }
      if (obj === null || typeof obj !== "object" && typeof obj !== "function") {
        return { "default": obj };
      }
      var cache = _getRequireWildcardCache(nodeInterop);
      if (cache && cache.has(obj)) {
        return cache.get(obj);
      }
      var newObj = {};
      var hasPropertyDescriptor = Object.defineProperty && Object.getOwnPropertyDescriptor;
      for (var key in obj) {
        if (key !== "default" && Object.prototype.hasOwnProperty.call(obj, key)) {
          var desc = hasPropertyDescriptor ? Object.getOwnPropertyDescriptor(obj, key) : null;
          if (desc && (desc.get || desc.set)) {
            Object.defineProperty(newObj, key, desc);
          } else {
            newObj[key] = obj[key];
          }
        }
      }
      newObj["default"] = obj;
      if (cache) {
        cache.set(obj, newObj);
      }
      return newObj;
    }
    var unescapable = (_unescapable = {}, _unescapable[t.tab] = true, _unescapable[t.newline] = true, _unescapable[t.cr] = true, _unescapable[t.feed] = true, _unescapable);
    var wordDelimiters = (_wordDelimiters = {}, _wordDelimiters[t.space] = true, _wordDelimiters[t.tab] = true, _wordDelimiters[t.newline] = true, _wordDelimiters[t.cr] = true, _wordDelimiters[t.feed] = true, _wordDelimiters[t.ampersand] = true, _wordDelimiters[t.asterisk] = true, _wordDelimiters[t.bang] = true, _wordDelimiters[t.comma] = true, _wordDelimiters[t.colon] = true, _wordDelimiters[t.semicolon] = true, _wordDelimiters[t.openParenthesis] = true, _wordDelimiters[t.closeParenthesis] = true, _wordDelimiters[t.openSquare] = true, _wordDelimiters[t.closeSquare] = true, _wordDelimiters[t.singleQuote] = true, _wordDelimiters[t.doubleQuote] = true, _wordDelimiters[t.plus] = true, _wordDelimiters[t.pipe] = true, _wordDelimiters[t.tilde] = true, _wordDelimiters[t.greaterThan] = true, _wordDelimiters[t.equals] = true, _wordDelimiters[t.dollar] = true, _wordDelimiters[t.caret] = true, _wordDelimiters[t.slash] = true, _wordDelimiters);
    var hex = {};
    var hexChars = "0123456789abcdefABCDEF";
    for (i = 0; i < hexChars.length; i++) {
      hex[hexChars.charCodeAt(i)] = true;
    }
    var i;
    function consumeWord(css, start) {
      var next = start;
      var code;
      do {
        code = css.charCodeAt(next);
        if (wordDelimiters[code]) {
          return next - 1;
        } else if (code === t.backslash) {
          next = consumeEscape(css, next) + 1;
        } else {
          next++;
        }
      } while (next < css.length);
      return next - 1;
    }
    function consumeEscape(css, start) {
      var next = start;
      var code = css.charCodeAt(next + 1);
      if (unescapable[code]) {
      } else if (hex[code]) {
        var hexDigits = 0;
        do {
          next++;
          hexDigits++;
          code = css.charCodeAt(next + 1);
        } while (hex[code] && hexDigits < 6);
        if (hexDigits < 6 && code === t.space) {
          next++;
        }
      } else {
        next++;
      }
      return next;
    }
    var FIELDS = {
      TYPE: 0,
      START_LINE: 1,
      START_COL: 2,
      END_LINE: 3,
      END_COL: 4,
      START_POS: 5,
      END_POS: 6
    };
    exports.FIELDS = FIELDS;
    function tokenize(input) {
      var tokens = [];
      var css = input.css.valueOf();
      var _css = css, length = _css.length;
      var offset = -1;
      var line = 1;
      var start = 0;
      var end = 0;
      var code, content, endColumn, endLine, escaped, escapePos, last, lines, next, nextLine, nextOffset, quote, tokenType;
      function unclosed(what, fix) {
        if (input.safe) {
          css += fix;
          next = css.length - 1;
        } else {
          throw input.error("Unclosed " + what, line, start - offset, start);
        }
      }
      while (start < length) {
        code = css.charCodeAt(start);
        if (code === t.newline) {
          offset = start;
          line += 1;
        }
        switch (code) {
          case t.space:
          case t.tab:
          case t.newline:
          case t.cr:
          case t.feed:
            next = start;
            do {
              next += 1;
              code = css.charCodeAt(next);
              if (code === t.newline) {
                offset = next;
                line += 1;
              }
            } while (code === t.space || code === t.newline || code === t.tab || code === t.cr || code === t.feed);
            tokenType = t.space;
            endLine = line;
            endColumn = next - offset - 1;
            end = next;
            break;
          case t.plus:
          case t.greaterThan:
          case t.tilde:
          case t.pipe:
            next = start;
            do {
              next += 1;
              code = css.charCodeAt(next);
            } while (code === t.plus || code === t.greaterThan || code === t.tilde || code === t.pipe);
            tokenType = t.combinator;
            endLine = line;
            endColumn = start - offset;
            end = next;
            break;
          // Consume these characters as single tokens.
          case t.asterisk:
          case t.ampersand:
          case t.bang:
          case t.comma:
          case t.equals:
          case t.dollar:
          case t.caret:
          case t.openSquare:
          case t.closeSquare:
          case t.colon:
          case t.semicolon:
          case t.openParenthesis:
          case t.closeParenthesis:
            next = start;
            tokenType = code;
            endLine = line;
            endColumn = start - offset;
            end = next + 1;
            break;
          case t.singleQuote:
          case t.doubleQuote:
            quote = code === t.singleQuote ? "'" : '"';
            next = start;
            do {
              escaped = false;
              next = css.indexOf(quote, next + 1);
              if (next === -1) {
                unclosed("quote", quote);
              }
              escapePos = next;
              while (css.charCodeAt(escapePos - 1) === t.backslash) {
                escapePos -= 1;
                escaped = !escaped;
              }
            } while (escaped);
            tokenType = t.str;
            endLine = line;
            endColumn = start - offset;
            end = next + 1;
            break;
          default:
            if (code === t.slash && css.charCodeAt(start + 1) === t.asterisk) {
              next = css.indexOf("*/", start + 2) + 1;
              if (next === 0) {
                unclosed("comment", "*/");
              }
              content = css.slice(start, next + 1);
              lines = content.split("\n");
              last = lines.length - 1;
              if (last > 0) {
                nextLine = line + last;
                nextOffset = next - lines[last].length;
              } else {
                nextLine = line;
                nextOffset = offset;
              }
              tokenType = t.comment;
              line = nextLine;
              endLine = nextLine;
              endColumn = next - nextOffset;
            } else if (code === t.slash) {
              next = start;
              tokenType = code;
              endLine = line;
              endColumn = start - offset;
              end = next + 1;
            } else {
              next = consumeWord(css, start);
              tokenType = t.word;
              endLine = line;
              endColumn = next - offset;
            }
            end = next + 1;
            break;
        }
        tokens.push([
          tokenType,
          // [0] Token type
          line,
          // [1] Starting line
          start - offset,
          // [2] Starting column
          endLine,
          // [3] Ending line
          endColumn,
          // [4] Ending column
          start,
          // [5] Start position / Source index
          end
          // [6] End position
        ]);
        if (nextOffset) {
          offset = nextOffset;
          nextOffset = null;
        }
        start = end;
      }
      return tokens;
    }
  }
});

// ../../node_modules/.vlt/~npm~postcss-selector-parser@7.1.1/node_modules/postcss-selector-parser/dist/parser.js
var require_parser = __commonJS({
  "../../node_modules/.vlt/~npm~postcss-selector-parser@7.1.1/node_modules/postcss-selector-parser/dist/parser.js"(exports, module) {
    "use strict";
    exports.__esModule = true;
    exports["default"] = void 0;
    var _root = _interopRequireDefault(require_root());
    var _selector = _interopRequireDefault(require_selector());
    var _className = _interopRequireDefault(require_className());
    var _comment = _interopRequireDefault(require_comment());
    var _id = _interopRequireDefault(require_id());
    var _tag = _interopRequireDefault(require_tag());
    var _string = _interopRequireDefault(require_string());
    var _pseudo = _interopRequireDefault(require_pseudo());
    var _attribute = _interopRequireWildcard(require_attribute());
    var _universal = _interopRequireDefault(require_universal());
    var _combinator = _interopRequireDefault(require_combinator());
    var _nesting = _interopRequireDefault(require_nesting());
    var _sortAscending = _interopRequireDefault(require_sortAscending());
    var _tokenize = _interopRequireWildcard(require_tokenize());
    var tokens = _interopRequireWildcard(require_tokenTypes());
    var types = _interopRequireWildcard(require_types());
    var _util = require_util();
    var _WHITESPACE_TOKENS;
    var _Object$assign;
    function _getRequireWildcardCache(nodeInterop) {
      if (typeof WeakMap !== "function") return null;
      var cacheBabelInterop = /* @__PURE__ */ new WeakMap();
      var cacheNodeInterop = /* @__PURE__ */ new WeakMap();
      return (_getRequireWildcardCache = function _getRequireWildcardCache2(nodeInterop2) {
        return nodeInterop2 ? cacheNodeInterop : cacheBabelInterop;
      })(nodeInterop);
    }
    function _interopRequireWildcard(obj, nodeInterop) {
      if (!nodeInterop && obj && obj.__esModule) {
        return obj;
      }
      if (obj === null || typeof obj !== "object" && typeof obj !== "function") {
        return { "default": obj };
      }
      var cache = _getRequireWildcardCache(nodeInterop);
      if (cache && cache.has(obj)) {
        return cache.get(obj);
      }
      var newObj = {};
      var hasPropertyDescriptor = Object.defineProperty && Object.getOwnPropertyDescriptor;
      for (var key in obj) {
        if (key !== "default" && Object.prototype.hasOwnProperty.call(obj, key)) {
          var desc = hasPropertyDescriptor ? Object.getOwnPropertyDescriptor(obj, key) : null;
          if (desc && (desc.get || desc.set)) {
            Object.defineProperty(newObj, key, desc);
          } else {
            newObj[key] = obj[key];
          }
        }
      }
      newObj["default"] = obj;
      if (cache) {
        cache.set(obj, newObj);
      }
      return newObj;
    }
    function _interopRequireDefault(obj) {
      return obj && obj.__esModule ? obj : { "default": obj };
    }
    function _defineProperties(target, props) {
      for (var i = 0; i < props.length; i++) {
        var descriptor = props[i];
        descriptor.enumerable = descriptor.enumerable || false;
        descriptor.configurable = true;
        if ("value" in descriptor) descriptor.writable = true;
        Object.defineProperty(target, descriptor.key, descriptor);
      }
    }
    function _createClass(Constructor, protoProps, staticProps) {
      if (protoProps) _defineProperties(Constructor.prototype, protoProps);
      if (staticProps) _defineProperties(Constructor, staticProps);
      Object.defineProperty(Constructor, "prototype", { writable: false });
      return Constructor;
    }
    var WHITESPACE_TOKENS = (_WHITESPACE_TOKENS = {}, _WHITESPACE_TOKENS[tokens.space] = true, _WHITESPACE_TOKENS[tokens.cr] = true, _WHITESPACE_TOKENS[tokens.feed] = true, _WHITESPACE_TOKENS[tokens.newline] = true, _WHITESPACE_TOKENS[tokens.tab] = true, _WHITESPACE_TOKENS);
    var WHITESPACE_EQUIV_TOKENS = Object.assign({}, WHITESPACE_TOKENS, (_Object$assign = {}, _Object$assign[tokens.comment] = true, _Object$assign));
    function tokenStart(token) {
      return {
        line: token[_tokenize.FIELDS.START_LINE],
        column: token[_tokenize.FIELDS.START_COL]
      };
    }
    function tokenEnd(token) {
      return {
        line: token[_tokenize.FIELDS.END_LINE],
        column: token[_tokenize.FIELDS.END_COL]
      };
    }
    function getSource(startLine, startColumn, endLine, endColumn) {
      return {
        start: {
          line: startLine,
          column: startColumn
        },
        end: {
          line: endLine,
          column: endColumn
        }
      };
    }
    function getTokenSource(token) {
      return getSource(token[_tokenize.FIELDS.START_LINE], token[_tokenize.FIELDS.START_COL], token[_tokenize.FIELDS.END_LINE], token[_tokenize.FIELDS.END_COL]);
    }
    function getTokenSourceSpan(startToken, endToken) {
      if (!startToken) {
        return void 0;
      }
      return getSource(startToken[_tokenize.FIELDS.START_LINE], startToken[_tokenize.FIELDS.START_COL], endToken[_tokenize.FIELDS.END_LINE], endToken[_tokenize.FIELDS.END_COL]);
    }
    function unescapeProp(node, prop) {
      var value = node[prop];
      if (typeof value !== "string") {
        return;
      }
      if (value.indexOf("\\") !== -1) {
        (0, _util.ensureObject)(node, "raws");
        node[prop] = (0, _util.unesc)(value);
        if (node.raws[prop] === void 0) {
          node.raws[prop] = value;
        }
      }
      return node;
    }
    function indexesOf(array, item) {
      var i = -1;
      var indexes = [];
      while ((i = array.indexOf(item, i + 1)) !== -1) {
        indexes.push(i);
      }
      return indexes;
    }
    function uniqs() {
      var list = Array.prototype.concat.apply([], arguments);
      return list.filter(function(item, i) {
        return i === list.indexOf(item);
      });
    }
    var Parser = /* @__PURE__ */ (function() {
      function Parser2(rule, options) {
        if (options === void 0) {
          options = {};
        }
        this.rule = rule;
        this.options = Object.assign({
          lossy: false,
          safe: false
        }, options);
        this.position = 0;
        this.css = typeof this.rule === "string" ? this.rule : this.rule.selector;
        this.tokens = (0, _tokenize["default"])({
          css: this.css,
          error: this._errorGenerator(),
          safe: this.options.safe
        });
        var rootSource = getTokenSourceSpan(this.tokens[0], this.tokens[this.tokens.length - 1]);
        this.root = new _root["default"]({
          source: rootSource
        });
        this.root.errorGenerator = this._errorGenerator();
        var selector = new _selector["default"]({
          source: {
            start: {
              line: 1,
              column: 1
            }
          },
          sourceIndex: 0
        });
        this.root.append(selector);
        this.current = selector;
        this.loop();
      }
      var _proto = Parser2.prototype;
      _proto._errorGenerator = function _errorGenerator() {
        var _this = this;
        return function(message, errorOptions) {
          if (typeof _this.rule === "string") {
            return new Error(message);
          }
          return _this.rule.error(message, errorOptions);
        };
      };
      _proto.attribute = function attribute2() {
        var attr2 = [];
        var startingToken = this.currToken;
        this.position++;
        while (this.position < this.tokens.length && this.currToken[_tokenize.FIELDS.TYPE] !== tokens.closeSquare) {
          attr2.push(this.currToken);
          this.position++;
        }
        if (this.currToken[_tokenize.FIELDS.TYPE] !== tokens.closeSquare) {
          return this.expected("closing square bracket", this.currToken[_tokenize.FIELDS.START_POS]);
        }
        var len = attr2.length;
        var node = {
          source: getSource(startingToken[1], startingToken[2], this.currToken[3], this.currToken[4]),
          sourceIndex: startingToken[_tokenize.FIELDS.START_POS]
        };
        if (len === 1 && !~[tokens.word].indexOf(attr2[0][_tokenize.FIELDS.TYPE])) {
          return this.expected("attribute", attr2[0][_tokenize.FIELDS.START_POS]);
        }
        var pos = 0;
        var spaceBefore = "";
        var commentBefore = "";
        var lastAdded = null;
        var spaceAfterMeaningfulToken = false;
        while (pos < len) {
          var token = attr2[pos];
          var content = this.content(token);
          var next = attr2[pos + 1];
          switch (token[_tokenize.FIELDS.TYPE]) {
            case tokens.space:
              spaceAfterMeaningfulToken = true;
              if (this.options.lossy) {
                break;
              }
              if (lastAdded) {
                (0, _util.ensureObject)(node, "spaces", lastAdded);
                var prevContent = node.spaces[lastAdded].after || "";
                node.spaces[lastAdded].after = prevContent + content;
                var existingComment = (0, _util.getProp)(node, "raws", "spaces", lastAdded, "after") || null;
                if (existingComment) {
                  node.raws.spaces[lastAdded].after = existingComment + content;
                }
              } else {
                spaceBefore = spaceBefore + content;
                commentBefore = commentBefore + content;
              }
              break;
            case tokens.asterisk:
              if (next[_tokenize.FIELDS.TYPE] === tokens.equals) {
                node.operator = content;
                lastAdded = "operator";
              } else if ((!node.namespace || lastAdded === "namespace" && !spaceAfterMeaningfulToken) && next) {
                if (spaceBefore) {
                  (0, _util.ensureObject)(node, "spaces", "attribute");
                  node.spaces.attribute.before = spaceBefore;
                  spaceBefore = "";
                }
                if (commentBefore) {
                  (0, _util.ensureObject)(node, "raws", "spaces", "attribute");
                  node.raws.spaces.attribute.before = spaceBefore;
                  commentBefore = "";
                }
                node.namespace = (node.namespace || "") + content;
                var rawValue = (0, _util.getProp)(node, "raws", "namespace") || null;
                if (rawValue) {
                  node.raws.namespace += content;
                }
                lastAdded = "namespace";
              }
              spaceAfterMeaningfulToken = false;
              break;
            case tokens.dollar:
              if (lastAdded === "value") {
                var oldRawValue = (0, _util.getProp)(node, "raws", "value");
                node.value += "$";
                if (oldRawValue) {
                  node.raws.value = oldRawValue + "$";
                }
                break;
              }
            // Falls through
            case tokens.caret:
              if (next[_tokenize.FIELDS.TYPE] === tokens.equals) {
                node.operator = content;
                lastAdded = "operator";
              }
              spaceAfterMeaningfulToken = false;
              break;
            case tokens.combinator:
              if (content === "~" && next[_tokenize.FIELDS.TYPE] === tokens.equals) {
                node.operator = content;
                lastAdded = "operator";
              }
              if (content !== "|") {
                spaceAfterMeaningfulToken = false;
                break;
              }
              if (next[_tokenize.FIELDS.TYPE] === tokens.equals) {
                node.operator = content;
                lastAdded = "operator";
              } else if (!node.namespace && !node.attribute) {
                node.namespace = true;
              }
              spaceAfterMeaningfulToken = false;
              break;
            case tokens.word:
              if (next && this.content(next) === "|" && attr2[pos + 2] && attr2[pos + 2][_tokenize.FIELDS.TYPE] !== tokens.equals && // this look-ahead probably fails with comment nodes involved.
              !node.operator && !node.namespace) {
                node.namespace = content;
                lastAdded = "namespace";
              } else if (!node.attribute || lastAdded === "attribute" && !spaceAfterMeaningfulToken) {
                if (spaceBefore) {
                  (0, _util.ensureObject)(node, "spaces", "attribute");
                  node.spaces.attribute.before = spaceBefore;
                  spaceBefore = "";
                }
                if (commentBefore) {
                  (0, _util.ensureObject)(node, "raws", "spaces", "attribute");
                  node.raws.spaces.attribute.before = commentBefore;
                  commentBefore = "";
                }
                node.attribute = (node.attribute || "") + content;
                var _rawValue = (0, _util.getProp)(node, "raws", "attribute") || null;
                if (_rawValue) {
                  node.raws.attribute += content;
                }
                lastAdded = "attribute";
              } else if (!node.value && node.value !== "" || lastAdded === "value" && !(spaceAfterMeaningfulToken || node.quoteMark)) {
                var _unescaped = (0, _util.unesc)(content);
                var _oldRawValue = (0, _util.getProp)(node, "raws", "value") || "";
                var oldValue = node.value || "";
                node.value = oldValue + _unescaped;
                node.quoteMark = null;
                if (_unescaped !== content || _oldRawValue) {
                  (0, _util.ensureObject)(node, "raws");
                  node.raws.value = (_oldRawValue || oldValue) + content;
                }
                lastAdded = "value";
              } else {
                var insensitive = content === "i" || content === "I";
                if ((node.value || node.value === "") && (node.quoteMark || spaceAfterMeaningfulToken)) {
                  node.insensitive = insensitive;
                  if (!insensitive || content === "I") {
                    (0, _util.ensureObject)(node, "raws");
                    node.raws.insensitiveFlag = content;
                  }
                  lastAdded = "insensitive";
                  if (spaceBefore) {
                    (0, _util.ensureObject)(node, "spaces", "insensitive");
                    node.spaces.insensitive.before = spaceBefore;
                    spaceBefore = "";
                  }
                  if (commentBefore) {
                    (0, _util.ensureObject)(node, "raws", "spaces", "insensitive");
                    node.raws.spaces.insensitive.before = commentBefore;
                    commentBefore = "";
                  }
                } else if (node.value || node.value === "") {
                  lastAdded = "value";
                  node.value += content;
                  if (node.raws.value) {
                    node.raws.value += content;
                  }
                }
              }
              spaceAfterMeaningfulToken = false;
              break;
            case tokens.str:
              if (!node.attribute || !node.operator) {
                return this.error("Expected an attribute followed by an operator preceding the string.", {
                  index: token[_tokenize.FIELDS.START_POS]
                });
              }
              var _unescapeValue = (0, _attribute.unescapeValue)(content), unescaped = _unescapeValue.unescaped, quoteMark = _unescapeValue.quoteMark;
              node.value = unescaped;
              node.quoteMark = quoteMark;
              lastAdded = "value";
              (0, _util.ensureObject)(node, "raws");
              node.raws.value = content;
              spaceAfterMeaningfulToken = false;
              break;
            case tokens.equals:
              if (!node.attribute) {
                return this.expected("attribute", token[_tokenize.FIELDS.START_POS], content);
              }
              if (node.value) {
                return this.error('Unexpected "=" found; an operator was already defined.', {
                  index: token[_tokenize.FIELDS.START_POS]
                });
              }
              node.operator = node.operator ? node.operator + content : content;
              lastAdded = "operator";
              spaceAfterMeaningfulToken = false;
              break;
            case tokens.comment:
              if (lastAdded) {
                if (spaceAfterMeaningfulToken || next && next[_tokenize.FIELDS.TYPE] === tokens.space || lastAdded === "insensitive") {
                  var lastComment = (0, _util.getProp)(node, "spaces", lastAdded, "after") || "";
                  var rawLastComment = (0, _util.getProp)(node, "raws", "spaces", lastAdded, "after") || lastComment;
                  (0, _util.ensureObject)(node, "raws", "spaces", lastAdded);
                  node.raws.spaces[lastAdded].after = rawLastComment + content;
                } else {
                  var lastValue = node[lastAdded] || "";
                  var rawLastValue = (0, _util.getProp)(node, "raws", lastAdded) || lastValue;
                  (0, _util.ensureObject)(node, "raws");
                  node.raws[lastAdded] = rawLastValue + content;
                }
              } else {
                commentBefore = commentBefore + content;
              }
              break;
            default:
              return this.error('Unexpected "' + content + '" found.', {
                index: token[_tokenize.FIELDS.START_POS]
              });
          }
          pos++;
        }
        unescapeProp(node, "attribute");
        unescapeProp(node, "namespace");
        this.newNode(new _attribute["default"](node));
        this.position++;
      };
      _proto.parseWhitespaceEquivalentTokens = function parseWhitespaceEquivalentTokens(stopPosition) {
        if (stopPosition < 0) {
          stopPosition = this.tokens.length;
        }
        var startPosition = this.position;
        var nodes = [];
        var space = "";
        var lastComment = void 0;
        do {
          if (WHITESPACE_TOKENS[this.currToken[_tokenize.FIELDS.TYPE]]) {
            if (!this.options.lossy) {
              space += this.content();
            }
          } else if (this.currToken[_tokenize.FIELDS.TYPE] === tokens.comment) {
            var spaces = {};
            if (space) {
              spaces.before = space;
              space = "";
            }
            lastComment = new _comment["default"]({
              value: this.content(),
              source: getTokenSource(this.currToken),
              sourceIndex: this.currToken[_tokenize.FIELDS.START_POS],
              spaces
            });
            nodes.push(lastComment);
          }
        } while (++this.position < stopPosition);
        if (space) {
          if (lastComment) {
            lastComment.spaces.after = space;
          } else if (!this.options.lossy) {
            var firstToken = this.tokens[startPosition];
            var lastToken = this.tokens[this.position - 1];
            nodes.push(new _string["default"]({
              value: "",
              source: getSource(firstToken[_tokenize.FIELDS.START_LINE], firstToken[_tokenize.FIELDS.START_COL], lastToken[_tokenize.FIELDS.END_LINE], lastToken[_tokenize.FIELDS.END_COL]),
              sourceIndex: firstToken[_tokenize.FIELDS.START_POS],
              spaces: {
                before: space,
                after: ""
              }
            }));
          }
        }
        return nodes;
      };
      _proto.convertWhitespaceNodesToSpace = function convertWhitespaceNodesToSpace(nodes, requiredSpace) {
        var _this2 = this;
        if (requiredSpace === void 0) {
          requiredSpace = false;
        }
        var space = "";
        var rawSpace = "";
        nodes.forEach(function(n) {
          var spaceBefore = _this2.lossySpace(n.spaces.before, requiredSpace);
          var rawSpaceBefore = _this2.lossySpace(n.rawSpaceBefore, requiredSpace);
          space += spaceBefore + _this2.lossySpace(n.spaces.after, requiredSpace && spaceBefore.length === 0);
          rawSpace += spaceBefore + n.value + _this2.lossySpace(n.rawSpaceAfter, requiredSpace && rawSpaceBefore.length === 0);
        });
        if (rawSpace === space) {
          rawSpace = void 0;
        }
        var result = {
          space,
          rawSpace
        };
        return result;
      };
      _proto.isNamedCombinator = function isNamedCombinator(position) {
        if (position === void 0) {
          position = this.position;
        }
        return this.tokens[position + 0] && this.tokens[position + 0][_tokenize.FIELDS.TYPE] === tokens.slash && this.tokens[position + 1] && this.tokens[position + 1][_tokenize.FIELDS.TYPE] === tokens.word && this.tokens[position + 2] && this.tokens[position + 2][_tokenize.FIELDS.TYPE] === tokens.slash;
      };
      _proto.namedCombinator = function namedCombinator() {
        if (this.isNamedCombinator()) {
          var nameRaw = this.content(this.tokens[this.position + 1]);
          var name = (0, _util.unesc)(nameRaw).toLowerCase();
          var raws = {};
          if (name !== nameRaw) {
            raws.value = "/" + nameRaw + "/";
          }
          var node = new _combinator["default"]({
            value: "/" + name + "/",
            source: getSource(this.currToken[_tokenize.FIELDS.START_LINE], this.currToken[_tokenize.FIELDS.START_COL], this.tokens[this.position + 2][_tokenize.FIELDS.END_LINE], this.tokens[this.position + 2][_tokenize.FIELDS.END_COL]),
            sourceIndex: this.currToken[_tokenize.FIELDS.START_POS],
            raws
          });
          this.position = this.position + 3;
          return node;
        } else {
          this.unexpected();
        }
      };
      _proto.combinator = function combinator2() {
        var _this3 = this;
        if (this.content() === "|") {
          return this.namespace();
        }
        var nextSigTokenPos = this.locateNextMeaningfulToken(this.position);
        if (nextSigTokenPos < 0 || this.tokens[nextSigTokenPos][_tokenize.FIELDS.TYPE] === tokens.comma || this.tokens[nextSigTokenPos][_tokenize.FIELDS.TYPE] === tokens.closeParenthesis) {
          var nodes = this.parseWhitespaceEquivalentTokens(nextSigTokenPos);
          if (nodes.length > 0) {
            var last = this.current.last;
            if (last) {
              var _this$convertWhitespa = this.convertWhitespaceNodesToSpace(nodes), space = _this$convertWhitespa.space, rawSpace = _this$convertWhitespa.rawSpace;
              if (rawSpace !== void 0) {
                last.rawSpaceAfter += rawSpace;
              }
              last.spaces.after += space;
            } else {
              nodes.forEach(function(n) {
                return _this3.newNode(n);
              });
            }
          }
          return;
        }
        var firstToken = this.currToken;
        var spaceOrDescendantSelectorNodes = void 0;
        if (nextSigTokenPos > this.position) {
          spaceOrDescendantSelectorNodes = this.parseWhitespaceEquivalentTokens(nextSigTokenPos);
        }
        var node;
        if (this.isNamedCombinator()) {
          node = this.namedCombinator();
        } else if (this.currToken[_tokenize.FIELDS.TYPE] === tokens.combinator) {
          node = new _combinator["default"]({
            value: this.content(),
            source: getTokenSource(this.currToken),
            sourceIndex: this.currToken[_tokenize.FIELDS.START_POS]
          });
          this.position++;
        } else if (WHITESPACE_TOKENS[this.currToken[_tokenize.FIELDS.TYPE]]) {
        } else if (!spaceOrDescendantSelectorNodes) {
          this.unexpected();
        }
        if (node) {
          if (spaceOrDescendantSelectorNodes) {
            var _this$convertWhitespa2 = this.convertWhitespaceNodesToSpace(spaceOrDescendantSelectorNodes), _space = _this$convertWhitespa2.space, _rawSpace = _this$convertWhitespa2.rawSpace;
            node.spaces.before = _space;
            node.rawSpaceBefore = _rawSpace;
          }
        } else {
          var _this$convertWhitespa3 = this.convertWhitespaceNodesToSpace(spaceOrDescendantSelectorNodes, true), _space2 = _this$convertWhitespa3.space, _rawSpace2 = _this$convertWhitespa3.rawSpace;
          if (!_rawSpace2) {
            _rawSpace2 = _space2;
          }
          var spaces = {};
          var raws = {
            spaces: {}
          };
          if (_space2.endsWith(" ") && _rawSpace2.endsWith(" ")) {
            spaces.before = _space2.slice(0, _space2.length - 1);
            raws.spaces.before = _rawSpace2.slice(0, _rawSpace2.length - 1);
          } else if (_space2[0] === " " && _rawSpace2[0] === " ") {
            spaces.after = _space2.slice(1);
            raws.spaces.after = _rawSpace2.slice(1);
          } else {
            raws.value = _rawSpace2;
          }
          node = new _combinator["default"]({
            value: " ",
            source: getTokenSourceSpan(firstToken, this.tokens[this.position - 1]),
            sourceIndex: firstToken[_tokenize.FIELDS.START_POS],
            spaces,
            raws
          });
        }
        if (this.currToken && this.currToken[_tokenize.FIELDS.TYPE] === tokens.space) {
          node.spaces.after = this.optionalSpace(this.content());
          this.position++;
        }
        return this.newNode(node);
      };
      _proto.comma = function comma() {
        if (this.position === this.tokens.length - 1) {
          this.root.trailingComma = true;
          this.position++;
          return;
        }
        this.current._inferEndPosition();
        var selector = new _selector["default"]({
          source: {
            start: tokenStart(this.tokens[this.position + 1])
          },
          sourceIndex: this.tokens[this.position + 1][_tokenize.FIELDS.START_POS]
        });
        this.current.parent.append(selector);
        this.current = selector;
        this.position++;
      };
      _proto.comment = function comment() {
        var current = this.currToken;
        this.newNode(new _comment["default"]({
          value: this.content(),
          source: getTokenSource(current),
          sourceIndex: current[_tokenize.FIELDS.START_POS]
        }));
        this.position++;
      };
      _proto.error = function error2(message, opts) {
        throw this.root.error(message, opts);
      };
      _proto.missingBackslash = function missingBackslash() {
        return this.error("Expected a backslash preceding the semicolon.", {
          index: this.currToken[_tokenize.FIELDS.START_POS]
        });
      };
      _proto.missingParenthesis = function missingParenthesis() {
        return this.expected("opening parenthesis", this.currToken[_tokenize.FIELDS.START_POS]);
      };
      _proto.missingSquareBracket = function missingSquareBracket() {
        return this.expected("opening square bracket", this.currToken[_tokenize.FIELDS.START_POS]);
      };
      _proto.unexpected = function unexpected() {
        return this.error("Unexpected '" + this.content() + "'. Escaping special characters with \\ may help.", this.currToken[_tokenize.FIELDS.START_POS]);
      };
      _proto.unexpectedPipe = function unexpectedPipe() {
        return this.error("Unexpected '|'.", this.currToken[_tokenize.FIELDS.START_POS]);
      };
      _proto.namespace = function namespace() {
        var before = this.prevToken && this.content(this.prevToken) || true;
        if (this.nextToken[_tokenize.FIELDS.TYPE] === tokens.word) {
          this.position++;
          return this.word(before);
        } else if (this.nextToken[_tokenize.FIELDS.TYPE] === tokens.asterisk) {
          this.position++;
          return this.universal(before);
        }
        this.unexpectedPipe();
      };
      _proto.nesting = function nesting() {
        if (this.nextToken) {
          var nextContent = this.content(this.nextToken);
          if (nextContent === "|") {
            this.position++;
            return;
          }
        }
        var current = this.currToken;
        this.newNode(new _nesting["default"]({
          value: this.content(),
          source: getTokenSource(current),
          sourceIndex: current[_tokenize.FIELDS.START_POS]
        }));
        this.position++;
      };
      _proto.parentheses = function parentheses() {
        var last = this.current.last;
        var unbalanced = 1;
        this.position++;
        if (last && last.type === types.PSEUDO) {
          var selector = new _selector["default"]({
            source: {
              start: tokenStart(this.tokens[this.position])
            },
            sourceIndex: this.tokens[this.position][_tokenize.FIELDS.START_POS]
          });
          var cache = this.current;
          last.append(selector);
          this.current = selector;
          while (this.position < this.tokens.length && unbalanced) {
            if (this.currToken[_tokenize.FIELDS.TYPE] === tokens.openParenthesis) {
              unbalanced++;
            }
            if (this.currToken[_tokenize.FIELDS.TYPE] === tokens.closeParenthesis) {
              unbalanced--;
            }
            if (unbalanced) {
              this.parse();
            } else {
              this.current.source.end = tokenEnd(this.currToken);
              this.current.parent.source.end = tokenEnd(this.currToken);
              this.position++;
            }
          }
          this.current = cache;
        } else {
          var parenStart = this.currToken;
          var parenValue = "(";
          var parenEnd;
          while (this.position < this.tokens.length && unbalanced) {
            if (this.currToken[_tokenize.FIELDS.TYPE] === tokens.openParenthesis) {
              unbalanced++;
            }
            if (this.currToken[_tokenize.FIELDS.TYPE] === tokens.closeParenthesis) {
              unbalanced--;
            }
            parenEnd = this.currToken;
            parenValue += this.parseParenthesisToken(this.currToken);
            this.position++;
          }
          if (last) {
            last.appendToPropertyAndEscape("value", parenValue, parenValue);
          } else {
            this.newNode(new _string["default"]({
              value: parenValue,
              source: getSource(parenStart[_tokenize.FIELDS.START_LINE], parenStart[_tokenize.FIELDS.START_COL], parenEnd[_tokenize.FIELDS.END_LINE], parenEnd[_tokenize.FIELDS.END_COL]),
              sourceIndex: parenStart[_tokenize.FIELDS.START_POS]
            }));
          }
        }
        if (unbalanced) {
          return this.expected("closing parenthesis", this.currToken[_tokenize.FIELDS.START_POS]);
        }
      };
      _proto.pseudo = function pseudo2() {
        var _this4 = this;
        var pseudoStr = "";
        var startingToken = this.currToken;
        while (this.currToken && this.currToken[_tokenize.FIELDS.TYPE] === tokens.colon) {
          pseudoStr += this.content();
          this.position++;
        }
        if (!this.currToken) {
          return this.expected(["pseudo-class", "pseudo-element"], this.position - 1);
        }
        if (this.currToken[_tokenize.FIELDS.TYPE] === tokens.word) {
          this.splitWord(false, function(first, length) {
            pseudoStr += first;
            _this4.newNode(new _pseudo["default"]({
              value: pseudoStr,
              source: getTokenSourceSpan(startingToken, _this4.currToken),
              sourceIndex: startingToken[_tokenize.FIELDS.START_POS]
            }));
            if (length > 1 && _this4.nextToken && _this4.nextToken[_tokenize.FIELDS.TYPE] === tokens.openParenthesis) {
              _this4.error("Misplaced parenthesis.", {
                index: _this4.nextToken[_tokenize.FIELDS.START_POS]
              });
            }
          });
        } else {
          return this.expected(["pseudo-class", "pseudo-element"], this.currToken[_tokenize.FIELDS.START_POS]);
        }
      };
      _proto.space = function space() {
        var content = this.content();
        if (this.position === 0 || this.prevToken[_tokenize.FIELDS.TYPE] === tokens.comma || this.prevToken[_tokenize.FIELDS.TYPE] === tokens.openParenthesis || this.current.nodes.every(function(node) {
          return node.type === "comment";
        })) {
          this.spaces = this.optionalSpace(content);
          this.position++;
        } else if (this.position === this.tokens.length - 1 || this.nextToken[_tokenize.FIELDS.TYPE] === tokens.comma || this.nextToken[_tokenize.FIELDS.TYPE] === tokens.closeParenthesis) {
          this.current.last.spaces.after = this.optionalSpace(content);
          this.position++;
        } else {
          this.combinator();
        }
      };
      _proto.string = function string() {
        var current = this.currToken;
        this.newNode(new _string["default"]({
          value: this.content(),
          source: getTokenSource(current),
          sourceIndex: current[_tokenize.FIELDS.START_POS]
        }));
        this.position++;
      };
      _proto.universal = function universal(namespace) {
        var nextToken = this.nextToken;
        if (nextToken && this.content(nextToken) === "|") {
          this.position++;
          return this.namespace();
        }
        var current = this.currToken;
        this.newNode(new _universal["default"]({
          value: this.content(),
          source: getTokenSource(current),
          sourceIndex: current[_tokenize.FIELDS.START_POS]
        }), namespace);
        this.position++;
      };
      _proto.splitWord = function splitWord(namespace, firstCallback) {
        var _this5 = this;
        var nextToken = this.nextToken;
        var word = this.content();
        while (nextToken && ~[tokens.dollar, tokens.caret, tokens.equals, tokens.word].indexOf(nextToken[_tokenize.FIELDS.TYPE])) {
          this.position++;
          var current = this.content();
          word += current;
          if (current.lastIndexOf("\\") === current.length - 1) {
            var next = this.nextToken;
            if (next && next[_tokenize.FIELDS.TYPE] === tokens.space) {
              word += this.requiredSpace(this.content(next));
              this.position++;
            }
          }
          nextToken = this.nextToken;
        }
        var hasClass = indexesOf(word, ".").filter(function(i) {
          var escapedDot = word[i - 1] === "\\";
          var isKeyframesPercent = /^\d+\.\d+%$/.test(word);
          return !escapedDot && !isKeyframesPercent;
        });
        var hasId = indexesOf(word, "#").filter(function(i) {
          return word[i - 1] !== "\\";
        });
        var interpolations = indexesOf(word, "#{");
        if (interpolations.length) {
          hasId = hasId.filter(function(hashIndex) {
            return !~interpolations.indexOf(hashIndex);
          });
        }
        var indices = (0, _sortAscending["default"])(uniqs([0].concat(hasClass, hasId)));
        indices.forEach(function(ind, i) {
          var index = indices[i + 1] || word.length;
          var value = word.slice(ind, index);
          if (i === 0 && firstCallback) {
            return firstCallback.call(_this5, value, indices.length);
          }
          var node;
          var current2 = _this5.currToken;
          var sourceIndex = current2[_tokenize.FIELDS.START_POS] + indices[i];
          var source = getSource(current2[1], current2[2] + ind, current2[3], current2[2] + (index - 1));
          if (~hasClass.indexOf(ind)) {
            var classNameOpts = {
              value: value.slice(1),
              source,
              sourceIndex
            };
            node = new _className["default"](unescapeProp(classNameOpts, "value"));
          } else if (~hasId.indexOf(ind)) {
            var idOpts = {
              value: value.slice(1),
              source,
              sourceIndex
            };
            node = new _id["default"](unescapeProp(idOpts, "value"));
          } else {
            var tagOpts = {
              value,
              source,
              sourceIndex
            };
            unescapeProp(tagOpts, "value");
            node = new _tag["default"](tagOpts);
          }
          _this5.newNode(node, namespace);
          namespace = null;
        });
        this.position++;
      };
      _proto.word = function word(namespace) {
        var nextToken = this.nextToken;
        if (nextToken && this.content(nextToken) === "|") {
          this.position++;
          return this.namespace();
        }
        return this.splitWord(namespace);
      };
      _proto.loop = function loop() {
        while (this.position < this.tokens.length) {
          this.parse(true);
        }
        this.current._inferEndPosition();
        return this.root;
      };
      _proto.parse = function parse3(throwOnParenthesis) {
        switch (this.currToken[_tokenize.FIELDS.TYPE]) {
          case tokens.space:
            this.space();
            break;
          case tokens.comment:
            this.comment();
            break;
          case tokens.openParenthesis:
            this.parentheses();
            break;
          case tokens.closeParenthesis:
            if (throwOnParenthesis) {
              this.missingParenthesis();
            }
            break;
          case tokens.openSquare:
            this.attribute();
            break;
          case tokens.dollar:
          case tokens.caret:
          case tokens.equals:
          case tokens.word:
            this.word();
            break;
          case tokens.colon:
            this.pseudo();
            break;
          case tokens.comma:
            this.comma();
            break;
          case tokens.asterisk:
            this.universal();
            break;
          case tokens.ampersand:
            this.nesting();
            break;
          case tokens.slash:
          case tokens.combinator:
            this.combinator();
            break;
          case tokens.str:
            this.string();
            break;
          // These cases throw; no break needed.
          case tokens.closeSquare:
            this.missingSquareBracket();
          case tokens.semicolon:
            this.missingBackslash();
          default:
            this.unexpected();
        }
      };
      _proto.expected = function expected(description, index, found) {
        if (Array.isArray(description)) {
          var last = description.pop();
          description = description.join(", ") + " or " + last;
        }
        var an = /^[aeiou]/.test(description[0]) ? "an" : "a";
        if (!found) {
          return this.error("Expected " + an + " " + description + ".", {
            index
          });
        }
        return this.error("Expected " + an + " " + description + ', found "' + found + '" instead.', {
          index
        });
      };
      _proto.requiredSpace = function requiredSpace(space) {
        return this.options.lossy ? " " : space;
      };
      _proto.optionalSpace = function optionalSpace(space) {
        return this.options.lossy ? "" : space;
      };
      _proto.lossySpace = function lossySpace(space, required) {
        if (this.options.lossy) {
          return required ? " " : "";
        } else {
          return space;
        }
      };
      _proto.parseParenthesisToken = function parseParenthesisToken(token) {
        var content = this.content(token);
        if (token[_tokenize.FIELDS.TYPE] === tokens.space) {
          return this.requiredSpace(content);
        } else {
          return content;
        }
      };
      _proto.newNode = function newNode(node, namespace) {
        if (namespace) {
          if (/^ +$/.test(namespace)) {
            if (!this.options.lossy) {
              this.spaces = (this.spaces || "") + namespace;
            }
            namespace = true;
          }
          node.namespace = namespace;
          unescapeProp(node, "namespace");
        }
        if (this.spaces) {
          node.spaces.before = this.spaces;
          this.spaces = "";
        }
        return this.current.append(node);
      };
      _proto.content = function content(token) {
        if (token === void 0) {
          token = this.currToken;
        }
        return this.css.slice(token[_tokenize.FIELDS.START_POS], token[_tokenize.FIELDS.END_POS]);
      };
      _proto.locateNextMeaningfulToken = function locateNextMeaningfulToken(startPosition) {
        if (startPosition === void 0) {
          startPosition = this.position + 1;
        }
        var searchPosition = startPosition;
        while (searchPosition < this.tokens.length) {
          if (WHITESPACE_EQUIV_TOKENS[this.tokens[searchPosition][_tokenize.FIELDS.TYPE]]) {
            searchPosition++;
            continue;
          } else {
            return searchPosition;
          }
        }
        return -1;
      };
      _createClass(Parser2, [{
        key: "currToken",
        get: function get() {
          return this.tokens[this.position];
        }
      }, {
        key: "nextToken",
        get: function get() {
          return this.tokens[this.position + 1];
        }
      }, {
        key: "prevToken",
        get: function get() {
          return this.tokens[this.position - 1];
        }
      }]);
      return Parser2;
    })();
    exports["default"] = Parser;
    module.exports = exports.default;
  }
});

// ../../node_modules/.vlt/~npm~postcss-selector-parser@7.1.1/node_modules/postcss-selector-parser/dist/processor.js
var require_processor = __commonJS({
  "../../node_modules/.vlt/~npm~postcss-selector-parser@7.1.1/node_modules/postcss-selector-parser/dist/processor.js"(exports, module) {
    "use strict";
    exports.__esModule = true;
    exports["default"] = void 0;
    var _parser = _interopRequireDefault(require_parser());
    function _interopRequireDefault(obj) {
      return obj && obj.__esModule ? obj : { "default": obj };
    }
    var Processor = /* @__PURE__ */ (function() {
      function Processor2(func, options) {
        this.func = func || function noop() {
        };
        this.funcRes = null;
        this.options = options;
      }
      var _proto = Processor2.prototype;
      _proto._shouldUpdateSelector = function _shouldUpdateSelector(rule, options) {
        if (options === void 0) {
          options = {};
        }
        var merged = Object.assign({}, this.options, options);
        if (merged.updateSelector === false) {
          return false;
        } else {
          return typeof rule !== "string";
        }
      };
      _proto._isLossy = function _isLossy(options) {
        if (options === void 0) {
          options = {};
        }
        var merged = Object.assign({}, this.options, options);
        if (merged.lossless === false) {
          return true;
        } else {
          return false;
        }
      };
      _proto._root = function _root(rule, options) {
        if (options === void 0) {
          options = {};
        }
        var parser = new _parser["default"](rule, this._parseOptions(options));
        return parser.root;
      };
      _proto._parseOptions = function _parseOptions(options) {
        return {
          lossy: this._isLossy(options)
        };
      };
      _proto._run = function _run(rule, options) {
        var _this = this;
        if (options === void 0) {
          options = {};
        }
        return new Promise(function(resolve12, reject) {
          try {
            var root2 = _this._root(rule, options);
            Promise.resolve(_this.func(root2)).then(function(transform) {
              var string = void 0;
              if (_this._shouldUpdateSelector(rule, options)) {
                string = root2.toString();
                rule.selector = string;
              }
              return {
                transform,
                root: root2,
                string
              };
            }).then(resolve12, reject);
          } catch (e) {
            reject(e);
            return;
          }
        });
      };
      _proto._runSync = function _runSync(rule, options) {
        if (options === void 0) {
          options = {};
        }
        var root2 = this._root(rule, options);
        var transform = this.func(root2);
        if (transform && typeof transform.then === "function") {
          throw new Error("Selector processor returned a promise to a synchronous call.");
        }
        var string = void 0;
        if (options.updateSelector && typeof rule !== "string") {
          string = root2.toString();
          rule.selector = string;
        }
        return {
          transform,
          root: root2,
          string
        };
      };
      _proto.ast = function ast(rule, options) {
        return this._run(rule, options).then(function(result) {
          return result.root;
        });
      };
      _proto.astSync = function astSync(rule, options) {
        return this._runSync(rule, options).root;
      };
      _proto.transform = function transform(rule, options) {
        return this._run(rule, options).then(function(result) {
          return result.transform;
        });
      };
      _proto.transformSync = function transformSync(rule, options) {
        return this._runSync(rule, options).transform;
      };
      _proto.process = function process3(rule, options) {
        return this._run(rule, options).then(function(result) {
          return result.string || result.root.toString();
        });
      };
      _proto.processSync = function processSync(rule, options) {
        var result = this._runSync(rule, options);
        return result.string || result.root.toString();
      };
      return Processor2;
    })();
    exports["default"] = Processor;
    module.exports = exports.default;
  }
});

// ../../node_modules/.vlt/~npm~postcss-selector-parser@7.1.1/node_modules/postcss-selector-parser/dist/selectors/constructors.js
var require_constructors = __commonJS({
  "../../node_modules/.vlt/~npm~postcss-selector-parser@7.1.1/node_modules/postcss-selector-parser/dist/selectors/constructors.js"(exports) {
    "use strict";
    exports.__esModule = true;
    exports.universal = exports.tag = exports.string = exports.selector = exports.root = exports.pseudo = exports.nesting = exports.id = exports.comment = exports.combinator = exports.className = exports.attribute = void 0;
    var _attribute = _interopRequireDefault(require_attribute());
    var _className = _interopRequireDefault(require_className());
    var _combinator = _interopRequireDefault(require_combinator());
    var _comment = _interopRequireDefault(require_comment());
    var _id = _interopRequireDefault(require_id());
    var _nesting = _interopRequireDefault(require_nesting());
    var _pseudo = _interopRequireDefault(require_pseudo());
    var _root = _interopRequireDefault(require_root());
    var _selector = _interopRequireDefault(require_selector());
    var _string = _interopRequireDefault(require_string());
    var _tag = _interopRequireDefault(require_tag());
    var _universal = _interopRequireDefault(require_universal());
    function _interopRequireDefault(obj) {
      return obj && obj.__esModule ? obj : { "default": obj };
    }
    var attribute2 = function attribute3(opts) {
      return new _attribute["default"](opts);
    };
    exports.attribute = attribute2;
    var className = function className2(opts) {
      return new _className["default"](opts);
    };
    exports.className = className;
    var combinator2 = function combinator3(opts) {
      return new _combinator["default"](opts);
    };
    exports.combinator = combinator2;
    var comment = function comment2(opts) {
      return new _comment["default"](opts);
    };
    exports.comment = comment;
    var id2 = function id3(opts) {
      return new _id["default"](opts);
    };
    exports.id = id2;
    var nesting = function nesting2(opts) {
      return new _nesting["default"](opts);
    };
    exports.nesting = nesting;
    var pseudo2 = function pseudo3(opts) {
      return new _pseudo["default"](opts);
    };
    exports.pseudo = pseudo2;
    var root2 = function root3(opts) {
      return new _root["default"](opts);
    };
    exports.root = root2;
    var selector = function selector2(opts) {
      return new _selector["default"](opts);
    };
    exports.selector = selector;
    var string = function string2(opts) {
      return new _string["default"](opts);
    };
    exports.string = string;
    var tag = function tag2(opts) {
      return new _tag["default"](opts);
    };
    exports.tag = tag;
    var universal = function universal2(opts) {
      return new _universal["default"](opts);
    };
    exports.universal = universal;
  }
});

// ../../node_modules/.vlt/~npm~postcss-selector-parser@7.1.1/node_modules/postcss-selector-parser/dist/selectors/guards.js
var require_guards = __commonJS({
  "../../node_modules/.vlt/~npm~postcss-selector-parser@7.1.1/node_modules/postcss-selector-parser/dist/selectors/guards.js"(exports) {
    "use strict";
    exports.__esModule = true;
    exports.isComment = exports.isCombinator = exports.isClassName = exports.isAttribute = void 0;
    exports.isContainer = isContainer;
    exports.isIdentifier = void 0;
    exports.isNamespace = isNamespace;
    exports.isNesting = void 0;
    exports.isNode = isNode2;
    exports.isPseudo = void 0;
    exports.isPseudoClass = isPseudoClass;
    exports.isPseudoElement = isPseudoElement;
    exports.isUniversal = exports.isTag = exports.isString = exports.isSelector = exports.isRoot = void 0;
    var _types = require_types();
    var _IS_TYPE;
    var IS_TYPE = (_IS_TYPE = {}, _IS_TYPE[_types.ATTRIBUTE] = true, _IS_TYPE[_types.CLASS] = true, _IS_TYPE[_types.COMBINATOR] = true, _IS_TYPE[_types.COMMENT] = true, _IS_TYPE[_types.ID] = true, _IS_TYPE[_types.NESTING] = true, _IS_TYPE[_types.PSEUDO] = true, _IS_TYPE[_types.ROOT] = true, _IS_TYPE[_types.SELECTOR] = true, _IS_TYPE[_types.STRING] = true, _IS_TYPE[_types.TAG] = true, _IS_TYPE[_types.UNIVERSAL] = true, _IS_TYPE);
    function isNode2(node) {
      return typeof node === "object" && IS_TYPE[node.type];
    }
    function isNodeType(type2, node) {
      return isNode2(node) && node.type === type2;
    }
    var isAttribute = isNodeType.bind(null, _types.ATTRIBUTE);
    exports.isAttribute = isAttribute;
    var isClassName = isNodeType.bind(null, _types.CLASS);
    exports.isClassName = isClassName;
    var isCombinator = isNodeType.bind(null, _types.COMBINATOR);
    exports.isCombinator = isCombinator;
    var isComment = isNodeType.bind(null, _types.COMMENT);
    exports.isComment = isComment;
    var isIdentifier = isNodeType.bind(null, _types.ID);
    exports.isIdentifier = isIdentifier;
    var isNesting = isNodeType.bind(null, _types.NESTING);
    exports.isNesting = isNesting;
    var isPseudo = isNodeType.bind(null, _types.PSEUDO);
    exports.isPseudo = isPseudo;
    var isRoot = isNodeType.bind(null, _types.ROOT);
    exports.isRoot = isRoot;
    var isSelector = isNodeType.bind(null, _types.SELECTOR);
    exports.isSelector = isSelector;
    var isString = isNodeType.bind(null, _types.STRING);
    exports.isString = isString;
    var isTag = isNodeType.bind(null, _types.TAG);
    exports.isTag = isTag;
    var isUniversal = isNodeType.bind(null, _types.UNIVERSAL);
    exports.isUniversal = isUniversal;
    function isPseudoElement(node) {
      return isPseudo(node) && node.value && (node.value.startsWith("::") || node.value.toLowerCase() === ":before" || node.value.toLowerCase() === ":after" || node.value.toLowerCase() === ":first-letter" || node.value.toLowerCase() === ":first-line");
    }
    function isPseudoClass(node) {
      return isPseudo(node) && !isPseudoElement(node);
    }
    function isContainer(node) {
      return !!(isNode2(node) && node.walk);
    }
    function isNamespace(node) {
      return isAttribute(node) || isTag(node);
    }
  }
});

// ../../node_modules/.vlt/~npm~postcss-selector-parser@7.1.1/node_modules/postcss-selector-parser/dist/selectors/index.js
var require_selectors = __commonJS({
  "../../node_modules/.vlt/~npm~postcss-selector-parser@7.1.1/node_modules/postcss-selector-parser/dist/selectors/index.js"(exports) {
    "use strict";
    exports.__esModule = true;
    var _types = require_types();
    Object.keys(_types).forEach(function(key) {
      if (key === "default" || key === "__esModule") return;
      if (key in exports && exports[key] === _types[key]) return;
      exports[key] = _types[key];
    });
    var _constructors = require_constructors();
    Object.keys(_constructors).forEach(function(key) {
      if (key === "default" || key === "__esModule") return;
      if (key in exports && exports[key] === _constructors[key]) return;
      exports[key] = _constructors[key];
    });
    var _guards = require_guards();
    Object.keys(_guards).forEach(function(key) {
      if (key === "default" || key === "__esModule") return;
      if (key in exports && exports[key] === _guards[key]) return;
      exports[key] = _guards[key];
    });
  }
});

// ../../node_modules/.vlt/~npm~postcss-selector-parser@7.1.1/node_modules/postcss-selector-parser/dist/index.js
var require_dist = __commonJS({
  "../../node_modules/.vlt/~npm~postcss-selector-parser@7.1.1/node_modules/postcss-selector-parser/dist/index.js"(exports, module) {
    "use strict";
    exports.__esModule = true;
    exports["default"] = void 0;
    var _processor = _interopRequireDefault(require_processor());
    var selectors2 = _interopRequireWildcard(require_selectors());
    function _getRequireWildcardCache(nodeInterop) {
      if (typeof WeakMap !== "function") return null;
      var cacheBabelInterop = /* @__PURE__ */ new WeakMap();
      var cacheNodeInterop = /* @__PURE__ */ new WeakMap();
      return (_getRequireWildcardCache = function _getRequireWildcardCache2(nodeInterop2) {
        return nodeInterop2 ? cacheNodeInterop : cacheBabelInterop;
      })(nodeInterop);
    }
    function _interopRequireWildcard(obj, nodeInterop) {
      if (!nodeInterop && obj && obj.__esModule) {
        return obj;
      }
      if (obj === null || typeof obj !== "object" && typeof obj !== "function") {
        return { "default": obj };
      }
      var cache = _getRequireWildcardCache(nodeInterop);
      if (cache && cache.has(obj)) {
        return cache.get(obj);
      }
      var newObj = {};
      var hasPropertyDescriptor = Object.defineProperty && Object.getOwnPropertyDescriptor;
      for (var key in obj) {
        if (key !== "default" && Object.prototype.hasOwnProperty.call(obj, key)) {
          var desc = hasPropertyDescriptor ? Object.getOwnPropertyDescriptor(obj, key) : null;
          if (desc && (desc.get || desc.set)) {
            Object.defineProperty(newObj, key, desc);
          } else {
            newObj[key] = obj[key];
          }
        }
      }
      newObj["default"] = obj;
      if (cache) {
        cache.set(obj, newObj);
      }
      return newObj;
    }
    function _interopRequireDefault(obj) {
      return obj && obj.__esModule ? obj : { "default": obj };
    }
    var parser = function parser2(processor) {
      return new _processor["default"](processor);
    };
    Object.assign(parser, selectors2);
    delete parser.__esModule;
    var _default = parser;
    exports["default"] = _default;
    module.exports = exports.default;
  }
});

// ../../src/satisfies/src/index.ts
import { relative, resolve } from "node:path";
var satisfies2 = (id2, spec2, fromLocation = process.cwd(), projectRoot = process.cwd(), monorepo) => !!id2 && satisfiesTuple(
  splitDepID(id2),
  spec2,
  fromLocation,
  projectRoot,
  monorepo
);
var satisfiesTuple = (tuple, spec2, fromLocation = process.cwd(), projectRoot = process.cwd(), monorepo) => {
  const { options } = spec2;
  spec2 = spec2.final;
  const [type2, first, second] = tuple;
  if (spec2.type !== type2) return false;
  switch (spec2.type) {
    case "registry": {
      if (!first) {
        if (spec2.registry !== options.registry) {
          return false;
        }
      } else {
        let namedRegistry = options.registries[first];
        if (!namedRegistry && first === defaultRegistryName) {
          namedRegistry = options.registry;
        }
        if (namedRegistry && namedRegistry !== spec2.registry) {
          return false;
        } else if (!namedRegistry && first !== spec2.registry) {
          return false;
        }
      }
      if (!second) throw error("Invalid DepID", { found: tuple });
      const [name, version] = parseNameVer(second);
      return (
        // mismatched name always invalid
        name !== spec2.name || !version ? false : !spec2.range ? true : spec2.range.test(Version.parse(version))
      );
    }
    case "file": {
      if (spec2.file === void 0) return false;
      const resolvedSpec = resolve(
        projectRoot,
        fromLocation,
        spec2.file
      );
      const resolvedId = resolve(projectRoot, first);
      return !relative(resolvedSpec, resolvedId);
    }
    case "workspace": {
      monorepo ??= Monorepo.load(projectRoot);
      if (!spec2.workspace) return false;
      const fromID = monorepo.get(first);
      const fromSpec = monorepo.get(spec2.workspace);
      if (fromID !== fromSpec || !fromSpec || !fromID) return false;
      if (!spec2.range) return true;
      const v = parse(fromID.manifest.version ?? "");
      return !!v && spec2.range.test(v);
    }
    case "remote": {
      return spec2.remoteURL === first;
    }
    case "git": {
      const {
        gitRemote,
        gitSelectorParsed = {},
        gitSelector,
        gitCommittish,
        namedGitHost,
        namedGitHostPath
      } = spec2;
      if (gitRemote !== first) {
        if (namedGitHost && namedGitHostPath) {
          const ngh = `${namedGitHost}:`;
          if (first.startsWith(ngh)) {
            if (first !== ngh + namedGitHostPath) return false;
          } else return false;
        } else return false;
      }
      if (gitSelector && !second) return false;
      const [parsed, committish] = Spec2.parseGitSelector(second ?? "");
      if (gitCommittish && committish)
        return committish.startsWith(gitCommittish);
      for (const [k, v] of Object.entries(gitSelectorParsed)) {
        if (parsed[k] !== v) return false;
      }
      return true;
    }
    /* c8 ignore start */
    default: {
      throw error("Invalid spec type", { spec: spec2 });
    }
  }
};
var parseNameVer = (nv) => {
  const at = nv.lastIndexOf("@");
  return at <= 0 ? [nv, ""] : [nv.substring(0, at), nv.substring(at + 1)];
};

// ../../src/graph/src/edge.ts
import { inspect } from "node:util";
var kCustomInspect = /* @__PURE__ */ Symbol.for("nodejs.util.inspect.custom");
var Edge = class {
  get [Symbol.toStringTag]() {
    return "@vltpkg/graph.Edge";
  }
  [kCustomInspect](_, options) {
    const str = inspect(
      {
        from: this.from.id,
        type: this.type,
        spec: String(this.spec),
        to: this.to?.id
      },
      options
    );
    return `${this[Symbol.toStringTag]} ${str}`;
  }
  /**
   * The Node this Edge is connecting from, this is usually the dependent.
   */
  from;
  /**
   * The node this Edge is connecting to, this is usually a direct dependency.
   */
  to;
  /**
   * What type of dependency relationship `from` and `to` nodes have.
   */
  type;
  /**
   * The defined spec value for `to` as parsed from the dependent metadata.
   */
  spec;
  constructor(type2, spec2, from, to) {
    this.from = from;
    this.to = to;
    this.type = type2;
    this.spec = spec2;
  }
  /**
   * The name of the dependency `to` as defined in the dependent metadata.
   */
  get name() {
    return this.spec.name;
  }
  /**
   * This edge was defined as part of a `devDependencies` in `package.json`
   */
  get dev() {
    return this.type === "dev";
  }
  get optional() {
    return this.type === "peerOptional" || this.type === "optional";
  }
  get peer() {
    return this.type === "peer" || this.type === "peerOptional";
  }
  get peerOptional() {
    return this.type === "peerOptional";
  }
  valid() {
    return !this.to ? this.optional : satisfies2(
      this.to.id,
      this.spec,
      this.from.location,
      this.from.projectRoot
    );
  }
  toJSON() {
    return {
      from: this.from.id,
      to: this.to?.id,
      type: this.type,
      spec: String(this.spec)
    };
  }
  toString() {
    const to = `${this.name}${this.to ? "" : " (missing)"}`;
    return `Edge from: ${this.from.id} --|${this.type}|--> ${to}`;
  }
};

// ../../src/graph/src/stringify-node.ts
var stringifyNode = (node) => {
  if (!node) return "";
  const version = node.version ? `@${node.version}` : "";
  const [type2, ref, nameVersion] = splitDepID(node.id);
  if (type2 === "registry") {
    let prefix = `${defaultRegistryName}:`;
    if (ref) {
      if (/^https?:\/\//.test(ref)) {
        prefix = `registry:${ref}#`;
      } else {
        prefix = `${ref}:`;
      }
    }
    return `${prefix}${nameVersion}`;
  } else if (type2 === "workspace") {
    return `workspace:${node.name}`;
  } else if (type2 === "file" && node.mainImporter) {
    return `root:${node.name}`;
  } else {
    const nameVersion2 = node.name !== node.id ? `:${node.name}${version}` : "";
    return `${type2}(${ref})${nameVersion2}`;
  }
};

// ../../src/graph/src/node.ts
var Node = class _Node {
  get [Symbol.toStringTag]() {
    return "@vltpkg/graph.Node";
  }
  #options;
  #location;
  #rawManifest;
  #optional = false;
  /**
   * True if a node is only reachable via optional or peerOptional edges from
   * any importer.
   *
   * Setting this to false, if previously set to true, will also unset
   * the flag on any optional-flagged non-optional dependencies.
   */
  get optional() {
    return this.#optional;
  }
  set optional(optional2) {
    const before = this.#optional;
    this.#optional = optional2;
    if (before && !optional2) {
      for (const { to, optional: optional3 } of this.edgesOut.values()) {
        if (!optional3 && to?.optional) to.optional = false;
      }
    }
  }
  isOptional() {
    return this.#optional;
  }
  #dev = false;
  /**
   * True if a node is only reachable via dev edges from any importer.
   *
   * Setting this to false, if previously set to true, will also unset
   * the flag on any dev-flagged non-dev dependencies.
   */
  get dev() {
    return this.#dev;
  }
  set dev(dev2) {
    const before = this.#dev;
    this.#dev = dev2;
    if (before && !dev2) {
      for (const { to, dev: dev3 } of this.edgesOut.values()) {
        if (!dev3 && to?.dev) to.dev = false;
      }
    }
  }
  isDev() {
    return this.#dev;
  }
  /**
   * True if there's a manifest-confused package name.
   */
  confused = false;
  /**
   * True if this node has been extracted to the file system.
   */
  extracted = false;
  /**
   * List of edges coming into this node.
   */
  edgesIn = /* @__PURE__ */ new Set();
  /**
   * List of edges from this node into other nodes. This usually represents
   * that the connected node is a direct dependency of this node.
   */
  edgesOut = /* @__PURE__ */ new Map();
  /**
   * A `mainImporter` node may have workspace connected to it,
   * equivalent to its `edgesOut` linked deps.
   */
  workspaces;
  /**
   * A reference to the {@link DepID} this node represents in the graph.
   */
  id;
  /**
   * True if this node is an importer node.
   */
  importer = false;
  /**
   * True if this node is the project root node.
   */
  mainImporter = false;
  /**
   * A reference to the graph this node is a part of.
   */
  graph;
  /**
   * The manifest integrity value.
   */
  integrity;
  /**
   * The manifest this node represents in the graph.
   */
  manifest;
  /**
   * Project where this node resides
   */
  projectRoot;
  /**
   * For registry nodes, this is the registry we fetched them from.
   * Needed because their un-prefixed dependencies need to come from
   * the same registry, if it's not the default.
   */
  registry;
  /**
   * If this node has been modified as part of applying a {@link GraphModifier}
   * then this field will contain the modifier query that was applied.
   * Otherwise, it will be `undefined`.
   */
  modifier;
  /**
   * The name of the package represented by this node, this is usually
   * equivalent to `manifest.name` but in a few ways it may differ such as
   * nodes loaded from a lockfile that lacks a loaded manifest.
   * This field should be used to retrieve package names instead.
   */
  #name;
  get name() {
    if (this.#name) return this.#name;
    this.#name = this.id;
    return this.#name;
  }
  /**
   * The version of the package represented by this node, this is usually
   * equivalent to `manifest.version` but in a few ways it may differ such as
   * nodes loaded from a lockfile that lacks a loaded manifest.
   * This field should be used to retrieve package versions instead.
   */
  version;
  /**
   * An address {@link PackageInfoClient} may use to extract this package.
   */
  resolved;
  /**
   * Platform requirements (engines, os, cpu) extracted from manifest.
   * Stored separately for optional dependencies to enable platform checks
   * when manifest is not loaded.
   */
  platform;
  /**
   * Record of binary names to their paths in the package, if any.
   */
  bins;
  /**
   * True if this node has been built as part of the reify step.
   */
  built = false;
  /**
   * Build state of this node - tracks whether it needs building, has been built, or failed.
   * - 'none': No build state (default)
   * - 'needed': Node needs to be built
   * - 'built': Node has been successfully built
   * - 'failed': Node build has failed
   */
  buildState = "none";
  /**
   * Deterministic unique string used to identify (and ultimately duplicate)
   * nodes that are affected by a peer context set modified resolution.
   * These are appended to the node {@link DepID} as the `extra` suffix.
   */
  peerSetHash;
  /**
   * True if this node is detached from the graph.
   * This is used to indicate that the node is not part of the graph
   * although the node is still available as part of the resolution process.
   * Allows for skipping fetching manifests for detached nodes.
   */
  detached = false;
  /**
   * The file system location for this node.
   */
  get location() {
    if (this.#location) {
      return this.#location;
    }
    this.#location = `./node_modules/.vlt/${this.id}/node_modules/${this.name}`;
    this.inVltStore = () => true;
    return this.#location;
  }
  set location(location) {
    this.#location = location;
    if (this.inVltStore !== _Node.prototype.inVltStore) {
      this.inVltStore = _Node.prototype.inVltStore;
    }
  }
  /**
   * The resolved location of the node in the file system.
   */
  resolvedLocation(scurry) {
    return scurry.cwd.resolve(this.location).fullpath();
  }
  /**
   * The location of the node_modules folder where this node's edgesOut
   * should be linked into. For nodes in the store, this is the parent
   * directory, since they're extracted into a node_modules folder
   * side by side with links to their deps. For nodes outside of the store
   * (ie, importers and arbitrary link deps) this is the node_modules folder
   * directly inside the node's directory.
   */
  nodeModules(scurry) {
    const loc = this.resolvedLocation(scurry);
    return this.inVltStore() ? loc.substring(0, loc.length - this.name.length - 1) : scurry.resolve(loc, "node_modules");
  }
  constructor(options, id2, manifest, spec2, name, version) {
    this.#options = options;
    this.projectRoot = options.projectRoot;
    if (id2) {
      this.id = id2;
    } else {
      if (!manifest || !spec2) {
        throw typeError(
          "A new Node needs either a manifest & spec or an id parameter",
          {
            manifest
          }
        );
      }
      this.id = getId(spec2, manifest);
    }
    this.graph = options.graph;
    this.manifest = manifest;
    this.#name = name || this.manifest?.name;
    this.version = version || this.manifest?.version;
  }
  /**
   * return true if this node is located in the vlt store
   * memoized the first time it's called, since the store location
   * doesn't change within the context of a single operation.
   */
  inVltStore() {
    const inStore = this.location.endsWith(
      `.vlt/${this.id}/node_modules/${this.name}`
    );
    this.inVltStore = () => inStore;
    return inStore;
  }
  #registryNodeResolved(tuple) {
    const spec2 = hydrateTuple(tuple, this.#name, this.#options);
    this.resolved = this.manifest?.dist?.tarball || spec2.conventionalRegistryTarball;
    this.integrity ??= this.manifest?.dist?.integrity;
  }
  get options() {
    return this.#options;
  }
  /* c8 ignore next */
  set options(_opts) {
  }
  equals(other) {
    return this.id === other.id && this.location === other.location;
  }
  /**
   * Sets the node as an importer along with its location.
   */
  setImporterLocation(location) {
    this.#location = location;
    this.importer = true;
  }
  /**
   * Sets the appropriate resolve / integrity value for this node.
   * Note that other places might also set these values, like for
   * example the lockfile that might have already have this info.
   */
  setResolved() {
    const tuple = splitDepID(this.id);
    const [type2, resolved] = tuple;
    switch (type2) {
      case "remote": {
        this.resolved = resolved;
        this.integrity ??= this.manifest?.dist?.integrity;
        break;
      }
      case "registry":
        this.#registryNodeResolved(tuple);
        break;
      default:
        this.resolved = resolved;
        break;
    }
  }
  setDefaultLocation() {
    const def = `./node_modules/.vlt/${this.id}/node_modules/${this.name}`;
    if (!this.importer && (!this.#location || this.#location !== def && /^(?:\.\/)?node_modules\//.test(this.#location))) {
      this.#location = def;
    }
  }
  /**
   * Add an edge from this node connecting it to a direct dependency.
   */
  addEdgesTo(type2, spec2, node) {
    const edge = new Edge(type2, spec2, this, node);
    node?.edgesIn.add(edge);
    this.edgesOut.set(spec2.name, edge);
    return edge;
  }
  /**
   * The raw manifest before any modifications.
   * If not set, falls back to the current manifest.
   */
  get rawManifest() {
    return this.#rawManifest ?? this.manifest;
  }
  /**
   * Sets this node as having a manifest-confused manifest.
   */
  setConfusedManifest(fixed, confused2) {
    this.manifest = fixed;
    this.#rawManifest = confused2;
    this.confused = true;
    this.#name = this.manifest.name;
  }
  /**
   * Sets this node as having a manifest-confused manifest.
   */
  maybeSetConfusedManifest(spec2, confused2) {
    if (isPackageNameConfused(spec2, this.manifest?.name)) {
      this.setConfusedManifest(
        {
          ...this.manifest,
          name: spec2.name
        },
        confused2
      );
    }
  }
  toJSON() {
    return {
      id: this.id,
      name: this.name,
      version: this.version,
      location: this.location,
      importer: this.importer,
      manifest: this.manifest && expandNormalizedManifestSymbols(this.manifest),
      projectRoot: this.projectRoot,
      integrity: this.integrity,
      resolved: this.resolved,
      dev: this.dev,
      optional: this.optional,
      confused: this.confused,
      modifier: this.modifier,
      platform: this.platform,
      buildState: this.buildState,
      ...this.peerSetHash ? { peerSetHash: this.peerSetHash } : void 0,
      ...this.confused ? { rawManifest: this.#rawManifest } : void 0
    };
  }
  toString() {
    return stringifyNode(this);
  }
};
var isNode = (value) => {
  return typeof value === "object" && value != null && "id" in value && "manifest" in value && value[Symbol.toStringTag] === "@vltpkg/graph.Node";
};
var asNode = (value) => {
  if (!isNode(value)) {
    throw typeError("Expected a node", { found: value });
  }
  return value;
};

// ../../node_modules/.vlt/~npm~foreground-child@3.3.1/node_modules/foreground-child/dist/esm/index.js
var import_cross_spawn = __toESM(require_cross_spawn(), 1);
import { spawn as nodeSpawn } from "node:child_process";

// ../../node_modules/.vlt/~npm~signal-exit@4.1.0/node_modules/signal-exit/dist/mjs/signals.js
var signals = [];
signals.push("SIGHUP", "SIGINT", "SIGTERM");
if (process.platform !== "win32") {
  signals.push(
    "SIGALRM",
    "SIGABRT",
    "SIGVTALRM",
    "SIGXCPU",
    "SIGXFSZ",
    "SIGUSR2",
    "SIGTRAP",
    "SIGSYS",
    "SIGQUIT",
    "SIGIOT"
    // should detect profiler and enable/disable accordingly.
    // see #21
    // 'SIGPROF'
  );
}
if (process.platform === "linux") {
  signals.push("SIGIO", "SIGPOLL", "SIGPWR", "SIGSTKFLT");
}

// ../../node_modules/.vlt/~npm~signal-exit@4.1.0/node_modules/signal-exit/dist/mjs/index.js
var processOk = (process3) => !!process3 && typeof process3 === "object" && typeof process3.removeListener === "function" && typeof process3.emit === "function" && typeof process3.reallyExit === "function" && typeof process3.listeners === "function" && typeof process3.kill === "function" && typeof process3.pid === "number" && typeof process3.on === "function";
var kExitEmitter = /* @__PURE__ */ Symbol.for("signal-exit emitter");
var global2 = globalThis;
var ObjectDefineProperty = Object.defineProperty.bind(Object);
var Emitter = class {
  emitted = {
    afterExit: false,
    exit: false
  };
  listeners = {
    afterExit: [],
    exit: []
  };
  count = 0;
  id = Math.random();
  constructor() {
    if (global2[kExitEmitter]) {
      return global2[kExitEmitter];
    }
    ObjectDefineProperty(global2, kExitEmitter, {
      value: this,
      writable: false,
      enumerable: false,
      configurable: false
    });
  }
  on(ev, fn) {
    this.listeners[ev].push(fn);
  }
  removeListener(ev, fn) {
    const list = this.listeners[ev];
    const i = list.indexOf(fn);
    if (i === -1) {
      return;
    }
    if (i === 0 && list.length === 1) {
      list.length = 0;
    } else {
      list.splice(i, 1);
    }
  }
  emit(ev, code, signal) {
    if (this.emitted[ev]) {
      return false;
    }
    this.emitted[ev] = true;
    let ret = false;
    for (const fn of this.listeners[ev]) {
      ret = fn(code, signal) === true || ret;
    }
    if (ev === "exit") {
      ret = this.emit("afterExit", code, signal) || ret;
    }
    return ret;
  }
};
var SignalExitBase = class {
};
var signalExitWrap = (handler) => {
  return {
    onExit(cb, opts) {
      return handler.onExit(cb, opts);
    },
    load() {
      return handler.load();
    },
    unload() {
      return handler.unload();
    }
  };
};
var SignalExitFallback = class extends SignalExitBase {
  onExit() {
    return () => {
    };
  }
  load() {
  }
  unload() {
  }
};
var SignalExit = class extends SignalExitBase {
  // "SIGHUP" throws an `ENOSYS` error on Windows,
  // so use a supported signal instead
  /* c8 ignore start */
  #hupSig = process2.platform === "win32" ? "SIGINT" : "SIGHUP";
  /* c8 ignore stop */
  #emitter = new Emitter();
  #process;
  #originalProcessEmit;
  #originalProcessReallyExit;
  #sigListeners = {};
  #loaded = false;
  constructor(process3) {
    super();
    this.#process = process3;
    this.#sigListeners = {};
    for (const sig of signals) {
      this.#sigListeners[sig] = () => {
        const listeners = this.#process.listeners(sig);
        let { count } = this.#emitter;
        const p = process3;
        if (typeof p.__signal_exit_emitter__ === "object" && typeof p.__signal_exit_emitter__.count === "number") {
          count += p.__signal_exit_emitter__.count;
        }
        if (listeners.length === count) {
          this.unload();
          const ret = this.#emitter.emit("exit", null, sig);
          const s = sig === "SIGHUP" ? this.#hupSig : sig;
          if (!ret)
            process3.kill(process3.pid, s);
        }
      };
    }
    this.#originalProcessReallyExit = process3.reallyExit;
    this.#originalProcessEmit = process3.emit;
  }
  onExit(cb, opts) {
    if (!processOk(this.#process)) {
      return () => {
      };
    }
    if (this.#loaded === false) {
      this.load();
    }
    const ev = opts?.alwaysLast ? "afterExit" : "exit";
    this.#emitter.on(ev, cb);
    return () => {
      this.#emitter.removeListener(ev, cb);
      if (this.#emitter.listeners["exit"].length === 0 && this.#emitter.listeners["afterExit"].length === 0) {
        this.unload();
      }
    };
  }
  load() {
    if (this.#loaded) {
      return;
    }
    this.#loaded = true;
    this.#emitter.count += 1;
    for (const sig of signals) {
      try {
        const fn = this.#sigListeners[sig];
        if (fn)
          this.#process.on(sig, fn);
      } catch (_) {
      }
    }
    this.#process.emit = (ev, ...a) => {
      return this.#processEmit(ev, ...a);
    };
    this.#process.reallyExit = (code) => {
      return this.#processReallyExit(code);
    };
  }
  unload() {
    if (!this.#loaded) {
      return;
    }
    this.#loaded = false;
    signals.forEach((sig) => {
      const listener = this.#sigListeners[sig];
      if (!listener) {
        throw new Error("Listener not defined for signal: " + sig);
      }
      try {
        this.#process.removeListener(sig, listener);
      } catch (_) {
      }
    });
    this.#process.emit = this.#originalProcessEmit;
    this.#process.reallyExit = this.#originalProcessReallyExit;
    this.#emitter.count -= 1;
  }
  #processReallyExit(code) {
    if (!processOk(this.#process)) {
      return 0;
    }
    this.#process.exitCode = code || 0;
    this.#emitter.emit("exit", this.#process.exitCode, null);
    return this.#originalProcessReallyExit.call(this.#process, this.#process.exitCode);
  }
  #processEmit(ev, ...args) {
    const og = this.#originalProcessEmit;
    if (ev === "exit" && processOk(this.#process)) {
      if (typeof args[0] === "number") {
        this.#process.exitCode = args[0];
      }
      const ret = og.call(this.#process, ev, ...args);
      this.#emitter.emit("exit", this.#process.exitCode, null);
      return ret;
    } else {
      return og.call(this.#process, ev, ...args);
    }
  }
};
var process2 = globalThis.process;
var {
  /**
   * Called when the process is exiting, whether via signal, explicit
   * exit, or running out of stuff to do.
   *
   * If the global process object is not suitable for instrumentation,
   * then this will be a no-op.
   *
   * Returns a function that may be used to unload signal-exit.
   */
  onExit,
  /**
   * Load the listeners.  Likely you never need to call this, unless
   * doing a rather deep integration with signal-exit functionality.
   * Mostly exposed for the benefit of testing.
   *
   * @internal
   */
  load: load2,
  /**
   * Unload the listeners.  Likely you never need to call this, unless
   * doing a rather deep integration with signal-exit functionality.
   * Mostly exposed for the benefit of testing.
   *
   * @internal
   */
  unload
} = signalExitWrap(processOk(process2) ? new SignalExit(process2) : new SignalExitFallback());

// ../../node_modules/.vlt/~npm~foreground-child@3.3.1/node_modules/foreground-child/dist/esm/all-signals.js
import constants from "node:constants";
var allSignals = (
  // this is the full list of signals that Node will let us do anything with
  Object.keys(constants).filter((k) => k.startsWith("SIG") && // https://github.com/tapjs/signal-exit/issues/21
  k !== "SIGPROF" && // no sense trying to listen for SIGKILL, it's impossible
  k !== "SIGKILL")
);

// ../../node_modules/.vlt/~npm~foreground-child@3.3.1/node_modules/foreground-child/dist/esm/proxy-signals.js
var proxySignals = (child) => {
  const listeners = /* @__PURE__ */ new Map();
  for (const sig of allSignals) {
    const listener = () => {
      try {
        child.kill(sig);
      } catch (_) {
      }
    };
    try {
      process.on(sig, listener);
      listeners.set(sig, listener);
    } catch (_) {
    }
  }
  const unproxy = () => {
    for (const [sig, listener] of listeners) {
      process.removeListener(sig, listener);
    }
  };
  child.on("exit", unproxy);
  return unproxy;
};

// ../../node_modules/.vlt/~npm~foreground-child@3.3.1/node_modules/foreground-child/dist/esm/watchdog.js
import { spawn } from "node:child_process";
var watchdogCode = String.raw`
const pid = parseInt(process.argv[1], 10)
process.title = 'node (foreground-child watchdog pid=' + pid + ')'
if (!isNaN(pid)) {
  let barked = false
  // keepalive
  const interval = setInterval(() => {}, 60000)
  const bark = () => {
    clearInterval(interval)
    if (barked) return
    barked = true
    process.removeListener('SIGHUP', bark)
    setTimeout(() => {
      try {
        process.kill(pid, 'SIGKILL')
        setTimeout(() => process.exit(), 200)
      } catch (_) {}
    }, 500)
  })
  process.on('SIGHUP', bark)
}
`;
var watchdog = (child) => {
  let dogExited = false;
  const dog = spawn(process.execPath, ["-e", watchdogCode, String(child.pid)], {
    stdio: "ignore"
  });
  dog.on("exit", () => dogExited = true);
  child.on("exit", () => {
    if (!dogExited)
      dog.kill("SIGKILL");
  });
  return dog;
};

// ../../node_modules/.vlt/~npm~foreground-child@3.3.1/node_modules/foreground-child/dist/esm/index.js
var spawn2 = process?.platform === "win32" ? import_cross_spawn.default : nodeSpawn;
var normalizeFgArgs = (fgArgs) => {
  let [program, args = [], spawnOpts = {}, cleanup = () => {
  }] = fgArgs;
  if (typeof args === "function") {
    cleanup = args;
    spawnOpts = {};
    args = [];
  } else if (!!args && typeof args === "object" && !Array.isArray(args)) {
    if (typeof spawnOpts === "function")
      cleanup = spawnOpts;
    spawnOpts = args;
    args = [];
  } else if (typeof spawnOpts === "function") {
    cleanup = spawnOpts;
    spawnOpts = {};
  }
  if (Array.isArray(program)) {
    const [pp, ...pa] = program;
    program = pp;
    args = pa;
  }
  return [program, args, { ...spawnOpts }, cleanup];
};
function foregroundChild(...fgArgs) {
  const [program, args, spawnOpts, cleanup] = normalizeFgArgs(fgArgs);
  spawnOpts.stdio = [0, 1, 2];
  if (process.send) {
    spawnOpts.stdio.push("ipc");
  }
  const child = spawn2(program, args, spawnOpts);
  const childHangup = () => {
    try {
      child.kill("SIGHUP");
    } catch (_) {
      child.kill("SIGTERM");
    }
  };
  const removeOnExit = onExit(childHangup);
  proxySignals(child);
  const dog = watchdog(child);
  let done = false;
  child.on("close", async (code, signal) => {
    if (done)
      return;
    done = true;
    const result = cleanup(code, signal, {
      watchdogPid: dog.pid
    });
    const res = isPromise(result) ? await result : result;
    removeOnExit();
    if (res === false)
      return;
    else if (typeof res === "string") {
      signal = res;
      code = null;
    } else if (typeof res === "number") {
      code = res;
      signal = null;
    }
    if (signal) {
      setTimeout(() => {
      }, 2e3);
      try {
        process.kill(process.pid, signal);
      } catch (_) {
        process.kill(process.pid, "SIGTERM");
      }
    } else {
      process.exit(code || 0);
    }
  });
  if (process.send) {
    process.removeAllListeners("message");
    child.on("message", (message, sendHandle) => {
      process.send?.(message, sendHandle);
    });
    process.on("message", (message, sendHandle) => {
      child.send(message, sendHandle);
    });
  }
  return child;
}
var isPromise = (o) => !!o && typeof o === "object" && typeof o.then === "function";

// ../../src/run/src/index.ts
import { statSync as statSync2 } from "node:fs";
import { delimiter, resolve as resolve2, sep } from "node:path";

// ../../src/run/src/node-gyp.ts
import { statSync } from "node:fs";
import { chmod, mkdir, stat, writeFile } from "node:fs/promises";
import { dirname, join } from "node:path";
var xdg = new XDG("vlt");
var shimPath;
async function getNodeGypShim() {
  if (shimPath) return shimPath;
  const runtimeDir = xdg.runtime("run");
  const shimFile = join(runtimeDir, "node-gyp");
  try {
    await stat(shimFile);
    shimPath = shimFile;
    return shimPath;
  } catch {
  }
  await mkdir(runtimeDir, { recursive: true });
  const shimContent = process.platform === "win32" ? `@echo off
vlx --yes node-gyp@latest %*
` : `#!/bin/sh
exec vlx --yes node-gyp@latest "$@"
`;
  await writeFile(shimFile, shimContent, "utf8");
  if (process.platform !== "win32") {
    await chmod(shimFile, 493);
  }
  shimPath = shimFile;
  return shimPath;
}
async function getNodeGypShimDir() {
  const shim = await getNodeGypShim();
  return dirname(shim);
}
function hasNodeGypReference(command) {
  return command.includes("node-gyp");
}
function hasNodeGypBinding(cwd) {
  try {
    return statSync(join(cwd, "binding.gyp")).isFile();
  } catch {
    return false;
  }
}

// ../../src/run/src/index.ts
var dotBins = /* @__PURE__ */ new Map();
var dirExists = (p) => {
  const cached = dotBins.get(p);
  if (cached !== void 0) return cached;
  try {
    const isDir = statSync2(p).isDirectory();
    dotBins.set(p, isDir);
    return isDir;
  } catch {
    dotBins.set(p, false);
    return false;
  }
};
var nmBin = `${sep}node_modules${sep}.bin`;
var addPaths = async (projectRoot, cwd, env2, command) => {
  const { PATH = "" } = env2;
  const PATHsplit = PATH.split(delimiter);
  const paths2 = /* @__PURE__ */ new Set();
  for (const p of PATHsplit) {
    if (p.endsWith(nmBin)) {
      paths2.add(p);
    }
  }
  for (const p of walkUp(cwd)) {
    const dotBin = resolve2(p, "node_modules/.bin");
    if (dirExists(dotBin)) paths2.add(dotBin);
    if (p === projectRoot) break;
  }
  for (const p of PATH.split(delimiter)) {
    if (p) paths2.add(p);
  }
  if (command && hasNodeGypReference(command)) {
    try {
      const shimDir = await getNodeGypShimDir();
      paths2.add(shimDir);
    } catch {
    }
  }
  env2.PATH = [...paths2].join(delimiter);
  return env2;
};
var run = async (options) => runImpl(options, exec, "");
var runFG = async (options) => runImpl(options, execFG, null);
var isRunResult = (v) => !!v && typeof v === "object" && !Array.isArray(v) && "stdout" in v && "stderr" in v && "status" in v && "signal" in v;
var runImpl = async (options, execImpl, empty2) => {
  const {
    arg0,
    packageJson = new PackageJson(),
    ignoreMissing = false,
    manifest,
    "script-shell": shell2 = true,
    ...execArgs
  } = options;
  const pjPath = resolve2(options.cwd, "package.json");
  const untrustworthy = !!(manifest?.gypfile && arg0 === "install" && manifest.scripts?.install === "node-gyp rebuild");
  const pj = (untrustworthy ? void 0 : manifest) ?? packageJson.read(options.cwd);
  const { scripts: scripts2 } = pj;
  const command = scripts2?.[arg0] ?? // npm's implicit install behavior: "If there is a binding.gyp file in the
  // root of your package and you haven't defined your own install or preinstall
  // scripts, npm will default the install command to compile using node-gyp
  // via node-gyp rebuild"
  (arg0 === "install" && !scripts2?.install && !scripts2?.preinstall && hasNodeGypBinding(options.cwd) ? "node-gyp rebuild" : void 0);
  const precommand = !options.ignorePrePost && scripts2?.[`pre${arg0}`];
  const postcommand = !options.ignorePrePost && scripts2?.[`post${arg0}`];
  const emptyResult = () => ({
    command: "",
    args: execArgs.args ?? [],
    cwd: options.cwd,
    status: 0,
    signal: null,
    stdout: empty2,
    stderr: empty2
  });
  const execCommand = (command2, preOrPost) => execImpl({
    arg0: command2,
    ...execArgs,
    "script-shell": shell2,
    // pre/post scripts always have empty args, main script uses execArgs.args
    args: preOrPost ? [] : execArgs.args ?? [],
    env: {
      ...execArgs.env,
      npm_package_json: pjPath,
      npm_lifecycle_event: `${preOrPost ?? ""}${arg0}`,
      npm_lifecycle_script: command2
    }
  });
  if (!command && !precommand && !postcommand) {
    if (ignoreMissing) {
      return emptyResult();
    }
    throw error("Script not defined in package.json", {
      name: arg0,
      cwd: options.cwd,
      args: options.args,
      path: pjPath,
      manifest: pj
    });
  }
  const pre = precommand ? await execCommand(precommand, "pre") : void 0;
  if (pre?.status || pre?.signal) {
    return {
      ...pre
    };
  }
  const main = command ? await execCommand(command) : emptyResult();
  if (main.signal || main.status) {
    return {
      ...main,
      ...pre ? { pre } : {}
    };
  }
  const post = postcommand ? await execCommand(postcommand, "post") : void 0;
  if (post?.signal || post?.status) {
    return {
      ...main,
      ...pre ? { pre } : {},
      post,
      signal: post.signal,
      status: post.status
    };
  }
  return {
    ...main,
    ...pre ? { pre } : {},
    ...post ? { post } : {}
  };
};
var shellEscape = (s) => `'${s.replace(/'/g, "'\\''")}'`;
var isPosixShell = (shell2) => {
  if (typeof shell2 === "string")
    return !/(^|\\)cmd\.exe$/i.test(shell2);
  return process.platform !== "win32";
};
var withShellArgs = (shell2, arg0, args) => {
  if (!shell2 || args.length === 0 || !isPosixShell(shell2))
    return [arg0, args];
  return [`${arg0} ${args.map(shellEscape).join(" ")}`, []];
};
var exec = async (options) => {
  const {
    arg0,
    args = [],
    cwd,
    env: env2 = {},
    projectRoot,
    "script-shell": shell2 = false,
    color = false,
    signal,
    ...spawnOptions
  } = options;
  const [spawnCmd, spawnArgs] = withShellArgs(shell2, arg0, args);
  const p = promiseSpawn(spawnCmd, spawnArgs, {
    ...spawnOptions,
    shell: shell2,
    stdio: "pipe",
    stdioString: true,
    cwd,
    env: await addPaths(
      projectRoot,
      cwd,
      {
        ...process.env,
        ...env2,
        FORCE_COLOR: color ? "1" : "0"
      },
      arg0
    ),
    windowsHide: true
  });
  proxySignals(p.process);
  return await p;
};
var execFG = async (options) => {
  const {
    arg0,
    args = [],
    cwd,
    projectRoot,
    env: env2 = {},
    "script-shell": shell2 = false,
    color = true,
    signal,
    ...spawnOptions
  } = options;
  const [spawnCmd, spawnArgs] = withShellArgs(shell2, arg0, args);
  const processEnv = await addPaths(
    projectRoot,
    cwd,
    {
      ...process.env,
      ...env2,
      FORCE_COLOR: color ? "1" : "0"
    },
    arg0
  );
  return new Promise((res) => {
    foregroundChild(
      spawnCmd,
      spawnArgs,
      {
        ...spawnOptions,
        shell: shell2,
        cwd,
        env: processEnv
      },
      (status, signal2) => {
        res({
          command: arg0,
          args,
          cwd,
          stdout: null,
          stderr: null,
          status,
          signal: signal2
        });
        return false;
      }
    );
  });
};
var runExecImpl = async (options, runImpl2, execImpl) => {
  const { arg0, packageJson = new PackageJson(), ...args } = options;
  const pj = packageJson.read(options.cwd);
  const { scripts: scripts2 } = pj;
  const command = scripts2?.[arg0];
  if (command) {
    return runImpl2({ ...args, packageJson, arg0 });
  } else {
    return execImpl({ ...args, arg0 });
  }
};
var runExec = async (options) => runExecImpl(options, run, exec);
var runExecFG = async (options) => runExecImpl(options, runFG, execFG);

// ../../src/dss-parser/src/index.ts
var import_postcss_selector_parser = __toESM(require_dist(), 1);

// ../../src/dss-parser/src/types.ts
var isPostcssNodeWithChildren = (node) => "type" in node && "nodes" in node;
var asPostcssNodeWithChildren = (node) => {
  if (!node) {
    throw error("Expected a query node");
  }
  if (!isPostcssNodeWithChildren(node)) {
    throw error("Not a query selector node with children", {
      found: node
    });
  }
  return node;
};
var isObj = (o) => !!o && typeof o === "object";
var isAttributeNode = (node) => isObj(node) && !!node.attribute && node.type === "attribute";
var asAttributeNode = (node) => {
  if (!node) {
    throw error("Expected a query node");
  }
  if (!isAttributeNode(node)) {
    throw error("Mismatching query node", {
      wanted: "attribute",
      found: node.type
    });
  }
  return node;
};
var isCombinatorNode = (node) => isObj(node) && !!node.value && node.type === "combinator";
var asCombinatorNode = (node) => {
  if (!node) {
    throw error("Expected a query node");
  }
  if (!isCombinatorNode(node)) {
    throw error("Mismatching query node", {
      wanted: "combinator",
      found: node.type
    });
  }
  return node;
};
var isIdentifierNode = (node) => isObj(node) && !!node.value && node.type === "id";
var asIdentifierNode = (node) => {
  if (!node) {
    throw error("Expected a query node");
  }
  if (!isIdentifierNode(node)) {
    throw error("Mismatching query node", {
      wanted: "id",
      found: node.type
    });
  }
  return node;
};
var isSelectorNode = (node) => isPostcssNodeWithChildren(node) && node.type === "selector";
var asSelectorNode = (node) => {
  if (!node) {
    throw error("Expected a query node");
  }
  if (!isSelectorNode(node)) {
    throw error("Mismatching query node", {
      wanted: "selector",
      found: node.type
    });
  }
  return node;
};
var isPseudoNode = (node) => isObj(node) && !!node.value && node.type === "pseudo";
var asPseudoNode = (node) => {
  if (!node) {
    throw error("Expected a query node");
  }
  if (!isPseudoNode(node)) {
    throw error("Mismatching query node", {
      wanted: "pseudo",
      found: node.type
    });
  }
  return node;
};
var isTagNode = (node) => isObj(node) && !!node.value && node.type === "tag";
var asTagNode = (node) => {
  if (!node) {
    throw error("Expected a query node");
  }
  if (!isTagNode(node)) {
    throw error("Mismatching query node", {
      wanted: "tag",
      found: node.type
    });
  }
  return node;
};
var isStringNode = (node) => isObj(node) && !!node.value && node.type === "string";
var asStringNode = (node) => {
  if (!node) {
    throw error("Expected a query node");
  }
  if (!isStringNode(node)) {
    throw error("Mismatching query node", {
      wanted: "string",
      found: node.type
    });
  }
  return node;
};
var isCommentNode = (node) => isObj(node) && !!node.value && node.type === "comment";

// ../../src/dss-parser/src/index.ts
var escapeScopedNamesSlashes = (query) => query.replace(
  /(#@(\w|-|\.)+)\//gm,
  (_, scope2) => `${scope2}\\/`
);
var escapeDots = (query) => query.replaceAll(".", "\\.");
var unescapeDots = (query) => query.replaceAll("\\.", ".");
var pseudoCleanUpNeeded = /* @__PURE__ */ new Set([
  ":published",
  ":score",
  ":malware",
  ":severity",
  ":sev",
  ":squat",
  ":semver",
  ":v"
]);
var hasParamsToEscape = (node) => pseudoCleanUpNeeded.has(node.value);
var parse2 = (query) => {
  const escapedQuery = escapeDots(escapeScopedNamesSlashes(query));
  const transformAst = (root2) => {
    root2.walk((node) => {
      if (node.value && typeof node.value === "string") {
        node.value = unescapeDots(node.value);
      }
      if (isPseudoNode(node) && hasParamsToEscape(node)) {
        for (const n of node.nodes) {
          const selector = asSelectorNode(n);
          selector.nodes.forEach((currentNode, index, arr) => {
            const nextNode = arr[index + 1];
            if (isCombinatorNode(currentNode) && isTagNode(nextNode)) {
              nextNode.value = `${currentNode.spaces.before}${currentNode.value}${currentNode.spaces.after}${nextNode.value}`;
              if (nextNode.source?.start?.line && currentNode.source?.start?.line) {
                nextNode.source.start.line = currentNode.source.start.line;
              }
              if (nextNode.source?.start?.column && currentNode.source?.start?.column) {
                nextNode.source.start.column = currentNode.source.start.column;
              }
              arr.splice(index, 1);
            }
          });
          selector.nodes.reduce((acc, currentNode) => {
            if (currentNode === acc) return acc;
            acc.value = `${acc.value}${currentNode.spaces.before}${currentNode.value}${currentNode.spaces.after}`;
            if (currentNode.source?.end?.line && acc.source?.end?.line) {
              acc.source.end.line = currentNode.source.end.line;
            }
            if (currentNode.source?.end?.column && acc.source?.end?.column) {
              acc.source.end.column = currentNode.source.end.column;
            }
            return acc;
          }, selector.first);
          selector.nodes.length = 1;
        }
      }
    });
  };
  return (0, import_postcss_selector_parser.default)(transformAst).astSync(escapedQuery);
};

// ../../src/query/src/pseudo/helpers.ts
var removeNode = (state, node) => {
  for (const edge of node.edgesIn) {
    state.partial.edges.delete(edge);
  }
  state.partial.nodes.delete(node);
};
var removeEdge = (state, edge) => {
  state.partial.edges.delete(edge);
  if (edge.to?.edgesIn.size === 1) {
    state.partial.nodes.delete(edge.to);
  }
};
var removeDanglingEdges = (state) => {
  for (const edge of state.partial.edges) {
    if (!edge.to || !state.partial.nodes.has(edge.to)) {
      state.partial.edges.delete(edge);
    }
  }
};
var removeUnlinkedNodes = (state) => {
  nodeLoop: for (const node of state.partial.nodes) {
    for (const edge of state.partial.edges) {
      if (edge.to === node) {
        continue nodeLoop;
      }
    }
    state.partial.nodes.delete(node);
  }
};
var removeQuotes = (value) => value.replace(/^"(.*?)"$/, "$1");
var assertSecurityArchive = (state, name) => {
  if (!state.securityArchive) {
    throw error(
      `Missing security archive while trying to parse the :${name} selector`,
      { found: state }
    );
  }
};
var clear = (state) => {
  state.partial.nodes.clear();
  state.partial.edges.clear();
  return state;
};
var createSecuritySelectorFilter = (name, type2) => {
  return async (state) => {
    assertSecurityArchive(state, name);
    for (const node of state.partial.nodes) {
      const report = state.securityArchive.get(node.id);
      const exclude = !report?.alerts.some(
        (alert) => alert.type === type2
      );
      if (exclude) {
        removeNode(state, node);
      }
    }
    removeDanglingEdges(state);
    return state;
  };
};

// ../../src/query/src/attribute.ts
var jsonFieldToString = (v) => String(v);
var getManifestPropertyValues = (node, properties, attribute2) => {
  if (!node.manifest) return;
  const traverse = /* @__PURE__ */ new Set([node.manifest]);
  const props = /* @__PURE__ */ new Set();
  for (const key of properties) {
    for (const prop of traverse) {
      if (!prop) {
        throw error("failed to find nested property in :attr", {
          found: properties
        });
      }
      if (Array.isArray(prop)) {
        for (const p of prop) {
          traverse.add(p);
        }
        continue;
      }
      if (typeof prop === "string" || typeof prop === "number" || typeof prop === "boolean") {
        continue;
      }
      if (key in prop) {
        const nextValue = prop[key];
        if (nextValue) {
          if (key === attribute2) {
            props.add(nextValue);
          } else {
            traverse.delete(prop);
            traverse.add(nextValue);
          }
        }
      }
    }
  }
  if (!props.size) return;
  const collect = /* @__PURE__ */ new Set();
  for (const prop of props) {
    if (Array.isArray(prop)) {
      for (const p of prop) {
        collect.add(p ? jsonFieldToString(p) : "");
      }
    } else {
      collect.add(jsonFieldToString(prop));
    }
  }
  return [...collect];
};
var filterAttributes = (state, comparator, value, propertyName, insensitive, prefixProperties = []) => {
  const check = (attr2) => comparator?.(
    insensitive ? jsonFieldToString(attr2).toLowerCase() : jsonFieldToString(attr2),
    insensitive ? value.toLowerCase() : value
  );
  const deleteNode = (node) => {
    for (const edge of node.edgesIn) {
      state.partial.edges.delete(edge);
    }
    state.partial.nodes.delete(node);
  };
  for (const node of state.partial.nodes) {
    const prefixes = prefixProperties.length ? prefixProperties : [propertyName];
    const attrs = getManifestPropertyValues(
      node,
      prefixes,
      propertyName
    );
    if (!attrs?.length) {
      deleteNode(node);
      continue;
    }
    if (comparator && !attrs.some(check)) {
      deleteNode(node);
    }
  }
  removeDanglingEdges(state);
  return state;
};
var attributeSelectors = {
  "=": (attr2, value = "") => attr2 === value,
  "^=": (attr2, value = "") => attr2.startsWith(value),
  "$=": (attr2, value = "") => attr2.endsWith(value),
  "~=": (attr2, value = "") => new Set(attr2.match(/\w+/g)).has(value),
  "*=": (attr2, value = "") => attr2.includes(value),
  "|=": (attr2, value = "") => attr2 === value || attr2.startsWith(`${value}-`),
  undefined: (attr2) => !!attr2
};
var attributeSelectorsMap = new Map(
  Object.entries(attributeSelectors)
);
var attribute = async (state) => {
  await state.cancellable();
  const curr = asAttributeNode(state.current);
  const operatorFn = attributeSelectorsMap.get(String(curr.operator));
  if (!operatorFn) {
    if (state.loose) {
      return state;
    }
    throw error(`Unsupported attribute operator: ${curr.operator}`, {
      found: state.current
    });
  }
  const value = curr.value || "";
  const propertyName = curr.attribute;
  const insensitive = !!curr.insensitive;
  state.specificity.commonCounter += 1;
  return filterAttributes(
    state,
    operatorFn,
    value,
    propertyName,
    insensitive
  );
};

// ../../src/query/src/combinator.ts
var childCombinator = async (state) => {
  const traverse = new Set(state.partial.nodes);
  state.partial.edges.clear();
  state.partial.nodes.clear();
  for (const node of traverse) {
    for (const edge of node.edgesOut.values()) {
      if (edge.to) {
        state.partial.edges.add(edge);
        state.partial.nodes.add(edge.to);
      }
    }
  }
  return state;
};
var subsequentSiblingCombinator = async (state) => {
  const traverse = new Set(state.partial.nodes);
  state.partial.edges.clear();
  state.partial.nodes.clear();
  for (const node of traverse) {
    for (const edge of node.edgesIn) {
      const parents = edge.from.edgesOut.values();
      for (const edge2 of parents) {
        if (edge2.to && edge2.to !== node) {
          state.partial.edges.add(edge2);
          state.partial.nodes.add(edge2.to);
        }
      }
    }
  }
  return state;
};
var descendentCombinator = async (state) => {
  if (state.prev?.type === "tag" || state.next?.type === "tag") {
    return state;
  }
  const traverse = new Set(state.partial.nodes);
  state.partial.edges.clear();
  state.partial.nodes.clear();
  for (const node of traverse) {
    const children = /* @__PURE__ */ new Set();
    for (const edge of node.edgesOut.values()) {
      if (edge.to) {
        children.add(edge.to);
        state.partial.edges.add(edge);
        state.partial.nodes.add(edge.to);
      }
    }
    for (const child of children) {
      traverse.add(child);
    }
  }
  return state;
};
var combinatorSelectors = {
  ">": childCombinator,
  "~": subsequentSiblingCombinator,
  " ": descendentCombinator
};
var combinatorSelectorsMap = new Map(
  Object.entries(combinatorSelectors)
);
var combinator = async (state) => {
  await state.cancellable();
  const curr = asCombinatorNode(state.current);
  const parserFn = curr.value && combinatorSelectorsMap.get(curr.value);
  if (!parserFn) {
    if (state.loose) {
      return state;
    }
    throw error(`Unsupported combinator: ${state.current.value}`, {
      found: state.current
    });
  }
  return parserFn(state);
};

// ../../src/query/src/id.ts
var id = async (state) => {
  const { value } = asIdentifierNode(state.current);
  if (!value) {
    throw error("Missing identifier name");
  }
  for (const edge of state.partial.edges) {
    if (edge.name !== value) {
      state.partial.edges.delete(edge);
      if (edge.to) {
        state.partial.nodes.delete(edge.to);
      }
    }
  }
  for (const node of state.partial.nodes) {
    if (node.edgesIn.size === 0 && node.name !== value && state.partial.nodes.has(node)) {
      state.partial.nodes.delete(node);
    }
  }
  state.specificity.idCounter += 1;
  return state;
};

// ../../src/query/src/pseudo/abandoned.ts
var abandoned = createSecuritySelectorFilter(
  "abandoned",
  "missingAuthor"
);

// ../../src/query/src/pseudo/attr.ts
var parseInternals = (nodes) => {
  const attributeSelector = asAttributeNode(
    asPostcssNodeWithChildren(nodes.pop()).nodes[0]
  );
  const properties = [];
  for (const selector of nodes) {
    const selectorNode = asPostcssNodeWithChildren(selector).nodes[0];
    if (isStringNode(selectorNode)) {
      properties.push(removeQuotes(asStringNode(selectorNode).value));
    } else {
      properties.push(asTagNode(selectorNode).value);
    }
  }
  properties.push(attributeSelector.attribute);
  return {
    attribute: attributeSelector.attribute,
    insensitive: attributeSelector.insensitive || false,
    operator: attributeSelector.operator,
    value: attributeSelector.value,
    properties
  };
};
var attr = async (state) => {
  let internals;
  try {
    internals = parseInternals(
      asPostcssNodeWithChildren(state.current).nodes
    );
  } catch (err) {
    throw error("Failed to parse :attr selector", {
      cause: err
    });
  }
  const comparator = internals.operator ? attributeSelectorsMap.get(internals.operator) : void 0;
  const value = internals.value || "";
  const propertyName = internals.attribute;
  const insensitive = internals.insensitive;
  const prefixProperties = internals.properties;
  return filterAttributes(
    state,
    comparator,
    value,
    propertyName,
    insensitive,
    prefixProperties
  );
};

// ../../src/query/src/pseudo/built.ts
var built = async (state) => {
  for (const node of state.partial.nodes) {
    if (node.buildState !== "built") {
      removeNode(state, node);
    }
  }
  removeDanglingEdges(state);
  return state;
};

// ../../src/query/src/pseudo/confused.ts
var confused = async (state) => {
  assertSecurityArchive(state, "confused");
  for (const node of state.partial.nodes) {
    const report = state.securityArchive.get(node.id);
    const exclude = !node.confused && !report?.alerts.some(
      (alert) => alert.type === "manifestConfusion"
    );
    if (exclude) {
      removeNode(state, node);
    }
  }
  removeDanglingEdges(state);
  return state;
};

// ../../src/query/src/pseudo/cve.ts
var parseInternals2 = (nodes) => {
  let cveId = "";
  if (isStringNode(asPostcssNodeWithChildren(nodes[0]).nodes[0])) {
    cveId = removeQuotes(
      asStringNode(asPostcssNodeWithChildren(nodes[0]).nodes[0]).value
    );
  } else if (isTagNode(asPostcssNodeWithChildren(nodes[0]).nodes[0])) {
    cveId = asTagNode(
      asPostcssNodeWithChildren(nodes[0]).nodes[0]
    ).value;
  }
  if (!cveId) {
    throw error("Expected a CVE ID", {
      found: asPostcssNodeWithChildren(nodes[0]).nodes[0]
    });
  }
  return { cveId };
};
var cve = async (state) => {
  assertSecurityArchive(state, "cve");
  let internals;
  try {
    internals = parseInternals2(
      asPostcssNodeWithChildren(state.current).nodes
    );
  } catch (err) {
    throw error("Failed to parse :cve selector", { cause: err });
  }
  const { cveId } = internals;
  for (const node of state.partial.nodes) {
    const report = state.securityArchive.get(node.id);
    const exclude = !report?.alerts.some(
      (alert) => alert.props?.cveId?.trim().toLowerCase() === cveId.trim().toLowerCase()
    );
    if (exclude) {
      removeNode(state, node);
    }
  }
  removeDanglingEdges(state);
  return state;
};

// ../../src/query/src/pseudo/cwe.ts
var parseInternals3 = (nodes) => {
  let cweId = "";
  if (isStringNode(asPostcssNodeWithChildren(nodes[0]).nodes[0])) {
    cweId = removeQuotes(
      asStringNode(asPostcssNodeWithChildren(nodes[0]).nodes[0]).value
    );
  } else if (isTagNode(asPostcssNodeWithChildren(nodes[0]).nodes[0])) {
    cweId = asTagNode(
      asPostcssNodeWithChildren(nodes[0]).nodes[0]
    ).value;
  }
  if (!cweId) {
    throw error("Expected a CWE ID", {
      found: asPostcssNodeWithChildren(nodes[0]).nodes[0]
    });
  }
  return { cweId };
};
var cwe = async (state) => {
  assertSecurityArchive(state, "cwe");
  let internals;
  try {
    internals = parseInternals3(
      asPostcssNodeWithChildren(state.current).nodes
    );
  } catch (err) {
    throw error("Failed to parse :cwe selector", { cause: err });
  }
  const { cweId } = internals;
  for (const node of state.partial.nodes) {
    const report = state.securityArchive.get(node.id);
    const exclude = !report?.alerts.some(
      (alert) => alert.props?.cwes?.some(
        (cwe2) => cwe2.id.trim().toLowerCase() === cweId.trim().toLowerCase()
      )
    );
    if (exclude) {
      removeNode(state, node);
    }
  }
  removeDanglingEdges(state);
  return state;
};

// ../../src/query/src/pseudo/debug.ts
var debug = createSecuritySelectorFilter(
  "debug",
  "debugAccess"
);

// ../../src/query/src/pseudo/deprecated.ts
var deprecated = createSecuritySelectorFilter(
  "deprecated",
  "deprecated"
);

// ../../src/query/src/pseudo/dev.ts
var dev = async (state) => {
  for (const edge of state.partial.edges) {
    if (edge.type !== "dev") {
      removeEdge(state, edge);
    }
  }
  removeUnlinkedNodes(state);
  return state;
};

// ../../src/query/src/pseudo/spec.ts
var parseInternals4 = (nodes) => {
  let specValue = "";
  if (nodes.length === 0) {
    throw new Error("No nodes provided to parseInternals");
  }
  const firstNode = asPostcssNodeWithChildren(nodes[0]);
  if (firstNode.nodes.length === 0) {
    throw new Error("First node has no child nodes");
  }
  if (firstNode.nodes.length === 1) {
    const targetNode = firstNode.nodes[0];
    try {
      specValue = removeQuotes(asStringNode(targetNode).value);
      return { specValue };
    } catch (err) {
      if (asError(err).message === "Mismatching query node" && isTagNode(targetNode)) {
        const tagNode = asTagNode(targetNode);
        specValue = tagNode.value;
        return { specValue };
      } else {
        throw err;
      }
    }
  }
  const parts = [];
  for (const node of firstNode.nodes) {
    switch (node.type) {
      case "tag":
        parts.push(asTagNode(node).value);
        break;
      case "class":
        parts.push("." + node.value);
        break;
      case "id":
        parts.push("#" + node.value);
        break;
      case "string":
        parts.push(removeQuotes(asStringNode(node).value));
        break;
      default:
        parts.push(node.value ?? String(node));
        break;
    }
  }
  specValue = parts.join("");
  return { specValue };
};
var spec = async (state) => {
  let internals;
  try {
    internals = parseInternals4(
      asPostcssNodeWithChildren(state.current).nodes
    );
  } catch (err) {
    throw error("Failed to parse :spec selector", {
      cause: err
    });
  }
  const { specValue } = internals;
  for (const edge of state.partial.edges) {
    if (edge.spec.bareSpec !== specValue) {
      removeEdge(state, edge);
    }
  }
  removeUnlinkedNodes(state);
  return state;
};

// ../../src/query/src/pseudo/diff.ts
var packageHasChanges = (changedFiles, packageLocation) => {
  const normalized = packageLocation.startsWith("./") ? packageLocation.slice(2) : packageLocation;
  if (!normalized || normalized === ".") {
    return changedFiles.size > 0;
  }
  for (const file of changedFiles) {
    if (file === normalized || file.startsWith(normalized + "/")) {
      return true;
    }
  }
  return false;
};
var diff = async (state) => {
  const currentNodes = asPostcssNodeWithChildren(state.current).nodes;
  const hasArg = currentNodes.length > 0 && asPostcssNodeWithChildren(currentNodes[0]).nodes.length > 0;
  let commitish = "HEAD";
  if (hasArg) {
    try {
      commitish = parseInternals4(currentNodes).specValue;
    } catch (err) {
      throw error("Failed to parse :diff selector", {
        cause: err
      });
    }
  }
  if (!state.diffFiles) {
    throw error("The :diff() selector requires a diffFiles provider");
  }
  const changedFiles = state.diffFiles(commitish);
  for (const node of state.partial.nodes) {
    const location = node.location ?? "";
    if (!packageHasChanges(changedFiles, location)) {
      removeNode(state, node);
    }
  }
  removeDanglingEdges(state);
  return state;
};

// ../../src/query/src/pseudo/dynamic.ts
var dynamic = createSecuritySelectorFilter(
  "dynamic",
  "dynamicRequire"
);

// ../../src/query/src/pseudo/empty.ts
var empty = async (state) => {
  for (const node of state.partial.nodes) {
    if (node.edgesOut.size > 0) {
      removeNode(state, node);
    }
  }
  return state;
};

// ../../src/query/src/pseudo/entropic.ts
var entropic = createSecuritySelectorFilter(
  "entropic",
  "highEntropyStrings"
);

// ../../src/query/src/pseudo/env.ts
var env = createSecuritySelectorFilter("env", "envVars");

// ../../src/query/src/pseudo/eval.ts
var evalParser = createSecuritySelectorFilter(
  "eval",
  "usesEval"
);

// ../../src/query/src/pseudo/fs.ts
var fs = createSecuritySelectorFilter(
  "fs",
  "filesystemAccess"
);

// ../../src/query/src/pseudo/host.ts
var parseInternals5 = (nodes) => {
  let contextKey = "";
  if (isStringNode(asPostcssNodeWithChildren(nodes[0]).nodes[0])) {
    contextKey = removeQuotes(
      asStringNode(asPostcssNodeWithChildren(nodes[0]).nodes[0]).value
    );
  } else if (isTagNode(asPostcssNodeWithChildren(nodes[0]).nodes[0])) {
    const tagNode = asTagNode(
      asPostcssNodeWithChildren(nodes[0]).nodes[0]
    );
    contextKey = tagNode.value;
  }
  if (!contextKey) {
    throw error("Expected a context key parameter for :host selector");
  }
  return contextKey;
};
var hostContext = async (state) => {
  if (!state.hostContexts) {
    throw error("No host contexts available for :host selector");
  }
  let contextKey;
  try {
    contextKey = parseInternals5(
      asPostcssNodeWithChildren(state.current).nodes
    );
  } catch (err) {
    throw error("Failed to parse :host selector", {
      cause: err
    });
  }
  const contextFunction = state.hostContexts.get(contextKey);
  if (!contextFunction) {
    throw error(`Unknown host context: ${contextKey}`, {
      validOptions: Array.from(state.hostContexts.keys())
    });
  }
  const {
    initialEdges,
    initialNodes,
    edges,
    nodes,
    securityArchive
  } = await contextFunction();
  state.securityArchive = securityArchive;
  state.initial.nodes.clear();
  state.initial.edges.clear();
  state.partial.nodes.clear();
  state.partial.edges.clear();
  state.importers.clear();
  for (const node of initialNodes) {
    state.initial.nodes.add(node);
  }
  for (const edge of initialEdges) {
    state.initial.edges.add(edge);
  }
  for (const node of nodes) {
    state.partial.nodes.add(node);
    state.importers.add(node);
  }
  for (const edge of edges) {
    state.partial.edges.add(edge);
  }
  return state;
};

// ../../src/query/src/pseudo/hostname.ts
var resolveGitHostname = (namedHost, gitHosts) => {
  const website = gitHostWebsites[namedHost];
  if (website) {
    try {
      return new URL(website).hostname;
    } catch {
    }
  }
  const template = gitHosts[namedHost];
  if (template) {
    try {
      const normalized = template.replace(/^git\+/, "").replace(/:(\$)/, "/$1");
      return new URL(normalized).hostname;
    } catch {
    }
  }
  return void 0;
};
var getGitHostname = (gitRemote, gitHosts) => {
  const colonIdx = gitRemote.indexOf(":");
  if (colonIdx > 0) {
    const possibleHost = gitRemote.slice(0, colonIdx);
    if (possibleHost in gitHosts) {
      return resolveGitHostname(possibleHost, gitHosts);
    }
    try {
      const normalized = gitRemote.replace(/^git\+/, "").replace(/^ssh:\/\/([^@]+@)?([^:/]+)[:/]/, "ssh://$1$2/");
      return new URL(normalized).hostname;
    } catch {
    }
  }
  try {
    return new URL(gitRemote).hostname;
  } catch {
  }
  return void 0;
};
var hostname = async (state) => {
  let internals;
  try {
    internals = parseInternals4(
      asPostcssNodeWithChildren(state.current).nodes
    );
  } catch (err) {
    throw error("Failed to parse :hostname selector", {
      cause: err
    });
  }
  const targetHostname = internals.specValue;
  for (const node of state.partial.nodes) {
    const tuple = splitDepID(node.id);
    const type2 = tuple[0];
    let nodeHostname;
    switch (type2) {
      case "registry": {
        const registryName = tuple[1];
        const options = getOptions(node.options);
        const registryUrl = options.registries[registryName] ?? options.registry;
        if (registryUrl) {
          try {
            nodeHostname = new URL(registryUrl).hostname;
          } catch {
          }
        }
        break;
      }
      case "git": {
        const gitRemote = tuple[1];
        const options = getOptions(node.options);
        nodeHostname = getGitHostname(gitRemote, options["git-hosts"]);
        break;
      }
      case "remote": {
        const url = tuple[1];
        try {
          nodeHostname = new URL(url).hostname;
        } catch {
        }
        break;
      }
      // file and workspace deps are local — no hostname
      default: {
        nodeHostname = void 0;
        break;
      }
    }
    if (nodeHostname !== targetHostname) {
      removeNode(state, node);
    }
  }
  removeDanglingEdges(state);
  return state;
};

// ../../src/query/src/pseudo/license.ts
var kindsMap = /* @__PURE__ */ new Map([
  ["unlicensed", "explicitlyUnlicensedItem"],
  ["misc", "miscLicenseIssues"],
  ["restricted", "nonpermissiveLicense"],
  ["ambiguous", "ambiguousClassifier"],
  ["copyleft", "copyleftLicense"],
  ["unknown", "unidentifiedLicense"],
  ["none", "noLicenseFound"],
  ["exception", "licenseException"],
  [void 0, void 0]
]);
var kinds = new Set(kindsMap.keys());
var isLicenseKind = (value) => kinds.has(value);
var asLicenseKind = (value) => {
  if (!isLicenseKind(value)) {
    throw error("Expected a valid license kind", {
      found: value,
      validOptions: Array.from(kinds)
    });
  }
  return value;
};
var parseInternals6 = (nodes) => {
  let kind;
  if (isStringNode(asPostcssNodeWithChildren(nodes[0]).nodes[0])) {
    kind = asLicenseKind(
      removeQuotes(
        asStringNode(asPostcssNodeWithChildren(nodes[0]).nodes[0]).value
      )
    );
  } else if (isTagNode(asPostcssNodeWithChildren(nodes[0]).nodes[0])) {
    kind = asLicenseKind(
      asTagNode(asPostcssNodeWithChildren(nodes[0]).nodes[0]).value
    );
  }
  return { kind };
};
var license = async (state) => {
  assertSecurityArchive(state, "license");
  let internals;
  try {
    internals = parseInternals6(
      asPostcssNodeWithChildren(state.current).nodes
    );
  } catch (err) {
    if (asError(err).message === "Expected a query node") {
      for (const node of state.partial.nodes) {
        const report = state.securityArchive.get(node.id);
        const exclude = !report?.alerts || report.alerts.some((alert) => alert.type === "noLicenseFound");
        if (exclude) {
          removeNode(state, node);
        }
      }
      removeDanglingEdges(state);
      return state;
    } else {
      throw error("Failed to parse :license selector", { cause: err });
    }
  }
  const { kind } = internals;
  const alertName = kindsMap.get(kind);
  for (const node of state.partial.nodes) {
    const report = state.securityArchive.get(node.id);
    const exclude = !report?.alerts.some(
      (alert) => alert.type === alertName
    );
    if (exclude) {
      removeNode(state, node);
    }
  }
  removeDanglingEdges(state);
  return state;
};

// ../../src/query/src/pseudo/link.ts
var link = async (state) => {
  for (const node of state.partial.nodes) {
    const [type2, path2] = splitDepID(node.id);
    if (type2 !== "file" || path2.endsWith("tar.gz") || path2 === ".") {
      removeNode(state, node);
    }
  }
  for (const edge of state.partial.edges) {
    if (!edge.spec.file || edge.spec.file.endsWith("tar.gz") || edge.spec.file === ".") {
      state.partial.edges.delete(edge);
    }
  }
  return state;
};

// ../../src/query/src/pseudo/malware.ts
var kindsMap2 = /* @__PURE__ */ new Map([
  ["critical", "malware"],
  ["high", "gptMalware"],
  ["medium", "gptSecurity"],
  ["low", "gptAnomaly"],
  ["0", "malware"],
  ["1", "gptMalware"],
  ["2", "gptSecurity"],
  ["3", "gptAnomaly"]
]);
var kindLevelMap = /* @__PURE__ */ new Map([
  ["critical", 0],
  ["high", 1],
  ["medium", 2],
  ["low", 3],
  ["0", 0],
  ["1", 1],
  ["2", 2],
  ["3", 3]
]);
var kinds2 = new Set(kindsMap2.keys());
var isMalwareKind = (value) => kinds2.has(value);
var asMalwareKind = (value) => {
  if (!isMalwareKind(value)) {
    throw error("Expected a valid malware kind", {
      found: value,
      validOptions: Array.from(kinds2)
    });
  }
  return value;
};
var parseInternals7 = (nodes) => {
  if (!nodes[0]) {
    return { kind: void 0, comparator: void 0 };
  }
  const selectorNode = asPostcssNodeWithChildren(nodes[0]);
  if (!selectorNode.nodes[0]) {
    return { kind: void 0, comparator: void 0 };
  }
  let kindValue = "";
  let comparator = void 0;
  let kind;
  if (isStringNode(selectorNode.nodes[0])) {
    kindValue = removeQuotes(
      asStringNode(selectorNode.nodes[0]).value
    );
  } else if (isTagNode(selectorNode.nodes[0])) {
    kindValue = asTagNode(selectorNode.nodes[0]).value;
  }
  if (kindValue.startsWith(">=")) {
    comparator = ">=";
    kindValue = kindValue.substring(2);
  } else if (kindValue.startsWith("<=")) {
    comparator = "<=";
    kindValue = kindValue.substring(2);
  } else if (kindValue.startsWith(">")) {
    comparator = ">";
    kindValue = kindValue.substring(1);
  } else if (kindValue.startsWith("<")) {
    comparator = "<";
    kindValue = kindValue.substring(1);
  }
  if (!comparator) {
    kind = asMalwareKind(kindValue);
  } else {
    if (isMalwareKind(kindValue)) {
      kind = kindValue;
    } else {
      throw error(
        "Expected a valid malware kind or number between 0-3",
        {
          found: kindValue
        }
      );
    }
  }
  return { kind, comparator };
};
var malware = async (state) => {
  assertSecurityArchive(state, "malware");
  let internals;
  try {
    internals = parseInternals7(
      asPostcssNodeWithChildren(state.current).nodes
    );
  } catch (err) {
    throw error("Failed to parse :malware selector", { cause: err });
  }
  const { kind, comparator } = internals;
  const alertName = comparator ? void 0 : kindsMap2.get(kind);
  for (const node of state.partial.nodes) {
    const report = state.securityArchive.get(node.id);
    if (!report?.alerts || report.alerts.length === 0) {
      removeNode(state, node);
    }
  }
  for (const node of state.partial.nodes) {
    const report = state.securityArchive.get(node.id);
    let exclude = true;
    if (report) {
      if (kind === void 0 && comparator === void 0) {
        exclude = !report.alerts.some(
          (alert) => alert.type === "malware" || alert.type === "gptMalware" || alert.type === "gptSecurity"
        );
      } else if (comparator) {
        const kindLevel = kindLevelMap.get(kind);
        if (kindLevel == null) break;
        for (const alert of report.alerts) {
          const alertType = alert.type;
          const currentAlertLevelKey = [...kindsMap2.entries()].find(
            ([_, alertValue]) => alertValue === alertType
          )?.[0];
          if (currentAlertLevelKey) {
            const currentAlertLevel = kindLevelMap.get(
              currentAlertLevelKey
            );
            if (currentAlertLevel == null) continue;
            switch (comparator) {
              case ">":
                if (currentAlertLevel > kindLevel) {
                  exclude = false;
                }
                break;
              case "<":
                if (currentAlertLevel < kindLevel) {
                  exclude = false;
                }
                break;
              case ">=":
                if (currentAlertLevel >= kindLevel) {
                  exclude = false;
                }
                break;
              case "<=":
                if (currentAlertLevel <= kindLevel) {
                  exclude = false;
                }
                break;
            }
            if (!exclude) break;
          }
        }
      } else {
        exclude = !report.alerts.some(
          (alert) => alert.type === alertName
        );
      }
    }
    if (exclude) {
      removeNode(state, node);
    }
  }
  removeDanglingEdges(state);
  return state;
};

// ../../src/query/src/pseudo/minified.ts
var minified = createSecuritySelectorFilter(
  "minified",
  "minifiedFile"
);

// ../../src/query/src/pseudo/missing.ts
var missing = async (state) => {
  for (const edge of state.partial.edges) {
    if (edge.to) {
      state.partial.edges.delete(edge);
    }
  }
  state.partial.nodes.clear();
  return state;
};

// ../../src/query/src/pseudo/native.ts
var nativeParser = createSecuritySelectorFilter(
  "native",
  "hasNativeCode"
);

// ../../src/query/src/pseudo/network.ts
var network = createSecuritySelectorFilter(
  "network",
  "networkAccess"
);

// ../../src/query/src/pseudo/obfuscated.ts
var obfuscated = createSecuritySelectorFilter(
  "obfuscated",
  "obfuscatedFile"
);

// ../../src/query/src/pseudo/optional.ts
var optional = async (state) => {
  for (const edge of state.partial.edges) {
    if (!edge.optional) {
      removeEdge(state, edge);
    }
  }
  removeUnlinkedNodes(state);
  return state;
};

// ../../src/query/src/pseudo/outdated.ts
var kinds3 = /* @__PURE__ */ new Set([
  "any",
  "major",
  "minor",
  "patch",
  "in-range",
  "out-of-range"
]);
var isOutdatedKind = (value) => kinds3.has(value);
var asOutdatedKind = (value) => {
  if (!isOutdatedKind(value)) {
    throw error("Expected a valid outdated kind", {
      found: value,
      validOptions: Array.from(kinds3)
    });
  }
  return value;
};
var retrieveRemoteVersions = async (node, signal) => {
  const spec2 = hydrate(node.id, String(node.name), node.options);
  if (!spec2.registry || !node.name) {
    return [];
  }
  const url = new URL(spec2.registry);
  url.pathname = `/${node.name}`;
  const response = await fetch(String(url), {
    headers: {
      Accept: "application/vnd.npm.install-v1+json"
    },
    signal
  });
  if (response.status === 404) {
    throw new AbortError("Missing API");
  }
  if (!response.ok) {
    throw error("Failed to fetch packument", {
      name: node.name,
      spec: spec2,
      response
    });
  }
  const packument = await response.json();
  return Object.keys(packument.versions).sort(compare);
};
var parseInternals8 = (nodes) => {
  let kind = "any";
  if (isStringNode(asPostcssNodeWithChildren(nodes[0]).nodes[0])) {
    kind = asOutdatedKind(
      removeQuotes(
        asStringNode(asPostcssNodeWithChildren(nodes[0]).nodes[0]).value
      )
    );
  } else if (isTagNode(asPostcssNodeWithChildren(nodes[0]).nodes[0])) {
    kind = asOutdatedKind(
      asTagNode(asPostcssNodeWithChildren(nodes[0]).nodes[0]).value
    );
  }
  return { kind };
};
var queueNode = async (state, node, kind) => {
  if (!node.name || !node.version) {
    return node;
  }
  const nodeVersion = node.version;
  let versions;
  try {
    versions = await pRetry(
      () => retrieveRemoteVersions(node, state.signal),
      {
        retries: state.retries,
        signal: state.signal
      }
    );
  } catch (err) {
    console.warn(
      error("Could not retrieve registry versions", {
        name: node.name,
        cause: err
      })
    );
    versions = [];
  }
  const greaterVersions = versions.filter(
    (version) => gt(version, nodeVersion)
  );
  if (!greaterVersions.length) {
    return node;
  }
  const checkKind = /* @__PURE__ */ new Map([
    ["major", major],
    ["minor", minor],
    ["patch", patch]
  ]);
  switch (kind) {
    case "any":
      return;
    case "major":
    case "minor":
    case "patch": {
      return greaterVersions.some((version) => {
        const va = checkKind.get(kind)?.(version);
        const vb = checkKind.get(kind)?.(nodeVersion);
        if (va === void 0 || vb === void 0) return false;
        return va > vb;
      }) ? void 0 : node;
    }
    // the node should be part of the result as long as it has at least
    // one parent node that has a spec definition that satisfies one
    // of the available remove versions
    case "in-range": {
      for (const edge of node.edgesIn) {
        if (!state.partial.edges.has(edge)) continue;
        if (greaterVersions.some(
          (version) => edge.spec.final.range && satisfies(version, edge.spec.final.range)
        )) {
          return;
        }
      }
      return node;
    }
    // the node is part of the result as long as none of its parents has
    // a spec definition that satisfies one of the available remote versions
    case "out-of-range": {
      for (const edge of node.edgesIn) {
        if (!state.partial.edges.has(edge)) continue;
        if (greaterVersions.some(
          (version) => edge.spec.final.range && satisfies(version, edge.spec.final.range)
        )) {
          return node;
        }
      }
      return;
    }
  }
};
var outdated = async (state) => {
  let internals;
  try {
    internals = parseInternals8(
      asPostcssNodeWithChildren(state.current).nodes
    );
  } catch (err) {
    if (asError(err).message === "Expected a query node") {
      internals = { kind: "any" };
    } else {
      throw error("Failed to parse :outdated selector", {
        cause: err
      });
    }
  }
  const { kind } = internals;
  const queue = [];
  for (const node of state.partial.nodes) {
    if (node.mainImporter || node.manifest?.private || splitDepID(node.id)[0] !== "registry") {
      removeNode(state, node);
      continue;
    }
    queue.push(queueNode(state, node, kind));
  }
  const removeNodeQueue = await Promise.all(queue);
  for (const node of removeNodeQueue) {
    if (node) {
      removeNode(state, node);
    }
  }
  return state;
};

// ../../src/query/src/pseudo/overridden.ts
var overridden = async (state) => {
  for (const edge of state.partial.edges) {
    if (!edge.spec.overridden) {
      removeEdge(state, edge);
    }
  }
  removeUnlinkedNodes(state);
  return state;
};

// ../../src/query/src/pseudo/path.ts
function normalizePath(path2) {
  const trimmed = path2.trim().replaceAll("\\", "/");
  if (trimmed === ".") {
    return "";
  }
  if (trimmed.startsWith("./")) {
    return trimmed.slice(2);
  }
  return trimmed;
}
function createPathMatcher(pattern, loose = false) {
  const normalizedPattern = normalizePath(pattern);
  const isRoot = normalizedPattern === "" || pattern.trim() === ".";
  return (path2) => {
    const normalizedPath = normalizePath(path2);
    if (isRoot) {
      return normalizedPath === "" || normalizedPath === ".";
    }
    try {
      return minimatch(normalizedPath, normalizedPattern, {
        dot: true,
        nocase: false,
        matchBase: normalizedPattern === "*"
      });
    } catch (err) {
      if (loose) {
        return false;
      }
      throw error(
        "Invalid glob pattern in :path selector",
        asError(err)
      );
    }
  };
}
var path = async (state) => {
  const pathContainer = asPostcssNodeWithChildren(state.current);
  if (!pathContainer.nodes[0]) {
    return clear(state);
  }
  const selector = asPostcssNodeWithChildren(pathContainer.nodes[0]);
  if (!selector.nodes[0]) {
    return clear(state);
  }
  let pathPattern = "";
  if (isStringNode(selector.nodes[0])) {
    pathPattern = removeQuotes(asStringNode(selector.nodes[0]).value);
  } else {
    if (state.loose) {
      return clear(state);
    }
    throw error(
      "Failed to parse path pattern in :path selector",
      new Error("Path pattern must be a quoted string")
    );
  }
  if (!pathPattern) {
    return clear(state);
  }
  if (pathPattern === "[" || pathPattern.includes("[") && !pathPattern.includes("]")) {
    if (state.loose) {
      return clear(state);
    }
    throw error(
      "Invalid glob pattern in :path selector",
      new Error(`Unmatched bracket in pattern: ${pathPattern}`)
    );
  }
  const matchPath = createPathMatcher(pathPattern, state.loose);
  for (const node of state.partial.nodes) {
    const nodePath = node.location || "";
    const [type2] = splitDepID(node.id);
    if (pathPattern === "." && node.mainImporter) {
      continue;
    }
    const pathBased = type2 === "workspace" || type2 === "file";
    if (!pathBased || !matchPath(nodePath)) {
      removeNode(state, node);
    }
  }
  removeDanglingEdges(state);
  return state;
};

// ../../src/query/src/pseudo/peer.ts
var peer = async (state) => {
  for (const edge of state.partial.edges) {
    if (!edge.peer) {
      removeEdge(state, edge);
    }
  }
  removeUnlinkedNodes(state);
  return state;
};

// ../../src/query/src/pseudo/prerelease.ts
var prerelease = async (state) => {
  for (const node of state.partial.nodes) {
    const version = node.manifest?.version;
    if (!version) {
      removeNode(state, node);
      continue;
    }
    const parsedVersion = parse(version);
    if (!parsedVersion) {
      removeNode(state, node);
      continue;
    }
    if (!parsedVersion.prerelease?.length) {
      removeNode(state, node);
    }
  }
  removeDanglingEdges(state);
  return state;
};

// ../../src/query/src/pseudo/published.ts
var retrieveRemoteDate = async (node, signal) => {
  const spec2 = hydrate(node.id, String(node.name), node.options);
  if (!spec2.registry || !node.name || !node.version) {
    return void 0;
  }
  const url = new URL(spec2.registry);
  url.pathname = `/${node.name}`;
  const response = await fetch(String(url), {
    signal
  });
  if (response.status === 404) {
    throw new AbortError("Missing API");
  }
  if (!response.ok) {
    throw error("Failed to fetch packument", {
      name: node.name,
      spec: spec2,
      response
    });
  }
  const packument = await response.json();
  const res = packument.time?.[node.version];
  return res;
};
var parseInternals9 = (nodes) => {
  let value = "";
  if (isStringNode(asPostcssNodeWithChildren(nodes[0]).nodes[0])) {
    value = removeQuotes(
      asStringNode(asPostcssNodeWithChildren(nodes[0]).nodes[0]).value
    );
  } else if (isTagNode(asPostcssNodeWithChildren(nodes[0]).nodes[0])) {
    const tagNode = asTagNode(
      asPostcssNodeWithChildren(nodes[0]).nodes[0]
    );
    value = tagNode.value;
  }
  let comparator;
  let relativeDate = value;
  if (value.startsWith(">=")) {
    comparator = ">=";
    relativeDate = value.slice(2);
  } else if (value.startsWith("<=")) {
    comparator = "<=";
    relativeDate = value.slice(2);
  } else if (value.startsWith(">")) {
    comparator = ">";
    relativeDate = value.slice(1);
  } else if (value.startsWith("<")) {
    comparator = "<";
    relativeDate = value.slice(1);
  }
  return { relativeDate, comparator };
};
var queueNode2 = async (state, node, relativeDate, comparator) => {
  if (!node.name || !node.version) {
    return node;
  }
  let publishedDate;
  try {
    publishedDate = await pRetry(
      () => retrieveRemoteDate(node, state.signal),
      {
        retries: state.retries,
        signal: state.signal
      }
    );
  } catch (err) {
    console.warn(
      error("Could not retrieve registry publish date", {
        name: node.name,
        cause: err
      })
    );
    return node;
  }
  if (!publishedDate) {
    return node;
  }
  const nodeDate = new Date(
    publishedDate.slice(0, relativeDate.length)
  );
  const compareDate = new Date(relativeDate);
  switch (comparator) {
    case ">":
      return nodeDate > compareDate ? void 0 : node;
    case "<":
      return nodeDate < compareDate ? void 0 : node;
    case ">=":
      return nodeDate >= compareDate ? void 0 : node;
    case "<=":
      return nodeDate <= compareDate ? void 0 : node;
    default:
      return nodeDate.getTime() === compareDate.getTime() ? void 0 : node;
  }
};
var published = async (state) => {
  let internals;
  try {
    internals = parseInternals9(
      asPostcssNodeWithChildren(state.current).nodes
    );
  } catch (err) {
    if (asError(err).message === "Expected a query node") {
      for (const node of state.partial.nodes) {
        if (node.mainImporter || node.manifest?.private || splitDepID(node.id)[0] !== "registry") {
          removeNode(state, node);
          continue;
        }
        if (!node.name || !node.version) {
          removeNode(state, node);
        }
      }
      removeDanglingEdges(state);
      return state;
    } else {
      throw error("Failed to parse :published selector", {
        cause: err
      });
    }
  }
  const { relativeDate, comparator } = internals;
  const queue = [];
  for (const node of state.partial.nodes) {
    if (node.mainImporter || node.manifest?.private || splitDepID(node.id)[0] !== "registry") {
      removeNode(state, node);
      continue;
    }
    queue.push(queueNode2(state, node, relativeDate, comparator));
  }
  const removeNodeQueue = await Promise.all(queue);
  for (const node of removeNodeQueue) {
    if (node) {
      removeNode(state, node);
    }
  }
  removeDanglingEdges(state);
  return state;
};

// ../../src/query/src/pseudo/private.ts
var privateParser = async (state) => {
  for (const node of state.partial.nodes) {
    if (!node.manifest || !asManifest(node.manifest).private) {
      removeNode(state, node);
    }
  }
  removeDanglingEdges(state);
  return state;
};

// ../../src/query/src/pseudo/registry.ts
var registry = async (state) => {
  const top = asPostcssNodeWithChildren(state.current);
  const selector = asPostcssNodeWithChildren(top.nodes[0]);
  const name = asTagNode(selector.nodes[0]).value;
  for (const node of state.partial.nodes) {
    const tuple = splitDepID(node.id);
    if (tuple[0] !== "registry" || tuple[1] !== name) {
      removeNode(state, node);
    }
  }
  removeDanglingEdges(state);
  return state;
};

// ../../src/query/src/pseudo/prod.ts
var prod = async (state) => {
  for (const edge of state.partial.edges) {
    if (edge.type !== "prod") {
      removeEdge(state, edge);
    }
  }
  removeUnlinkedNodes(state);
  return state;
};

// ../../src/query/src/pseudo/root.ts
var root = async (state) => {
  for (const edge of state.partial.edges) {
    if (!edge.to?.mainImporter) {
      state.partial.edges.delete(edge);
    }
  }
  for (const node of state.partial.nodes) {
    if (!node.mainImporter) {
      state.partial.nodes.delete(node);
    }
  }
  return state;
};

// ../../src/query/src/pseudo/scanned.ts
var scanned = async (state) => {
  for (const node of state.partial.nodes) {
    if (!state.securityArchive?.has(node.id)) {
      removeNode(state, node);
    }
  }
  removeDanglingEdges(state);
  return state;
};

// ../../src/query/src/pseudo/score.ts
var kinds4 = /* @__PURE__ */ new Set([
  "overall",
  "license",
  "maintenance",
  "quality",
  "supplyChain",
  "vulnerability",
  void 0
]);
var isScoreKind = (value) => kinds4.has(value);
var asScoreKind = (value) => {
  if (!isScoreKind(value)) {
    throw error("Expected a valid score kind", {
      found: value,
      validOptions: Array.from(kinds4)
    });
  }
  return value;
};
var parseInternals10 = (nodes) => {
  let rateStr = "";
  let comparator = "=";
  let kind = "overall";
  if (isStringNode(asPostcssNodeWithChildren(nodes[0]).nodes[0])) {
    rateStr = removeQuotes(
      asStringNode(asPostcssNodeWithChildren(nodes[0]).nodes[0]).value
    );
  } else if (isTagNode(asPostcssNodeWithChildren(nodes[0]).nodes[0])) {
    const tagNode = asTagNode(
      asPostcssNodeWithChildren(nodes[0]).nodes[0]
    );
    rateStr = tagNode.value;
  }
  if (rateStr.startsWith(">=")) {
    comparator = ">=";
    rateStr = rateStr.substring(2);
  } else if (rateStr.startsWith("<=")) {
    comparator = "<=";
    rateStr = rateStr.substring(2);
  } else if (rateStr.startsWith(">")) {
    comparator = ">";
    rateStr = rateStr.substring(1);
  } else if (rateStr.startsWith("<")) {
    comparator = "<";
    rateStr = rateStr.substring(1);
  }
  let rate = parseFloat(rateStr);
  if (rate > 1) {
    rate = rate / 100;
  }
  if (rate < 0 || rate > 1) {
    throw error("Expected rate to be between 0 and 100", {
      found: rateStr
    });
  }
  if (nodes.length > 1) {
    if (isStringNode(asPostcssNodeWithChildren(nodes[1]).nodes[0])) {
      kind = asScoreKind(
        removeQuotes(
          asStringNode(asPostcssNodeWithChildren(nodes[1]).nodes[0]).value
        )
      );
    } else if (isTagNode(asPostcssNodeWithChildren(nodes[1]).nodes[0])) {
      kind = asScoreKind(
        asTagNode(asPostcssNodeWithChildren(nodes[1]).nodes[0]).value
      );
    }
  }
  return { comparator, rate, kind };
};
var score = async (state) => {
  assertSecurityArchive(state, "score");
  let internals;
  try {
    internals = parseInternals10(
      asPostcssNodeWithChildren(state.current).nodes
    );
  } catch (err) {
    if (asError(err).message === "Expected a query node") {
      for (const node of state.partial.nodes) {
        const report = state.securityArchive.get(node.id);
        if (!report) {
          removeNode(state, node);
        }
      }
      removeDanglingEdges(state);
      return state;
    } else {
      throw error("Failed to parse :score selector", { cause: err });
    }
  }
  const { comparator, rate, kind } = internals;
  for (const node of state.partial.nodes) {
    const report = state.securityArchive.get(node.id);
    if (!report) {
      removeNode(state, node);
      continue;
    }
    const scoreValue = report.score[kind];
    let exclude = false;
    switch (comparator) {
      case ">":
        exclude = scoreValue <= rate;
        break;
      case "<":
        exclude = scoreValue >= rate;
        break;
      case ">=":
        exclude = scoreValue < rate;
        break;
      case "<=":
        exclude = scoreValue > rate;
        break;
      default:
        exclude = scoreValue !== rate;
        break;
    }
    if (exclude) {
      removeNode(state, node);
    }
  }
  removeDanglingEdges(state);
  return state;
};

// ../../src/query/src/pseudo/scripts.ts
var nodeNeedsBuild = (node) => {
  const { manifest } = node;
  if (!manifest) return false;
  const { scripts: scripts2 = {} } = manifest;
  const runInstall = !!(scripts2.install || scripts2.preinstall || scripts2.postinstall);
  if (runInstall) return true;
  const prepable = node.id.startsWith("git") || node.importer;
  const runPrepare = !!(scripts2.prepare || scripts2.preprepare || scripts2.postprepare) && prepable;
  if (runPrepare) return true;
  return false;
};
var scripts = async (state) => {
  for (const node of state.partial.nodes) {
    if (!nodeNeedsBuild(node)) {
      removeNode(state, node);
    }
  }
  removeDanglingEdges(state);
  return state;
};

// ../../src/query/src/pseudo/shell.ts
var shell = createSecuritySelectorFilter(
  "shell",
  "shellAccess"
);

// ../../src/query/src/pseudo/semver.ts
var semverFunctionNames = /* @__PURE__ */ new Set([
  "satisfies",
  "gt",
  "gte",
  "lt",
  "lte",
  "eq",
  "neq"
]);
var isSemverFunctionName = (name) => semverFunctionNames.has(name);
var asSemverFunctionName = (name) => {
  if (!isSemverFunctionName(name)) {
    throw error("Invalid semver function name", {
      found: name,
      validOptions: Array.from(semverFunctionNames)
    });
  }
  return name;
};
var semverFunctions = /* @__PURE__ */ new Map([
  ["satisfies", satisfies],
  ["gt", gt],
  ["gte", gte],
  ["lt", lt],
  ["lte", lte],
  ["eq", eq],
  ["neq", neq]
]);
var parseInternals11 = (nodes, loose) => {
  let semverValue = "";
  try {
    semverValue = removeQuotes(
      asStringNode(asPostcssNodeWithChildren(nodes[0]).nodes[0]).value
    );
  } catch (err) {
    if (asError(err).message === "Mismatching query node" && isTagNode(asPostcssNodeWithChildren(nodes[0]).nodes[0])) {
      const tagNode = asTagNode(
        asPostcssNodeWithChildren(nodes[0]).nodes[0]
      );
      semverValue = tagNode.value;
    } else {
      throw err;
    }
  }
  let fnName = "satisfies";
  try {
    if (nodes[1]) {
      try {
        fnName = asSemverFunctionName(
          removeQuotes(
            asStringNode(asPostcssNodeWithChildren(nodes[1]).nodes[0]).value
          )
        );
      } catch (err) {
        if (asError(err).message === "Mismatching query node") {
          fnName = asSemverFunctionName(
            asTagNode(asPostcssNodeWithChildren(nodes[1]).nodes[0]).value
          );
        } else {
          throw err;
        }
      }
    }
  } catch (e) {
    if (!loose) {
      throw e;
    }
  }
  const semverFunction = semverFunctions.get(fnName);
  if (!semverFunction) {
    throw error("Invalid semver function name", {
      found: fnName,
      validOptions: Array.from(semverFunctions.keys())
    });
  }
  let compareAttribute;
  if (nodes[2]) {
    const parentNode = asPostcssNodeWithChildren(nodes[2]);
    const currNode = parentNode.nodes[0];
    if (isAttributeNode(currNode)) {
      const { attribute: attribute2 } = asAttributeNode(currNode);
      compareAttribute = {
        attribute: attribute2,
        properties: [attribute2]
      };
    } else if (isPseudoNode(currNode)) {
      compareAttribute = parseInternals(
        asPseudoNode(currNode).nodes
      );
    } else if (isStringNode(currNode)) {
      const attribute2 = removeQuotes(asStringNode(currNode).value);
      compareAttribute = {
        attribute: attribute2,
        properties: [attribute2]
      };
    }
  }
  return {
    semverValue,
    semverFunction,
    compareAttribute
  };
};
var semverParser = async (state) => {
  let internals;
  try {
    internals = parseInternals11(
      asPostcssNodeWithChildren(state.current).nodes,
      !!state.loose
    );
  } catch (err) {
    throw error("Failed to parse :semver selector", {
      cause: err
    });
  }
  const { semverValue, semverFunction, compareAttribute } = internals;
  for (const node of state.partial.nodes) {
    if (compareAttribute) {
      const compareValues = getManifestPropertyValues(
        node,
        compareAttribute.properties,
        compareAttribute.attribute
      );
      const compareValue = compareValues?.[0];
      const semverValueVersion = parse(semverValue);
      const compareValueRange = compareValue && parseRange(compareValue);
      if (semverFunction === satisfies && semverValueVersion && compareValueRange) {
        if (!satisfies(semverValueVersion, compareValueRange)) {
          removeNode(state, node);
        }
      } else if (!compareValue || !semverFunction(compareValue, semverValue)) {
        removeNode(state, node);
      }
    } else {
      const manifestVersion = node.manifest?.version;
      if (!manifestVersion || !semverFunction(manifestVersion, semverValue)) {
        removeNode(state, node);
      }
    }
  }
  return state;
};

// ../../src/query/src/pseudo/severity.ts
var kindsMap3 = /* @__PURE__ */ new Map([
  ["critical", "criticalCVE"],
  ["high", "cve"],
  ["medium", "potentialVulnerability"],
  ["low", "mildCVE"],
  ["0", "criticalCVE"],
  ["1", "cve"],
  ["2", "potentialVulnerability"],
  ["3", "mildCVE"]
]);
var kindLevelMap2 = /* @__PURE__ */ new Map([
  ["critical", 0],
  ["high", 1],
  ["medium", 2],
  ["low", 3],
  ["0", 0],
  ["1", 1],
  ["2", 2],
  ["3", 3]
]);
var kinds5 = new Set(kindsMap3.keys());
var isSeverityKind = (value) => kinds5.has(value);
var parseInternals12 = (nodes) => {
  let kind;
  let comparator;
  if (nodes.length === 0) {
    throw error("Missing severity kind parameter");
  }
  let kindValue = "";
  if (isStringNode(asPostcssNodeWithChildren(nodes[0]).nodes[0])) {
    kindValue = removeQuotes(
      asStringNode(asPostcssNodeWithChildren(nodes[0]).nodes[0]).value
    );
  } else if (isTagNode(asPostcssNodeWithChildren(nodes[0]).nodes[0])) {
    kindValue = asTagNode(
      asPostcssNodeWithChildren(nodes[0]).nodes[0]
    ).value;
  }
  if (kindValue.startsWith(">=")) {
    comparator = ">=";
    kindValue = kindValue.substring(2);
  } else if (kindValue.startsWith("<=")) {
    comparator = "<=";
    kindValue = kindValue.substring(2);
  } else if (kindValue.startsWith(">")) {
    comparator = ">";
    kindValue = kindValue.substring(1);
  } else if (kindValue.startsWith("<")) {
    comparator = "<";
    kindValue = kindValue.substring(1);
  }
  if (kindValue) {
    if (isSeverityKind(kindValue)) {
      kind = kindValue;
    } else {
      throw error(
        "Expected a valid severity kind or number between 0-3",
        {
          found: kindValue
        }
      );
    }
  }
  return { kind, comparator };
};
var severity = async (state) => {
  assertSecurityArchive(state, "severity");
  let internals;
  try {
    internals = parseInternals12(
      asPostcssNodeWithChildren(state.current).nodes
    );
  } catch (err) {
    throw error("Failed to parse :severity selector", { cause: err });
  }
  const { kind, comparator } = internals;
  for (const node of state.partial.nodes) {
    const report = state.securityArchive.get(node.id);
    if (!report?.alerts || report.alerts.length === 0) {
      removeNode(state, node);
    }
  }
  for (const node of state.partial.nodes) {
    const report = state.securityArchive.get(node.id);
    let exclude = true;
    if (report) {
      if (comparator) {
        const kindLevel = kindLevelMap2.get(kind);
        if (!kindLevel) break;
        for (const alert of report.alerts) {
          const alertType = alert.type;
          const currentAlertLevelKey = [...kindsMap3.entries()].find(
            ([_, alertValue]) => alertValue === alertType
          )?.[0];
          if (currentAlertLevelKey) {
            const currentAlertLevel = kindLevelMap2.get(
              currentAlertLevelKey
            );
            if (currentAlertLevel == null) continue;
            switch (comparator) {
              case ">":
                if (currentAlertLevel > kindLevel) {
                  exclude = false;
                }
                break;
              case "<":
                if (currentAlertLevel < kindLevel) {
                  exclude = false;
                }
                break;
              case ">=":
                if (currentAlertLevel >= kindLevel) {
                  exclude = false;
                }
                break;
              case "<=":
                if (currentAlertLevel <= kindLevel) {
                  exclude = false;
                }
                break;
            }
          }
        }
      } else {
        const alertName = kindsMap3.get(kind);
        exclude = !report.alerts.some(
          (alert) => alert.type === alertName
        );
      }
    }
    if (exclude) {
      removeNode(state, node);
    }
  }
  removeDanglingEdges(state);
  return state;
};

// ../../src/query/src/pseudo/shrinkwrap.ts
var shrinkwrap = createSecuritySelectorFilter(
  "shrinkwrap",
  "shrinkwrap"
);

// ../../src/query/src/pseudo/squat.ts
var kindsMap4 = /* @__PURE__ */ new Map([
  ["critical", "didYouMean"],
  ["medium", "gptDidYouMean"],
  ["0", "didYouMean"],
  ["2", "gptDidYouMean"],
  [void 0, void 0]
]);
var kindLevelMap3 = /* @__PURE__ */ new Map([
  ["critical", 0],
  ["medium", 2],
  ["0", 0],
  ["2", 2]
]);
var kinds6 = new Set(kindsMap4.keys());
var isSquatKind = (value) => kinds6.has(value);
var parseInternals13 = (nodes) => {
  let kind;
  let comparator;
  let kindValue = "";
  if (isStringNode(asPostcssNodeWithChildren(nodes[0]).nodes[0])) {
    kindValue = removeQuotes(
      asStringNode(asPostcssNodeWithChildren(nodes[0]).nodes[0]).value
    );
  } else if (isTagNode(asPostcssNodeWithChildren(nodes[0]).nodes[0])) {
    kindValue = asTagNode(
      asPostcssNodeWithChildren(nodes[0]).nodes[0]
    ).value;
  }
  if (kindValue.startsWith(">=")) {
    comparator = ">=";
    kindValue = kindValue.substring(2);
  } else if (kindValue.startsWith("<=")) {
    comparator = "<=";
    kindValue = kindValue.substring(2);
  } else if (kindValue.startsWith(">")) {
    comparator = ">";
    kindValue = kindValue.substring(1);
  } else if (kindValue.startsWith("<")) {
    comparator = "<";
    kindValue = kindValue.substring(1);
  }
  if (kindValue) {
    if (isSquatKind(kindValue)) {
      kind = kindValue;
    } else {
      throw error("Expected a valid squat kind for comparison", {
        found: kindValue,
        validOptions: Array.from(kinds6)
      });
    }
  }
  return { kind, comparator };
};
var squat = async (state) => {
  assertSecurityArchive(state, "squat");
  let internals;
  try {
    internals = parseInternals13(
      asPostcssNodeWithChildren(state.current).nodes
    );
  } catch (err) {
    if (asError(err).message === "Expected a query node") {
      internals = { kind: void 0, comparator: void 0 };
    } else {
      throw error("Failed to parse :squat selector", { cause: err });
    }
  }
  const { kind, comparator } = internals;
  for (const node of state.partial.nodes) {
    const report = state.securityArchive.get(node.id);
    if (!report?.alerts || report.alerts.length === 0) {
      removeNode(state, node);
    }
  }
  for (const node of state.partial.nodes) {
    const report = state.securityArchive.get(node.id);
    if (!report) continue;
    let exclude = true;
    if (kind === void 0 && comparator === void 0) {
      exclude = !report.alerts.some(
        (alert) => [...kindsMap4.values()].includes(
          alert.type
        )
      );
    } else if (comparator) {
      const kindLevel = kindLevelMap3.get(kind);
      if (kindLevel === void 0) break;
      let matchesComparison = false;
      for (const alert of report.alerts) {
        const alertType = alert.type;
        const alertLevelKey = [...kindsMap4.entries()].find(
          ([_, value]) => value === alertType
        )?.[0];
        if (alertLevelKey) {
          const alertLevel = kindLevelMap3.get(alertLevelKey);
          if (alertLevel === void 0) continue;
          switch (comparator) {
            case ">":
              if (alertLevel > kindLevel) {
                matchesComparison = true;
              }
              break;
            case "<":
              if (alertLevel < kindLevel) {
                matchesComparison = true;
              }
              break;
            case ">=":
              if (alertLevel >= kindLevel) {
                matchesComparison = true;
              }
              break;
            case "<=":
              if (alertLevel <= kindLevel) {
                matchesComparison = true;
              }
              break;
          }
          if (matchesComparison) break;
        }
      }
      exclude = !matchesComparison;
    } else {
      const alertName = kindsMap4.get(kind);
      exclude = !report.alerts.some((alert) => alert.type === alertName);
    }
    if (exclude) {
      removeNode(state, node);
    }
  }
  removeDanglingEdges(state);
  return state;
};

// ../../src/query/src/pseudo/suspicious.ts
var suspicious = createSecuritySelectorFilter(
  "suspicious",
  "suspiciousStarActivity"
);

// ../../src/query/src/pseudo/tracker.ts
var tracker = createSecuritySelectorFilter(
  "tracker",
  "telemetry"
);

// ../../src/query/src/pseudo/trivial.ts
var trivial = createSecuritySelectorFilter(
  "trivial",
  "trivialPackage"
);

// ../../src/query/src/pseudo/type.ts
var type = async (state) => {
  const type2 = asPostcssNodeWithChildren(state.current);
  const selector = asPostcssNodeWithChildren(type2.nodes[0]);
  const name = asTagNode(selector.nodes[0]).value;
  for (const node of state.partial.nodes) {
    const nodeType = splitDepID(node.id)[0];
    if (nodeType !== name) {
      removeNode(state, node);
    }
  }
  removeDanglingEdges(state);
  return state;
};

// ../../src/query/src/pseudo/undesirable.ts
var undesirable = createSecuritySelectorFilter(
  "undesirable",
  "troll"
);

// ../../src/query/src/pseudo/unknown.ts
var unknown = createSecuritySelectorFilter(
  "unknown",
  "newAuthor"
);

// ../../src/query/src/pseudo/unmaintained.ts
var unmaintained = createSecuritySelectorFilter(
  "unmaintained",
  "unmaintained"
);

// ../../src/query/src/pseudo/unpopular.ts
var unpopular = createSecuritySelectorFilter(
  "unpopular",
  "unpopularPackage"
);

// ../../src/query/src/pseudo/unstable.ts
var unstable = createSecuritySelectorFilter(
  "unstable",
  "unstableOwnership"
);

// ../../src/query/src/pseudo/workspace.ts
var workspace = async (state) => {
  for (const node of state.partial.nodes) {
    if (!node.importer || node.mainImporter) {
      removeNode(state, node);
    }
  }
  for (const edge of state.partial.edges) {
    if (edge.to?.importer && !edge.to.mainImporter) continue;
    state.partial.edges.delete(edge);
  }
  return state;
};

// ../../src/query/src/pseudo.ts
var has = async (state) => {
  const top = asPostcssNodeWithChildren(state.current);
  const collectNodes = /* @__PURE__ */ new Set();
  const collectEdges = /* @__PURE__ */ new Set();
  for (const node of top.nodes) {
    if (isSelectorNode(node)) {
      const nestedState = await state.walk({
        cancellable: state.cancellable,
        initial: {
          edges: new Set(state.initial.edges),
          nodes: new Set(state.initial.nodes)
        },
        current: node,
        walk: state.walk,
        collect: {
          edges: /* @__PURE__ */ new Set(),
          nodes: /* @__PURE__ */ new Set()
        },
        partial: {
          edges: new Set(state.partial.edges),
          nodes: new Set(state.partial.nodes)
        },
        hostContexts: state.hostContexts,
        importers: state.importers,
        retries: state.retries,
        securityArchive: state.securityArchive,
        signal: state.signal,
        scopeIDs: state.scopeIDs,
        comment: state.comment,
        specificity: { ...state.specificity }
      });
      for (const n of nestedState.collect.nodes) {
        collectNodes.add(n);
      }
      for (const e of nestedState.partial.edges) {
        collectEdges.add(e);
      }
    }
  }
  if (collectNodes.size === 0) {
    state.partial.edges.clear();
    state.partial.nodes.clear();
    return state;
  }
  const compareNodes = /* @__PURE__ */ new Set();
  const traverse = new Set(collectNodes);
  for (const node of traverse) {
    for (const edge of node.edgesIn) {
      compareNodes.add(edge.from);
      if (edge.from.edgesIn.size) {
        traverse.add(edge.from);
      }
    }
  }
  nodesLoop: for (const node of state.partial.nodes) {
    if (node.edgesOut.size === 0 || !compareNodes.has(node)) {
      removeNode(state, node);
      continue;
    }
    for (const edge of node.edgesOut.values()) {
      if (collectEdges.has(edge)) {
        continue nodesLoop;
      }
    }
    removeNode(state, node);
  }
  removeDanglingEdges(state);
  return state;
};
var is = async (state) => {
  const top = asPostcssNodeWithChildren(state.current);
  const collect = /* @__PURE__ */ new Set();
  for (const node of top.nodes) {
    if (isSelectorNode(node)) {
      const nestedState = await state.walk({
        cancellable: state.cancellable,
        collect: {
          edges: /* @__PURE__ */ new Set(),
          nodes: /* @__PURE__ */ new Set()
        },
        current: node,
        initial: state.initial,
        loose: true,
        partial: {
          nodes: new Set(state.partial.nodes),
          edges: new Set(state.partial.edges)
        },
        importers: state.importers,
        hostContexts: state.hostContexts,
        walk: state.walk,
        retries: state.retries,
        securityArchive: state.securityArchive,
        signal: state.signal,
        scopeIDs: state.scopeIDs,
        comment: state.comment,
        specificity: { ...state.specificity }
      });
      for (const n of nestedState.collect.nodes) {
        collect.add(n);
      }
    }
  }
  for (const node of state.partial.nodes) {
    if (!collect.has(node)) {
      removeNode(state, node);
    }
  }
  return state;
};
var not = async (state) => {
  const top = asPostcssNodeWithChildren(state.current);
  const collect = /* @__PURE__ */ new Set();
  for (const node of top.nodes) {
    if (isSelectorNode(node)) {
      const nestedState = await state.walk({
        cancellable: state.cancellable,
        collect: {
          edges: /* @__PURE__ */ new Set(),
          nodes: /* @__PURE__ */ new Set()
        },
        current: node,
        initial: state.initial,
        partial: {
          nodes: new Set(state.partial.nodes),
          edges: new Set(state.partial.edges)
        },
        importers: state.importers,
        hostContexts: state.hostContexts,
        walk: state.walk,
        retries: state.retries,
        securityArchive: state.securityArchive,
        signal: state.signal,
        scopeIDs: state.scopeIDs,
        comment: state.comment,
        specificity: { ...state.specificity }
      });
      for (const n of nestedState.collect.nodes) {
        collect.add(n);
      }
    } else {
      throw error("Error parsing :not() selectors", {
        wanted: { type: "selector" },
        found: node
      });
    }
  }
  for (const node of state.partial.nodes) {
    if (collect.has(node)) {
      removeNode(state, node);
    }
  }
  removeDanglingEdges(state);
  return state;
};
var project = async (state) => {
  for (const node of state.partial.nodes) {
    if (!node.importer) {
      removeNode(state, node);
    }
  }
  for (const edge of state.partial.edges) {
    if (!edge.to?.importer) {
      state.partial.edges.delete(edge);
    }
  }
  return state;
};
var scope = async (state) => {
  const scopeIDSet = new Set(state.scopeIDs);
  for (const node of state.partial.nodes) {
    if (!scopeIDSet.has(node.id)) {
      removeNode(state, node);
    }
  }
  removeDanglingEdges(state);
  return state;
};
var pseudoSelectors = new Map(
  Object.entries({
    abandoned,
    attr,
    built,
    confused,
    cve,
    cwe,
    debug,
    deprecated,
    dev,
    diff,
    dynamic,
    eval: evalParser,
    empty,
    entropic,
    env,
    fs,
    has,
    host: hostContext,
    hostname,
    is,
    license,
    link,
    malware,
    minified,
    missing,
    native: nativeParser,
    network,
    not,
    obfuscated,
    optional,
    outdated,
    overridden,
    path,
    peer,
    prerelease,
    published,
    private: privateParser,
    prod,
    registry,
    project,
    root,
    scanned,
    scope,
    score,
    scripts,
    semver: semverParser,
    sev: severity,
    spec,
    severity,
    shell,
    shrinkwrap,
    squat,
    suspicious,
    tracker,
    trivial,
    type,
    undesirable,
    unknown,
    unmaintained,
    unpopular,
    unstable,
    v: semverParser,
    workspace
  })
);
var pseudo = async (state) => {
  await state.cancellable();
  const curr = asPseudoNode(state.current);
  const parserFn = curr.value && pseudoSelectors.get(curr.value.slice(1));
  if (!parserFn) {
    if (state.loose) {
      state.partial.edges.clear();
      state.partial.nodes.clear();
      return state;
    }
    throw error(`Unsupported pseudo-class: ${state.current.value}`, {
      found: state.current
    });
  }
  const result = await parserFn(state);
  const pseudoValue = curr.value.slice(1);
  if (pseudoValue && pseudoValue !== "not" && pseudoValue !== "is" && pseudoValue !== "has") {
    result.specificity.commonCounter += 1;
  }
  return result;
};

// ../../src/query/src/index.ts
var noopFn = async (state) => state;
var selectors = {
  attribute,
  /* c8 ignore start */
  class: async (state) => {
    throw error("Unsupported selector", { found: state.current });
  },
  /* c8 ignore end */
  combinator,
  comment: async (state) => {
    if (state.current.value && !state.comment) {
      const commentValue = state.current.value;
      const cleanComment = commentValue.replace(/^\/\*/, "").replace(/\*\/$/, "").trim();
      state.comment = cleanComment;
    }
    return state;
  },
  id,
  nesting: noopFn,
  pseudo,
  root: noopFn,
  selector: async (state) => {
    state.partial.nodes = new Set(state.initial.nodes);
    state.partial.edges = new Set(state.initial.edges);
    return state;
  },
  string: async (state) => {
    throw error("Unsupported selector", { found: state.current });
  },
  tag: async (state) => {
    if (state.current.value !== "{" && state.current.value !== "}") {
      throw error("Unsupported selector", { found: state.current });
    }
    return state;
  },
  universal: noopFn
};
var selectorsMap = new Map(
  Object.entries(selectors)
);
var walk = async (state) => {
  await state.cancellable();
  const parserFn = selectorsMap.get(state.current.type);
  if (!parserFn) {
    if (state.loose) {
      return state;
    }
    throw error(
      `Missing parser for query node: ${state.current.type}`,
      {
        found: state.current
      }
    );
  }
  state = await parserFn(state);
  if (isPostcssNodeWithChildren(state.current) && state.current.type !== "pseudo") {
    const node = asPostcssNodeWithChildren(
      state.current
    );
    if (node.nodes.length) {
      for (let i = 0; i < node.nodes.length; i++) {
        const current = node.nodes[i];
        if (!current) continue;
        const childState = {
          ...state,
          current,
          next: node.nodes[i + 1],
          prev: node.nodes[i - 1]
        };
        state = await walk(childState);
      }
    }
    if (isSelectorNode(node)) {
      for (const edge of state.partial.edges) {
        state.collect.edges.add(edge);
      }
      for (const node2 of state.partial.nodes) {
        state.collect.nodes.add(node2);
      }
    }
  }
  return state;
};
var securitySelectors = /* @__PURE__ */ new Set([
  ":abandoned",
  ":confused",
  ":cve",
  ":cwe",
  ":debug",
  ":deprecated",
  ":dynamic",
  ":entropic",
  ":env",
  ":eval",
  ":fs",
  ":license",
  ":malware",
  ":minified",
  ":native",
  ":network",
  ":obfuscated",
  ":scanned",
  ":score",
  ":sev",
  ":severity",
  ":shell",
  ":shrinkwrap",
  ":squat",
  ":suspicious",
  ":tracker",
  ":trivial",
  ":undesirable",
  ":unknown",
  ":unmaintained",
  ":unpopular",
  ":unstable"
]);
var setMethodToJSON = (node) => {
  const { toJSON } = node;
  const insights = node.insights;
  node.toJSON = () => ({
    ...toJSON.call(node),
    insights
  });
};
var Query = class {
  #cache;
  #diffFiles;
  #edges;
  #nodes;
  #importers;
  #retries;
  #securityArchive;
  #hostContexts;
  /**
   * Helper method to determine if a given query string is using any of
   * the known security selectors. This is useful so that operations can
   * skip hydrating the security archive if it's not needed.
   */
  static hasSecuritySelectors(query) {
    for (const selector of securitySelectors) {
      if (query.includes(selector)) {
        return true;
      }
    }
    return false;
  }
  /**
   * Sorts an array of QueryResponse objects by specificity. Objects with
   * higher idCounter values come first, if idCounter values are equal,
   * then objects with higher commonCounter values come first. Otherwise,
   * the original order is preserved.
   */
  static specificitySort(responses) {
    return [...responses].sort((a, b) => {
      if (a.specificity.idCounter !== b.specificity.idCounter) {
        return b.specificity.idCounter - a.specificity.idCounter;
      }
      if (a.specificity.commonCounter !== b.specificity.commonCounter) {
        return b.specificity.commonCounter - a.specificity.commonCounter;
      }
      return 0;
    });
  }
  constructor({
    edges,
    nodes,
    importers,
    retries,
    securityArchive,
    hostContexts,
    diffFiles
  }) {
    this.#cache = /* @__PURE__ */ new Map();
    this.#diffFiles = diffFiles;
    this.#edges = edges;
    this.#nodes = nodes;
    this.#importers = importers;
    this.#retries = retries ?? 3;
    this.#securityArchive = securityArchive;
    this.#hostContexts = hostContexts;
  }
  #getQueryResponseEdges(_edges) {
    return Array.from(_edges);
  }
  #getQueryResponseNodes(_nodes) {
    const nodes = Array.from(_nodes);
    for (const node of nodes) {
      const securityArchiveEntry = this.#securityArchive?.get(node.id);
      if (!securityArchiveEntry) {
        node.insights = {
          scanned: false
        };
        setMethodToJSON(node);
        continue;
      }
      node.insights = {
        scanned: true,
        score: securityArchiveEntry.score,
        abandoned: securityArchiveEntry.alerts.some(
          (i) => i.type === "missingAuthor"
        ),
        confused: securityArchiveEntry.alerts.some(
          (i) => i.type === "manifestConfusion"
        ),
        cve: securityArchiveEntry.alerts.map((i) => i.props?.cveId).filter((i) => i !== void 0),
        cwe: Array.from(
          new Set(
            securityArchiveEntry.alerts.filter((i) => i.props?.cveId).flatMap((i) => i.props?.cwes?.map((j) => j.id))
          )
        ),
        debug: securityArchiveEntry.alerts.some(
          (i) => i.type === "debugAccess"
        ),
        deprecated: securityArchiveEntry.alerts.some(
          (i) => i.type === "deprecated"
        ),
        dynamic: securityArchiveEntry.alerts.some(
          (i) => i.type === "dynamicRequire"
        ),
        entropic: securityArchiveEntry.alerts.some(
          (i) => i.type === "highEntropyStrings"
        ),
        env: securityArchiveEntry.alerts.some(
          (i) => i.type === "envVars"
        ),
        eval: securityArchiveEntry.alerts.some(
          (i) => i.type === "usesEval"
        ),
        fs: securityArchiveEntry.alerts.some(
          (i) => i.type === "filesystemAccess"
        ),
        license: {
          unlicensed: securityArchiveEntry.alerts.some(
            (i) => i.type === "explicitlyUnlicensedItem"
          ),
          misc: securityArchiveEntry.alerts.some(
            (i) => i.type === "miscLicenseIssues"
          ),
          restricted: securityArchiveEntry.alerts.some(
            (i) => i.type === "nonpermissiveLicense"
          ),
          ambiguous: securityArchiveEntry.alerts.some(
            (i) => i.type === "ambiguousClassifier"
          ),
          copyleft: securityArchiveEntry.alerts.some(
            (i) => i.type === "copyleftLicense"
          ),
          unknown: securityArchiveEntry.alerts.some(
            (i) => i.type === "unidentifiedLicense"
          ),
          none: securityArchiveEntry.alerts.some(
            (i) => i.type === "noLicenseFound"
          ),
          exception: securityArchiveEntry.alerts.some(
            (i) => i.type === "licenseException"
          )
        },
        malware: {
          low: securityArchiveEntry.alerts.some(
            (i) => i.type === "gptAnomaly"
          ),
          medium: securityArchiveEntry.alerts.some(
            (i) => i.type === "gptSecurity"
          ),
          high: securityArchiveEntry.alerts.some(
            (i) => i.type === "gptMalware"
          ),
          critical: securityArchiveEntry.alerts.some(
            (i) => i.type === "malware"
          )
        },
        minified: securityArchiveEntry.alerts.some(
          (i) => i.type === "minifiedFile"
        ),
        native: securityArchiveEntry.alerts.some(
          (i) => i.type === "hasNativeCode"
        ),
        network: securityArchiveEntry.alerts.some(
          (i) => i.type === "networkAccess"
        ),
        obfuscated: securityArchiveEntry.alerts.some(
          (i) => i.type === "obfuscatedFile"
        ),
        scripts: securityArchiveEntry.alerts.some(
          (i) => i.type === "installScripts"
        ),
        severity: {
          low: securityArchiveEntry.alerts.some(
            (i) => i.type === "mildCVE"
          ),
          medium: securityArchiveEntry.alerts.some(
            (i) => i.type === "potentialVulnerability"
          ),
          high: securityArchiveEntry.alerts.some(
            (i) => i.type === "cve"
          ),
          critical: securityArchiveEntry.alerts.some(
            (i) => i.type === "criticalCVE"
          )
        },
        shell: securityArchiveEntry.alerts.some(
          (i) => i.type === "shellAccess"
        ),
        shrinkwrap: securityArchiveEntry.alerts.some(
          (i) => i.type === "shrinkwrap"
        ),
        squat: {
          medium: securityArchiveEntry.alerts.some(
            (i) => i.type === "gptDidYouMean"
          ),
          critical: securityArchiveEntry.alerts.some(
            (i) => i.type === "didYouMean"
          )
        },
        suspicious: securityArchiveEntry.alerts.some(
          (i) => i.type === "suspiciousStarActivity"
        ),
        tracker: securityArchiveEntry.alerts.some(
          (i) => i.type === "telemetry"
        ),
        trivial: securityArchiveEntry.alerts.some(
          (i) => i.type === "trivialPackage"
        ),
        undesirable: securityArchiveEntry.alerts.some(
          (i) => i.type === "troll"
        ),
        unknown: securityArchiveEntry.alerts.some(
          (i) => i.type === "newAuthor"
        ),
        unmaintained: securityArchiveEntry.alerts.some(
          (i) => i.type === "unmaintained"
        ),
        unpopular: securityArchiveEntry.alerts.some(
          (i) => i.type === "unpopularPackage"
        ),
        unstable: securityArchiveEntry.alerts.some(
          (i) => i.type === "unstableOwnership"
        )
      };
      setMethodToJSON(node);
    }
    return nodes;
  }
  /**
   * Search the graph for nodes and edges that match the given query.
   */
  async search(query, {
    signal,
    scopeIDs = [joinDepIDTuple(["file", "."])]
  }) {
    if (!query)
      return {
        edges: [],
        nodes: [],
        importers: [],
        comment: "",
        specificity: { idCounter: 0, commonCounter: 0 }
      };
    const cachedResult = this.#cache.get(query);
    if (cachedResult) {
      return cachedResult;
    }
    const nodes = this.#nodes;
    const edges = this.#edges;
    const importers = this.#importers;
    for (const importer of importers) {
      if (!importer.workspaces) continue;
      for (const edge of importer.workspaces.values()) {
        edges.add(edge);
      }
    }
    const current = parse2(query);
    const loose = asPostcssNodeWithChildren(current).nodes.length > 1;
    const {
      collect,
      comment,
      importers: stateResultImporters,
      specificity
    } = await walk({
      cancellable: async () => {
        await new Promise((resolve12) => {
          setTimeout(resolve12, 0);
        });
        signal.throwIfAborted();
      },
      current,
      initial: {
        nodes: new Set(nodes),
        edges: new Set(edges)
      },
      collect: {
        nodes: /* @__PURE__ */ new Set(),
        edges: /* @__PURE__ */ new Set()
      },
      comment: "",
      diffFiles: this.#diffFiles,
      loose,
      importers,
      partial: { nodes, edges },
      retries: this.#retries,
      signal,
      securityArchive: this.#securityArchive,
      scopeIDs,
      walk,
      specificity: { idCounter: 0, commonCounter: 0 },
      hostContexts: this.#hostContexts
    });
    const res = {
      edges: this.#getQueryResponseEdges(collect.edges),
      nodes: this.#getQueryResponseNodes(collect.nodes),
      importers: this.#getQueryResponseNodes(stateResultImporters),
      comment,
      specificity
    };
    this.#cache.set(query, res);
    return res;
  }
  /**
   * Parses a query string in order to retrieve an array of tokens.
   */
  static getQueryTokens(query) {
    if (!query) return [];
    const tokens = [];
    const ast = (q) => {
      try {
        return parse2(q);
      } catch (_e) {
        return ast(q.slice(0, -1));
      }
    };
    const processNode = (node) => {
      for (const key of selectorsMap.keys()) {
        if (node.type === key && node.type !== "root") {
          let token = `${node.spaces.before}${node.value}${node.spaces.after}`;
          if (isIdentifierNode(node)) {
            token = `${node.spaces.before}#${node.value}${node.spaces.after}`;
          } else if (isSelectorNode(node)) {
            token = `${node.spaces.before},${node.spaces.after}`;
          } else if (isAttributeNode(node)) {
            token = String(
              node.source?.start?.column && node.source.end?.column && `${node.spaces.before}${query.slice(node.source.start.column - 1, node.source.end.column)}${node.spaces.after}`
            );
          }
          if (isPostcssNodeWithChildren(node) && isPseudoNode(node) && node.nodes.length) {
            token = String(token.split("(")[0]);
            token += "(";
          }
          if (!isSelectorNode(node) || node.parent?.nodes.indexOf(node) !== 0) {
            tokens.push({
              ...node,
              token
            });
          }
        }
      }
      if (isPostcssNodeWithChildren(node)) {
        for (const child of node.nodes) {
          processNode(child);
        }
        if (isPseudoNode(node) && node.nodes.length) {
          tokens.push({
            ...node,
            token: ")" + node.spaces.after,
            type: "pseudo"
          });
        }
      }
    };
    processNode(ast(query));
    return tokens;
  }
};

// ../../src/graph/src/dependencies.ts
var isDependencyTypeShort = (obj) => shortDependencyTypes.has(obj);
var isDependencySaveType = (obj) => shortDependencyTypes.has(obj) || obj === "implicit";
var isObj2 = (o) => !!o && typeof o === "object";
var isDependency = (o) => (
  // TODO: it would be nice to have a @vltpkg/spec.isSpec method
  isObj2(o) && isObj2(o.spec) && !!o.spec.type && isDependencySaveType(o.type)
);
var asDependency = (obj) => {
  if (!isDependency(obj)) {
    throw error("Invalid dependency", { found: obj });
  }
  return obj;
};
var shorten = (typeLong, name, manifest) => {
  const shortName = dependencyTypes.get(typeLong);
  if (!shortName) {
    throw error("Invalid dependency type name", {
      found: typeLong,
      validOptions: [...longDependencyTypes]
    });
  }
  if (shortName !== "peer") {
    return shortName;
  }
  if (name && manifest?.peerDependenciesMeta?.[name]?.optional === true) {
    return "peerOptional";
  }
  return "peer";
};
var isStringArray = (a) => Array.isArray(a) && !a.some((b) => typeof b !== "string");
var getRawDependencies = (node) => {
  const dependencies = /* @__PURE__ */ new Map();
  const bundleDeps = node.manifest?.bundleDependencies ?? [];
  const bundled = !node.importer && !node.id.startsWith("git") && isStringArray(bundleDeps) ? new Set(bundleDeps) : /* @__PURE__ */ new Set();
  for (const depType of longDependencyTypes) {
    const obj = node.manifest?.[depType];
    if (depType === "devDependencies" && !node.importer && !node.id.startsWith("git") && !node.id.startsWith("file")) {
      continue;
    }
    if (obj) {
      for (const [name, bareSpec] of Object.entries(obj)) {
        if (bundled.has(name)) continue;
        dependencies.set(name, {
          name,
          type: depType,
          bareSpec,
          registry: node.registry
        });
      }
    }
  }
  return dependencies;
};
var getDependencies = (node, options) => {
  const res = /* @__PURE__ */ new Map();
  const dependencies = getRawDependencies(node);
  for (const { name, type: type2, bareSpec } of dependencies.values()) {
    const depType = shorten(type2, name, node.manifest);
    const spec2 = Spec.parse(name, bareSpec, {
      ...options,
      registry: node.registry
    });
    res.set(name, {
      spec: spec2,
      type: depType
    });
  }
  return res;
};

// ../../src/graph/src/graph.ts
import { inspect as inspect2 } from "node:util";

// ../../src/graph/src/lockfile/save.ts
import { mkdirSync, writeFileSync } from "node:fs";
import { dirname as dirname2, resolve as resolve3 } from "node:path";

// ../../src/graph/src/lockfile/types.ts
var LOCKFILE_VERSION = 1;
var getFlagNumFromNode = (node) => node.optional && node.dev ? LockfileNodeFlagDevOptional : node.optional ? LockfileNodeFlagOptional : node.dev ? LockfileNodeFlagDev : LockfileNodeFlagNone;
var getBooleanFlagsFromNum = (flags) => ({
  dev: !!(flags & LockfileNodeFlagDev),
  optional: !!(flags & LockfileNodeFlagOptional)
});
var LockfileNodeFlagNone = 0;
var LockfileNodeFlagOptional = 1;
var LockfileNodeFlagDev = 2;
var LockfileNodeFlagDevOptional = 3;
var BuildStateNone = void 0;
var BuildStateNeeded = 1;
var BuildStateBuilt = 2;
var BuildStateFailed = 3;
var getBuildStateFromNode = (node) => {
  switch (node.buildState) {
    case "needed":
      return BuildStateNeeded;
    case "built":
      return BuildStateBuilt;
    case "failed":
      return BuildStateFailed;
    default:
      return BuildStateNone;
  }
};
var getBuildStateFromNum = (state) => {
  switch (state) {
    case BuildStateNeeded:
      return "needed";
    case BuildStateBuilt:
      return "built";
    case BuildStateFailed:
      return "failed";
    default:
      return "none";
  }
};

// ../../src/graph/src/lockfile/save.ts
var formatNodes = (nodes, saveManifests, saveBuildData, registry2, throwOnMissingManifest) => {
  const arr = [...nodes].filter((node) => !node.importer);
  const orderedNodes = arr.sort(
    (a, b) => a.id.localeCompare(b.id, "en")
  );
  const res = {};
  for (const node of orderedNodes) {
    const customRegistry = node.resolved && registry2 && !node.resolved.startsWith(registry2);
    const resolved = customRegistry ? node.resolved : void 0;
    const location = node.id.startsWith("file") || node.inVltStore() ? void 0 : node.location;
    const flags = getFlagNumFromNode(node);
    const lockfileNode = [flags, node.name];
    if (node.integrity) {
      lockfileNode[2] = node.integrity;
    }
    if (resolved && !node.id.startsWith("remote")) {
      lockfileNode[3] = resolved;
    }
    if (location) {
      lockfileNode[4] = location;
    }
    if (saveManifests && node.manifest) {
      lockfileNode[5] = expandNormalizedManifestSymbols(node.manifest);
      if (node.confused && node.rawManifest) {
        lockfileNode[6] = expandNormalizedManifestSymbols(
          node.rawManifest
        );
      }
    }
    if (throwOnMissingManifest && !node.manifest) {
      throw error(`Missing manifest for node ${node.id}.`);
    }
    if (node.optional && node.platform) {
      lockfileNode[7] = node.platform;
    }
    if (node.bins && Object.keys(node.bins).length) {
      lockfileNode[8] = node.bins;
    }
    if (saveBuildData) {
      const buildState = getBuildStateFromNode(node);
      if (buildState !== void 0) {
        lockfileNode[9] = buildState;
      }
    }
    res[node.id] = lockfileNode;
  }
  return res;
};
var formatEdges = (edges) => Object.fromEntries(
  [...edges].sort(
    (a, b) => (
      /* c8 ignore start - nondeterminstic and annoying to test */
      // sort importers to the top, then alphabetically by
      // id, type, target
      Number(b.from.importer) - Number(a.from.importer) || a.from.id.localeCompare(b.from.id, "en") || a.type.localeCompare(b.type, "en") || (a.to?.id ?? "").localeCompare(b.to?.id ?? "")
    )
    /* c8 ignore stop */
  ).map((edge) => [
    `${edge.from.id} ${edge.spec.name}`,
    `${edge.type} ${edge.spec.bareSpec || "*"} ${edge.to?.id ?? "MISSING"}`
  ])
);
var removeDefaultItems = (defaultItems, items) => {
  const res = {};
  for (const [key, value] of Object.entries(items)) {
    if (!defaultItems[key] || defaultItems[key] !== value) {
      res[key] = value;
    }
  }
  return res;
};
var lockfileData = ({
  graph,
  catalog,
  catalogs,
  "git-hosts": gitHosts,
  "git-host-archives": gitHostArchives,
  modifiers,
  registry: registry2,
  registries,
  saveManifests,
  saveBuildData,
  "scope-registries": scopeRegistries,
  "jsr-registries": jsrRegistries,
  throwOnMissingManifest
}) => {
  const cleanGitHosts = isRecordStringString(gitHosts) ? removeDefaultItems(defaultGitHosts, gitHosts) : void 0;
  const cleanGitHostArchives = isRecordStringString(gitHostArchives) ? removeDefaultItems(defaultGitHostArchives, gitHostArchives) : void 0;
  const cleanModifiers = modifiers && isRecordStringString(modifiers.config) ? modifiers.config : void 0;
  const cleanRegistries = isRecordStringString(registries) ? removeDefaultItems(defaultRegistries, registries) : void 0;
  const cleanScopeRegistries = isRecordStringString(scopeRegistries) ? removeDefaultItems(defaultScopeRegistries, scopeRegistries) : void 0;
  const cleanJsrRegistries = isRecordStringString(jsrRegistries) ? removeDefaultItems(defaultJsrRegistries, jsrRegistries) : void 0;
  const hasItems = (clean) => clean && Object.keys(clean).length;
  return {
    lockfileVersion: LOCKFILE_VERSION,
    options: {
      ...hasItems(cleanModifiers) ? { modifiers: cleanModifiers } : {},
      ...hasItems(catalog) ? { catalog } : {},
      ...hasItems(catalogs) ? { catalogs } : {},
      ...hasItems(cleanScopeRegistries) ? { "scope-registries": cleanScopeRegistries } : void 0,
      ...hasItems(cleanJsrRegistries) ? { "jsr-registries": cleanJsrRegistries } : void 0,
      ...registry2 !== void 0 && registry2 !== defaultRegistry ? { registry: registry2 } : void 0,
      ...hasItems(cleanRegistries) ? { registries: cleanRegistries } : void 0,
      ...hasItems(cleanGitHosts) ? { "git-hosts": cleanGitHosts } : void 0,
      ...hasItems(cleanGitHostArchives) ? { "git-host-archives": cleanGitHostArchives } : void 0
    },
    nodes: formatNodes(
      graph.nodes.values(),
      saveManifests,
      saveBuildData,
      registry2,
      throwOnMissingManifest
    ),
    edges: formatEdges(graph.edges)
  };
};
var extraFormat = (jsonString) => {
  const str = `${jsonString}
`;
  const [init2, ...parts] = str.split('  "nodes": {');
  const res = [init2];
  for (const part of parts) {
    res.push(
      part.replaceAll("\n      ", "").replaceAll("\n    ]", "]")
    );
  }
  return res.join('  "nodes": {');
};
var saveData = (data, fileName, saveManifests = false) => {
  const json = JSON.stringify(data, null, 2);
  const content = saveManifests ? json : extraFormat(json);
  writeFileSync(fileName, content);
};
var save = (options) => {
  const { graph } = options;
  const data = lockfileData({ ...options, saveManifests: false });
  const fileName = resolve3(graph.projectRoot, "vlt-lock.json");
  saveData(data, fileName, false);
};
var saveHidden = (options) => {
  const { graph } = options;
  let data;
  try {
    data = lockfileData({
      ...options,
      saveManifests: true,
      saveBuildData: true,
      throwOnMissingManifest: true
    });
  } catch {
  }
  if (!data) return;
  const fileName = resolve3(
    graph.projectRoot,
    "node_modules/.vlt-lock.json"
  );
  mkdirSync(dirname2(fileName), { recursive: true });
  saveData(data, fileName, true);
};

// ../../src/graph/src/resolve-save-type.ts
var resolveSaveType = (node, name, saveType) => saveType !== "implicit" ? saveType : node.edgesOut.get(name)?.type ?? "prod";

// ../../src/graph/src/graph.ts
var kCustomInspect2 = /* @__PURE__ */ Symbol.for("nodejs.util.inspect.custom");
var cacheKeySeparator = "\u2502";
var mainDepID = joinDepIDTuple(["file", "."]);
var getMap = (m) => m ?? /* @__PURE__ */ new Map();
var getResolutionCacheKey = (spec2, location, extra) => {
  const f = spec2.final;
  const fromPrefix = f.type === "file" ? location + " : " : "";
  const typePrecisionKey = f.registry ? `${cacheKeySeparator}registry${cacheKeySeparator}${f.registry}` : f.gitRemote ? `${cacheKeySeparator}git${cacheKeySeparator}${f.gitRemote}` : `${cacheKeySeparator}${f.type}`;
  const modifierSuffix = `${cacheKeySeparator}${extra}`;
  return fromPrefix + String(f) + typePrecisionKey + modifierSuffix;
};
var Graph = class {
  get [Symbol.toStringTag]() {
    return "@vltpkg/graph.Graph";
  }
  #options;
  #nodeOptions;
  /**
   * A {@link Monorepo} instance, used for managing workspaces.
   */
  monorepo;
  /**
   * An inventory with all manifests related to an install.
   */
  manifests;
  /**
   * A set of all edges in this graph.
   */
  edges = /* @__PURE__ */ new Set();
  /**
   * Map registered dep ids to the node that represent them in the graph.
   */
  nodes = /* @__PURE__ */ new Map();
  /**
   * Map of nodes by their name
   */
  nodesByName = /* @__PURE__ */ new Map();
  /**
   * Cached resolutions for spec lookups
   */
  resolutions = /* @__PURE__ */ new Map();
  /**
   * Reverse map of resolutions
   */
  resolutionsReverse = /* @__PURE__ */ new Map();
  /**
   * A set of importer nodes in this graph.
   */
  importers = /* @__PURE__ */ new Set();
  /**
   * The {@link Node} that represents the project root `package.json`.
   */
  mainImporter;
  /**
   * A set of extraneous dependencies found when building the graph.
   */
  extraneousDependencies = /* @__PURE__ */ new Set();
  /**
   * The root of the project this graph represents
   */
  projectRoot;
  /**
   * The peer context sets used to resolve peer dependencies within this graph.
   */
  peerContexts;
  /**
   * Cache of forked peer contexts so identical fork operations can reuse
   * previously created contexts instead of duplicating them.
   *
   * Key format is internal and constructed in `ideal/peers.ts`.
   */
  peerContextForkCache = /* @__PURE__ */ new Map();
  /**
   * Tracks the current peer context index.
   */
  currentPeerContextIndex = 0;
  constructor(options) {
    const { mainManifest, monorepo } = options;
    this.#options = options;
    const specOptions = getOptions({
      registry: options.registry,
      registries: options.registries,
      "git-hosts": options["git-hosts"],
      "git-host-archives": options["git-host-archives"],
      "scope-registries": options["scope-registries"],
      "jsr-registries": options["jsr-registries"],
      catalog: options.catalog,
      catalogs: options.catalogs
    });
    this.manifests = getMap(options.manifests);
    this.projectRoot = options.projectRoot;
    this.#nodeOptions = {
      ...this.#options,
      ...specOptions,
      graph: this
    };
    const mainImporterLocation = ".";
    const mainImporterSpec = Spec2.parse(
      mainManifest.name || "(root)",
      mainImporterLocation
    );
    const mainImporter = this.addNode(
      mainDepID,
      mainManifest,
      mainImporterSpec
    );
    mainImporter.setImporterLocation(mainImporterLocation);
    mainImporter.mainImporter = true;
    this.mainImporter = mainImporter;
    this.mainImporter.workspaces = /* @__PURE__ */ new Map();
    this.importers.add(mainImporter);
    this.manifests.set(mainImporter.id, mainManifest);
    this.monorepo = monorepo;
    if (this.monorepo) {
      for (const ws of this.monorepo) {
        const wsNode = this.addNode(
          ws.id,
          ws.manifest,
          void 0,
          ws.name
        );
        wsNode.setImporterLocation(`./${ws.path}`);
        if (wsNode.manifest) {
          this.manifests.set(wsNode.id, wsNode.manifest);
          if (wsNode.manifest.bin) {
            wsNode.bins = wsNode.manifest.bin;
          }
        }
        this.importers.add(wsNode);
        const edge = new Edge(
          "prod",
          Spec2.parse(wsNode.name, "workspace:*", this.#options),
          this.mainImporter,
          wsNode
        );
        this.mainImporter.workspaces.set(wsNode.name, edge);
      }
    }
    const initialPeerContext = /* @__PURE__ */ new Map();
    initialPeerContext.index = this.currentPeerContextIndex;
    this.peerContexts = [initialPeerContext];
  }
  /**
   * Get the next peer context index.
   */
  nextPeerContextIndex() {
    return ++this.currentPeerContextIndex;
  }
  /**
   * Delete all nodes and edges that are unreachable from the importers.
   * The collection of deleted nodes is returned.
   *
   * NOTE: This can be extremely slow for large graphs, and is almost always
   * unnecessary! Only call when it is known that some unreachable nodes may
   * have been created, for example when deleting the unneeded subgraph when an
   * optional node fails to resolve/install.
   */
  gc() {
    const { nodes } = this;
    this.edges.clear();
    this.nodes = /* @__PURE__ */ new Map();
    const marked = new Set(this.importers);
    for (const imp of marked) {
      nodes.delete(imp.id);
      this.nodes.set(imp.id, imp);
      for (const edge of imp.edgesOut.values()) {
        this.edges.add(edge);
        const { to } = edge;
        if (!to || marked.has(to)) continue;
        marked.add(to);
        nodes.delete(to.id);
        this.nodes.set(to.id, to);
      }
    }
    for (const node of nodes.values()) {
      this.removeNode(node);
    }
    return nodes;
  }
  /**
   * Create a new edge between two nodes of the graph in case both exist,
   * in case the destination node does not exists, then a dangling edge,
   * pointing to nothing will be created to represent that missing dependency.
   */
  addEdge(type2, spec2, from, to) {
    if (spec2.name === "(unknown)") {
      if (to) {
        spec2.name = to.name || "(unknown)";
        spec2.spec = `${to.name}@${spec2.bareSpec}`;
      } else {
        throw error(
          "Impossible to place a missing, nameless dependency",
          { spec: spec2 }
        );
      }
    }
    const existing = from.edgesOut.get(spec2.name);
    if (existing) {
      const edge = existing;
      if (edge.type === type2 && edge.spec.bareSpec === spec2.bareSpec) {
        if (to && to !== edge.to) {
          edge.to?.edgesIn.delete(edge);
          edge.to = to;
          edge.to.edgesIn.add(edge);
        }
        return edge;
      }
      this.edges.delete(edge);
    }
    const f = from;
    const edgeOut = f.addEdgesTo(
      resolveSaveType(from, spec2.name, type2),
      spec2,
      to
    );
    this.edges.add(edgeOut);
    return edgeOut;
  }
  /**
   * Find an existing node to satisfy a dependency
   */
  findResolution(spec2, fromNode, extra = "") {
    const f = spec2.final;
    const sf = getResolutionCacheKey(f, fromNode.location, extra);
    const cached = this.resolutions.get(sf);
    if (cached) return cached;
    const nbn = this.nodesByName.get(f.name);
    if (!nbn) return void 0;
    for (const node of nbn) {
      if (satisfies2(
        node.id,
        f,
        fromNode.location,
        this.projectRoot,
        this.monorepo
      )) {
        this.resolutions.set(sf, node);
        this.resolutionsReverse.get(node)?.add(sf);
        return node;
      }
    }
  }
  /**
   * Create a new node in the graph.
   */
  addNode(id2, manifest, spec2, name, version) {
    const node = new Node(
      this.#nodeOptions,
      id2,
      manifest,
      spec2,
      name,
      version
    );
    this.nodes.set(node.id, node);
    const nbn = this.nodesByName.get(node.name) ?? /* @__PURE__ */ new Set();
    nbn.add(node);
    const newByNameSet = new Set(
      [...nbn].sort((a, b) => a.id.localeCompare(b.id))
    );
    this.nodesByName.set(node.name, newByNameSet);
    if (manifest) {
      this.manifests.set(node.id, manifest);
    }
    return node;
  }
  /**
   * Place a new package into the graph representation, creating the new
   * edges and possibly new nodes that are to be expected when traversing
   * the graph in a top-down direction, e.g: from importers to leafs.
   *
   * For different uses that are not a direct top-down traversal of the graph
   * consider using `addNode()` and `addEdge()` instead.
   */
  placePackage(fromNode, depType, spec2, manifest, id2, extra) {
    if (!manifest && !id2) {
      this.addEdge(depType, spec2, fromNode);
      return;
    }
    const flags = {
      dev: fromNode.dev || depType === "dev",
      optional: fromNode.optional || depType === "optional" || depType === "peerOptional"
    };
    const depId = id2 || manifest && getId(spec2, manifest, extra);
    if (!depId) {
      throw error("Could not find dep id when placing package", {
        spec: spec2,
        manifest
      });
    }
    const toFoundNode = this.nodes.get(depId);
    if (toFoundNode) {
      this.addEdge(depType, spec2, fromNode, toFoundNode);
      toFoundNode.detached = false;
      toFoundNode.dev &&= flags.dev;
      toFoundNode.optional &&= flags.optional;
      return toFoundNode;
    }
    const toNode = this.addNode(depId, manifest, spec2);
    toNode.registry = spec2.registry;
    toNode.dev = flags.dev;
    toNode.optional = flags.optional;
    if (extra) {
      const { modifier, peerSetHash } = splitExtra(extra);
      toNode.modifier = modifier;
      toNode.peerSetHash = peerSetHash;
    }
    if (manifest) {
      const { bin, engines, os: os2, cpu, libc } = manifest;
      if (engines || os2 || cpu || libc) {
        const platform = {};
        if (engines) platform.engines = engines;
        if (os2) platform.os = os2;
        if (cpu) platform.cpu = cpu;
        if (libc) platform.libc = libc;
        toNode.platform = platform;
      }
      if (bin) {
        toNode.bins = bin;
      }
    }
    toNode.maybeSetConfusedManifest(spec2, manifest);
    this.addEdge(depType, spec2, fromNode, toNode);
    const f = getResolutionCacheKey(
      spec2.final,
      fromNode.location,
      extra || ""
    );
    this.resolutions.set(f, toNode);
    const rrev = this.resolutionsReverse.get(toNode) ?? /* @__PURE__ */ new Set();
    rrev.add(f);
    this.resolutionsReverse.set(toNode, rrev);
    return toNode;
  }
  /**
   * Removes a node and its relevant edges from the graph.
   *
   * Use the `keepEdges` option to keep the edges that were pointing to
   * this node and only removes their `to` property value.
   *
   * If a replacement is provided, then any edges that were previously
   * pointing to the removed node will be directed to the replacement,
   * if it is valid to do so.
   */
  removeNode(node, replacement, keepEdges) {
    this.nodes.delete(node.id);
    const nbn = this.nodesByName.get(node.name);
    if (nbn?.size === 1) this.nodesByName.delete(node.name);
    else nbn?.delete(node);
    for (const r of this.resolutionsReverse.get(node) ?? /* @__PURE__ */ new Set()) {
      this.resolutions.delete(r);
    }
    this.resolutionsReverse.delete(node);
    this.manifests.delete(node.id);
    for (const edge of node.edgesOut.values()) {
      this.edges.delete(edge);
    }
    for (const edge of node.edgesIn) {
      if (replacement && satisfies2(
        replacement.id,
        edge.spec,
        edge.from.location,
        this.projectRoot,
        this.monorepo
      )) {
        edge.to = replacement;
      } else if (keepEdges) {
        edge.to = void 0;
      } else {
        edge.from.edgesOut.delete(edge.spec.name);
        this.edges.delete(edge);
      }
    }
  }
  /**
   * Removes the resolved node of a given edge.
   */
  removeEdgeResolution(edge, extra = "") {
    const node = edge.to;
    const resolutionKey = getResolutionCacheKey(
      edge.spec,
      edge.from.location,
      extra
    );
    if (node) {
      edge.to = void 0;
      this.resolutions.delete(resolutionKey);
      this.resolutionsReverse.get(node)?.delete(resolutionKey);
      this.nodesByName.delete(node.name);
      node.edgesIn.delete(edge);
      if (node.edgesIn.size === 0) {
        this.nodes.delete(node.id);
      }
    }
  }
  /**
   * Remove all edges from the graph while preserving nodes and resolution caches.
   * This allows the graph to be reconstructed efficiently using the existing nodes.
   */
  resetEdges() {
    this.edges.clear();
    for (const node of this.nodes.values()) {
      node.detached = true;
      node.edgesOut.clear();
      node.edgesIn.clear();
    }
  }
  toJSON() {
    return lockfileData({
      ...this.#options,
      graph: this,
      saveManifests: true
    });
  }
  [kCustomInspect2](_, options) {
    const data = this.toJSON();
    return `${this[Symbol.toStringTag]} ${inspect2(data, options)}`;
  }
};

// ../../src/graph/src/lockfile/load.ts
import { readFileSync } from "node:fs";
import { resolve as resolve4 } from "node:path";

// ../../src/graph/src/lockfile/load-edges.ts
var retrieveNodeFromGraph = (key, value, graph, fromId, seenNodes) => {
  const foundNode = graph.nodes.get(asDepID(fromId));
  if (!foundNode) {
    throw error("Edge info missing its `from` node", {
      found: {
        nodes: [...graph.nodes].map(([id2]) => id2),
        from: foundNode,
        fromId,
        edge: { [key]: value }
      }
    });
  }
  if (seenNodes) {
    seenNodes.set(fromId, foundNode);
  }
  return foundNode;
};
var loadEdges = (graph, edges, options) => {
  const entries = Object.entries(edges);
  const edgeCount = entries.length;
  const useOptimizations = edgeCount > 50;
  const edgeProcessingQueue = [];
  const seenNodes = useOptimizations ? /* @__PURE__ */ new Map() : void 0;
  for (const [key, value] of entries) {
    const [fromId, specName] = fastSplit(key, " ", 2);
    const [depType, valRest] = fastSplit(value, " ", 2);
    const vrSplit = valRest?.lastIndexOf(" ") ?? -1;
    if (!valRest || !depType || !fromId || !specName || vrSplit < 1) {
      continue;
    }
    if (!isDependencyTypeShort(depType)) {
      throw error("Found unsupported dependency type in lockfile", {
        validOptions: [...longDependencyTypes]
      });
    }
    let fromNode;
    if (seenNodes) {
      const seen = seenNodes.get(fromId);
      if (seen) {
        fromNode = seen;
      } else {
        fromNode = retrieveNodeFromGraph(
          key,
          value,
          graph,
          fromId,
          seenNodes
        );
      }
    } else {
      fromNode = retrieveNodeFromGraph(key, value, graph, fromId);
    }
    const toId = valRest.substring(vrSplit + 1);
    let toNode = void 0;
    if (toId !== "MISSING") {
      if (seenNodes) {
        const seen = seenNodes.get(toId);
        if (seen) {
          toNode = seen;
        } else {
          toNode = graph.nodes.get(asDepID(toId));
          if (toNode) {
            seenNodes.set(toId, toNode);
          }
        }
      } else {
        toNode = graph.nodes.get(asDepID(toId));
      }
    }
    const spec2 = Spec.parse(specName, valRest.substring(0, vrSplit), {
      ...options,
      registry: fromNode.registry
    });
    if (useOptimizations) {
      edgeProcessingQueue.push({
        fromNode,
        toNode,
        depType,
        spec: spec2
      });
    } else {
      graph.addEdge(depType, spec2, fromNode, toNode);
    }
  }
  if (useOptimizations) {
    for (const {
      fromNode,
      toNode,
      depType,
      spec: spec2
    } of edgeProcessingQueue) {
      graph.addEdge(depType, spec2, fromNode, toNode);
    }
  }
};

// ../../src/graph/src/lockfile/load-nodes.ts
var loadNodes = (graph, nodes, options, actual2, throwOnMissingManifest) => {
  const entries = Object.entries(nodes);
  const nodeCount = entries.length;
  const registryVersionCache = nodeCount > 50 ? /* @__PURE__ */ new Map() : null;
  for (const [id2, lockfileNode] of entries) {
    const [
      flags,
      name,
      integrity,
      resolved,
      location,
      manifest,
      rawManifest,
      platform,
      bins,
      buildState
    ] = lockfileNode;
    if (graph.nodes.has(id2)) continue;
    const [type2, filepath, maybeExtra, lastExtra] = splitDepID(id2);
    const extra = type2 === "registry" || type2 === "git" ? lastExtra : maybeExtra;
    const registrySpec = maybeExtra;
    const referenceNode = actual2?.nodes.get(id2);
    const mani = manifest ?? referenceNode?.manifest;
    if (!mani && throwOnMissingManifest) {
      throw error(
        `Missing manifest for node ${id2} and no reference node found.`
      );
    }
    let version;
    if (type2 === "registry" && registrySpec && registrySpec.indexOf("@") > 0) {
      if (registryVersionCache) {
        const seenVersion = registryVersionCache.get(registrySpec);
        if (seenVersion) {
          version = seenVersion;
        } else {
          version = registrySpec.split("@").slice(-1)[0] || void 0;
          if (version) {
            registryVersionCache.set(registrySpec, version);
          }
        }
      } else {
        version = registrySpec.split("@").slice(-1)[0] || void 0;
      }
    }
    const node = mani ? graph.addNode(id2, mani) : graph.addNode(
      id2,
      void 0,
      void 0,
      name ?? void 0,
      version
    );
    if (extra) {
      const { modifier, peerSetHash } = splitExtra(extra);
      if (modifier) {
        node.modifier = modifier;
      }
      if (peerSetHash) {
        node.peerSetHash = peerSetHash;
      }
    }
    const { dev: dev2, optional: optional2 } = getBooleanFlagsFromNum(flags);
    node.options = options;
    node.dev = dev2;
    node.optional = optional2;
    node.integrity = integrity ?? referenceNode?.integrity;
    node.resolved = type2 === "remote" ? filepath : resolved ?? referenceNode?.resolved;
    node.projectRoot = graph.projectRoot;
    if (!node.resolved) node.setResolved();
    if (location) {
      node.location = location;
    } else {
      if (type2 === "file") {
        node.location = filepath;
      }
    }
    if (mani && rawManifest) {
      node.setConfusedManifest(mani, rawManifest);
    }
    if (platform) {
      node.platform = platform;
    }
    if (bins) {
      node.bins = bins;
    }
    if (buildState !== void 0 && buildState !== null) {
      node.buildState = getBuildStateFromNum(buildState);
    }
  }
};

// ../../src/graph/src/lockfile/load.ts
var loadLockfile = (projectRoot, lockfilePath) => JSON.parse(
  readFileSync(resolve4(projectRoot, lockfilePath), {
    encoding: "utf8"
  })
);
var load3 = (options) => {
  const { projectRoot } = options;
  return loadObject(
    options,
    loadLockfile(projectRoot, "vlt-lock.json")
  );
};
var loadHidden = (options) => {
  const { projectRoot } = options;
  options.throwOnMissingManifest = true;
  return loadObject(
    options,
    loadLockfile(projectRoot, "node_modules/.vlt-lock.json")
  );
};
var loadObject = (options, lockfileData2) => {
  const version = lockfileData2.lockfileVersion;
  if (version == null) {
    throw error("Missing lockfile version", {
      code: "ELOCKFILEVERSION",
      found: version,
      wanted: LOCKFILE_VERSION
    });
  }
  if (version !== LOCKFILE_VERSION) {
    throw error(
      `Unsupported lockfile version.

  Run: \`vlt update\` to start a new, supported lockfile.`,
      {
        code: "ELOCKFILEVERSION",
        found: version,
        wanted: LOCKFILE_VERSION
      }
    );
  }
  const { mainManifest, scurry } = options;
  const packageJson = options.packageJson ?? new PackageJson();
  const monorepo = options.monorepo ?? Monorepo.maybeLoad(options.projectRoot, { packageJson, scurry });
  const {
    catalog = {},
    catalogs = {},
    "scope-registries": scopeRegistries,
    registry: registry2,
    registries,
    "git-hosts": gitHosts,
    "git-host-archives": gitHostArchives
    /* c8 ignore next */
  } = lockfileData2.options ?? {};
  const mergedOptions = {
    ...options,
    catalog,
    catalogs,
    "scope-registries": scopeRegistries ? { ...options["scope-registries"], ...scopeRegistries } : options["scope-registries"],
    registry: registry2 ?? options.registry,
    registries: registries ? { ...options.registries, ...registries } : options.registries,
    "git-hosts": gitHosts ? { ...options["git-hosts"], ...gitHosts } : options["git-hosts"],
    "git-host-archives": gitHostArchives ? { ...options["git-host-archives"], ...gitHostArchives } : options["git-host-archives"]
  };
  const graph = new Graph({
    ...mergedOptions,
    mainManifest,
    monorepo
  });
  loadNodes(
    graph,
    lockfileData2.nodes,
    mergedOptions,
    options.actual,
    options.throwOnMissingManifest
  );
  loadEdges(graph, lockfileData2.edges, mergedOptions);
  for (const node of graph.nodes.values()) {
    const [firstEdge] = node.edgesIn;
    if (firstEdge?.spec.registry) {
      node.registry = firstEdge.spec.registry;
    }
  }
  return graph;
};

// ../../src/graph/src/actual/load.ts
import { existsSync, readFileSync as readFileSync2 } from "node:fs";
import { resolve as resolve5 } from "node:path";
var isStoreConfigObject = (obj) => isObject(obj) && Object.prototype.hasOwnProperty.call(obj, "modifiers") && isObject(obj.modifiers);
var asStoreConfigObject = (obj) => {
  if (!isStoreConfigObject(obj)) {
    throw new TypeError(`Expected a store config object, got ${obj}`);
  }
  return obj;
};
var pathBasedType = /* @__PURE__ */ new Set(["file", "workspace"]);
var isPathBasedType = (type2) => pathBasedType.has(type2);
var getPathBasedId = (spec2, path2) => isPathBasedType(spec2.type) ? joinDepIDTuple([spec2.type, path2.relativePosix()]) : findDepID(path2);
var findDepID = ({ parent, name }) => parent?.name === ".vlt" ? asDepID(name) : parent?.isCWD === false ? findDepID(parent) : void 0;
var findNodeModules = ({
  parent,
  name,
  isCWD
}) => parent?.name === "node_modules" ? parent : parent && name !== ".vlt" && !isCWD ? findNodeModules(parent) : void 0;
var findName = ({ parent, name }) => parent?.name.startsWith("@") ? `${parent.name}/${name}` : name;
var maybeApplyModifierToSpec = (spec2, depName, modifierRefs) => {
  const activeModifier = modifierRefs?.get(depName);
  const queryModifier = activeModifier?.modifier.query;
  const completeModifier = activeModifier && activeModifier.interactiveBreadcrumb.current === activeModifier.modifier.breadcrumb.last;
  if (queryModifier && completeModifier && "spec" in activeModifier.modifier) {
    const modifiedSpec = activeModifier.modifier.spec;
    modifiedSpec.overridden = true;
    return { spec: modifiedSpec, queryModifier };
  }
  return { spec: spec2, queryModifier };
};
var readDir = (scurry, currDir, fromNodeName) => {
  const res = /* @__PURE__ */ new Set();
  for (const entry of scurry.readdirSync(currDir)) {
    if (entry.name.startsWith(".")) continue;
    if (entry.name.startsWith("@")) {
      const scopedItems = readDir(scurry, entry, fromNodeName);
      for (const scopedItem of scopedItems) {
        res.add(scopedItem);
      }
      continue;
    }
    if (!entry.isSymbolicLink()) continue;
    const realpath = entry.realpathSync();
    if (!realpath) {
      continue;
    }
    const alias = findName(entry);
    const name = findName(realpath);
    res.add({
      alias,
      name,
      realpath
    });
  }
  return res;
};
var parseDir = (options, scurry, packageJson, depsFound, graph, fromNode, currDir) => {
  const { loadManifests, modifiers } = options;
  const dependencies = getRawDependencies(fromNode);
  const seenDeps = /* @__PURE__ */ new Set();
  const readItems = readDir(
    scurry,
    currDir,
    fromNode.name
  );
  const modifierRefs = modifiers?.tryDependencies(fromNode, [
    ...getDependencies(fromNode, options).values()
  ]);
  for (const { alias, name, realpath } of readItems) {
    let node;
    seenDeps.add(alias);
    if (!loadManifests) {
      const depId = findDepID(realpath);
      if (depId) {
        let h = hydrate2(depId, alias, options);
        if (h.type === "registry" && h.registry === h.options.registry && fromNode.registry) {
          h.registry = fromNode.registry;
        }
        const { spec: modifiedSpec, queryModifier } = maybeApplyModifierToSpec(h, alias, modifierRefs);
        h = modifiedSpec;
        node = graph.placePackage(
          fromNode,
          "prod",
          // defaults to prod deps
          h,
          // uses spec from hydrated id
          {
            name
          },
          depId,
          joinExtra({ modifier: queryModifier })
        );
        const activeModifier = modifierRefs?.get(alias);
        if (activeModifier && node) {
          modifiers?.updateActiveEntry(node, activeModifier);
        }
      }
    }
    const deps = dependencies.get(alias);
    if (!node) {
      const mani = packageJson.read(realpath.fullpath());
      const type2 = deps?.type || "dependencies";
      const bareSpec = deps?.bareSpec || "*";
      const depType = shorten(type2, alias, fromNode.manifest);
      let spec2 = Spec2.parse(alias, bareSpec, {
        ...options,
        registry: fromNode.registry
      });
      const { spec: modifiedSpec, queryModifier } = maybeApplyModifierToSpec(spec2, alias, modifierRefs);
      spec2 = modifiedSpec;
      const maybeId = getPathBasedId(spec2, realpath);
      let peerSetHash;
      if (maybeId) {
        try {
          const tuple = splitDepID(maybeId);
          const type3 = tuple[0];
          const extra = type3 === "registry" || type3 === "git" ? tuple[3] : tuple[2];
          peerSetHash = extra ? splitExtra(extra).peerSetHash : void 0;
        } catch {
        }
      }
      node = graph.placePackage(
        fromNode,
        depType,
        spec2,
        mani,
        maybeId,
        joinExtra({ modifier: queryModifier, peerSetHash })
      );
      const activeModifier = modifierRefs?.get(alias);
      if (activeModifier && node) {
        modifiers?.updateActiveEntry(node, activeModifier);
      }
    }
    if (node) {
      if (loadManifests && !deps) {
        const [edge] = node.edgesIn;
        if (edge) {
          graph.extraneousDependencies.add(edge);
        }
      }
      node.location = `./${realpath.relativePosix()}`;
      const node_modules = findNodeModules(realpath);
      if (node_modules) {
        depsFound.set(node, node_modules);
      }
    }
  }
  for (const { name, type: type2, bareSpec } of dependencies.values()) {
    if (!seenDeps.has(name)) {
      const depType = shorten(type2, name, fromNode.manifest);
      let spec2 = Spec2.parse(name, bareSpec, {
        ...options,
        registry: fromNode.registry
      });
      const { spec: modifiedSpec, queryModifier } = maybeApplyModifierToSpec(spec2, name, modifierRefs);
      spec2 = modifiedSpec;
      graph.placePackage(
        fromNode,
        depType,
        spec2,
        void 0,
        void 0,
        joinExtra({ modifier: queryModifier })
      );
    }
  }
};
var verifyImporterNodeModules = (graph, projectRoot) => {
  for (const importer of graph.importers) {
    const nm = resolve5(projectRoot, importer.location, "node_modules");
    if (!existsSync(nm)) {
      throw new Error(
        `Missing node_modules for importer: ${importer.location}`
      );
    }
  }
};
var load4 = (options) => {
  const done = graphStep("actual");
  const {
    modifiers,
    monorepo,
    projectRoot,
    packageJson,
    scurry,
    skipHiddenLockfile = false,
    skipLoadingNodesOnModifiersChange = false
  } = options;
  const mainManifest = options.mainManifest ?? packageJson.read(projectRoot);
  if (!skipHiddenLockfile) {
    try {
      const graph2 = loadHidden({
        ...options,
        projectRoot,
        mainManifest,
        packageJson,
        monorepo,
        scurry
      });
      verifyImporterNodeModules(graph2, projectRoot);
      done();
      return graph2;
    } catch {
    }
  }
  const graph = new Graph({ ...options, mainManifest });
  let storeConfig = { modifiers: void 0 };
  try {
    storeConfig = asStoreConfigObject(
      JSON.parse(
        readFileSync2(
          scurry.resolve("node_modules/.vlt/vlt.json"),
          "utf8"
        )
      )
    );
  } catch {
  }
  const storeModifiers = JSON.stringify(storeConfig.modifiers ?? {});
  const optionsModifiers = JSON.stringify(modifiers?.config);
  const modifiersChanged = storeModifiers !== optionsModifiers;
  const shouldLoadDependencies = !(skipLoadingNodesOnModifiersChange && modifiersChanged);
  if (shouldLoadDependencies) {
    const depsFound = /* @__PURE__ */ new Map();
    for (const importer of graph.importers) {
      modifiers?.tryImporter(importer);
      depsFound.set(
        importer,
        scurry.cwd.resolve(`${importer.location}/node_modules`)
      );
    }
    for (const [node, path2] of depsFound.entries()) {
      parseDir(
        options,
        scurry,
        packageJson,
        depsFound,
        graph,
        node,
        path2
      );
    }
    modifiers?.rollbackActiveEntries();
    if (scurry.cwd.resolve("node_modules").lstatSync()?.isDirectory()) {
      saveHidden({
        ...options,
        graph
      });
    }
  }
  done();
  return graph;
};

// ../../src/graph/src/reify/build.ts
import { join as join2 } from "node:path";

// ../../src/graph/src/non-empty-list.ts
var isNonEmptyList = (list) => !!list.length;
var nonEmptyList = (nodes) => isNonEmptyList(nodes) ? nodes : void 0;

// ../../src/graph/src/remove-optional-subgraph.ts
var removeOptionalSubgraph = (graph, startingNode) => {
  const removed = /* @__PURE__ */ new Set();
  for (const node of findOptionalSubgraph(startingNode)) {
    graph.removeNode(node, void 0, true);
    removed.add(node);
  }
  return removed;
};
function* findOptionalSubgraph(node, seen = /* @__PURE__ */ new Set()) {
  if (seen.has(node)) return;
  seen.add(node);
  yield node;
  for (const { from, optional: optional2 } of node.edgesIn) {
    if (from.isOptional() && !optional2) {
      for (const dep of findOptionalSubgraph(from, seen)) yield dep;
    }
  }
}

// ../../src/graph/src/reify/optional-fail.ts
function optionalFail(diff2, node) {
  return node.isOptional() ? () => del(diff2, node) : void 0;
}
var del = (diff2, node) => {
  diff2.hadOptionalFailures = true;
  for (const del2 of removeOptionalSubgraph(diff2.to, node)) {
    diff2.nodes.delete.add(del2);
    diff2.nodes.add.delete(del2);
  }
  diff2.nodes.add.delete(node);
  diff2.nodes.delete.add(node);
};

// ../../src/graph/src/reify/bin-chmod.ts
import { statSync as statSync3, existsSync as existsSync2 } from "node:fs";
import { chmod as chmod2 } from "node:fs/promises";
var binChmodAll = async (nodes, scurry) => {
  const chmods = [];
  for (const node of nodes) {
    chmods.push(binChmod(node, scurry));
  }
  await Promise.all(chmods);
};
var binChmod = async (node, scurry) => {
  const chmods = [];
  if (!node.bins) return;
  for (const bin of Object.values(node.bins)) {
    const path2 = scurry.resolve(
      `${node.resolvedLocation(scurry)}/${bin}`
    );
    if (existsSync2(path2)) {
      chmods.push(makeExecutable(path2));
    }
  }
  await Promise.all(chmods);
};
var execMode = 0;
var makeExecutable = async (path2) => {
  if (!execMode) {
    execMode = statSync3(path2).mode & 511 | 73;
  }
  await chmod2(path2, execMode);
};

// ../../src/graph/src/reify/build.ts
var build = async (diff2, packageJson, scurry, allowScriptsNodes) => {
  const graph = diff2.to;
  const nodes = nonEmptyList([...graph.importers]);
  const res = { success: [], failure: [] };
  const shouldRunScripts = (node) => allowScriptsNodes.has(node.id);
  if (!nodes) return res;
  await graphRun({
    graph: nodes,
    visit: async (node, signal, path2) => {
      if (!node.importer && (!diff2.nodes.add.has(node) || !shouldRunScripts(node)))
        return;
      try {
        await visit(packageJson, scurry, node, signal, path2);
        if (!node.importer) {
          node.buildState = "built";
          res.success.push(node);
        }
      } catch (err) {
        if (node.optional) {
          node.buildState = "failed";
          res.failure.push(node);
          await Promise.reject(err).catch(optionalFail(diff2, node));
        } else {
          throw err;
        }
      }
    },
    getDeps: (node) => {
      const deps = [];
      for (const { to } of node.edgesOut.values()) {
        if (to) deps.push(to);
      }
      return deps;
    }
  });
  return res;
};
var visit = async (packageJson, scurry, node, signal, _path) => {
  node.manifest ??= packageJson.read(node.resolvedLocation(scurry));
  const { manifest } = node;
  const { scripts: scripts2 = {} } = manifest;
  const {
    install: install2,
    preinstall,
    postinstall,
    prepare,
    preprepare,
    postprepare
  } = scripts2;
  const hasBindingGyp = scurry.lstatSync(join2(node.resolvedLocation(scurry), "binding.gyp"))?.isFile() ?? false;
  const hasImplicitInstall = hasBindingGyp && !install2 && !preinstall;
  const runInstall = !!(install2 || preinstall || postinstall) || hasImplicitInstall;
  if (runInstall) {
    await run({
      signal,
      arg0: "install",
      ignoreMissing: true,
      packageJson,
      cwd: node.resolvedLocation(scurry),
      projectRoot: node.projectRoot,
      manifest
    });
  }
  const prepable = node.id.startsWith("git") || node.importer || !node.inVltStore();
  const runPrepare = !!(prepare || preprepare || postprepare) && prepable;
  if (runPrepare) {
    await run({
      signal,
      arg0: "prepare",
      ignoreMissing: true,
      packageJson,
      cwd: node.resolvedLocation(scurry),
      projectRoot: node.projectRoot,
      manifest
    });
  }
  await binChmod(node, scurry);
};

// ../../src/graph/src/diff.ts
var kCustomInspect3 = /* @__PURE__ */ Symbol.for("nodejs.util.inspect.custom");
var Diff = class {
  from;
  to;
  projectRoot;
  /**
   * If changes need to be made later for failures of optional nodes,
   * set this flag so that we know to call graph.gc() at the appropriate time.
   */
  hadOptionalFailures = false;
  /**
   * Collection of nodes to add and delete
   */
  nodes = {
    /** Nodes in the `to` graph that are not in the `from` graph */
    add: /* @__PURE__ */ new Set(),
    /** Nodes in the `from` graph that are not in the `to` graph */
    delete: /* @__PURE__ */ new Set()
  };
  /**
   * Collection of nodes to add and delete
   */
  edges = {
    /** Edges in the `to` graph that are not found in the `from` graph */
    add: /* @__PURE__ */ new Set(),
    /** Edges in the `from` graph that are not found in the `to` graph */
    delete: /* @__PURE__ */ new Set()
  };
  /**
   * True if the diff only contains optional nodes (computed during construction)
   */
  optionalOnly = true;
  get [Symbol.toStringTag]() {
    return "@vltpkg/graph.Diff";
  }
  constructor(from, to) {
    this.from = from;
    this.to = to;
    this.projectRoot = from.projectRoot;
    if (to.projectRoot !== from.projectRoot) {
      throw error("projectRoot mismatch in Graph diff", {
        wanted: from.projectRoot,
        found: to.projectRoot
      });
    }
    for (const [id2, node] of this.from.nodes) {
      if (!this.to.nodes.get(id2)?.equals(node)) {
        this.nodes.delete.add(node);
      }
    }
    for (const [id2, node] of this.to.nodes) {
      if (!this.from.nodes.get(id2)?.equals(node)) {
        this.nodes.add.add(node);
        if (!node.optional) {
          this.optionalOnly = false;
        }
      }
    }
    for (const edge of this.to.edges) {
      const fromNode = this.from.nodes.get(edge.from.id);
      const fromEdge = fromNode?.edgesOut.get(edge.spec.name);
      if (fromEdge?.to?.id === edge.to?.id) continue;
      if (fromEdge?.to) this.edges.delete.add(fromEdge);
      if (edge.to) {
        this.edges.add.add(edge);
        if (!edge.optional) {
          this.optionalOnly = false;
        }
      }
    }
    for (const edge of this.from.edges) {
      const toNode = this.to.nodes.get(edge.from.id);
      const toEdge = toNode?.edgesOut.get(edge.spec.name);
      if (toEdge?.to?.id === edge.to?.id) continue;
      if (edge.to) this.edges.delete.add(edge);
      if (toEdge?.to) this.edges.add.add(toEdge);
    }
  }
  [kCustomInspect3](_, options) {
    const red = options?.colors ? ["\x1B[31m", "\x1B[m"] : ["", ""];
    const green = options?.colors ? ["\x1B[32m", "\x1B[m"] : ["", ""];
    const lines = [];
    for (const node of this.nodes.add) {
      lines.push(`+ ${node.id}`);
    }
    for (const node of this.nodes.delete) {
      lines.push(`- ${node.id}`);
    }
    for (const edge of this.edges.add) {
      const to = edge.to?.id ?? "";
      lines.push(
        `+ ${edge.from.id} ${edge.type} ${edge.spec} ${to}`.trim()
      );
    }
    for (const edge of this.edges.delete) {
      const to = edge.to?.id ?? "";
      lines.push(
        `- ${edge.from.id} ${edge.type} ${edge.spec} ${to}`.trim()
      );
    }
    const wrap = (s, c) => c.join(s);
    const color = options?.colors ? (s) => wrap(s, s.startsWith("+") ? green : red) : (s) => s;
    return `${this[Symbol.toStringTag]} {
${lines.sort((a, b) => a.substring(1).localeCompare(b.substring(1), "en")).map((s) => "  " + color(s)).join("\n")}
}`;
  }
  hasChanges() {
    return this.nodes.add.size > 0 || this.nodes.delete.size > 0 || this.edges.add.size > 0 || this.edges.delete.size > 0;
  }
  toJSON() {
    return {
      nodes: {
        add: [...this.nodes.add].map((node) => node.toJSON()),
        delete: [...this.nodes.delete].map((node) => node.toJSON())
      },
      edges: {
        add: [...this.edges.add].map((edge) => edge.toJSON()),
        delete: [...this.edges.delete].map((edge) => edge.toJSON())
      }
    };
  }
};

// ../../src/graph/src/build.ts
var filterNodesByQuery = async (targetQuery, graph) => {
  const securityArchive = Query.hasSecuritySelectors(targetQuery) ? await SecurityArchive.start({
    nodes: [...graph.nodes.values()]
  }) : void 0;
  const edges = graph.edges;
  const nodes = new Set(graph.nodes.values());
  const importers = graph.importers;
  const query = new Query({
    edges,
    nodes,
    importers,
    securityArchive
  });
  const { nodes: resultNodes } = await query.search(targetQuery, {
    signal: new AbortController().signal
  });
  return new Set(resultNodes.map((node) => node.id));
};
var build2 = async (options) => {
  const {
    projectRoot,
    packageJson,
    monorepo = Monorepo.maybeLoad(projectRoot),
    scurry,
    mainManifest = packageJson.read(projectRoot),
    target,
    ...loadOptions
  } = options;
  const actualGraph = load4({
    ...loadOptions,
    projectRoot,
    packageJson,
    monorepo,
    scurry,
    loadManifests: true
  });
  const targetFilteredNodes = await filterNodesByQuery(
    target,
    actualGraph
  );
  const diff2 = new Diff(
    new Graph({
      ...options,
      projectRoot,
      monorepo,
      mainManifest
    }),
    actualGraph
  );
  diff2.nodes.add = new Set(
    [...diff2.nodes.add].filter((node) => node.buildState === "needed")
  );
  const buildResult = await build(
    diff2,
    packageJson,
    scurry,
    targetFilteredNodes
  );
  saveHidden({
    ...options,
    graph: actualGraph
  });
  return buildResult;
};

// ../../src/graph/src/visualization/json-output.ts
function jsonOutput({
  edges,
  nodes,
  importers
}) {
  const res = [];
  const seenIds = /* @__PURE__ */ new Set();
  const orderedEdges = [...edges].sort((a, b) => {
    const aIsWorkspace = a.spec.type === "workspace";
    const bIsWorkspace = b.spec.type === "workspace";
    if (aIsWorkspace && !bIsWorkspace) return -1;
    if (!aIsWorkspace && bIsWorkspace) return 1;
    return 0;
  });
  for (const edge of orderedEdges) {
    if (edge.to) seenIds.add(edge.to.id);
    res.push({
      name: edge.name,
      fromID: edge.from.id,
      spec: String(edge.spec),
      type: edge.type,
      to: edge.to,
      overridden: edge.spec.overridden
    });
  }
  const orderedImporters = [...importers].sort((a, b) => {
    if (!a.name) return 1;
    if (!b.name) return -1;
    return a.name.localeCompare(b.name);
  });
  for (const node of orderedImporters) {
    if (!nodes.includes(node) || seenIds.has(node.id)) continue;
    res.unshift({
      /* c8 ignore next - name can't be missing but ts won't know */
      name: node.name || node.id,
      to: node,
      overridden: false
    });
  }
  return res;
}

// ../../src/graph/src/visualization/human-readable-output.ts
import { styleText as utilStyleText } from "node:util";
var styleText = (format, s) => utilStyleText(format, s, { validateStream: false });
var chars = new Map(
  Object.entries({
    connection: "\u2500",
    down: "\u2502",
    "last-child": "\u2514",
    "middle-child": "\u251C",
    t: "\u252C"
  })
);
var isSelected = (options, edge, node) => (!node || options.nodes.includes(node)) && (!edge || options.edges.includes(edge));
var getTreeItems = (initialItems, options) => {
  const seenNodes = /* @__PURE__ */ new Set();
  const treeItems = /* @__PURE__ */ new Map();
  const traverse = new Set(initialItems);
  for (const item of traverse) {
    if (item.node) {
      if (seenNodes.has(item.node)) {
        item.seen = true;
        continue;
      }
      seenNodes.add(item.node);
      const edges = [...item.node.edgesOut.values()];
      const workspaces = item.node.workspaces ? [...item.node.workspaces.values()] : [];
      const allEdges = [...edges, ...workspaces].sort(
        (a, b) => a.name.localeCompare(b.name, "en")
      );
      const seenEdgeName = /* @__PURE__ */ new Set();
      for (const edge of allEdges) {
        if (seenEdgeName.has(edge.name)) {
          continue;
        }
        seenEdgeName.add(edge.name);
        const toItems = treeItems.get(edge) ?? /* @__PURE__ */ new Map();
        const nextItem = {
          edge,
          node: edge.to,
          hasSibling: false,
          padding: "",
          prefix: "",
          seen: false,
          include: isSelected(options, edge, edge.to),
          parent: item
        };
        toItems.set(edge.to, nextItem);
        treeItems.set(edge, toItems);
        traverse.add(nextItem);
      }
    }
  }
  for (const item of [...traverse].reverse()) {
    if (item.include && item.parent) {
      item.parent.include = true;
    }
  }
  return treeItems;
};
function humanReadableOutput(options, { colors }) {
  const { importers } = options;
  const createStyleText = (style) => (s) => colors ? styleText(style, s) : s;
  const dim = createStyleText("dim");
  const red = createStyleText("red");
  const reset = createStyleText("reset");
  const yellow = createStyleText("yellow");
  const initialItems = /* @__PURE__ */ new Set();
  for (const importer of importers) {
    initialItems.add({
      name: importer.name,
      edge: void 0,
      node: importer,
      prefix: "",
      padding: "",
      hasSibling: false,
      seen: false,
      include: isSelected(options, void 0, importer),
      parent: void 0
    });
  }
  const treeItems = getTreeItems(initialItems, options);
  let res = "";
  const traverse = (item) => {
    let header = "";
    let content = "";
    const name = item.name;
    const decoratedName = options.highlightSelection && isSelected(options, item.edge, item.node) && name ? yellow(name) : name;
    if (!item.node && item.include) {
      const missing2 = item.edge?.type.endsWith("ptional") ? dim("(missing optional)") : red("(missing)");
      return `${item.padding}${item.prefix}${decoratedName} ${missing2}
`;
    }
    header += `${item.padding}${item.prefix}${decoratedName}
`;
    if (!item.seen) {
      const edges = item.node ? [...item.node.edgesOut.values()] : [];
      const workspaces = item.node?.workspaces ? [...item.node.workspaces.values()] : [];
      const allEdges = [...edges, ...workspaces].sort(
        (a, b) => a.name.localeCompare(b.name, "en")
      );
      const nextItems = allEdges.map((i) => treeItems.get(i)?.get(i.to));
      const includedItems = nextItems.filter((i) => i?.include);
      for (const nextItem of nextItems) {
        if (!nextItem) continue;
        const parent = item;
        const isLast = includedItems.indexOf(nextItem) === includedItems.length - 1;
        const depIdTuple = nextItem.node?.id && splitDepID(nextItem.node.id);
        const hasCustomReg = depIdTuple?.[0] === "registry" && depIdTuple[1] && depIdTuple[1] !== defaultRegistryName;
        const nodeName = hasCustomReg ? `${depIdTuple[1]}:${nextItem.node?.name}` : nextItem.node?.name;
        const toName = nextItem.node?.version ? `${nodeName}@${nextItem.node.version}` : nodeName;
        const nextChar = isLast ? "last-child" : "middle-child";
        const aliasedPackage = hasCustomReg || nextItem.node?.name && nextItem.edge?.name !== nextItem.node.name;
        nextItem.name = nextItem.node?.confused ? `${nextItem.edge?.name} ${red("(confused)")}` : nextItem.edge?.spec.overridden ? (
          /* c8 ignore next */
          `${nextItem.edge.name}@${nextItem.node?.version || nextItem.edge.spec.bareSpec}${aliasedPackage ? ` (${toName})` : ""} ${yellow("(overridden)")}`
        ) : aliasedPackage ? `${nextItem.edge?.name} (${toName})` : `${nextItem.edge?.name}@${nextItem.node?.version || nextItem.edge?.spec.bareSpec}`;
        nextItem.padding = parent.prefix.length ? `${parent.padding}${parent.hasSibling ? chars.get("down") : " "} ` : "";
        nextItem.prefix = `${chars.get(nextChar)}${chars.get("connection")}${chars.get("connection")} `;
        nextItem.hasSibling = !isLast;
        content += traverse(nextItem);
      }
    }
    const regularConnection = `${chars.get("connection")} `;
    const parentConnection = `${chars.get("t")} `;
    return item.include ? `${content ? header.replace(regularConnection, parentConnection) : header}${content}` : "";
  };
  for (const item of initialItems) {
    res += traverse(item);
  }
  return reset(res);
}

// ../../src/graph/src/visualization/mermaid-output.ts
var missingCount = 0;
var isSelected2 = (options, edge, node) => (!node || options.nodes.includes(node)) && /* c8 ignore next */
(!edge || options.edges.includes(edge));
function generateShortId(index) {
  const base = 52;
  const digitToChar = (digit) => {
    if (digit < 26) {
      return String.fromCharCode(97 + digit);
    } else {
      return String.fromCharCode(65 + (digit - 26));
    }
  };
  let result = "";
  let num = index + 1;
  while (num > 0) {
    num--;
    const remainder = num % base;
    result = digitToChar(remainder) + result;
    num = Math.floor(num / base);
  }
  return result;
}
function createDepIdMapping(importers) {
  const mapping = /* @__PURE__ */ new Map();
  const uniqueDepIds = /* @__PURE__ */ new Set();
  const [importer] = importers;
  if (importer) {
    for (const node of importer.graph.nodes.values()) {
      uniqueDepIds.add(node.id);
    }
  }
  let index = 0;
  for (const depId of uniqueDepIds) {
    mapping.set(depId, generateShortId(index++));
  }
  return mapping;
}
var nodeRef = (node, labeledNodes, depIdMapping, options) => {
  const shortId = depIdMapping.get(
    node.id
  ) ?? "";
  const selectedClass = options.highlightSelection && isSelected2(options, void 0, node) ? ":::a" : "";
  if (labeledNodes.has(node.id)) {
    return shortId + selectedClass;
  }
  labeledNodes.add(node.id);
  return `${shortId}("${String(node).replaceAll("@", "#64;")}")${selectedClass}`;
};
function parseNode(seenNodes, labeledNodes, includedItems, depIdMapping, options, node, isImporter = false) {
  if (seenNodes.has(node.id) || !includedItems.get(node)) {
    return "";
  }
  seenNodes.add(node.id);
  const nodeLabel = isImporter ? nodeRef(node, labeledNodes, depIdMapping, options) : "";
  const allEdges = [
    ...node.edgesOut.values(),
    ...node.workspaces?.values() ?? []
  ];
  const edges = allEdges.map(
    (e) => parseEdge(
      seenNodes,
      labeledNodes,
      includedItems,
      depIdMapping,
      options,
      e
    )
  ).filter(Boolean).join("\n");
  if (isImporter) {
    return `${nodeLabel}${edges.length ? "\n" : ""}${edges}`;
  }
  return edges;
}
function parseEdge(seenNodes, labeledNodes, includedItems, depIdMapping, options, edge) {
  if (!includedItems.get(edge)) {
    return "";
  }
  const edgeType = edge.type === "prod" ? "" : ` (${edge.type})`;
  const edgeResult = nodeRef(edge.from, labeledNodes, depIdMapping, options) + ` -->|"${String(edge.spec).replaceAll("@", "#64;")}${edgeType}"| `;
  const missingLabel = edge.type.endsWith("ptional") ? "Missing Optional" : "Missing";
  if (!edge.to) {
    return edgeResult + `missing-${missingCount++}(${missingLabel})`;
  }
  const toRef = nodeRef(edge.to, labeledNodes, depIdMapping, options);
  const childEdges = parseNode(
    seenNodes,
    labeledNodes,
    includedItems,
    depIdMapping,
    options,
    edge.to
  );
  return edgeResult + toRef + (childEdges ? "\n" + childEdges : "");
}
function mermaidOutput(options) {
  const { edges, importers, nodes, highlightSelection } = options;
  const seen = /* @__PURE__ */ new Set();
  const includedItems = /* @__PURE__ */ new Map();
  const traverse = new Set(
    [...importers].map((i) => ({ self: i, parent: void 0 }))
  );
  for (const item of traverse) {
    if (seen.has(item.self)) continue;
    seen.add(item.self);
    if (item.self instanceof Edge) {
      if (edges.includes(item.self)) {
        includedItems.set(item.self, true);
      }
      if (item.self.to) {
        traverse.add({ self: item.self.to, parent: item.self });
      }
    }
    if (item.self instanceof Node) {
      if (nodes.includes(item.self)) {
        includedItems.set(item.self, true);
      }
      for (const edge of item.self.edgesOut.values()) {
        traverse.add({ self: edge, parent: item.self });
      }
      if (item.self.workspaces) {
        for (const edge of item.self.workspaces.values()) {
          traverse.add({ self: edge, parent: item.self });
        }
      }
    }
  }
  for (const item of [...traverse].reverse()) {
    if (includedItems.has(item.self) && item.parent) {
      includedItems.set(item.parent, true);
    }
  }
  const depIdMapping = createDepIdMapping(importers);
  const labeledNodes = /* @__PURE__ */ new Set();
  const seenNodes = /* @__PURE__ */ new Set();
  const graphOutput = [...importers].map(
    (i) => parseNode(
      seenNodes,
      labeledNodes,
      includedItems,
      depIdMapping,
      options,
      i,
      true
      // isImporter
    )
  ).filter(Boolean).join("\n");
  const styleDefinition = highlightSelection ? "\nclassDef a fill:gold,color:#242424" : "";
  return "flowchart TD\n" + graphOutput + styleDefinition;
}

// ../../src/rollback-remove/src/index.ts
import { spawn as spawn3 } from "node:child_process";
import { rename } from "node:fs/promises";
import { basename, dirname as dirname3 } from "node:path";

// ../../src/rollback-remove/src/remove.ts
import { resolve as resolve6 } from "node:path";
var __CODE_SPLIT_SCRIPT_NAME = resolve6(import.meta.dirname, "rollback-remove-src-remove.js");

// ../../src/rollback-remove/src/index.ts
var isDeno = globalThis.Deno != void 0;
var RollbackRemove = class {
  #key = String(Math.random()).substring(2);
  #paths = /* @__PURE__ */ new Map();
  async rm(path2) {
    if (this.#paths.has(path2)) return;
    const target = `${dirname3(path2)}/.VLT.DELETE.${this.#key}.${basename(path2)}`;
    this.#paths.set(path2, target);
    await rename(path2, target).catch((e) => {
      if (e instanceof Error && "code" in e && /* c8 ignore start - very spurious weirdness on Windows */
      (e.code === "ENOENT" || e.code === "EPERM")) {
        this.#paths.delete(path2);
        return;
      }
      throw e;
    });
  }
  confirm() {
    if (!this.#paths.size) return;
    const env2 = { ...process.env };
    const args = [];
    const detached = !(isDeno && process.platform === "win32");
    if (isDeno) {
      args.push(
        "--unstable-node-globals",
        "--unstable-bare-node-builtins"
      );
    }
    args.push(__CODE_SPLIT_SCRIPT_NAME);
    const child = spawn3(process.execPath, args, {
      stdio: ["pipe", "ignore", "ignore"],
      detached,
      env: env2
    });
    for (const path2 of this.#paths.values()) {
      child.stdin.write(`${path2}\0`);
    }
    child.stdin.end();
    if (detached) {
      child.unref();
    }
    this.#paths.clear();
  }
  async rollback() {
    const promises = [];
    for (const [original, moved] of this.#paths) {
      promises.push(
        rimraf(original).catch(() => {
        }).then(() => rename(moved, original))
      );
    }
    await Promise.all(promises);
    this.#paths.clear();
  }
};

// ../../src/dss-breadcrumb/src/index.ts
var passthroughComparator = () => () => true;
var semverComparator = ({ range }) => ({ semver }) => {
  if (range && semver) {
    return intersects(semver, range);
  }
  return false;
};
var pseudoSelectors2 = /* @__PURE__ */ new Map([
  [":semver", semverComparator],
  [":v", semverComparator]
]);
var importerNames = /* @__PURE__ */ new Set([":project", ":workspace", ":root"]);
for (const importerName of importerNames) {
  pseudoSelectors2.set(importerName, passthroughComparator);
}
var removeQuotes2 = (value) => value.replace(/^"(.*?)"$/, "$1");
var extractPseudoParameter = (item) => {
  if (!isPostcssNodeWithChildren(item) || !item.nodes[0]) {
    return {};
  }
  let first;
  try {
    const firstNode = asPostcssNodeWithChildren(item.nodes[0]).nodes[0];
    if (isStringNode(firstNode)) {
      first = removeQuotes2(firstNode.value);
    }
    if (isTagNode(firstNode)) {
      first = asTagNode(firstNode).value;
    }
  } catch {
  }
  if (item.value === ":semver" || item.value === ":v") {
    return {
      semverValue: first
    };
  }
  return {};
};
var getPseudoSelectorFullText = (item) => {
  if (!isPostcssNodeWithChildren(item) || !item.nodes[0]) {
    return item.value || "";
  }
  const baseValue = item.value;
  const paramNode = item.nodes[0];
  let paramText = "";
  if (isPostcssNodeWithChildren(paramNode)) {
    paramText = paramNode.nodes.map((node) => {
      if (isStringNode(node)) {
        return asStringNode(node).value;
      } else if (isTagNode(node)) {
        return asTagNode(node).value;
      } else {
        return node.value;
      }
    }).join("");
  }
  return `${baseValue}(${paramText})`;
};
var Breadcrumb = class {
  #items;
  comment;
  specificity;
  /**
   * Initializes the interactive breadcrumb with a query string.
   */
  constructor(query) {
    this.#items = [];
    this.specificity = { idCounter: 0, commonCounter: 0 };
    const ast = parse2(query);
    let afterCombinator = true;
    for (const item of ast.first.nodes) {
      const pseudoNode = isPseudoNode(item);
      if (pseudoNode && !pseudoSelectors2.has(item.value)) {
        throw error("Invalid pseudo selector", {
          found: item.value
        });
      }
      const allowedTypes = isIdentifierNode(item) || pseudoNode || isCombinatorNode(item) && item.value === ">" || isCommentNode(item);
      const hasChildren = isPostcssNodeWithChildren(item) && item.nodes.length > 0;
      const semverNode = pseudoNode && (item.value === ":semver" || item.value === ":v");
      if (hasChildren && !pseudoNode || !allowedTypes) {
        throw error("Invalid query", { found: query });
      }
      if (isCombinatorNode(item)) {
        afterCombinator = true;
        continue;
      } else if (isCommentNode(item)) {
        const cleanComment = item.value.replace(/^\/\*/, "").replace(/\*\/$/, "").trim();
        this.comment = cleanComment;
        afterCombinator = true;
      } else {
        const lastItem = this.#items.length > 0 ? this.#items[this.#items.length - 1] : void 0;
        const providedRange = pseudoNode && (item.value === ":semver" || item.value === ":v") ? extractPseudoParameter(item).semverValue ?? "" : "";
        const internalOptions = {
          ...semverNode ? { range: providedRange } : {}
        };
        const comparator = (pseudoSelectors2.get(item.value) ?? passthroughComparator)(internalOptions);
        if (lastItem && !afterCombinator) {
          if (pseudoNode && isPseudoNode(lastItem)) {
            throw error("Invalid query", { found: query });
          }
          let currentValue = item.value;
          if (item.type === "id") {
            currentValue = `#${item.value}`;
          } else if (pseudoNode) {
            currentValue = getPseudoSelectorFullText(item);
          }
          lastItem.value = `${lastItem.value}${currentValue}`;
          if (isIdentifierNode(item)) {
            lastItem.name = item.value;
          }
          if (pseudoNode) {
            const lastItemComparator = lastItem.comparator;
            lastItem.comparator = (opts) => comparator(opts) && lastItemComparator(opts);
            lastItem.importer ||= importerNames.has(item.value);
          }
          if (isIdentifierNode(item)) {
            this.specificity.idCounter++;
          } else if (pseudoNode) {
            this.specificity.commonCounter++;
          }
          afterCombinator = false;
          continue;
        }
        let itemValue = item.value;
        if (item.type === "id") {
          itemValue = `#${item.value}`;
        } else if (pseudoNode) {
          itemValue = getPseudoSelectorFullText(item);
        }
        const newItem = {
          comparator,
          value: itemValue,
          name: item.type === "id" ? item.value : void 0,
          type: item.type,
          prev: lastItem,
          next: void 0,
          importer: pseudoNode && importerNames.has(item.value)
        };
        if (lastItem) {
          lastItem.next = newItem;
        }
        this.#items.push(newItem);
        if (isIdentifierNode(item)) {
          this.specificity.idCounter++;
        } else if (pseudoNode) {
          this.specificity.commonCounter++;
        }
        afterCombinator = false;
      }
    }
    if (!this.#items[0]) {
      throw error("Failed to parse query", {
        found: query
      });
    }
  }
  /**
   * Retrieves the first breadcrumb item.
   */
  get first() {
    if (!this.#items[0]) {
      throw error("Failed to find first breadcrumb item");
    }
    return this.#items[0];
  }
  /**
   * Retrieves the last breadcrumb item.
   */
  get last() {
    const lastItem = this.#items[this.#items.length - 1];
    if (!lastItem) {
      throw error("Failed to find first breadcrumb item");
    }
    return lastItem;
  }
  /**
   * Returns `true` if the breadcrumb is composed of a single item.
   */
  get single() {
    return this.#items.length === 1;
  }
  [Symbol.iterator]() {
    return this.#items.values();
  }
  /**
   * Empties the current breadcrumb list.
   */
  clear() {
    for (const item of this.#items) {
      item.prev = void 0;
      item.next = void 0;
    }
    this.#items.length = 0;
  }
  /**
   * Gets an {@link InteractiveBreadcrumb} instance that can be
   * used to track state of the current breadcrumb item.
   */
  interactive() {
    return new InteractiveBreadcrumb(this);
  }
};
var InteractiveBreadcrumb = class {
  #current;
  constructor(breadcrumb) {
    this.#current = breadcrumb.first;
  }
  /**
   * The current breadcrumb item.
   */
  get current() {
    return this.#current;
  }
  /**
   * Returns `true` if the current breadcrumb has no more items left.
   */
  get done() {
    return !this.#current;
  }
  /**
   * The next breadcrumb item.
   */
  next() {
    this.#current = this.#current?.next;
    return this;
  }
};
var parseBreadcrumb = (query) => new Breadcrumb(query);
var specificitySort = (breadcrumbs) => {
  return [...breadcrumbs].sort((a, b) => {
    if (a.specificity.idCounter !== b.specificity.idCounter) {
      return b.specificity.idCounter - a.specificity.idCounter;
    }
    if (a.specificity.commonCounter !== b.specificity.commonCounter) {
      return b.specificity.commonCounter - a.specificity.commonCounter;
    }
    return 0;
  });
};

// ../../src/graph/src/modifiers.ts
var GraphModifier = class _GraphModifier {
  /** The loaded modifiers configuration */
  #config;
  /** A set of all modifiers loaded from vlt.json */
  #modifiers = /* @__PURE__ */ new Set();
  /** A set of all edge modifiers loaded from vlt.json */
  #edgeModifiers = /* @__PURE__ */ new Set();
  /** A set of all node modifiers loaded from vlt.json */
  #nodeModifiers = /* @__PURE__ */ new Set();
  /**
   * A map of initial entries, keyed by the name of the first breadcrumb
   * item to its modifier entry. Useful for checking for non-importer
   * starting breadcrumbs, e.g: `#a > #b`
   */
  #initialEntries = /* @__PURE__ */ new Map();
  /**
   * A multi-level map of active entries, keyed by:
   * - modifiers
   * - edge name
   * - from node
   * that allows for retrieving seen {@link ModifierActiveEntry} instances
   * in constant time.
   */
  #activeEntries = /* @__PURE__ */ new Map();
  /**
   * A set of currently active modifiers, which are being parsed.
   */
  activeModifiers = /* @__PURE__ */ new Set();
  /** A set of all modifier string values loaded from vlt.json */
  modifierNames = /* @__PURE__ */ new Set();
  constructor(options) {
    this.load(options);
  }
  /**
   * Load the modifiers definitions from vlt.json,
   * converting the result into a GraphModifierConfigObject
   */
  get config() {
    if (this.#config) return this.#config;
    return this.#config = load("modifiers", assertRecordStringString) ?? {};
  }
  /**
   * Loads the modifiers defined in `vlt.json` into memory.
   */
  load(options) {
    for (const [key, value] of Object.entries(this.config)) {
      this.modifierNames.add(key);
      const breadcrumb = parseBreadcrumb(key);
      if (!breadcrumb.last.name) {
        throw error("Could not find name in breadcrumb", {
          found: key
        });
      }
      let mod;
      if (typeof value === "string") {
        mod = {
          breadcrumb,
          query: key,
          refs: /* @__PURE__ */ new Set(),
          spec: Spec2.parse(breadcrumb.last.name, value, options),
          type: "edge",
          value
        };
        this.#edgeModifiers.add(mod);
      } else {
        const manifest = asNormalizedManifest(
          normalizeManifest(value)
        );
        mod = {
          breadcrumb,
          query: key,
          manifest,
          refs: /* @__PURE__ */ new Set(),
          type: "node",
          value: manifest
        };
        this.#nodeModifiers.add(mod);
      }
      this.#modifiers.add(mod);
      if (breadcrumb.first.name) {
        const initialSet = this.#initialEntries.get(breadcrumb.first.name) ?? /* @__PURE__ */ new Set();
        initialSet.add(mod);
        this.#initialEntries.set(breadcrumb.first.name, initialSet);
      }
    }
  }
  /**
   * Try matching the provided node against the top-level selectors. In case
   * a match is found it will also register the active entry modifier and
   * update the active entry to the current importer node.
   */
  tryImporter(importer) {
    for (const modifier of this.#modifiers) {
      const { first } = modifier.breadcrumb;
      const matchRoot = first.value === ":root" && importer.mainImporter;
      const matchWorkspace = first.value === ":workspace" && importer.importer;
      const matchAny = first.value === ":project" || matchRoot || matchWorkspace;
      if (first.importer && matchAny) {
        const active = this.newModifier(importer, modifier);
        const single = active.modifier.breadcrumb.single;
        if (!single) {
          this.updateActiveEntry(importer, active);
        }
      }
    }
  }
  /**
   * Try matching the provided node and spec to the current
   * active parsing modifier entries along with possible starting-level
   * modifiers.
   *
   * Any entries in which the breachcrumb have already reached its last
   * element will be prioritized, along with checking for specificity,
   * the complete entry with the highest specificity will be returned or just
   * the entry with the highest specificity if no complete entry is found.
   * Returns `undefined` if no matching entry is found.
   *
   * This method works with the assumption that it's going to be called
   * during a graph traversal, such that any ascendent has been checked
   * and the active modifier entry state has been updated in the previous
   * iteration.
   */
  tryNewDependency(from, spec2) {
    const { name, semver } = spec2;
    const all = /* @__PURE__ */ new Map();
    for (const modifier of this.#modifiers) {
      const entry = this.#activeEntries.get(modifier)?.get(name)?.get(from);
      if (entry) {
        all.set(entry.modifier.breadcrumb, entry);
      }
    }
    const initialSet = this.#initialEntries.get(name) ?? /* @__PURE__ */ new Set();
    for (const initial of initialSet) {
      const initialEntry = (
        /* c8 ignore next - difficult to test branch */
        this.#activeEntries.get(initial)?.get(name)?.get(from) ?? this.newModifier(from, initial)
      );
      all.set(initialEntry.modifier.breadcrumb, initialEntry);
    }
    const arr = [...all.values()];
    const completeEntries = arr.filter(
      (active) => active.interactiveBreadcrumb.current === active.modifier.breadcrumb.last
    );
    for (const entry of completeEntries) {
      this.deregisterModifier(entry.modifier);
    }
    const entries = completeEntries.length ? completeEntries : arr;
    return all.get(
      specificitySort(
        entries.filter(
          (i) => i.interactiveBreadcrumb.current?.comparator({
            semver
          })
        ).map((i) => i.modifier.breadcrumb)
      )[0]
    );
  }
  /**
   * Returns the set of {@link ModifierActiveEntry} instances that matches
   * the provided {@link Dependency} specs for a given node.
   *
   * This method is mostly a helper to {@link GraphModifier.tryNewDependency}
   * that handles the registered modifiers traversal lookup.
   */
  tryDependencies(from, dependencies) {
    const modifierRefs = /* @__PURE__ */ new Map();
    for (const { spec: spec2 } of dependencies) {
      const active = this.tryNewDependency(from, spec2);
      if (active) {
        modifierRefs.set(spec2.name, active);
      }
    }
    return modifierRefs;
  }
  /**
   * Updates an active entry state keeping track of items in the multi-level
   * active entries map. If the current breadcrumb state shows there's no more
   * items left, then we deregister the modifier.
   */
  updateActiveEntry(from, active) {
    const { modifier } = active;
    const interactiveBreadcrumb = active.interactiveBreadcrumb.next();
    const name = interactiveBreadcrumb.current?.name;
    if (interactiveBreadcrumb.done || !name) {
      this.deregisterModifier(modifier);
      return;
    }
    this.activeModifiers.add(active);
    active.modifier.refs.add({ from, name });
    const nameMap = this.#activeEntries.get(modifier) ?? /* @__PURE__ */ new Map();
    this.#activeEntries.set(modifier, nameMap);
    const nodeMap = nameMap.get(name) ?? /* @__PURE__ */ new Map();
    nameMap.set(name, nodeMap);
    nodeMap.set(from, active);
  }
  /**
   * Creates a new active modifier.
   */
  newModifier(from, modifier) {
    return {
      modifier,
      interactiveBreadcrumb: modifier.breadcrumb.interactive(),
      originalFrom: from
    };
  }
  /**
   * Removes a previously registered modifier from the active entries.
   */
  deregisterModifier(modifier) {
    for (const { from, name } of modifier.refs) {
      const nodeMap = this.#activeEntries.get(modifier)?.get(name);
      if (nodeMap) {
        const entry = nodeMap.get(from);
        if (entry) {
          this.activeModifiers.delete(entry);
        }
        nodeMap.delete(from);
        if (!nodeMap.size) {
          this.#activeEntries.get(modifier)?.delete(name);
        }
      }
    }
  }
  /**
   * Operates in previously registered nodes and edges in order to put
   * back in place any of the original edges that were referenced to in
   * active (ongoing) breadcrumb parsing entries that were never completed.
   *
   * This method can be used to easily rollback any pending operations
   * once the graph traversal is done.
   */
  rollbackActiveEntries() {
    for (const modifier of this.activeModifiers) {
      if (modifier.originalEdge) {
        modifier.originalFrom.edgesOut.set(
          modifier.originalEdge.spec.name,
          modifier.originalEdge
        );
      }
      this.deregisterModifier(modifier.modifier);
    }
  }
  /**
   * Convenience method to instantiate and load in one call.
   * Returns undefined if the project does not have a vlt.json file,
   * otherwise returns the loaded Modifiers instance.
   */
  static maybeLoad(options) {
    const config = load("modifiers", assertRecordStringString);
    if (!config) return;
    return new _GraphModifier(options);
  }
  /**
   * Convenience method to instantiate and load in one call.
   * Throws if called on a directory that does not have a vlt.json file.
   */
  static load(options) {
    return new _GraphModifier(options);
  }
};

// ../../src/graph/src/ideal/remove-satisfied-specs.ts
var removeSatisfiedSpecs = ({
  add,
  graph
}) => {
  for (const [depID, dependencies] of add.entries()) {
    const importer = graph.nodes.get(depID);
    if (!importer) {
      throw error("Referred importer node id could not be found", {
        found: depID
      });
    }
    for (const [name, dependency] of dependencies) {
      const edge = importer.edgesOut.get(name);
      if (!edge) {
        continue;
      }
      if (satisfies2(
        edge.to?.id,
        dependency.spec,
        edge.from.location,
        graph.projectRoot,
        graph.monorepo
      )) {
        dependencies.delete(name);
      }
    }
  }
  for (const [depID, dependencies] of add.entries()) {
    if (dependencies.size === 0) {
      add.delete(depID);
    }
  }
};

// ../../src/graph/src/ideal/get-importer-specs.ts
var hasDepName = (importer, edge) => {
  for (const depType of longDependencyTypes) {
    const listedDeps = importer.manifest?.[depType];
    if (listedDeps && Object.hasOwn(listedDeps, edge.name))
      return true;
  }
  return false;
};
var AddImportersDependenciesMapImpl = class extends Map {
  modifiedDependencies = false;
};
var RemoveImportersDependenciesMapImpl = class extends Map {
  modifiedDependencies = false;
};
var getImporterSpecs = (options) => {
  const { add, graph, remove } = options;
  const addResult = new AddImportersDependenciesMapImpl();
  const removeResult = new RemoveImportersDependenciesMapImpl();
  for (const importer of graph.importers) {
    const addDeps = /* @__PURE__ */ new Map();
    const removeDeps = /* @__PURE__ */ new Set();
    for (const edge of importer.edgesOut.values()) {
      if (!hasDepName(importer, edge) && !add.get(importer.id)?.has(edge.name)) {
        removeDeps.add(edge.name);
        removeResult.modifiedDependencies = true;
      }
    }
    for (const depType of longDependencyTypes) {
      const deps = Object.entries(importer.manifest?.[depType] ?? {});
      for (const [depName, depSpec] of deps) {
        const edge = importer.edgesOut.get(depName);
        if (edge?.to && depSpec === edge.spec.bareSpec) continue;
        const dependency = asDependency({
          spec: Spec2.parse(depName, depSpec, options),
          type: shorten(depType, depName, importer.manifest)
        });
        addDeps.set(depName, dependency);
      }
    }
    addResult.set(importer.id, addDeps);
    removeResult.set(importer.id, removeDeps);
  }
  const transientAdd = /* @__PURE__ */ new Map();
  const transientRemove = /* @__PURE__ */ new Map();
  for (const node of graph.nodes.values()) {
    if (graph.importers.has(node) || !node.id.startsWith("file"))
      continue;
    const nodePath = options.scurry.cwd.resolve(node.location);
    const stat3 = nodePath.lstatSync();
    if (stat3?.isDirectory()) {
      const manifest = options.packageJson.read(nodePath.fullpath());
      node.manifest = manifest;
      const addDeps = /* @__PURE__ */ new Map();
      const removeDeps = /* @__PURE__ */ new Set();
      for (const edge of node.edgesOut.values()) {
        if (!hasDepName(node, edge) && !add.get(node.id)?.has(edge.name)) {
          removeDeps.add(edge.name);
        }
      }
      for (const depType of longDependencyTypes) {
        const deps = Object.entries(manifest[depType] ?? {});
        for (const [depName, depSpec] of deps) {
          const edge = node.edgesOut.get(depName);
          if (edge?.to && depSpec === edge.spec.bareSpec) continue;
          const dependency = asDependency({
            spec: Spec2.parse(depName, depSpec, options),
            type: shorten(depType, depName, manifest)
          });
          addDeps.set(depName, dependency);
        }
      }
      if (addDeps.size > 0) {
        transientAdd.set(node.id, addDeps);
      }
      if (removeDeps.size > 0) {
        transientRemove.set(node.id, removeDeps);
      }
    }
  }
  for (const [id2, addDeps] of add.entries()) {
    const deps = addResult.get(id2);
    if (!deps) {
      if (id2.startsWith("file")) {
        transientAdd.set(id2, addDeps);
      }
      continue;
    }
    for (const [name, dep] of addDeps.entries()) {
      deps.set(name, dep);
    }
  }
  for (const [key, removeSet] of remove) {
    const importerRemoveItem = removeResult.get(key);
    if (importerRemoveItem) {
      for (const depName of removeSet) {
        importerRemoveItem.add(depName);
      }
    } else if (key.startsWith("file")) {
      const existing = transientRemove.get(key);
      if (existing) {
        for (const depName of removeSet) {
          existing.add(depName);
        }
      } else {
        transientRemove.set(key, new Set(removeSet));
      }
    }
  }
  for (const [key, removeItem] of removeResult) {
    if (removeItem.size === 0) {
      removeResult.delete(key);
    }
  }
  removeSatisfiedSpecs({
    add: addResult,
    graph
  });
  for (const addDeps of addResult.values()) {
    if (addDeps.size > 0) {
      addResult.modifiedDependencies = true;
      break;
    }
  }
  return {
    add: addResult,
    remove: removeResult,
    transientAdd,
    transientRemove
  };
};

// ../../src/graph/src/reify/calculate-save-value.ts
var SAVE_PREFIX = "^";
var calculateSaveValue = (nodeType, spec2, existing, nodeVersion) => {
  if (spec2.type === "catalog") {
    return spec2.bareSpec;
  }
  if (
    // if not from the registry, save whatever we requested
    nodeType === "registry" && // if we installed exactly what we already wanted, leave it untouched
    spec2.bareSpec !== existing && // if we installed a specific version, keep that specific version.
    !spec2.final.range?.isSingle
  ) {
    if (existing && existing === nodeVersion) {
      return existing;
    } else if (existing && !spec2.bareSpec) {
      return existing;
    } else {
      const finalRange = spec2.final.semver && spec2.final.bareSpec || `${SAVE_PREFIX}${nodeVersion}`;
      if (spec2.subspec && spec2.final.namedRegistry) {
        return `${spec2.final.namedRegistry}:${spec2.final.name}@${finalRange}`;
      }
      if (spec2.final.namedJsrRegistry) {
        return spec2.bareSpec.replace(
          new RegExp(
            `^(?:.*?@)?${spec2.final.namedJsrRegistry}:(@[^/]+/[^@]+)(@.*?)?$`
          ),
          `${spec2.final.namedJsrRegistry}:$1@${finalRange}`
        ).replace(
          // otherwise, swap out the final version for the save range
          new RegExp(
            `^(?:.*?@)?${spec2.final.namedJsrRegistry}:([^@].*?)?$`
          ),
          `${spec2.final.namedJsrRegistry}:${finalRange}`
        );
      }
      return finalRange;
    }
  }
  return spec2.bareSpec;
};

// ../../src/graph/src/fixup-added-names.ts
var fixupAddedNames = (add, manifest, options, spec2) => {
  if (add && manifest?.name && spec2.name === "(unknown)") {
    const s = add.get(String(spec2));
    if (s) {
      add.delete(String(spec2));
      spec2 = Spec2.parse(manifest.name, spec2.bareSpec, options);
      const n = {
        type: s.type,
        spec: spec2
      };
      add.set(manifest.name, n);
    }
  }
  if (add && manifest?.version && !spec2.bareSpec) {
    const addEntry = add.get(spec2.name);
    if (addEntry) {
      const saveValue = calculateSaveValue(
        spec2.final.type,
        spec2,
        void 0,
        manifest.version
      );
      if (saveValue && saveValue !== spec2.bareSpec) {
        spec2 = Spec2.parse(spec2.name, saveValue, options);
        addEntry.spec = spec2;
      }
    }
  }
  return spec2;
};

// ../../src/graph/src/reify/extract-node.ts
var getOptionalFailedNodeRemover = (node, diff2) => {
  return diff2 ? optionalFail(diff2, node) : node.isOptional() ? () => removeOptionalSubgraph(node.graph, node) : void 0;
};
var extractNode = async (node, scurry, remover, options, packageInfo, diff2) => {
  node.extracted = true;
  const { manifest = {} } = node;
  const target = node.resolvedLocation(scurry);
  const from = scurry.resolve("");
  const spec2 = hydrate2(node.id, node.name, options);
  const removeOptionalFailedNode = getOptionalFailedNodeRemover(
    node,
    diff2
  );
  const { integrity, resolved } = node;
  const platformData = node.platform ?? manifest;
  if (removeOptionalFailedNode && (manifest.deprecated || !platformCheck(
    platformData,
    process.version,
    process.platform,
    process.arch
    // libc is auto-detected by platformCheck when not provided
  ))) {
    removeOptionalFailedNode();
    return {
      success: false,
      node,
      error: new Error("Platform check failed or package deprecated")
    };
  }
  try {
    await remover.rm(target);
    if (removeOptionalFailedNode) {
      try {
        const result = await packageInfo.extract(spec2, target, {
          from,
          integrity,
          resolved
        });
        if (result.integrity && !node.integrity) {
          node.integrity = result.integrity;
        }
        return { success: true, node };
      } catch (error2) {
        removeOptionalFailedNode();
        return { success: false, node, error: error2 };
      }
    } else {
      const result = await packageInfo.extract(spec2, target, {
        from,
        integrity,
        resolved
      });
      if (result.integrity && !node.integrity) {
        node.integrity = result.integrity;
      }
      return { success: true, node };
    }
  } catch (error2) {
    if (removeOptionalFailedNode) {
      removeOptionalFailedNode();
      return { success: false, node, error: error2 };
    }
    throw error2;
  }
};

// ../../src/graph/src/ideal/sorting.ts
var isPeerType = (type2) => type2 === "peer" || type2 === "peerOptional";
var compareByHasPeerDeps = (a, b) => {
  const aHasPeer = a.manifest?.peerDependencies && Object.keys(a.manifest.peerDependencies).length > 0 ? 1 : 0;
  const bHasPeer = b.manifest?.peerDependencies && Object.keys(b.manifest.peerDependencies).length > 0 ? 1 : 0;
  if (aHasPeer !== bHasPeer) return aHasPeer - bHasPeer;
  const aName = a.manifest?.name || a.spec?.name || a.name || "";
  const bName = b.manifest?.name || /* c8 ignore next - very hard to test */
  b.spec?.name || b.name || "";
  return aName.localeCompare(bName, "en");
};
var compareByType = (a, b) => {
  const aIsPeer = isPeerType(a.type) ? 1 : 0;
  const bIsPeer = isPeerType(b.type) ? 1 : 0;
  if (aIsPeer !== bIsPeer) return aIsPeer - bIsPeer;
  const aName = a.target?.name ?? a.spec?.name ?? "";
  const bName = b.target?.name ?? b.spec?.name ?? "";
  return aName.localeCompare(bName, "en");
};
var getNodeOrderedDependencies = (fromNode, options) => {
  const deps = /* @__PURE__ */ new Map();
  for (const [name, { spec: spec2, type: type2 }] of fromNode.edgesOut.entries()) {
    deps.set(name, { spec: spec2, type: type2 });
  }
  const addedDeps = options?.add.get(fromNode.id);
  if (addedDeps) {
    for (const [name, { spec: spec2, type: type2 }] of addedDeps.entries()) {
      deps.set(name, { spec: spec2, type: type2 });
    }
  }
  const removedDeps = options?.remove.get(fromNode.id);
  if (removedDeps) {
    for (const name of removedDeps) {
      deps.delete(name);
    }
  }
  return getOrderedDependencies([...deps.values()]);
};
var getOrderedDependencies = (deps) => [...deps].sort(compareByType);

// ../../src/graph/src/ideal/peers.ts
var nodeSatisfiesSpec = (node, spec2, fromNode, graph) => satisfies2(
  node.id,
  spec2,
  fromNode.location,
  fromNode.projectRoot,
  graph.monorepo
);
var parseSpec = (name, bareSpec, fromNode, graph) => Spec2.parse(name, bareSpec, {
  ...graph.mainImporter.options,
  registry: fromNode.registry
});
var getForkKey = (peerContext, entries) => {
  const base = peerContext.index ?? 0;
  const sig = entries.map(
    (e) => `${e.spec.final.name}|${e.type}|${e.target?.id ?? "\u2205"}|${e.spec}`
  ).sort().join(";");
  return `${base}::${sig}`;
};
var shouldIgnoreContextMismatch = (peerName, contextTarget, fromNode, graph) => {
  const parentManifest = fromNode.manifest;
  if (!parentManifest) return false;
  for (const depType of longDependencyTypes) {
    const declared = parentManifest[depType]?.[peerName];
    if (!declared) continue;
    const parentSpec = parseSpec(peerName, declared, fromNode, graph);
    return !nodeSatisfiesSpec(
      contextTarget,
      parentSpec,
      fromNode,
      graph
    );
  }
  return false;
};
var buildIncompatibleResult = (target, peerSpec, type2, fromNode, graph) => {
  if (nodeSatisfiesSpec(target, peerSpec, fromNode, graph)) {
    return {
      compatible: false,
      forkEntry: { spec: peerSpec, target, type: type2 }
    };
  }
  return void 0;
};
var checkPeerEdgesCompatible = (existingNode, fromNode, peerContext, graph) => {
  const peerDeps = existingNode.manifest?.peerDependencies;
  if (!peerDeps || Object.keys(peerDeps).length === 0) {
    return { compatible: true };
  }
  const parseOpts = {
    ...graph.mainImporter.options,
    registry: fromNode.registry
  };
  const fromLocation = fromNode.location;
  const projectRoot = fromNode.projectRoot;
  const monorepo = graph.monorepo;
  const satisfiesMemo = /* @__PURE__ */ new Map();
  const satisfiesNodeSpec = (node, spec2) => {
    const key = `${node.id}\0${spec2.type}\0${spec2.bareSpec}\0${String(spec2.final)}`;
    let result = satisfiesMemo.get(key);
    if (result === void 0) {
      result = satisfies2(
        node.id,
        spec2,
        fromLocation,
        projectRoot,
        monorepo
      );
      satisfiesMemo.set(key, result);
    }
    return result;
  };
  const nodeSatisfiesAll = (node, specs) => {
    for (const s of specs) {
      if (!satisfiesNodeSpec(node, s)) return false;
    }
    return true;
  };
  for (const peerName in peerDeps) {
    const peerBareSpec = peerDeps[peerName];
    if (!peerBareSpec) continue;
    const existingEdge = existingNode.edgesOut.get(peerName);
    if (existingEdge === void 0) {
      return { compatible: false };
    }
    if (!existingEdge.to) continue;
    const peerSpec = Spec2.parse(peerName, peerBareSpec, parseOpts);
    const contextEntry = peerContext.get(peerName);
    if (contextEntry?.target && contextEntry.target.id !== existingEdge.to.id && !shouldIgnoreContextMismatch(
      peerName,
      contextEntry.target,
      fromNode,
      graph
    )) {
      const existingTarget = existingEdge.to;
      const existingTargetSatisfiesPeer = satisfiesNodeSpec(
        existingTarget,
        peerSpec
      );
      if (existingTargetSatisfiesPeer && nodeSatisfiesAll(existingTarget, contextEntry.specs)) {
        continue;
      }
      const result = buildIncompatibleResult(
        contextEntry.target,
        peerSpec,
        contextEntry.type,
        fromNode,
        graph
      );
      if (result) return result;
    }
    const siblingEdge = fromNode.edgesOut.get(peerName);
    if (siblingEdge?.to && siblingEdge.to.id !== existingEdge.to.id) {
      const existingTarget = existingEdge.to;
      const existingTargetSatisfiesPeer = satisfiesNodeSpec(
        existingTarget,
        peerSpec
      );
      if (existingTargetSatisfiesPeer && satisfiesNodeSpec(existingTarget, siblingEdge.spec)) {
        continue;
      }
      const result = buildIncompatibleResult(
        siblingEdge.to,
        peerSpec,
        siblingEdge.type,
        fromNode,
        graph
      );
      if (result) return result;
    }
    const manifest = fromNode.manifest;
    let declared;
    let declaredType;
    if (manifest) {
      for (const depType of longDependencyTypes) {
        const deps = manifest[depType];
        if (deps && typeof deps === "object" && !Array.isArray(deps) && peerName in deps) {
          declared = deps[peerName];
          declaredType = depType;
          break;
        }
      }
    }
    if (declared && declaredType) {
      const parentSpec = Spec2.parse(peerName, declared, parseOpts);
      if (satisfiesNodeSpec(existingEdge.to, parentSpec)) {
        continue;
      }
      const candidates = graph.nodesByName.get(peerName);
      if (candidates) {
        for (const candidateNode of candidates) {
          if (candidateNode.id !== existingEdge.to.id && satisfiesNodeSpec(candidateNode, parentSpec) && satisfiesNodeSpec(candidateNode, peerSpec)) {
            return {
              compatible: false,
              forkEntry: {
                spec: peerSpec,
                target: candidateNode,
                type: shorten(declaredType)
              }
            };
          }
        }
      }
    }
  }
  return { compatible: true };
};
var retrievePeerContextHash = (peerContext) => {
  if (!peerContext?.index) return void 0;
  return `peer.${peerContext.index}`;
};
var incompatibleSpecs = (spec2, entry) => {
  if (entry.specs.size > 0) {
    for (const s_ of entry.specs) {
      const s = s_.final;
      if (
        // Registry types: check semver range intersection
        spec2.type === "registry" && (!spec2.range || !s.range || !intersects(spec2.range, s.range)) || // Non-registry types: require exact bareSpec match
        spec2.type !== "registry" && spec2.bareSpec !== s.bareSpec
      ) {
        return true;
      }
    }
  }
  return false;
};
var getOrderedPeerContextEntries = (entries) => [...entries].sort(compareByType);
var checkEntriesToPeerContext = (peerContext, entries) => {
  for (const { spec: spec2, target } of entries) {
    const name = target?.name ?? spec2.final.name;
    const entry = peerContext.get(name);
    if (!entry?.active) continue;
    if (incompatibleSpecs(spec2.final, entry)) {
      return true;
    }
  }
  return false;
};
var addEntriesToPeerContext = (peerContext, entries, fromNode, monorepo) => {
  if (checkEntriesToPeerContext(peerContext, entries)) return true;
  for (const { dependent, spec: spec2, target, type: type2 } of entries) {
    const name = target?.name ?? spec2.final.name;
    let entry = peerContext.get(name);
    if (!entry) {
      entry = {
        active: true,
        specs: /* @__PURE__ */ new Set([spec2]),
        target,
        type: type2,
        contextDependents: /* @__PURE__ */ new Set()
      };
      peerContext.set(name, entry);
      if (dependent) entry.contextDependents.add(dependent);
      continue;
    }
    if (incompatibleSpecs(spec2.final, entry)) return true;
    if (target && [...entry.specs].every(
      (s) => satisfies2(
        target.id,
        s,
        fromNode.location,
        fromNode.projectRoot,
        monorepo
      )
    )) {
      if (target.id !== entry.target?.id && target.version !== entry.target?.version) {
        for (const dep of entry.contextDependents) {
          const edge = dep.edgesOut.get(name);
          if (edge?.to && edge.to !== target) {
            edge.to.edgesIn.delete(edge);
            edge.to = target;
            target.edgesIn.add(edge);
          }
        }
        entry.target = target;
      }
      entry.target ??= target;
    }
    entry.specs.add(spec2);
    if (dependent) entry.contextDependents.add(dependent);
  }
  return false;
};
var forkPeerContext = (graph, peerContext, entries) => {
  const forkKey = getForkKey(peerContext, entries);
  const cached = graph.peerContextForkCache.get(forkKey);
  if (cached) {
    return cached;
  }
  const nextPeerContext = /* @__PURE__ */ new Map();
  nextPeerContext.index = graph.nextPeerContextIndex();
  graph.peerContexts[nextPeerContext.index] = nextPeerContext;
  graph.peerContextForkCache.set(forkKey, nextPeerContext);
  for (const [name, entry] of peerContext.entries()) {
    nextPeerContext.set(name, {
      active: false,
      specs: new Set(entry.specs),
      target: void 0,
      type: entry.type,
      contextDependents: new Set(entry.contextDependents)
    });
  }
  for (const entry of entries) {
    const { dependent, spec: spec2, target, type: type2 } = entry;
    const name = target?.name ?? spec2.final.name;
    const newEntry = {
      active: true,
      specs: /* @__PURE__ */ new Set([spec2]),
      target,
      type: type2,
      contextDependents: dependent ? /* @__PURE__ */ new Set([dependent]) : /* @__PURE__ */ new Set()
    };
    nextPeerContext.set(name, newEntry);
  }
  return nextPeerContext;
};
var findFromPeerClosure = (name, peerSpec, queuedEntries, fromNode, graph) => {
  const start = queuedEntries.map((e) => e.target).filter((n) => !!n);
  const seen = /* @__PURE__ */ new Set();
  const q = start.map((n) => ({
    n,
    depth: 0
  }));
  while (q.length) {
    const cur = q.shift();
    if (!cur || seen.has(cur.n.id)) continue;
    seen.add(cur.n.id);
    const edge = cur.n.edgesOut.get(name);
    if (edge?.to && nodeSatisfiesSpec(edge.to, peerSpec, fromNode, graph)) {
      return edge.to;
    }
    for (const e of cur.n.edgesOut.values()) {
      if ((e.type === "peer" || e.type === "peerOptional") && e.to) {
        q.push({ n: e.to, depth: cur.depth + 1 });
      }
    }
  }
  return void 0;
};
var startPeerPlacement = (peerContext, manifest, fromNode, options) => {
  const queueMap = /* @__PURE__ */ new Map();
  let peerSetHash;
  if (manifest.peerDependencies && Object.keys(manifest.peerDependencies).length > 0) {
    peerSetHash = retrievePeerContextHash(peerContext);
    const siblingDeps = getDependencies(fromNode, {
      ...options,
      registry: fromNode.registry
    });
    for (const [depName, dep] of siblingDeps) {
      queueMap.set(depName, dep);
    }
    for (const edge of fromNode.edgesOut.values()) {
      queueMap.set(edge.name, {
        spec: edge.spec,
        target: edge.to,
        type: edge.type
      });
    }
  }
  return {
    peerSetHash,
    // Sort queuedEntries for deterministic order
    queuedEntries: getOrderedPeerContextEntries([
      ...queueMap.values()
    ])
  };
};
var endPeerPlacement = (peerContext, nextDeps, nextPeerDeps, graph, spec2, fromNode, node, type2, queuedEntries) => ({
  /**
   * Add the new entries to the current peer context set.
   *
   * Two sets of entries are checked:
   * - `prevEntries`: Parent's queued entries + self-reference
   * - `nextEntries`: This node's deps + peer deps (with node as dependent)
   *
   * If either conflicts with the current context, returns ALL entries to be
   * added to a forked context (prevEntries last for priority).
   *
   * Returns `undefined` if no fork needed (entries added directly to context).
   */
  putEntries: () => {
    const prevEntries = [
      ...queuedEntries,
      /* ref itself */
      {
        spec: spec2,
        target: node,
        type: type2
      }
    ];
    const nextEntries = [
      ...nextDeps.map((dep) => ({ ...dep, dependent: node })),
      ...[...nextPeerDeps.values()].map((dep) => ({
        ...dep,
        dependent: node
      }))
    ];
    const conflictPrev = checkEntriesToPeerContext(
      peerContext,
      prevEntries
    );
    const conflictNext = nextEntries.length > 0 && checkEntriesToPeerContext(peerContext, nextEntries);
    if (conflictPrev || conflictNext) {
      return [...nextEntries, ...prevEntries];
    }
    addEntriesToPeerContext(
      peerContext,
      prevEntries,
      fromNode,
      graph.monorepo
    );
    if (nextEntries.length > 0) {
      addEntriesToPeerContext(
        peerContext,
        nextEntries,
        node,
        graph.monorepo
      );
    }
    return void 0;
  },
  /**
   * Try to resolve peer dependencies using already seen target
   * values from the current peer context set.
   *
   * Resolution priority (highest to lowest):
   * 1. Sibling deps from parent (workspace direct deps take priority)
   * 2. Peer-edge closure of sibling targets (handles peer cycles)
   * 3. Global peer context set entries
   * 4. Add to nextDeps for normal resolution (or create dangling edge for optional)
   */
  resolvePeerDeps: () => {
    for (const nextDep of nextPeerDeps.values()) {
      const { spec: spec3, type: type3 } = nextDep;
      if (type3 !== "peer" && type3 !== "peerOptional") continue;
      const name = spec3.final.name;
      const siblingEntry = queuedEntries.find(
        (e) => (e.target?.name ?? e.spec.final.name) === name
      );
      const siblingTarget = siblingEntry?.target ?? fromNode.edgesOut.get(name)?.to;
      if (siblingTarget && nodeSatisfiesSpec(siblingTarget, spec3, fromNode, graph)) {
        const existingEdge = node.edgesOut.get(name);
        if (existingEdge?.to && existingEdge.to !== siblingTarget) {
          existingEdge.to.edgesIn.delete(existingEdge);
          existingEdge.to = siblingTarget;
          siblingTarget.edgesIn.add(existingEdge);
        } else if (!existingEdge) {
          graph.addEdge(type3, spec3, node, siblingTarget);
        }
        continue;
      }
      const localPeer = findFromPeerClosure(
        name,
        spec3,
        queuedEntries,
        fromNode,
        graph
      );
      if (localPeer && !node.edgesOut.has(name)) {
        graph.addEdge(type3, spec3, node, localPeer);
        continue;
      }
      const entry = peerContext.get(name);
      if (!node.edgesOut.has(name) && entry?.target && nodeSatisfiesSpec(entry.target, spec3, fromNode, graph)) {
        graph.addEdge(type3, spec3, node, entry.target);
        entry.specs.add(spec3.final);
        continue;
      }
      if (type3 === "peerOptional") {
        graph.addEdge(type3, spec3, node);
      } else if (siblingEntry && siblingEntry.spec.bareSpec !== spec3.bareSpec) {
        nextDeps.push({ ...nextDep, spec: siblingEntry.spec });
      } else {
        nextDeps.push(nextDep);
      }
    }
  }
});
var postPlacementPeerCheck = (graph, sortedLevelResults) => {
  for (const childDepsToProcess of sortedLevelResults) {
    const sortedChildDeps = [...childDepsToProcess].sort(
      (a, b) => a.node.id.localeCompare(b.node.id, "en")
    );
    const needsForking = /* @__PURE__ */ new Map();
    for (const childDep of sortedChildDeps) {
      const needsFork = childDep.updateContext.putEntries();
      if (needsFork) {
        needsForking.set(childDep, needsFork);
      }
    }
    const sortedNeedsForkingEntries = [
      ...needsForking.entries()
    ].sort(([a], [b]) => a.node.id.localeCompare(b.node.id, "en"));
    let prevContext;
    for (const [childDep, nextEntries] of sortedNeedsForkingEntries) {
      if (prevContext && !checkEntriesToPeerContext(prevContext, nextEntries)) {
        addEntriesToPeerContext(
          prevContext,
          nextEntries,
          childDep.node,
          graph.monorepo
        );
        childDep.peerContext = prevContext;
        continue;
      }
      childDep.peerContext = forkPeerContext(
        graph,
        childDep.peerContext,
        nextEntries
      );
      prevContext = childDep.peerContext;
    }
    for (const childDep of sortedChildDeps) {
      childDep.updateContext.resolvePeerDeps();
      childDep.deps = getOrderedDependencies(childDep.deps);
    }
  }
};

// ../../src/graph/src/ideal/append-nodes.ts
var shouldInstallDepType = (node, depType) => depType !== "devDependencies" || node.importer || node.id.startsWith("git");
var getFileTypeInfo = (spec2, fromNode, scurry) => {
  const f = spec2.final;
  if (f.type !== "file") return;
  if (!f.file) {
    throw error("no path on file specifier", { spec: spec2 });
  }
  const target = scurry.cwd.resolve(fromNode.location).resolve(f.file);
  const path2 = target.relativePosix();
  const id2 = joinDepIDTuple(["file", path2]);
  return {
    path: path2,
    id: id2,
    isDirectory: !!target.lstatSync()?.isDirectory()
  };
};
var isStringArray2 = (a) => Array.isArray(a) && !a.some((b) => typeof b !== "string");
var findCompatibleResolution = (spec2, fromNode, graph, peerContext, queryModifier, _peer) => {
  const fromLoc = fromNode.location;
  const projectRoot = graph.projectRoot;
  const monorepo = graph.monorepo;
  const final = spec2.final;
  const satisfiesCache = /* @__PURE__ */ new Map();
  const satisfiesFinal = (n) => {
    const key = n.id;
    const cached = satisfiesCache.get(key);
    if (cached !== void 0) {
      return cached;
    }
    const result = satisfies2(
      key,
      final,
      fromLoc,
      projectRoot,
      monorepo
    );
    satisfiesCache.set(key, result);
    return result;
  };
  const existingEdge = fromNode.edgesOut.get(spec2.name);
  let existingNode;
  if (existingEdge?.to && !existingEdge.to.detached && satisfiesFinal(existingEdge.to)) {
    existingNode = existingEdge.to;
  } else {
    existingNode = graph.findResolution(spec2, fromNode, queryModifier);
  }
  let peerCompatResult = existingNode ? checkPeerEdgesCompatible(
    existingNode,
    fromNode,
    peerContext,
    graph
  ) : { compatible: true };
  if (existingNode && !peerCompatResult.compatible) {
    const candidates = graph.nodesByName.get(final.name);
    if (candidates && candidates.size > 1) {
      for (const candidate of candidates) {
        if (candidate === existingNode) continue;
        if (candidate.detached) continue;
        if (!satisfiesFinal(candidate)) continue;
        const compat = checkPeerEdgesCompatible(
          candidate,
          fromNode,
          peerContext,
          graph
        );
        if (compat.compatible) {
          existingNode = candidate;
          peerCompatResult = compat;
          break;
        }
      }
    }
  }
  return { existingNode, peerCompatResult };
};
var fetchManifestsForDeps = async (packageInfo, graph, fromNode, deps, scurry, peerContext, modifierRefs, depth = 0) => {
  const fetchTasks = [];
  const placementTasks = [];
  const reuseTasks = [];
  const forkRequests = [];
  for (const { spec: originalSpec, type: type2 } of deps) {
    let spec2 = originalSpec;
    const fileTypeInfo = getFileTypeInfo(spec2, fromNode, scurry);
    const activeModifier = modifierRefs?.get(spec2.name);
    const queryModifier = activeModifier?.modifier.query;
    const completeModifier = activeModifier && activeModifier.interactiveBreadcrumb.current === activeModifier.modifier.breadcrumb.last;
    if (queryModifier && completeModifier && "spec" in activeModifier.modifier) {
      spec2 = activeModifier.modifier.spec;
      if (spec2.bareSpec === "-") {
        continue;
      }
    }
    const peer2 = type2 === "peer" || type2 === "peerOptional";
    const { existingNode, peerCompatResult } = findCompatibleResolution(
      spec2,
      fromNode,
      graph,
      peerContext,
      queryModifier,
      peer2
    );
    const effectivePeerContext = peerContext;
    if (!peerCompatResult.compatible && peerCompatResult.forkEntry) {
      forkRequests.push(peerCompatResult.forkEntry);
    }
    const validExistingNode = existingNode && !existingNode.detached && // Regular deps can always reuse.
    // Peer deps can reuse as well if their peer edges are compatible.
    /* c8 ignore start */
    (!peer2 || peerCompatResult.compatible) && // Check if existing node's peer edges are compatible with new parent
    peerCompatResult.compatible;
    if (validExistingNode || // importers are handled at the ./refresh-ideal-graph.ts top-level
    // so we should just skip whenever we find one
    existingNode?.importer) {
      reuseTasks.push({ type: type2, spec: spec2, fromNode, toNode: existingNode });
      continue;
    }
    const edgeOptional = type2 === "optional" || type2 === "peerOptional";
    const manifestPromise = (
      // the "detached" node state means that it has already been load as
      // part of a graph (either lockfile or actual) and it has valid manifest
      // data so we shortcut the package info manifest fetch here
      existingNode?.detached && existingNode.manifest ? Promise.resolve(existingNode.manifest) : packageInfo.manifest(spec2, { from: scurry.resolve(fromNode.location) }).then((manifest) => manifest).catch((er) => {
        if (edgeOptional || fromNode.optional) {
          return void 0;
        }
        throw er;
      })
    );
    const fetchTask = {
      spec: spec2,
      type: type2,
      fromNode,
      fileTypeInfo,
      activeModifier,
      queryModifier,
      edgeOptional,
      manifestPromise,
      depth,
      peerContext: effectivePeerContext
    };
    fetchTasks.push(fetchTask);
  }
  for (const fetchTask of fetchTasks) {
    const manifest = await fetchTask.manifestPromise;
    placementTasks.push({
      fetchTask,
      manifest
    });
  }
  placementTasks.sort(compareByHasPeerDeps);
  return { placementTasks, reuseTasks, forkRequests };
};
var processPlacementTasks = async (graph, options, placementTasks, add, modifiers, scurry, packageInfo, extractPromises, actual2, seenExtracted, remover, transientAdd, transientRemove) => {
  const childDepsToProcess = [];
  for (const placementTask of placementTasks) {
    const { fetchTask, manifest } = placementTask;
    let {
      activeModifier,
      edgeOptional,
      fileTypeInfo,
      fromNode,
      peerContext,
      queryModifier,
      spec: spec2,
      type: type2
    } = fetchTask;
    const additiveMap = fromNode.importer ? add : transientAdd?.get(fromNode.id);
    spec2 = fixupAddedNames(additiveMap, manifest, options, spec2);
    if (!manifest) {
      if (!edgeOptional && fromNode.isOptional()) {
        removeOptionalSubgraph(graph, fromNode);
        continue;
      } else if (edgeOptional) {
        continue;
      } else {
        throw error("failed to resolve dependency", {
          spec: spec2,
          from: fromNode.location
        });
      }
    }
    const peerPlacement = startPeerPlacement(
      peerContext,
      manifest,
      fromNode,
      options
    );
    const peerSetHash = peerPlacement.peerSetHash;
    const queuedEntries = peerPlacement.queuedEntries;
    const node = graph.placePackage(
      fromNode,
      type2,
      spec2,
      normalizeManifest(manifest),
      fileTypeInfo?.id,
      joinExtra({ peerSetHash, modifier: queryModifier })
    );
    if (!node) {
      throw error("failed to place package", {
        from: fromNode.location,
        spec: spec2
      });
    }
    if (activeModifier) {
      modifiers?.updateActiveEntry(node, activeModifier);
    }
    const eligibleForExtraction = type2 !== "peer" && type2 !== "peerOptional" && remover && extractPromises && actual2 && scurry && packageInfo && node.inVltStore() && !node.isOptional() && // this fixes an issue with installing `file:pathname` specs
    /* c8 ignore next */
    !fileTypeInfo?.isDirectory && !node.importer;
    if (eligibleForExtraction) {
      if (seenExtracted?.has(node.id)) {
        continue;
      }
      seenExtracted?.add(node.id);
      const actualNode = actual2.nodes.get(node.id);
      if (!actualNode?.equals(node)) {
        const extractPromise = extractNode(
          node,
          scurry,
          remover,
          options,
          packageInfo
        );
        extractPromises.push(extractPromise);
      }
    }
    if (fileTypeInfo?.path && fileTypeInfo.isDirectory) {
      node.location = fileTypeInfo.path;
    }
    if (!node.resolved) {
      node.setResolved();
    }
    const nextPeerDeps = /* @__PURE__ */ new Map();
    const bundleDeps = manifest.bundleDependencies;
    const bundled = new Set(
      node.id.startsWith("git") || node.importer || !isStringArray2(bundleDeps) ? [] : bundleDeps
    );
    const nextDeps = [];
    for (const depTypeName of longDependencyTypes) {
      const depRecord = manifest[depTypeName];
      if (depRecord && shouldInstallDepType(node, depTypeName)) {
        const sortedEntries = Object.entries(depRecord).sort(
          ([a], [b]) => a.localeCompare(b, "en")
        );
        for (const [name, bareSpec] of sortedEntries) {
          if (bundled.has(name)) continue;
          const dep = {
            type: shorten(depTypeName, name, manifest),
            spec: Spec2.parse(name, bareSpec, {
              ...options,
              registry: spec2.registry
            })
          };
          if (depTypeName === "peerDependencies") {
            nextPeerDeps.set(name, dep);
          } else {
            nextDeps.push(dep);
          }
        }
      }
    }
    const transientDeps = transientAdd?.get(node.id);
    if (transientDeps) {
      for (const [, dep] of transientDeps) {
        if (dep.type === "peer" || dep.type === "peerOptional") {
          nextPeerDeps.set(dep.spec.name, dep);
          continue;
        }
        const index = nextDeps.findIndex(
          (d) => d.spec.name === dep.spec.name
        );
        if (index !== -1) {
          nextDeps.splice(index, 1);
        }
        nextDeps.push(dep);
      }
    }
    const transientRemovals = transientRemove?.get(node.id);
    if (transientRemovals) {
      for (const depName of transientRemovals) {
        const index = nextDeps.findIndex(
          (dep) => dep.spec.name === depName
        );
        if (index !== -1) {
          nextDeps.splice(index, 1);
          continue;
        }
        if (nextPeerDeps.has(depName)) {
          nextPeerDeps.delete(depName);
        }
      }
    }
    const updateContext = endPeerPlacement(
      peerContext,
      nextDeps,
      nextPeerDeps,
      graph,
      spec2,
      fromNode,
      node,
      type2,
      queuedEntries
    );
    childDepsToProcess.push({
      node,
      deps: nextDeps,
      modifierRefs: modifiers?.tryDependencies(node, nextDeps),
      peerContext,
      updateContext
    });
  }
  return childDepsToProcess;
};
var appendNodes = async (packageInfo, graph, fromNode, deps, scurry, options, seen, add, modifiers, modifierRefs, extractPromises, actual2, seenExtracted, remover, transientAdd, transientRemove) => {
  if (seen.has(fromNode.id)) return;
  seen.add(fromNode.id);
  let initialPeerContext = graph.peerContexts[0];
  if (!initialPeerContext)
    throw error("no initial peer context found in graph");
  if (fromNode.importer && fromNode !== graph.mainImporter) {
    const nextPeerContext = /* @__PURE__ */ new Map();
    nextPeerContext.index = graph.nextPeerContextIndex();
    graph.peerContexts[nextPeerContext.index] = nextPeerContext;
    initialPeerContext = nextPeerContext;
  }
  let currentLevelDeps = [
    {
      node: fromNode,
      deps,
      modifierRefs,
      depth: 0,
      peerContext: initialPeerContext,
      /* c8 ignore start */
      updateContext: {
        putEntries: () => void 0,
        resolvePeerDeps: () => {
        }
      }
      /* c8 ignore stop */
    }
  ];
  while (currentLevelDeps.length > 0) {
    const nextLevelDeps = [];
    const fetchResults = await Promise.all(
      currentLevelDeps.map(
        async ({
          node,
          deps: nodeDeps,
          modifierRefs: nodeModifierRefs,
          peerContext,
          depth
        }) => {
          seen.add(node.id);
          const result = await fetchManifestsForDeps(
            packageInfo,
            graph,
            node,
            // Sort by name for deterministic ordering (reproducible builds)
            nodeDeps.sort(
              (a, b) => a.spec.name.localeCompare(b.spec.name, "en")
            ),
            scurry,
            peerContext,
            nodeModifierRefs,
            depth
          );
          return {
            entry: {
              node,
              deps: nodeDeps,
              modifierRefs: nodeModifierRefs,
              peerContext,
              depth
            },
            result
          };
        }
      )
    );
    const sortedResults = fetchResults.sort((a, b) => {
      const keyA = `${a.entry.node.id}::${a.entry.depth}`;
      const keyB = `${b.entry.node.id}::${b.entry.depth}`;
      return keyA.localeCompare(keyB, "en");
    });
    const levelResults = [];
    for (const { entry, result } of sortedResults) {
      if (result.forkRequests.length > 0) {
        const forkedContext = forkPeerContext(
          graph,
          entry.peerContext,
          result.forkRequests
        );
        entry.peerContext = forkedContext;
        for (const task of result.placementTasks) {
          task.fetchTask.peerContext = forkedContext;
        }
      }
      const sortedReuseTasks = result.reuseTasks.sort(
        (a, b) => a.spec.name.localeCompare(b.spec.name, "en")
      );
      for (const {
        type: type2,
        spec: spec2,
        fromNode: fromNode2,
        toNode
      } of sortedReuseTasks) {
        graph.addEdge(type2, spec2, fromNode2, toNode);
      }
      const placed = await processPlacementTasks(
        graph,
        options,
        result.placementTasks,
        add,
        modifiers,
        scurry,
        packageInfo,
        extractPromises,
        actual2,
        seenExtracted,
        remover,
        transientAdd,
        transientRemove
      );
      levelResults.push(placed);
    }
    postPlacementPeerCheck(graph, levelResults);
    for (const childDepsToProcess of levelResults) {
      for (const childDep of childDepsToProcess) {
        if (!seen.has(childDep.node.id)) {
          const currentDepth = currentLevelDeps[0]?.depth ?? 0;
          nextLevelDeps.push({
            ...childDep,
            depth: currentDepth + 1
          });
        }
      }
    }
    currentLevelDeps = nextLevelDeps;
  }
};

// ../../src/graph/src/ideal/refresh-ideal-graph.ts
var getOrderedImporters = (graph) => {
  const orderedImporters = [...graph.importers].sort((a, b) => {
    if (a === graph.mainImporter) return -1;
    if (b === graph.mainImporter) return 1;
    return compareByHasPeerDeps(
      { manifest: a.manifest },
      { manifest: b.manifest }
    );
  });
  return orderedImporters;
};
var refreshIdealGraph = async ({
  add,
  graph,
  modifiers,
  packageInfo,
  scurry,
  actual: actual2,
  remove,
  remover,
  transientAdd,
  transientRemove,
  ...specOptions
}) => {
  const seen = /* @__PURE__ */ new Set();
  const extractPromises = [];
  const seenExtracted = /* @__PURE__ */ new Set();
  const orderedImporters = getOrderedImporters(graph);
  const depsPerImporter = /* @__PURE__ */ new Map();
  for (const importer of orderedImporters) {
    const deps = getNodeOrderedDependencies(importer, { add, remove });
    depsPerImporter.set(importer, deps);
  }
  if (add.modifiedDependencies || remove.modifiedDependencies) {
    graph.resetEdges();
  }
  for (const importer of orderedImporters) {
    modifiers?.tryImporter(importer);
    const addedDeps = add.get(importer.id);
    const deps = depsPerImporter.get(importer);
    if (!deps) continue;
    const modifierRefs = modifiers?.tryDependencies(importer, deps);
    await appendNodes(
      packageInfo,
      graph,
      importer,
      deps,
      scurry,
      specOptions,
      seen,
      addedDeps,
      modifiers,
      modifierRefs,
      extractPromises,
      actual2,
      seenExtracted,
      remover,
      transientAdd,
      transientRemove
    );
  }
  for (const node of graph.nodes.values()) {
    node.setDefaultLocation();
  }
  if (extractPromises.length > 0) {
    await Promise.all(extractPromises);
  }
};

// ../../src/graph/src/ideal/build-ideal-from-starting-graph.ts
var buildIdealFromStartingGraph = async (options) => {
  const importerSpecs = getImporterSpecs(options);
  options.add.modifiedDependencies = options.add.modifiedDependencies || importerSpecs.add.modifiedDependencies;
  options.remove.modifiedDependencies = options.remove.modifiedDependencies || importerSpecs.remove.modifiedDependencies;
  for (const [nodeId, deps] of importerSpecs.add) {
    const node = options.graph.nodes.get(nodeId);
    if (!node) continue;
    if (!options.add.has(nodeId)) {
      options.add.set(nodeId, deps);
      continue;
    }
    for (const [depName, dep] of deps) {
      if (!options.add.get(nodeId)?.has(depName)) {
        options.add.get(nodeId)?.set(depName, dep);
      }
      dep.type = resolveSaveType(node, depName, dep.type);
    }
  }
  for (const [nodeId, deps] of importerSpecs.remove) {
    if (!options.remove.has(nodeId)) {
      options.remove.set(nodeId, deps);
      continue;
    }
    for (const depName of deps) {
      options.remove.get(nodeId)?.add(depName);
    }
  }
  await refreshIdealGraph({
    ...options,
    transientAdd: importerSpecs.transientAdd,
    transientRemove: importerSpecs.transientRemove
  });
  options.graph.gc();
  return options.graph;
};

// ../../src/graph/src/ideal/build.ts
var getMap2 = (m) => m ?? /* @__PURE__ */ new Map();
var validateFileDepNode = (graph, id2) => {
  const [type2, path2] = splitDepID(id2);
  if (type2 === "file" && !graph.nodes.get(id2)) {
    throw error(
      "The current working dir is not a dependency of this project",
      { path: path2 }
    );
  }
};
var build3 = async (options) => {
  const done = graphStep("build");
  const { packageInfo, packageJson, scurry, monorepo } = options;
  const mainManifest = options.mainManifest ?? packageJson.read(options.projectRoot);
  let graph;
  try {
    graph = load3({
      ...options,
      mainManifest,
      monorepo
    });
  } catch (err) {
    const cause = err.cause;
    if (cause?.code === "ELOCKFILEVERSION") {
      if (typeof cause.found === "number" && typeof cause.wanted === "number") {
        throw err;
      }
    }
    graph = load4({
      ...options,
      mainManifest,
      monorepo
    });
  }
  const res = await buildIdealFromStartingGraph({
    ...options,
    scurry,
    add: getMap2(options.add),
    graph,
    packageInfo,
    remove: getMap2(options.remove),
    actual: options.actual
  });
  done();
  if (options.add) {
    for (const [addKey, value] of options.add.entries()) {
      if (value.size) validateFileDepNode(res, addKey);
    }
  }
  if (options.remove) {
    for (const [removeKey, value] of options.remove.entries()) {
      if (value.size) validateFileDepNode(res, removeKey);
    }
  }
  return res;
};

// ../../src/graph/src/reify/index.ts
import { availableParallelism as availableParallelism2 } from "node:os";

// ../../node_modules/.vlt/~npm~promise-call-limit@3.0.2/node_modules/promise-call-limit/dist/esm/index.js
import * as os from "node:os";
var defLimit = "availableParallelism" in os ? Math.max(1, os.availableParallelism() - 1) : Math.max(1, os.cpus().length - 1);
var callLimit = (queue, { limit: limit2 = defLimit, rejectLate } = {}) => new Promise((res, rej) => {
  let active = 0;
  let current = 0;
  const results = [];
  let rejected = false;
  let rejection;
  const reject = (er) => {
    if (rejected)
      return;
    rejected = true;
    rejection ??= er;
    if (!rejectLate)
      rej(rejection);
  };
  let resolved = false;
  const resolve12 = () => {
    if (resolved || active > 0)
      return;
    resolved = true;
    res(results);
  };
  const run2 = () => {
    const c = current++;
    if (c >= queue.length)
      return rejected ? reject() : resolve12();
    active++;
    const step = queue[c];
    if (!step)
      throw new Error("walked off queue");
    results[c] = step().then((result) => {
      active--;
      results[c] = result;
      return result;
    }, (er) => {
      active--;
      reject(er);
    }).then((result) => {
      if (rejected && active === 0)
        return rej(rejection);
      run2();
      return result;
    });
  };
  for (let i = 0; i < limit2; i++)
    run2();
});

// ../../src/cmd-shim/src/index.ts
import {
  chmod as chmod3,
  mkdir as mkdir2,
  readFile as readFile2,
  stat as stat2,
  writeFile as writeFile2
} from "node:fs/promises";
import { dirname as dirname5, relative as relative2 } from "node:path";

// ../../src/cmd-shim/src/to-batch-syntax.ts
var convertToSetCommand = (key, value) => convertToSetCommand_(key.trim(), value.trim());
var convertToSetCommand_ = (key, value) => key && value ? `@SET ${key}=${replaceDollarWithPercentPair(value)}\r
` : "";
var extractVariableValuePairs = (declarations) => declarations.reduce(
  (pairs, declaration) => {
    const [key = "", val = ""] = declaration.split("=");
    pairs[key] = val;
    return pairs;
  },
  {}
);
var convertToSetCommands = (variableString) => Object.entries(extractVariableValuePairs(variableString.split(" "))).map(([key, val]) => convertToSetCommand(key, val)).join("");
var replaceDollarWithPercentPair = (value) => {
  const dollarExpressions = /\$\{?([^$@#?\- \t{}:]+)\}?/g;
  let result = "";
  let startIndex = 0;
  do {
    const match = dollarExpressions.exec(value);
    if (match) {
      const betweenMatches = value.substring(startIndex, match.index) || "";
      result += betweenMatches + "%" + String(match[1]) + "%";
      startIndex = dollarExpressions.lastIndex;
    }
  } while (dollarExpressions.lastIndex > 0);
  result += value.slice(startIndex);
  return result;
};

// ../../src/cmd-shim/src/read.ts
import { lstat, readFile, readlink } from "node:fs/promises";
import { dirname as dirname4, resolve as resolve7 } from "node:path";

// ../../src/cmd-shim/src/paths.ts
var paths = process.platform === "win32" ? (path2) => [
  path2 + ".cmd",
  path2 + ".ps1",
  path2,
  path2 + ".pwsh"
] : (path2) => [path2];

// ../../src/cmd-shim/src/read.ts
var extractPath = (path2, cmdshimContents) => {
  if (/\.cmd$/i.test(path2)) {
    return extractPathFromCmd(cmdshimContents);
  } else if (/\.(ps1|pwsh)$/i.test(path2)) {
    return extractPathFromPowershell(cmdshimContents);
  } else {
    return extractPathFromCygwin(cmdshimContents);
  }
};
var extractPathFromPowershell = (cmdshimContents) => {
  const matches = /"[$]basedir\/([^"]+?)"\s+[$]args/.exec(
    cmdshimContents
  );
  return matches?.[1]?.replace(/\\/g, "/");
};
var extractPathFromCmd = (cmdshimContents) => {
  const matches = /"%(?:~dp0|dp0%)\\([^"]+?)"\s+%[*]/.exec(
    cmdshimContents
  );
  return matches?.[1]?.replace(/\\/g, "/");
};
var extractPathFromCygwin = (cmdshimContents) => {
  const matches = /"[$]basedir\/([^"]+?)"\s+"[$]@"/.exec(
    cmdshimContents
  );
  return matches?.[1]?.replace(/\\/g, "/");
};
var findCmdShimIfExists = async (path2) => {
  path2 = path2.replace(/\.(cmd|pwsh|ps1)$/i, "");
  for (const p of paths(path2)) {
    const result = await readCmdShimIfExists(p);
    if (result) return [p, result];
  }
};
var readCmdShimIfExists = async (path2) => {
  try {
    const st = await lstat(path2);
    if (st.isSymbolicLink()) {
      return resolve7(dirname4(path2), await readlink(path2));
    }
    const contents = await readFile(path2);
    const destination = extractPath(path2, contents.toString());
    if (destination) return resolve7(dirname4(path2), destination);
  } catch {
  }
};

// ../../src/cmd-shim/src/index.ts
var shebangExpr = /^#!\s*(?:\/usr\/bin\/env\s+(?:-S\s+)?((?:[^ \t=]+=[^ \t=]+\s+)*))?([^ \t]+)(.*)$/;
var cmdShimIfExists = async (from, to, remover) => {
  try {
    await stat2(from);
  } catch {
    return;
  }
  await writeShim(from, to, remover);
};
var writeShim = async (from, to, remover) => {
  await Promise.all([
    remover.rm(to),
    remover.rm(to + ".cmd"),
    remover.rm(to + ".ps1"),
    remover.rm(to + ".pwsh")
  ]);
  await mkdir2(dirname5(to), { recursive: true });
  const data = await readFile2(from, "utf8").catch(() => "");
  if (!data) {
    return await writeShim_(from, to);
  }
  const firstLine = data.trim().split(/\r*\n/)[0];
  const shebang = firstLine?.match(shebangExpr) ?? void 0;
  return writeShim_(
    from,
    to,
    shebang?.[2],
    shebang?.[3],
    shebang?.[1]
  );
};
var writeShim_ = async (from, to, prog, args, variables) => {
  let shTarget = relative2(dirname5(to), from);
  let target = shTarget.split("/").join("\\");
  let longProg;
  let shProg = prog?.split("\\").join("/");
  let shLongProg;
  let pwshProg = shProg && `"${shProg}$exe"`;
  let pwshLongProg;
  shTarget = shTarget.split("\\").join("/");
  args = args || "";
  variables = variables || "";
  if (!prog) {
    prog = `"%dp0%\\${target}"`;
    shProg = `"$basedir/${shTarget}"`;
    pwshProg = shProg;
    args = "";
    target = "";
    shTarget = "";
  } else {
    longProg = `"%dp0%\\${prog}.exe"`;
    shLongProg = `"$basedir/${prog}"`;
    pwshLongProg = `"$basedir/${prog}$exe"`;
    target = `"%dp0%\\${target}"`;
    shTarget = `"$basedir/${shTarget}"`;
  }
  const head = "@ECHO off\r\nGOTO start\r\n:find_dp0\r\nSET dp0=%~dp0\r\nEXIT /b\r\n:start\r\nSETLOCAL\r\nCALL :find_dp0\r\n";
  let cmd;
  if (longProg) {
    shLongProg = (shLongProg ?? "").trim();
    args = args.trim();
    const variablesBatch = convertToSetCommands(variables);
    cmd = `${head}${variablesBatch}\r
IF EXIST ${longProg} (\r
  SET "_prog=${longProg.replace(/(^")|("$)/g, "")}"\r
) ELSE (\r
  SET "_prog=${prog.replace(/(^")|("$)/g, "")}"\r
  SET PATHEXT=%PATHEXT:;.JS;=;%\r
)\r
\r
endLocal & goto #_undefined_# 2>NUL || title %COMSPEC% & "%_prog%" ${args} ${target} %*\r
`;
  } else {
    cmd = `${head}${prog} ${args} ${target} %*\r
`;
  }
  let sh = `#!/bin/sh
basedir=$(dirname "$(echo "$0" | sed -e 's,\\\\,/,g')")

case \`uname\` in
    *CYGWIN*|*MINGW*|*MSYS*)
        if command -v cygpath > /dev/null 2>&1; then
            basedir=\`cygpath -w "$basedir"\`
        fi
    ;;
esac

`;
  if (shLongProg) {
    sh += `if [ -x ${shLongProg} ]; then
  exec ${variables}${shLongProg} ${args} ${shTarget} "$@"
else 
  exec ${variables}${shProg} ${args} ${shTarget} "$@"
fi
`;
  } else {
    sh += `exec ${shProg} ${args} ${shTarget} "$@"
`;
  }
  let pwsh = '#!/usr/bin/env pwsh\n$basedir=Split-Path $MyInvocation.MyCommand.Definition -Parent\n\n$exe=""\nif ($PSVersionTable.PSVersion -lt "6.0" -or $IsWindows) {\n  # Fix case when both the Windows and Linux builds of Node\n  # are installed in the same directory\n  $exe=".exe"\n}\n';
  if (shLongProg) {
    pwsh += `$ret=0
if (Test-Path ${pwshLongProg}) {
  # Support pipeline input
  if ($MyInvocation.ExpectingInput) {
    $input | & ${pwshLongProg} ${args} ${shTarget} $args
  } else {
    & ${pwshLongProg} ${args} ${shTarget} $args
  }
  $ret=$LASTEXITCODE
} else {
  # Support pipeline input
  if ($MyInvocation.ExpectingInput) {
    $input | & ${pwshProg} ${args} ${shTarget} $args
  } else {
    & ${pwshProg} ${args} ${shTarget} $args
  }
  $ret=$LASTEXITCODE
}
exit $ret
`;
  } else {
    pwsh += `# Support pipeline input
if ($MyInvocation.ExpectingInput) {
  $input | & ${pwshProg} ${args} ${shTarget} $args
} else {
  & ${pwshProg} ${args} ${shTarget} $args
}
exit $LASTEXITCODE
`;
  }
  await Promise.all([
    writeFile2(to + ".cmd", cmd, "utf8"),
    writeFile2(to + ".ps1", pwsh, "utf8"),
    writeFile2(to, sh, "utf8")
  ]);
  await chmodShim(to);
};
var chmodShim = async (to) => await Promise.all([
  chmod3(to, 493),
  chmod3(to + ".cmd", 493),
  chmod3(to + ".ps1", 493)
]);

// ../../src/graph/src/reify/add-edge.ts
import { mkdir as mkdir3, symlink } from "node:fs/promises";
import { dirname as dirname6, relative as relative3, resolve as resolve8 } from "node:path";
var clobberSymlink = async (target, link2, remover, type2 = "file") => {
  const symlinkType = type2 === "dir" && process.platform === "win32" ? "junction" : type2;
  const symlinkTarget = symlinkType === "junction" ? resolve8(dirname6(link2), target) : target;
  await mkdir3(dirname6(link2), { recursive: true });
  try {
    await symlink(symlinkTarget, link2, symlinkType);
  } catch (er) {
    if (er.code !== "EEXIST") {
      throw er;
    }
    await remover.rm(link2);
    try {
      await symlink(symlinkTarget, link2, symlinkType);
    } catch (er2) {
      if (er2.code !== "EEXIST") {
        throw er2;
      }
    }
  }
};
var addEdge = async (edge, scurry, remover, bins) => {
  if (!edge.to) return;
  const binRoot = scurry.resolve(
    edge.from.nodeModules(scurry),
    ".bin"
  );
  const path2 = scurry.resolve(
    edge.from.nodeModules(scurry),
    edge.spec.name
  );
  const promises = [];
  const target = relative3(
    dirname6(path2),
    edge.to.resolvedLocation(scurry)
  );
  const p = clobberSymlink(target, path2, remover, "dir");
  if (process.platform === "win32") await p;
  else promises.push(p);
  if (bins) {
    for (const [key, val] of Object.entries(bins)) {
      const link2 = scurry.resolve(binRoot, key);
      const absTarget = scurry.resolve(path2, val);
      const target2 = relative3(binRoot, absTarget);
      promises.push(
        process.platform === "win32" ? cmdShimIfExists(absTarget, link2, remover) : clobberSymlink(target2, link2, remover)
      );
    }
  }
  if (promises.length) await Promise.all(promises);
};

// ../../src/graph/src/reify/add-edges.ts
var addEdges = (diff2, scurry, remover) => {
  const actions = [];
  for (const edge of diff2.edges.add) {
    const { to } = edge;
    if (!to) continue;
    const bins = to.bins;
    actions.push(() => addEdge(edge, scurry, remover, bins));
  }
  return actions;
};

// ../../src/graph/src/reify/add-nodes.ts
var addNodes = (diff2, scurry, remover, options, packageInfo) => {
  const actions = [];
  for (const node of diff2.nodes.add) {
    if (!node.inVltStore()) continue;
    if (node.extracted) continue;
    actions.push(
      () => extractNode(node, scurry, remover, options, packageInfo, diff2)
    );
  }
  return actions;
};

// ../../src/graph/src/reify/delete-edge.ts
var rmBinPosix = (remover, bin) => {
  return [remover.rm(bin)];
};
var rmBinWin32 = (remover, bin) => {
  return [
    remover.rm(bin),
    remover.rm(bin + ".cmd"),
    remover.rm(bin + ".ps1")
  ];
};
var rmBin = process.platform === "win32" ? rmBinWin32 : rmBinPosix;
var deleteEdge = async (edge, scurry, remover) => {
  const {
    spec: { name },
    to
  } = edge;
  const nm = edge.from.nodeModules(scurry);
  const path2 = scurry.resolve(nm, name);
  const binRoot = scurry.cwd.resolve(`${nm}/.bin`);
  const promises = [];
  promises.push(remover.rm(path2));
  const bins = to?.bins;
  if (bins) {
    for (const key of Object.keys(bins)) {
      const bin = binRoot.resolve(key).fullpath();
      promises.push(...rmBin(remover, bin));
    }
  }
  await Promise.all(promises);
};

// ../../src/graph/src/reify/delete-edges.ts
var deleteEdges = (diff2, scurry, remover) => {
  const promises = [];
  for (const edge of diff2.edges.delete) {
    if (diff2.nodes.delete.has(edge.from) && edge.from.inVltStore()) {
      continue;
    }
    promises.push(() => deleteEdge(edge, scurry, remover));
  }
  return promises;
};

// ../../src/graph/src/reify/check-needed-build.ts
import { join as join3 } from "node:path";
var nodeNeedsBuild2 = (node, scurry, packageJson) => {
  if (node.built) return false;
  let manifest = node.manifest;
  if (!manifest) {
    try {
      manifest = packageJson.read(node.resolvedLocation(scurry));
      node.manifest = manifest;
    } catch {
      return false;
    }
  }
  const { scripts: scripts2 = {} } = manifest;
  const runInstall = !!(scripts2.install || scripts2.preinstall || scripts2.postinstall);
  if (runInstall) return true;
  const hasBindingGyp = scurry.lstatSync(join3(node.resolvedLocation(scurry), "binding.gyp"))?.isFile() ?? false;
  if (hasBindingGyp && !scripts2.install && !scripts2.preinstall)
    return true;
  const prepable = node.id.startsWith("git") || node.importer || !node.inVltStore();
  const runPrepare = !!(scripts2.prepare || scripts2.preprepare || scripts2.postprepare) && prepable;
  if (runPrepare) return true;
  return false;
};
var checkNeededBuild = (options) => {
  const { diff: diff2, scurry, packageJson } = options;
  const nodesToBuild = [...diff2.nodes.add].filter(
    (node) => nodeNeedsBuild2(node, scurry, packageJson)
  );
  for (const node of nodesToBuild) {
    node.buildState = "needed";
  }
  const buildData = {
    needsBuildNodes: nodesToBuild
  };
  return buildData;
};

// ../../src/graph/src/reify/delete-nodes.ts
var deleteNodes = (diff2, remover, scurry) => {
  const store = scurry.resolve("node_modules/.vlt");
  const rmActions = [];
  for (const node of diff2.nodes.delete) {
    if (!node.inVltStore()) continue;
    rmActions.push(remover.rm(scurry.resolve(store, node.id)));
    for (const edge of node.edgesIn) {
      rmActions.push(deleteEdge(edge, scurry, remover));
    }
  }
  return rmActions;
};

// ../../src/graph/src/reify/internal-hoist.ts
import { mkdir as mkdir4, symlink as symlink2 } from "node:fs/promises";
import { dirname as dirname7, relative as relative4 } from "node:path";
var pickNodeToHoist = (nodes) => {
  let pick = void 0;
  let pickNode = void 0;
  for (const node of nodes) {
    if (node.importer || !node.inVltStore()) {
      continue;
    }
    const id2 = splitDepID(node.id);
    if (!pick || !pickNode) {
      pick = id2;
      pickNode = node;
      continue;
    }
    const impDep = [...node.edgesIn].some((n) => n.from.importer);
    const pickImpDep = [...pickNode.edgesIn].some(
      (n) => n.from.importer
    );
    if (impDep !== pickImpDep) {
      if (!pickImpDep) {
        pick = id2;
        pickNode = node;
      }
      continue;
    }
    if (id2[0] === "registry") {
      if (pick[0] !== "registry") {
        pick = id2;
        pickNode = node;
        continue;
      }
      const pickVersion = pickNode.version;
      const nodeVersion = node.version;
      if (pickVersion) {
        if (!nodeVersion) continue;
        if (Version.parse(nodeVersion).greaterThan(
          Version.parse(pickVersion)
        )) {
          pick = id2;
          pickNode = node;
        }
        continue;
      } else if (nodeVersion) {
        pick = id2;
        pickNode = node;
        continue;
      }
    } else {
      if (pick[0] === "registry") continue;
      if (pickNode.id.localeCompare(node.id, "en") > 0) {
        pick = id2;
        pickNode = node;
      }
    }
  }
  return pickNode;
};
var internalHoist = async (graph, options, remover) => {
  const links = /* @__PURE__ */ new Map();
  for (const [name, nodes] of graph.nodesByName) {
    const pickNode = pickNodeToHoist(nodes);
    if (pickNode) {
      let picked = false;
      if (pickNode.edgesIn.size > 0) {
        for (const edgeIn of pickNode.edgesIn) {
          const otherName = edgeIn.name;
          if (otherName !== name && !links.has(otherName)) {
            picked = true;
            links.set(otherName, pickNode);
          }
        }
      }
      if (!picked) {
        links.set(name, pickNode);
      }
    }
  }
  const { scurry } = options;
  const hoistDir = scurry.cwd.resolve(
    "node_modules/.vlt/node_modules"
  );
  await mkdir4(hoistDir.fullpath(), { recursive: true });
  const removes = [];
  for (const entry of await hoistDir.readdir()) {
    const name = entry.name;
    if (name.startsWith("@")) {
      for (const pkg of await entry.readdir()) {
        await checkExisting(
          `${name}/${pkg.name}`,
          pkg,
          links,
          removes,
          scurry,
          remover
        );
      }
    } else {
      await checkExisting(
        name,
        entry,
        links,
        removes,
        scurry,
        remover
      );
    }
  }
  await Promise.all(removes);
  const symlinks = [];
  for (const [name, { name: nodeName, id: id2 }] of links) {
    const target = scurry.resolve(
      `node_modules/.vlt/${id2}/node_modules/${nodeName}`
    );
    const path2 = scurry.resolve(
      `node_modules/.vlt/node_modules/${name}`
    );
    if (name.includes("/")) {
      await mkdir4(dirname7(path2), { recursive: true });
    }
    symlinks.push(
      symlink2(relative4(dirname7(path2), target), path2, "dir")
    );
  }
  await Promise.all(symlinks);
};
var checkExisting = async (name, entry, links, removes, scurry, remover) => {
  const target = await entry.readlink();
  const { id: id2 } = links.get(name) ?? {};
  if (!target || !id2 || target !== scurry.cwd.resolve(
    `node_modules/.vlt/${id2}/node_modules/${name}`
  )) {
    removes.push(remover.rm(entry.fullpath()));
  } else {
    links.delete(name);
  }
};

// ../../src/graph/src/reify/rollback.ts
var rollback = async (remover, diff2, scurry) => {
  const promises = [];
  const store = scurry.resolve("node_modules/.vlt");
  const backRoller = new RollbackRemove();
  for (const node of diff2.nodes.add) {
    if (!node.inVltStore()) continue;
    const path2 = scurry.resolve(store, node.id);
    promises.push(backRoller.rm(path2).catch(() => {
    }));
  }
  for (const edge of diff2.edges.add) {
    promises.push(deleteEdge(edge, scurry, backRoller));
  }
  await Promise.all(promises).catch(() => {
  });
  backRoller.confirm();
  await remover.rollback().catch(() => {
  });
};

// ../../src/graph/src/reify/update-importers-package-json.ts
var depTypesMap = /* @__PURE__ */ new Map([
  ["prod", "dependencies"],
  ["dev", "devDependencies"],
  ["peer", "peerDependencies"],
  ["peerOptional", "peerDependencies"],
  ["optional", "optionalDependencies"]
]);
var addOrRemoveDeps = (nodeId, graph, addOrRemove) => {
  const node = graph.nodes.get(nodeId);
  if (!node) {
    throw error("Failed to retrieve node", {
      found: nodeId
    });
  }
  const manifest = node.manifest;
  if (!manifest) {
    throw error("Could not find manifest data for node", {
      found: nodeId
    });
  }
  const deps = addOrRemove?.get(nodeId);
  if (!deps) {
    throw error("Failed to retrieve added deps info", {
      manifest
    });
  }
  let manifestChanged = false;
  for (const deleteNameOrAddItem of deps) {
    if (typeof deleteNameOrAddItem === "string") {
      const name = deleteNameOrAddItem;
      for (const depType of longDependencyTypes) {
        if (manifest[depType]?.[name]) {
          delete manifest[depType][name];
          manifestChanged = true;
        }
      }
      if (manifest.peerDependenciesMeta?.[name]) {
        delete manifest.peerDependenciesMeta[name];
        manifestChanged = true;
      }
    } else {
      const [name, dep] = deleteNameOrAddItem;
      const depTypeShort = resolveSaveType(node, name, dep.type);
      const depType = depTypesMap.get(depTypeShort);
      if (!depType) {
        throw error("Failed to retrieve dependency type", {
          validOptions: [...depTypesMap.keys()],
          found: dep.type
        });
      }
      const n = node.edgesOut.get(name)?.to;
      if (!n) {
        throw error("Dependency node could not be found");
      }
      const [nodeType] = splitDepID(n.id);
      for (const dtype of longDependencyTypes) {
        if (dtype === depType || !manifest[dtype]) continue;
        delete manifest[dtype][name];
      }
      if (depTypeShort === "peerOptional") {
        manifest.peerDependenciesMeta ??= {};
        manifest.peerDependenciesMeta[name] = { optional: true };
      } else if (manifest.peerDependenciesMeta?.[name]) {
        delete manifest.peerDependenciesMeta[name];
      }
      const dependencies = manifest[depType] ?? (manifest[depType] = {});
      const existing = dependencies[name];
      const saveValue = calculateSaveValue(
        nodeType,
        dep.spec,
        existing,
        n.version
      );
      dependencies[name] = saveValue;
      manifestChanged = manifestChanged || saveValue !== existing;
    }
  }
  return manifestChanged ? manifest : void 0;
};
var updatePackageJson = ({
  add,
  graph,
  packageJson,
  remove
}) => {
  const manifestsToUpdate = /* @__PURE__ */ new Set();
  const operations = /* @__PURE__ */ new Set([add, remove]);
  for (const operation of operations) {
    if (operation) {
      for (const nodeId of operation.keys()) {
        const manifest = addOrRemoveDeps(nodeId, graph, operation);
        if (manifest) {
          manifestsToUpdate.add(manifest);
        }
      }
    }
  }
  const commit = () => {
    for (const manifest of manifestsToUpdate) {
      packageJson.save(manifest);
    }
  };
  return commit;
};

// ../../src/graph/src/reify/index.ts
import { copyFileSync } from "node:fs";
var limit = Math.max(availableParallelism2() - 1, 1) * 8;
var filterNodesByQuery2 = async (graph, allowScriptsQuery) => {
  if (allowScriptsQuery === ":not(*)" || !allowScriptsQuery) {
    return /* @__PURE__ */ new Set();
  }
  if (allowScriptsQuery === "*") {
    return new Set(graph.nodes.keys());
  }
  const securityArchive = Query.hasSecuritySelectors(allowScriptsQuery) ? await SecurityArchive.start({
    nodes: [...graph.nodes.values()]
  }) : void 0;
  const edges = graph.edges;
  const nodes = new Set(graph.nodes.values());
  const importers = graph.importers;
  const query = new Query({
    edges,
    nodes,
    importers,
    securityArchive
  });
  const { nodes: resultNodes } = await query.search(
    allowScriptsQuery,
    {
      signal: new AbortController().signal
    }
  );
  return new Set(resultNodes.map((node) => node.id));
};
var reify = async (options) => {
  const done = graphStep("reify");
  const { graph, scurry, remover } = options;
  const actual2 = options.actual ?? load4({
    ...options,
    loadManifests: true
  });
  const diff2 = new Diff(actual2, graph);
  const noModifiedDependencies = !options.add?.modifiedDependencies && !options.remove?.modifiedDependencies;
  const skipOptionalOnly = noModifiedDependencies && diff2.optionalOnly;
  const skippable = skipOptionalOnly && !options.update;
  const res = { diff: diff2 };
  if (!diff2.hasChanges() || skippable) {
    done();
    return res;
  }
  let success = false;
  try {
    const { buildQueue } = await reify_(options, diff2, remover);
    remover.confirm();
    success = true;
    res.buildQueue = buildQueue;
  } finally {
    if (!success) {
      await rollback(remover, diff2, scurry).catch(() => {
      });
    }
  }
  done();
  return res;
};
var reify_ = async (options, diff2, remover) => {
  const res = {};
  const {
    add,
    remove,
    packageInfo,
    packageJson,
    scurry,
    allowScripts
  } = options;
  const saveImportersPackageJson = (
    /* c8 ignore next */
    add?.modifiedDependencies || remove?.modifiedDependencies ? updatePackageJson({
      add,
      remove,
      graph: options.graph,
      packageJson
    }) : void 0
  );
  const lfData = lockfileData(options);
  const actions = addNodes(
    diff2,
    scurry,
    remover,
    options,
    packageInfo
  ).concat(deleteEdges(diff2, scurry, remover));
  if (actions.length) await callLimit(actions, { limit });
  const edgeActions = addEdges(diff2, scurry, remover);
  if (edgeActions.length) await callLimit(edgeActions, { limit });
  await internalHoist(diff2.to, options, remover);
  checkNeededBuild({ diff: diff2, scurry, packageJson });
  const allowScriptsNodes = await filterNodesByQuery2(
    diff2.to,
    allowScripts
  );
  await binChmodAll(diff2.nodes.add, scurry);
  await build(diff2, packageJson, scurry, allowScriptsNodes);
  res.buildQueue = [...diff2.nodes.add].filter((node) => node.buildState === "needed").map((node) => node.id);
  if (diff2.hadOptionalFailures) {
    for (const node of options.graph.gc().values()) {
      diff2.nodes.add.delete(node);
      diff2.nodes.delete.add(node);
    }
  }
  saveHidden(options);
  const rmActions = deleteNodes(
    diff2,
    remover,
    scurry
  );
  if (rmActions.length) await Promise.all(rmActions);
  saveImportersPackageJson?.();
  saveData(lfData, scurry.resolve("vlt-lock.json"), false);
  if (scurry.lstatSync("vlt.json")) {
    copyFileSync(
      scurry.resolve("vlt.json"),
      scurry.resolve("node_modules/.vlt/vlt.json")
    );
  }
  return res;
};

// ../../src/graph/src/install.ts
import { existsSync as existsSync5, rmSync as rmSync3 } from "node:fs";
import { resolve as resolve11 } from "node:path";

// ../../src/graph/src/uninstall.ts
import { existsSync as existsSync3, rmSync } from "node:fs";
import { resolve as resolve9 } from "node:path";
var uninstall = async (options, remove) => {
  const mainManifest = options.packageJson.read(options.projectRoot);
  const modifiers = GraphModifier.maybeLoad(options);
  const remover = new RollbackRemove();
  try {
    const act = load4({
      ...options,
      modifiers: void 0,
      mainManifest,
      loadManifests: true
    });
    const graph = await build3({
      ...options,
      actual: act,
      remove,
      mainManifest,
      loadManifests: true,
      remover
    });
    if (options.lockfileOnly) {
      lockfile.save({ graph, modifiers });
      const saveImportersPackageJson = (
        /* c8 ignore next */
        remove?.modifiedDependencies ? updatePackageJson({
          ...options,
          remove,
          graph
        }) : void 0
      );
      saveImportersPackageJson?.();
      return { graph, diff: void 0 };
    }
    const diff2 = await reify({
      ...options,
      remove,
      actual: act,
      graph,
      loadManifests: true,
      remover
    });
    return { graph, diff: diff2 };
  } catch (err) {
    await remover.rollback().catch(() => {
    });
    try {
      const hiddenLockfile = resolve9(
        options.projectRoot,
        "node_modules/.vlt-lock.json"
      );
      if (existsSync3(hiddenLockfile)) {
        rmSync(hiddenLockfile, { force: true });
      }
    } catch {
    }
    throw err;
  }
};

// ../../src/graph/src/update.ts
import { existsSync as existsSync4, rmSync as rmSync2 } from "node:fs";
import { resolve as resolve10 } from "node:path";
var update = async (options) => {
  let mainManifest = void 0;
  try {
    mainManifest = options.packageJson.read(options.projectRoot);
  } catch (err) {
    if (asError(err).message === "Could not read package.json file") {
      await init({ cwd: options.projectRoot });
      mainManifest = options.packageJson.read(options.projectRoot, {
        reload: true
      });
    } else {
      throw err;
    }
  }
  const modifiers = GraphModifier.maybeLoad(options);
  const remover = new RollbackRemove();
  try {
    const done = graphStep("build");
    const graph = await buildIdealFromStartingGraph({
      ...options,
      add: Object.assign(/* @__PURE__ */ new Map(), { modifiedDependencies: false }),
      remove: Object.assign(/* @__PURE__ */ new Map(), {
        modifiedDependencies: false
      }),
      graph: new Graph({ ...options, mainManifest }),
      modifiers,
      remover
    });
    done();
    const act = load4({
      ...options,
      mainManifest,
      loadManifests: true
    });
    const { buildQueue, diff: diff2 } = await reify({
      ...options,
      actual: act,
      graph,
      loadManifests: true,
      modifiers,
      remover,
      update: true
    });
    return { buildQueue, graph, diff: diff2 };
  } catch (err) {
    await remover.rollback().catch(() => {
    });
    try {
      const hiddenLockfile = resolve10(
        options.projectRoot,
        "node_modules/.vlt-lock.json"
      );
      if (existsSync4(hiddenLockfile)) {
        rmSync2(hiddenLockfile, { force: true });
      }
    } catch {
    }
    throw err;
  }
};

// ../../src/graph/src/virtual-root.ts
var VIRTUAL_ROOT_ID = joinDepIDTuple([
  "file",
  "__virtual%root__"
]);
var createVirtualRoot = (name = "virtual-root", options, mainImporters) => {
  const res = {
    id: VIRTUAL_ROOT_ID,
    name,
    version: "1.0.0",
    manifest: {
      name,
      version: "1.0.0"
    },
    edgesIn: /* @__PURE__ */ new Set(),
    edgesOut: /* @__PURE__ */ new Map([]),
    confused: false,
    importer: true,
    mainImporter: true,
    location: ".",
    graph: { importers: /* @__PURE__ */ new Set() },
    projectRoot: "",
    dev: false,
    optional: false,
    options,
    setConfusedManifest() {
    },
    setResolved() {
    },
    maybeSetConfusedManifest() {
    },
    workspaces: void 0,
    toJSON() {
      return {
        id: this.id,
        name: this.name,
        version: this.version,
        location: this.location,
        importer: this.importer,
        manifest: this.manifest,
        projectRoot: this.projectRoot,
        integrity: this.integrity,
        resolved: this.resolved,
        dev: this.dev,
        optional: this.optional,
        confused: false
      };
    }
  };
  res[Symbol.toStringTag] = "@vltpkg/graph.Node";
  for (const importer of mainImporters) {
    const name2 = importer.name || "(unknown)";
    if (importer.mainImporter) {
      const spec2 = Spec.parse(name2, "file:.", options);
      const edge = {
        name: spec2.name,
        from: res,
        to: importer,
        spec: spec2,
        type: "prod"
      };
      res.edgesOut.set(name2, edge);
      importer.edgesIn.add(edge);
    }
  }
  return res;
};

// ../../src/graph/src/index.ts
var actual = { load: load4 };
var lockfile = {
  load: load3,
  loadEdges,
  loadNodes,
  save
};

// ../../src/graph/src/install.ts
var install = async (options, add) => {
  if (options.lockfileOnly && options.cleanInstall) {
    throw error(
      "Cannot use --lockfile-only with --clean-install (ci command). Clean install requires filesystem operations."
    );
  }
  if (options.expectLockfile || options.frozenLockfile) {
    const lockfilePath = resolve11(options.projectRoot, "vlt-lock.json");
    if (!existsSync5(lockfilePath)) {
      throw error(
        "vlt-lock.json file is required when using --expect-lockfile, --frozen-lockfile, or ci command",
        {
          path: lockfilePath
        }
      );
    }
  }
  let mainManifest = void 0;
  try {
    mainManifest = options.packageJson.read(options.projectRoot);
  } catch (err) {
    if (asError(err).message === "Could not read package.json file") {
      await init({ cwd: options.projectRoot });
      mainManifest = options.packageJson.read(options.projectRoot, {
        reload: true
      });
    } else {
      throw err;
    }
  }
  const fullMonorepo = Monorepo.maybeLoad(options.projectRoot, {
    packageJson: options.packageJson,
    scurry: options.scurry
  });
  if (options.frozenLockfile) {
    if (add?.modifiedDependencies) {
      const dependencies = [];
      for (const [, deps] of add) {
        for (const [name] of deps) {
          dependencies.push(name);
        }
      }
      throw error(
        "Cannot add dependencies when using --frozen-lockfile",
        { found: dependencies.join(", ") }
      );
    }
    const lockfileGraph = load3({
      ...options,
      mainManifest,
      monorepo: fullMonorepo
    });
    const emptyAdd = Object.assign(
      /* @__PURE__ */ new Map(),
      { modifiedDependencies: false }
    );
    const emptyRemove = Object.assign(/* @__PURE__ */ new Map(), {
      modifiedDependencies: false
    });
    const importerSpecs = getImporterSpecs({
      graph: lockfileGraph,
      add: emptyAdd,
      remove: emptyRemove,
      ...options
    });
    const specChanges = [];
    for (const importer of lockfileGraph.importers) {
      const deps = getDependencies(importer, options);
      for (const [depName, dep] of deps) {
        const edge = importer.edgesOut.get(depName);
        if (edge?.spec) {
          if (edge.spec.toString() !== dep.spec.toString()) {
            const node = lockfileGraph.nodes.get(importer.id);
            const location = node?.location || importer.id;
            specChanges.push(
              `  ${location}: ${depName} spec changed from "${edge.spec}" to "${dep.spec}"`
            );
          }
        }
      }
    }
    if (importerSpecs.add.modifiedDependencies || importerSpecs.remove.modifiedDependencies || specChanges.length > 0) {
      const details = [];
      if (specChanges.length > 0) {
        details.push(...specChanges);
      }
      for (const [importerId, deps] of importerSpecs.add) {
        if (deps.size > 0) {
          const node = lockfileGraph.nodes.get(importerId);
          const location = node?.location || importerId;
          const depNames = Array.from(deps.keys());
          const depLabelAdd = deps.size === 1 ? "dependency" : "dependencies";
          details.push(
            `  ${location}: ${deps.size} ${depLabelAdd} to add (${depNames.join(", ")})`
          );
        }
      }
      for (const [importerId, deps] of importerSpecs.remove) {
        if (deps.size > 0) {
          const node = lockfileGraph.nodes.get(importerId);
          const location = node?.location || importerId;
          const depNames = Array.from(deps);
          const depLabelRemove = deps.size === 1 ? "dependency" : (
            /* c8 ignore next */
            "dependencies"
          );
          details.push(
            `  ${location}: ${deps.size} ${depLabelRemove} to remove (${depNames.join(", ")})`
          );
        }
      }
      const lockfilePath = resolve11(
        options.projectRoot,
        "vlt-lock.json"
      );
      throw error(
        'Lockfile is out of sync with package.json. Run "vlt install" to update.\n' + details.join("\n"),
        {
          path: lockfilePath
        }
      );
    }
  }
  const remover = new RollbackRemove();
  if (options.cleanInstall) {
    const nodeModulesPath = resolve11(
      options.projectRoot,
      "node_modules"
    );
    if (existsSync5(nodeModulesPath)) {
      await remover.rm(nodeModulesPath);
      remover.confirm();
    }
  }
  try {
    const remove = Object.assign(/* @__PURE__ */ new Map(), {
      modifiedDependencies: false
    });
    const modifiers = GraphModifier.maybeLoad(options);
    let act = load4({
      ...options,
      mainManifest,
      loadManifests: true,
      modifiers: void 0,
      // modifiers should not be used here
      monorepo: fullMonorepo
    });
    if (act.importers.size === act.nodes.size) {
      act = void 0;
    }
    const graph = await build3({
      ...options,
      actual: act,
      add,
      mainManifest,
      loadManifests: true,
      modifiers,
      remove,
      remover,
      monorepo: fullMonorepo
    });
    if (options.lockfileOnly) {
      lockfile.save({ graph, modifiers });
      const saveImportersPackageJson = (
        /* c8 ignore next */
        add?.modifiedDependencies || remove.modifiedDependencies ? updatePackageJson({
          ...options,
          add,
          graph,
          remove
        }) : void 0
      );
      saveImportersPackageJson?.();
      return { graph, diff: void 0 };
    }
    const { diff: diff2, buildQueue } = await reify({
      ...options,
      add,
      actual: act,
      graph,
      loadManifests: true,
      modifiers,
      remove,
      remover
    });
    return { buildQueue, graph, diff: diff2 };
  } catch (err) {
    await remover.rollback().catch(() => {
    });
    try {
      const hiddenLockfile = resolve11(
        options.projectRoot,
        "node_modules/.vlt-lock.json"
      );
      if (existsSync5(hiddenLockfile)) {
        rmSync3(hiddenLockfile, { force: true });
      }
    } catch {
    }
    throw err;
  }
};

export {
  asDependency,
  asNode,
  run,
  runFG,
  isRunResult,
  exec,
  execFG,
  runExec,
  runExecFG,
  Query,
  build2 as build,
  jsonOutput,
  humanReadableOutput,
  mermaidOutput,
  callLimit,
  findCmdShimIfExists,
  RollbackRemove,
  GraphModifier,
  install,
  uninstall,
  update,
  VIRTUAL_ROOT_ID,
  createVirtualRoot,
  actual
};
/*! Bundled license information:

cssesc/cssesc.js:
  (*! https://mths.be/cssesc v3.0.0 by @mathias *)
*/
