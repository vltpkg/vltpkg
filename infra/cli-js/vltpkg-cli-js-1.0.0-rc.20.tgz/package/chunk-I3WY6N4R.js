var global = globalThis;
import {Buffer} from "node:buffer";
import {setTimeout as _vlt_setTimeout,clearTimeout as _vlt_clearTimeout,setImmediate as _vlt_setImmediate,clearImmediate as _vlt_clearImmediate,setInterval as _vlt_setInterval,clearInterval as _vlt_clearInterval} from "node:timers";
globalThis.setTimeout = _vlt_setTimeout;
globalThis.clearTimeout = _vlt_clearTimeout;
globalThis.setImmediate = _vlt_setImmediate;
globalThis.clearImmediate = _vlt_clearImmediate;
globalThis.setInterval = _vlt_setInterval;
globalThis.clearInterval = _vlt_clearInterval;
import {createRequire as _vlt_createRequire} from "node:module";
var require = _vlt_createRequire(import.meta.filename);
import {
  It,
  require_lib,
  zn
} from "./chunk-FI5TUER7.js";
import {
  minimatch
} from "./chunk-Z76BQOEV.js";
import {
  Spec2 as Spec
} from "./chunk-FEV5BCW7.js";
import {
  parse,
  stringify
} from "./chunk-HTOTG4TS.js";
import {
  error
} from "./chunk-WZWDS3W4.js";
import {
  __toESM
} from "./chunk-PZLD7RTK.js";

// ../../src/cli-sdk/src/pack-tarball.ts
var ssri = __toESM(require_lib(), 1);
import assert from "node:assert";
import { existsSync, statSync } from "node:fs";
import { join } from "node:path";
var replaceWorkspaceAndCatalogSpecs = (manifest_, config) => {
  const manifest = parse(stringify(manifest_));
  const { monorepo, catalog = {}, catalogs = {} } = config.options;
  const depTypes = [
    "dependencies",
    "devDependencies",
    "optionalDependencies",
    "peerDependencies"
  ];
  for (const depType of depTypes) {
    const deps = manifest[depType];
    if (!deps || typeof deps !== "object") continue;
    const depsObj = deps;
    for (const [depName, depSpec] of Object.entries(depsObj)) {
      if (typeof depSpec !== "string") continue;
      const spec = Spec.parse(`${depName}@${depSpec}`, {
        catalog,
        catalogs
      });
      switch (spec.type) {
        case "workspace": {
          assert(
            monorepo,
            error(`No workspace configuration found for ${depName}`, {
              found: depName
            })
          );
          const workspaceName = spec.workspace;
          assert(
            workspaceName,
            error(`No workspace name found for ${depName}`, {
              found: depName
            })
          );
          const workspace = monorepo.get(workspaceName);
          assert(
            workspace,
            error(`Workspace '${workspaceName}' not found`, {
              found: workspaceName,
              validOptions: Array.from(monorepo.keys())
            })
          );
          const actualVersion = workspace.manifest.version;
          assert(
            actualVersion,
            error(
              `No version found for workspace '${workspaceName}'`,
              {
                found: workspaceName,
                wanted: "package version"
              }
            )
          );
          depsObj[depName] = actualVersion;
          break;
        }
        case "catalog": {
          const catalogName = spec.catalog || "";
          const targetCatalog = catalogName ? catalogs[catalogName] : catalog;
          assert(
            targetCatalog,
            error(`Catalog '${catalogName}' not found`, {
              found: catalogName,
              validOptions: Object.keys(catalogs)
            })
          );
          const actualVersion = targetCatalog[depName];
          assert(
            actualVersion,
            error(
              `Package '${depName}' not found in catalog '${catalogName || "default"}'`,
              {
                found: depName,
                validOptions: Object.keys(targetCatalog)
              }
            )
          );
          depsObj[depName] = actualVersion;
          break;
        }
      }
    }
  }
  return manifest;
};
var packTarball = async (manifest, dir, config) => {
  let packDir = dir;
  const cliPublishDir = config.get("publish-directory");
  const manifestPublishDir = manifest.publishConfig?.directory;
  const publishDirectory = cliPublishDir ?? manifestPublishDir;
  if (publishDirectory) {
    const resolvedPublishDir = cliPublishDir ? publishDirectory : join(dir, publishDirectory);
    assert(
      existsSync(resolvedPublishDir),
      error(
        `Publish directory does not exist: ${resolvedPublishDir}`,
        {
          found: resolvedPublishDir
        }
      )
    );
    assert(
      statSync(resolvedPublishDir).isDirectory(),
      error(
        `Publish directory is not a directory: ${resolvedPublishDir}`,
        {
          found: resolvedPublishDir,
          wanted: "directory"
        }
      )
    );
    if (existsSync(join(resolvedPublishDir, "package.json"))) {
      manifest = config.options.packageJson.read(resolvedPublishDir);
    }
    packDir = resolvedPublishDir;
  }
  assert(
    manifest.name && manifest.version,
    error("Package must have a name and version")
  );
  const processedManifest = replaceWorkspaceAndCatalogSpecs(
    manifest,
    config
  );
  const filename = `${manifest.name.replace("@", "").replace("/", "-")}-${manifest.version}.tgz`;
  const tarballName = `${manifest.name}-${manifest.version}.tgz`;
  try {
    config.options.packageJson.write(packDir, processedManifest);
    const tarballData = await zn(
      {
        cwd: packDir,
        gzip: true,
        portable: true,
        prefix: "package/",
        filter: (path) => {
          const normalizedPath = path.replace(/^\.\//, "");
          if (path === "." || normalizedPath === "") {
            return true;
          }
          const alwaysExcludePatterns = [
            /^\.?\/?\.git(\/|$)/,
            /^\.?\/?node_modules(\/|$)/,
            /^\.?\/?\.nyc_output(\/|$)/,
            /^\.?\/?coverage(\/|$)/,
            /^\.?\/?\.DS_Store$/,
            /^\.?\/?\.npmrc$/,
            /^\.?\/?package-lock\.json$/,
            /^\.?\/?yarn\.lock$/,
            /^\.?\/?pnpm-lock\.yaml$/,
            /^\.?\/?bun\.lockb$/,
            /^\.?\/?bun\.lock$/,
            /^\.?\/?vlt-lock\.json$/,
            /~$/,
            /\.swp$/,
            /\.tgz$/
          ];
          if (alwaysExcludePatterns.some(
            (pattern) => pattern.test(normalizedPath)
          )) {
            return false;
          }
          const alwaysIncludePatterns = [
            /^README(\..*)?$/i,
            /^CHANGELOG(\..*)?$/i,
            /^HISTORY(\..*)?$/i,
            /^LICENSE(\..*)?$/i,
            /^LICENCE(\..*)?$/i
          ];
          if (alwaysIncludePatterns.some(
            (pattern) => pattern.test(normalizedPath)
          )) {
            return true;
          }
          if (normalizedPath === "package.json") {
            return true;
          }
          const manifestWithFiles = manifest;
          if (manifestWithFiles.files && Array.isArray(manifestWithFiles.files)) {
            if (manifestWithFiles.files.length === 0) {
              return false;
            }
            return manifestWithFiles.files.some((pattern) => {
              if (pattern.endsWith("/")) {
                const dirName = pattern.slice(0, -1);
                const globPattern = pattern.replace(/\/$/, "/**");
                const matchesDir = normalizedPath === dirName;
                const matchesContents = minimatch(
                  normalizedPath,
                  globPattern,
                  {
                    dot: true
                  }
                );
                return matchesDir || matchesContents;
              }
              const directMatch = minimatch(normalizedPath, pattern, {
                dot: true
              });
              const isParentDir = pattern.includes("/") && pattern.startsWith(normalizedPath + "/");
              return directMatch || isParentDir;
            });
          }
          const defaultExcludePatterns = [
            /^\.?\/?\.vscode(\/|$)/,
            /^\.?\/?\.idea(\/|$)/,
            /^\.?\/?\.gitignore$/,
            /^\.?\/?\.npmignore$/,
            /^\.?\/?\.editorconfig$/
          ];
          return !defaultExcludePatterns.some(
            (pattern) => pattern.test(normalizedPath)
          );
        }
      },
      ["."]
    ).concat();
    let unpackedSize = 0;
    const files = [];
    await new Promise((resolve, reject) => {
      const stream = It({
        onentry: (entry) => {
          if (entry.type === "File") {
            unpackedSize += entry.size;
            const cleanPath = entry.path.replace(/^[^/]+\//, "");
            if (cleanPath) {
              files.push(cleanPath);
            }
          }
        }
      });
      stream.on("end", () => resolve()).on("error", reject).write(tarballData);
      stream.end();
    });
    const integrityMap = ssri.fromData(tarballData, {
      algorithms: [.../* @__PURE__ */ new Set(["sha1", "sha512"])]
    });
    const integrity = integrityMap.sha512?.[0]?.toString();
    const shasum = integrityMap.sha1?.[0]?.hexDigest();
    return {
      name: manifest.name,
      version: manifest.version,
      filename,
      tarballName,
      tarballData,
      unpackedSize,
      files,
      integrity,
      shasum
    };
  } finally {
    config.options.packageJson.write(packDir, manifest);
  }
};

export {
  packTarball
};
