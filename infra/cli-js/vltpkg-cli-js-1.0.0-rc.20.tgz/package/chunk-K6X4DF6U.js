var global = globalThis;
import {Buffer} from "node:buffer";
import {setTimeout as _vlt_setTimeout,clearTimeout as _vlt_clearTimeout,setImmediate as _vlt_setImmediate,clearImmediate as _vlt_clearImmediate,setInterval as _vlt_setInterval,clearInterval as _vlt_clearInterval} from "node:timers";
globalThis.setTimeout = _vlt_setTimeout;
globalThis.clearTimeout = _vlt_clearTimeout;
globalThis.setImmediate = _vlt_setImmediate;
globalThis.clearImmediate = _vlt_clearImmediate;
globalThis.setInterval = _vlt_setInterval;
globalThis.clearInterval = _vlt_clearInterval;
import {createRequire as _vlt_createRequire} from "node:module";
var require = _vlt_createRequire(import.meta.filename);
import {
  asDependency
} from "./chunk-EHD7YJKI.js";
import {
  Spec2 as Spec,
  joinDepIDTuple
} from "./chunk-FEV5BCW7.js";

// ../../src/cli-sdk/src/parse-add-remove-args.ts
var rootDepID = joinDepIDTuple(["file", "."]);
var getCwdDepID = (scurry) => {
  const cwd = process.cwd();
  const relPath = scurry.relativePosix(cwd);
  if (!relPath || relPath.startsWith("..")) {
    return rootDepID;
  }
  return joinDepIDTuple(["file", relPath.split("\\").join("/")]);
};
var getWorkspaceImporters = (opts, monorepo) => {
  const res = /* @__PURE__ */ new Set();
  if (monorepo) {
    for (const ws of monorepo.filter(opts)) {
      res.add(ws.id);
    }
  }
  return res;
};
var getType = (opts) => opts["save-prod"] ? "prod" : opts["save-dev"] ? "dev" : opts["save-peer"] ? opts["save-optional"] ? "peerOptional" : "peer" : opts["save-optional"] ? "optional" : "implicit";
var AddImportersDependenciesMapImpl = class extends Map {
  modifiedDependencies = false;
};
var RemoveImportersDependenciesMapImpl = class extends Map {
  modifiedDependencies = false;
};
var parseAddArgs = (config, scurry, monorepo) => {
  const add = new AddImportersDependenciesMapImpl();
  const items = config.positionals;
  const type = getType(config.values);
  const importers = getWorkspaceImporters(config.values, monorepo);
  const newDependencies = /* @__PURE__ */ new Map();
  const specOptions = config.options;
  const getName = (s) => s.name === "(unknown)" ? s.spec : s.name;
  for (const item of items) {
    const spec = Spec.parseArgs(item, specOptions);
    newDependencies.set(getName(spec), asDependency({ spec, type }));
    add.modifiedDependencies = true;
  }
  for (const importer of importers) {
    add.set(importer, newDependencies);
  }
  if (!importers.size) {
    const cwdDepID = getCwdDepID(scurry);
    add.set(cwdDepID, newDependencies);
  }
  return {
    add
  };
};
var parseRemoveArgs = (config, scurry, monorepo) => {
  const remove = new RemoveImportersDependenciesMapImpl();
  const importers = getWorkspaceImporters(config.values, monorepo);
  for (const importer of importers) {
    remove.set(importer, new Set(config.positionals));
    remove.modifiedDependencies = true;
  }
  if (!importers.size) {
    const cwdDepID = getCwdDepID(scurry);
    remove.set(cwdDepID, new Set(config.positionals));
    remove.modifiedDependencies = true;
  }
  return {
    remove
  };
};

export {
  parseAddArgs,
  parseRemoveArgs
};
