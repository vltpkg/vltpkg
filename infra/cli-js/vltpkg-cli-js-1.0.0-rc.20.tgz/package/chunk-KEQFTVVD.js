var global = globalThis;
import {Buffer} from "node:buffer";
import {setTimeout as _vlt_setTimeout,clearTimeout as _vlt_clearTimeout,setImmediate as _vlt_setImmediate,clearImmediate as _vlt_clearImmediate,setInterval as _vlt_setInterval,clearInterval as _vlt_clearInterval} from "node:timers";
globalThis.setTimeout = _vlt_setTimeout;
globalThis.clearTimeout = _vlt_clearTimeout;
globalThis.setImmediate = _vlt_setImmediate;
globalThis.clearImmediate = _vlt_clearImmediate;
globalThis.setInterval = _vlt_setInterval;
globalThis.clearInterval = _vlt_clearInterval;
import {createRequire as _vlt_createRequire} from "node:module";
var require = _vlt_createRequire(import.meta.filename);
import {
  stderr
} from "./chunk-2M5IL56T.js";
import {
  ViewClass
} from "./chunk-RXNA2XCX.js";
import {
  mermaidOutput
} from "./chunk-EHD7YJKI.js";
import {
  urlOpen
} from "./chunk-D7U7KDEM.js";

// ../../src/cli-sdk/src/mermaid-image-view.ts
var MermaidImageView = class extends ViewClass {
  format;
  constructor(...args) {
    super(...args);
    this.format = this.config.values.view;
  }
  async done(result, _opts) {
    const mermaidText = mermaidOutput(result);
    const { renderMermaidToFile, renderMermaidToPng } = await import("./render-mermaid-4IFSZEQQ.js");
    if (this.format === "png") {
      stderr(`Generating PNG image...`);
      const filePath = await renderMermaidToPng(mermaidText);
      stderr(`Image saved to: ${filePath}`);
      await urlOpen(filePath);
    } else {
      stderr(`Generating SVG image...`);
      const filePath = await renderMermaidToFile(mermaidText);
      stderr(`Image saved to: ${filePath}`);
      await urlOpen(filePath);
    }
  }
};

export {
  MermaidImageView
};
