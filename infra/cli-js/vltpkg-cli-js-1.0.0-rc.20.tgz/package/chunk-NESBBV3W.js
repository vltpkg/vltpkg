var global = globalThis;
import {Buffer} from "node:buffer";
import {setTimeout as _vlt_setTimeout,clearTimeout as _vlt_clearTimeout,setImmediate as _vlt_setImmediate,clearImmediate as _vlt_clearImmediate,setInterval as _vlt_setInterval,clearInterval as _vlt_clearInterval} from "node:timers";
globalThis.setTimeout = _vlt_setTimeout;
globalThis.clearTimeout = _vlt_clearTimeout;
globalThis.setImmediate = _vlt_setImmediate;
globalThis.clearImmediate = _vlt_clearImmediate;
globalThis.setInterval = _vlt_setInterval;
globalThis.clearInterval = _vlt_clearInterval;
import {createRequire as _vlt_createRequire} from "node:module";
var require = _vlt_createRequire(import.meta.filename);
import {
  error
} from "./chunk-WZWDS3W4.js";
import {
  __glob
} from "./chunk-PZLD7RTK.js";

// import("./commands/**/*.ts") in ../../src/cli-sdk/src/load-command.ts
var globImport_commands_ts = __glob({
  "./commands/bugs.ts": () => import("./bugs-STS6CCIN.js"),
  "./commands/build.ts": () => import("./build-R53AIRYP.js"),
  "./commands/cache.ts": () => import("./cache-ONE6FR54.js"),
  "./commands/ci.ts": () => import("./ci-ZN23NAON.js"),
  "./commands/config.ts": () => import("./config-HQVCCM7J.js"),
  "./commands/create.ts": () => import("./create-Y7XHTBQ4.js"),
  "./commands/docs.ts": () => import("./docs-MAEJNV2V.js"),
  "./commands/exec-cache.ts": () => import("./exec-cache-DIBLJ7G2.js"),
  "./commands/exec-local.ts": () => import("./exec-local-7Q3DIAH5.js"),
  "./commands/exec.ts": () => import("./exec-DVXYT2NZ.js"),
  "./commands/help.ts": () => import("./help-3IAO7UUF.js"),
  "./commands/init.ts": () => import("./init-32T4YJZ5.js"),
  "./commands/install.ts": () => import("./install-CP6762EI.js"),
  "./commands/install/reporter.ts": () => import("./reporter-2NY7CSTJ.js"),
  "./commands/list.ts": () => import("./list-QB4LJA5M.js"),
  "./commands/login.ts": () => import("./login-P5LKRXRG.js"),
  "./commands/logout.ts": () => import("./logout-ROCRV5M4.js"),
  "./commands/pack.ts": () => import("./pack-VWJRERWU.js"),
  "./commands/ping.ts": () => import("./ping-ZVVAVJEV.js"),
  "./commands/pkg.ts": () => import("./pkg-IFZZ2YCJ.js"),
  "./commands/publish.ts": () => import("./publish-SUBFSPAT.js"),
  "./commands/query.ts": () => import("./query-SHN4XGVH.js"),
  "./commands/repo.ts": () => import("./repo-USSZAQAK.js"),
  "./commands/run-exec.ts": () => import("./run-exec-57NOY4JH.js"),
  "./commands/run.ts": () => import("./run-J654XULS.js"),
  "./commands/token.ts": () => import("./token-NLAQTRSA.js"),
  "./commands/uninstall.ts": () => import("./uninstall-WLKETZ53.js"),
  "./commands/update.ts": () => import("./update-25PY5I26.js"),
  "./commands/version.ts": () => import("./version-QK3C2L7K.js"),
  "./commands/view.ts": () => import("./view-ADABXK3B.js"),
  "./commands/whoami.ts": () => import("./whoami-2U5TWOPM.js")
});

// ../../src/cli-sdk/src/load-command.ts
var loadCommand = async (command) => {
  try {
    return await globImport_commands_ts(`./commands/${command}.ts`);
  } catch (e) {
    throw error("Could not load command", {
      found: command,
      cause: e
    });
  }
};

export {
  loadCommand
};
