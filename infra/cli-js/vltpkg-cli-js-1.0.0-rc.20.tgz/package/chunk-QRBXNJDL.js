var global = globalThis;
import {Buffer} from "node:buffer";
import {setTimeout as _vlt_setTimeout,clearTimeout as _vlt_clearTimeout,setImmediate as _vlt_setImmediate,clearImmediate as _vlt_clearImmediate,setInterval as _vlt_setInterval,clearInterval as _vlt_clearInterval} from "node:timers";
globalThis.setTimeout = _vlt_setTimeout;
globalThis.clearTimeout = _vlt_clearTimeout;
globalThis.setImmediate = _vlt_setImmediate;
globalThis.clearImmediate = _vlt_clearImmediate;
globalThis.setInterval = _vlt_setInterval;
globalThis.clearInterval = _vlt_clearInterval;
import {createRequire as _vlt_createRequire} from "node:module";
var require = _vlt_createRequire(import.meta.filename);
import {
  init
} from "./chunk-VVTZN4QQ.js";
import {
  commandUsage
} from "./chunk-5E5GX4G6.js";
import {
  asWSConfig,
  assertWSConfig,
  minimatch
} from "./chunk-Z76BQOEV.js";
import {
  load,
  save
} from "./chunk-HTOTG4TS.js";

// ../../src/cli-sdk/src/commands/init.ts
import { mkdirSync } from "node:fs";
import { relative, resolve } from "node:path";
var usage = () => commandUsage({
  command: "init",
  usage: "",
  description: `Create a new package.json file in the current directory.`,
  options: {
    workspace: {
      value: "<path|glob>",
      description: "Create package.json files in matching workspaces."
    }
  }
});
var views = {
  human: (results) => {
    const output = [];
    if (Array.isArray(results)) {
      for (const result of results) {
        for (const [type, { path }] of Object.entries(result)) {
          output.push(`Wrote ${type} to ${path}:`);
        }
      }
    } else {
      for (const [type, { path, data }] of Object.entries(results)) {
        output.push(`Wrote ${type} to ${path}:

${JSON.stringify(data, null, 2)}`);
      }
    }
    output.push(`
Modify/add properties using \`vlt pkg\`. For example:

  vlt pkg set "description=My new project"`);
    return output.join("\n");
  }
};
var command = async (conf) => {
  if (conf.values.workspace?.length) {
    const workspacesConfig = load("workspaces", assertWSConfig);
    const parsedWSConfig = asWSConfig(workspacesConfig ?? {});
    const results = [];
    const addToConfig = [];
    for (const workspace of conf.values.workspace) {
      const cwd = resolve(conf.options.projectRoot, workspace);
      mkdirSync(cwd, { recursive: true });
      results.push(await init({ cwd }));
      const isMatched = Object.values(parsedWSConfig).some(
        (patterns) => {
          return patterns.some(
            (pattern) => minimatch(workspace, pattern)
          );
        }
      );
      if (!isMatched) {
        addToConfig.push(
          relative(conf.options.projectRoot, cwd).replace(/\\/g, "/")
        );
      }
    }
    if (addToConfig.length > 0) {
      let workspaces = workspacesConfig;
      if (typeof workspacesConfig === "string") {
        workspaces = [workspacesConfig, ...addToConfig];
      } else if (Array.isArray(workspacesConfig)) {
        workspaces = [...workspacesConfig, ...addToConfig];
      } else {
        workspaces = workspacesConfig ?? {};
        if (!workspaces.packages) {
          workspaces.packages = addToConfig;
        } else {
          if (typeof workspaces.packages === "string") {
            workspaces.packages = [
              workspaces.packages,
              ...addToConfig
            ];
          } else {
            workspaces.packages = [
              ...workspaces.packages,
              ...addToConfig
            ];
          }
        }
      }
      save("workspaces", workspaces);
    }
    return results;
  }
  return init({ cwd: process.cwd() });
};

export {
  usage,
  views,
  command
};
