var global = globalThis;
import {Buffer} from "node:buffer";
import {setTimeout as _vlt_setTimeout,clearTimeout as _vlt_clearTimeout,setImmediate as _vlt_setImmediate,clearImmediate as _vlt_clearImmediate,setInterval as _vlt_setInterval,clearInterval as _vlt_clearInterval} from "node:timers";
globalThis.setTimeout = _vlt_setTimeout;
globalThis.clearTimeout = _vlt_clearTimeout;
globalThis.setImmediate = _vlt_setImmediate;
globalThis.clearImmediate = _vlt_clearImmediate;
globalThis.setInterval = _vlt_setInterval;
globalThis.clearInterval = _vlt_clearInterval;
import {createRequire as _vlt_createRequire} from "node:module";
var require = _vlt_createRequire(import.meta.filename);
import {
  PackageJson,
  getUser
} from "./chunk-Z76BQOEV.js";
import {
  asError,
  normalizeManifest
} from "./chunk-KXBF4HVG.js";

// ../../src/init/src/index.ts
import { basename, resolve } from "node:path";

// ../../src/init/src/get-author-from-git-user.ts
var getAuthorFromGitUser = (user) => {
  if (!user) return "";
  const { name, email } = user;
  let res = "";
  if (name) res += name;
  if (email) {
    if (name) res += " ";
    res += `<${email}>`;
  }
  return res;
};

// ../../src/init/src/index.ts
var stderr = console.error;
var template = ({ name, author }) => normalizeManifest({
  name,
  version: "1.0.0",
  description: "",
  main: "index.js",
  ...author ? { author } : void 0
});
var init = async ({
  cwd = process.cwd(),
  author,
  logger = stderr
} = {}) => {
  const packageJson = new PackageJson();
  const path = resolve(cwd, "package.json");
  let existingData;
  try {
    existingData = packageJson.read(cwd);
    logger("package.json already exists");
  } catch (err) {
    if (asError(err).message !== "Could not read package.json file") {
      throw err;
    }
  }
  const name = basename(cwd);
  const templateData = template({
    name,
    author: author ?? getAuthorFromGitUser(await getUser().catch(() => void 0))
  });
  const data = existingData ? { ...templateData, ...existingData } : templateData;
  const indent = 2;
  packageJson.write(cwd, data, indent);
  return { manifest: { path, data } };
};

export {
  init
};
