var global = globalThis;
import {Buffer} from "node:buffer";
import {setTimeout as _vlt_setTimeout,clearTimeout as _vlt_clearTimeout,setImmediate as _vlt_setImmediate,clearImmediate as _vlt_clearImmediate,setInterval as _vlt_setInterval,clearInterval as _vlt_clearInterval} from "node:timers";
globalThis.setTimeout = _vlt_setTimeout;
globalThis.clearTimeout = _vlt_clearTimeout;
globalThis.setImmediate = _vlt_setImmediate;
globalThis.clearImmediate = _vlt_clearImmediate;
globalThis.setInterval = _vlt_setInterval;
globalThis.clearInterval = _vlt_clearInterval;
import {createRequire as _vlt_createRequire} from "node:module";
var require = _vlt_createRequire(import.meta.filename);
import {
  InstallReporter
} from "./chunk-FPRLLVBW.js";
import "./chunk-VTEFO2FT.js";
import "./chunk-RXNA2XCX.js";
import "./chunk-WGDTG44V.js";
import {
  install
} from "./chunk-EHD7YJKI.js";
import "./chunk-K4X2TU3S.js";
import "./chunk-VVTZN4QQ.js";
import {
  commandUsage
} from "./chunk-5E5GX4G6.js";
import "./chunk-Z76BQOEV.js";
import "./chunk-BGQCUUCA.js";
import "./chunk-E74WGW5C.js";
import "./chunk-FEV5BCW7.js";
import "./chunk-VCSVHRCS.js";
import "./chunk-D27QPHKI.js";
import "./chunk-JLJKOF75.js";
import "./chunk-KXBF4HVG.js";
import "./chunk-HTOTG4TS.js";
import "./chunk-XNLSTHDK.js";
import "./chunk-WZWDS3W4.js";
import "./chunk-PZLD7RTK.js";

// ../../src/cli-sdk/src/commands/ci.ts
var usage = () => commandUsage({
  command: "ci",
  usage: "",
  description: `Clean install from lockfile. Deletes node_modules and installs 
                  dependencies exactly as specified in vlt-lock.json. This is 
                  similar to running 'vlt install --expect-lockfile' but performs 
                  a clean install by removing node_modules first.`,
  examples: {
    "": { description: "Clean install from lockfile" }
  },
  options: {
    "allow-scripts": {
      value: "<query>",
      description: "Filter which packages are allowed to run lifecycle scripts using DSS query syntax."
    },
    "lockfile-only": {
      description: "Only update lockfile and package.json files; skip node_modules operations."
    }
  }
});
var views = {
  json: (i) => i.graph.toJSON(),
  human: InstallReporter
};
var command = async (conf) => {
  const ciOptions = {
    ...conf.options,
    // allow all scripts by default on ci (unless user specifies a filter)
    allowScripts: conf.get("allow-scripts") ?? "*",
    expectLockfile: true,
    frozenLockfile: true,
    cleanInstall: true,
    lockfileOnly: conf.options["lockfile-only"]
  };
  const { graph } = await install(ciOptions);
  return { graph };
};
export {
  command,
  usage,
  views
};
