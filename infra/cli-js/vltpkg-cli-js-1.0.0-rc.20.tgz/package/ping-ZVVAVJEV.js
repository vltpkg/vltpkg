var global = globalThis;
import {Buffer} from "node:buffer";
import {setTimeout as _vlt_setTimeout,clearTimeout as _vlt_clearTimeout,setImmediate as _vlt_setImmediate,clearImmediate as _vlt_clearImmediate,setInterval as _vlt_setInterval,clearInterval as _vlt_clearInterval} from "node:timers";
globalThis.setTimeout = _vlt_setTimeout;
globalThis.clearTimeout = _vlt_clearTimeout;
globalThis.setImmediate = _vlt_setImmediate;
globalThis.clearImmediate = _vlt_clearImmediate;
globalThis.setInterval = _vlt_setInterval;
globalThis.clearInterval = _vlt_clearInterval;
import {createRequire as _vlt_createRequire} from "node:module";
var require = _vlt_createRequire(import.meta.filename);
import {
  commandUsage
} from "./chunk-5E5GX4G6.js";
import {
  RegistryClient
} from "./chunk-KRZRGALT.js";
import "./chunk-D7U7KDEM.js";
import "./chunk-BGQCUUCA.js";
import "./chunk-E74WGW5C.js";
import "./chunk-VCSVHRCS.js";
import "./chunk-D27QPHKI.js";
import "./chunk-JLJKOF75.js";
import "./chunk-KXBF4HVG.js";
import "./chunk-XNLSTHDK.js";
import {
  error
} from "./chunk-WZWDS3W4.js";
import "./chunk-PZLD7RTK.js";

// ../../src/cli-sdk/src/commands/ping.ts
var usage = () => commandUsage({
  command: "ping",
  usage: ["", "[<registry-alias>]"],
  description: `Ping configured registries to verify connectivity
                  and check registry health.

                  By default, pings all configured registries including
                  the default registry.

                  If a registry alias is provided, ping only that specific
                  registry. Registry aliases are configured via the
                  \`registries\` field in vlt.json or with the
                  \`--registries\` option.`,
  options: {
    registry: {
      value: "<url>",
      description: "The default registry URL to ping."
    },
    registries: {
      value: "<alias=url>",
      description: "Named registry aliases to ping."
    }
  }
});
var formatPingResult = (r) => {
  const prefix = r.alias ? `${r.alias} (${r.registry})` : r.registry;
  if (r.status === "ok") {
    return `Ping successful: ${prefix} (${r.time}ms)`;
  } else {
    return `Ping failed: ${prefix} - ${r.error}`;
  }
};
var views = {
  human: (r) => {
    if (Array.isArray(r)) {
      return r.map(formatPingResult).join("\n");
    }
    return formatPingResult(r);
  },
  json: (r) => r
};
var pingRegistry = async (rc, registry, alias) => {
  const url = new URL("-/ping?write=true", registry);
  const start = Date.now();
  try {
    const response = await rc.request(url, { useCache: false });
    const time = Date.now() - start;
    if (response.statusCode >= 200 && response.statusCode < 300) {
      return {
        registry,
        alias,
        status: "ok",
        time,
        statusCode: response.statusCode
      };
    } else {
      return {
        registry,
        alias,
        status: "error",
        time,
        statusCode: response.statusCode,
        error: `Registry returned status ${response.statusCode}`
      };
    }
  } catch (err) {
    const time = Date.now() - start;
    return {
      registry,
      alias,
      status: "error",
      time,
      error: err instanceof Error ? err.message : String(err)
    };
  }
};
var command = async (conf) => {
  const rc = new RegistryClient(conf.options);
  const registryAlias = conf.positionals[0];
  if (registryAlias) {
    const registries = conf.options.registries;
    const registry = registries[registryAlias];
    if (!registry) {
      const availableAliases = Object.keys(registries);
      throw error("Unknown registry alias", {
        found: registryAlias,
        wanted: availableAliases.length > 0 ? availableAliases : void 0
      });
    }
    return await pingRegistry(rc, registry, registryAlias);
  } else {
    const registries = conf.options.registries;
    const results = [];
    results.push(
      await pingRegistry(rc, conf.options.registry, "default")
    );
    for (const [alias, registry] of Object.entries(registries)) {
      if (registry !== conf.options.registry) {
        results.push(await pingRegistry(rc, registry, alias));
      }
    }
    return results;
  }
};
export {
  command,
  usage,
  views
};
