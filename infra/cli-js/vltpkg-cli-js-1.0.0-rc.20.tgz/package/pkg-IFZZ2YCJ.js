var global = globalThis;
import {Buffer} from "node:buffer";
import {setTimeout as _vlt_setTimeout,clearTimeout as _vlt_clearTimeout,setImmediate as _vlt_setImmediate,clearImmediate as _vlt_clearImmediate,setInterval as _vlt_setInterval,clearInterval as _vlt_clearInterval} from "node:timers";
globalThis.setTimeout = _vlt_setTimeout;
globalThis.clearTimeout = _vlt_clearTimeout;
globalThis.setImmediate = _vlt_setImmediate;
globalThis.clearImmediate = _vlt_clearImmediate;
globalThis.setInterval = _vlt_setInterval;
globalThis.clearInterval = _vlt_clearInterval;
import {createRequire as _vlt_createRequire} from "node:module";
var require = _vlt_createRequire(import.meta.filename);
import {
  views
} from "./chunk-QRBXNJDL.js";
import {
  del,
  get,
  set
} from "./chunk-DBANBIL2.js";
import {
  createHostContextsMap
} from "./chunk-IWQKSXJL.js";
import {
  GraphModifier,
  Query,
  VIRTUAL_ROOT_ID,
  actual
} from "./chunk-EHD7YJKI.js";
import {
  SecurityArchive
} from "./chunk-K4X2TU3S.js";
import {
  init
} from "./chunk-VVTZN4QQ.js";
import {
  commandUsage
} from "./chunk-5E5GX4G6.js";
import {
  minimatch
} from "./chunk-Z76BQOEV.js";
import "./chunk-BGQCUUCA.js";
import "./chunk-E74WGW5C.js";
import "./chunk-FEV5BCW7.js";
import "./chunk-VCSVHRCS.js";
import "./chunk-D27QPHKI.js";
import "./chunk-JLJKOF75.js";
import "./chunk-KXBF4HVG.js";
import "./chunk-HTOTG4TS.js";
import "./chunk-XNLSTHDK.js";
import {
  error
} from "./chunk-WZWDS3W4.js";
import "./chunk-PZLD7RTK.js";

// ../../src/cli-sdk/src/commands/pkg.ts
import assert from "node:assert";
import { resolve } from "node:path";
var views2 = {
  human: (results, _, config) => {
    if (config.positionals[0] === "init") {
      return views.human(results);
    }
    if (Array.isArray(results) && typeof results[0] === "string") {
      return results.join("\n");
    }
    return JSON.stringify(results, null, 2);
  }
};
var usage = () => commandUsage({
  command: "pkg",
  usage: "[<command>] [<args>]",
  description: "Get or manipulate package.json values",
  subcommands: {
    get: {
      usage: "[<key>]",
      description: "Get a single value"
    },
    init: {
      usage: "",
      description: "Initialize a new package.json file in the current directory"
    },
    pick: {
      usage: "[<key> [<key> ...]]",
      description: "Get multiple values or the entire package"
    },
    set: {
      usage: "<key>=<value> [<key>=<value> ...]",
      description: "Set one or more key value pairs"
    },
    delete: {
      usage: "<key> [<key> ...]",
      description: "Delete one or more keys from the package"
    }
  },
  examples: {
    'set "array[1].key=value"': {
      description: "Set a value on an object inside an array"
    },
    'set "array[]=value"': {
      description: "Append a value to an array"
    }
  },
  options: {
    scope: {
      value: "<query>",
      description: "Filter package.json targets using a DSS query."
    },
    workspace: {
      value: "<path|glob>",
      description: "Limit package.json targets to matching workspaces."
    },
    "workspace-group": {
      value: "<name>",
      description: "Limit package.json targets to workspace groups."
    },
    recursive: {
      description: "Operate across all workspaces in the current monorepo."
    }
  }
});
var command = async (conf) => {
  const [sub, ...args] = conf.positionals;
  if (sub === "init") {
    return await init({ cwd: process.cwd() });
  }
  assert(
    sub,
    error("pkg command requires a subcommand", {
      code: "EUSAGE",
      validOptions: ["get", "pick", "set", "rm", "init"]
    })
  );
  const { options, projectRoot } = conf;
  const queryString = conf.get("scope");
  const paths = conf.get("workspace");
  const groups = conf.get("workspace-group");
  const recursive = conf.get("recursive");
  const locations = [];
  let single = null;
  if (queryString) {
    const modifiers = GraphModifier.maybeLoad(options);
    const mainManifest = options.packageJson.maybeRead(projectRoot);
    let graph;
    let securityArchive;
    if (mainManifest) {
      graph = actual.load({
        ...options,
        mainManifest,
        modifiers,
        monorepo: options.monorepo,
        loadManifests: false
      });
      securityArchive = Query.hasSecuritySelectors(queryString) ? await SecurityArchive.start({
        nodes: [...graph.nodes.values()]
      }) : void 0;
    }
    const hostContexts = await createHostContextsMap(conf);
    const edges = graph?.edges ?? /* @__PURE__ */ new Set();
    const nodes = graph?.nodes ? new Set(graph.nodes.values()) : (
      /* c8 ignore next */
      /* @__PURE__ */ new Set()
    );
    const importers = graph?.importers ?? /* @__PURE__ */ new Set();
    const query = new Query({
      edges,
      nodes,
      importers,
      securityArchive,
      hostContexts
    });
    const { nodes: resultNodes } = await query.search(queryString, {
      signal: new AbortController().signal
    });
    for (const node of resultNodes) {
      const location = node.location;
      assert(
        location,
        error(`node ${node.id} has no location`, {
          found: node
        })
      );
      if (node.id !== VIRTUAL_ROOT_ID) {
        locations.push(resolve(node.projectRoot, location));
      }
    }
  } else if (paths?.length || groups?.length || recursive) {
    for (const workspace of options.monorepo ?? []) {
      if (paths?.length) {
        const matches = paths.some(
          (p) => workspace.path === p || workspace.name === p || workspace.fullpath === p || resolve(projectRoot, p) === workspace.fullpath || minimatch(workspace.path, p)
        );
        if (!matches) continue;
      }
      locations.push(workspace.fullpath);
    }
  } else {
    single = options.packageJson.find(process.cwd()) ?? projectRoot;
  }
  if (single) {
    return commandSingle(single, sub, args, conf);
  }
  assert(
    locations.length > 0,
    error("No matching package found using scope", {
      found: queryString || "workspace selection"
    })
  );
  const results = [];
  for (const location of locations) {
    results.push(await commandSingle(location, sub, args, conf));
  }
  return results;
};
var commandSingle = async (location, sub, args, conf) => {
  const pkg = conf.options.packageJson;
  const manifest = pkg.read(location);
  switch (sub) {
    case "get":
      return get2(manifest, args);
    case "pick":
      return pick(manifest, args);
    case "set":
      return set2(manifest, location, pkg, args);
    case "rm":
    case "remove":
    case "unset":
    case "delete":
      return rm(manifest, location, pkg, args);
    default: {
      throw error("Unrecognized pkg command", {
        code: "EUSAGE",
        found: sub,
        validOptions: ["get", "set", "rm"]
      });
    }
  }
};
var get2 = (manifest, args) => {
  const noArg = () => error(
    "get requires not more than 1 argument. use `pick` to get more than 1.",
    { code: "EUSAGE" },
    noArg
  );
  if (args.length === 1) {
    const [key] = args;
    assert(key, noArg());
    return get(manifest, key);
  }
  assert(args.length === 0, noArg());
  return pick(manifest, args);
};
var pick = (manifest, args) => {
  return args.length ? args.reduce(
    (acc, key) => set(acc, key, get(manifest, key)),
    {}
  ) : manifest;
};
var set2 = (manifest, location, pkg, args) => {
  assert(
    args.length >= 1,
    error("set requires arguments", { code: "EUSAGE" })
  );
  const res = args.reduce((acc, p) => {
    const index = p.indexOf("=");
    assert(
      index !== -1,
      error("set arguments must contain `=`", {
        code: "EUSAGE"
      })
    );
    return set(
      acc,
      p.substring(0, index),
      p.substring(index + 1)
    );
  }, manifest);
  pkg.write(location, res);
};
var rm = (manifest, location, pkg, args) => {
  assert(
    args.length >= 1,
    error("rm requires arguments", { code: "EUSAGE" })
  );
  const res = args.reduce((acc, key) => {
    del(acc, key);
    return acc;
  }, manifest);
  pkg.write(location, res);
  return {
    manifest: res,
    location
  };
};
export {
  command,
  usage,
  views2 as views
};
