var global = globalThis;
import {Buffer} from "node:buffer";
import {setTimeout as _vlt_setTimeout,clearTimeout as _vlt_clearTimeout,setImmediate as _vlt_setImmediate,clearImmediate as _vlt_clearImmediate,setInterval as _vlt_setInterval,clearInterval as _vlt_clearInterval} from "node:timers";
globalThis.setTimeout = _vlt_setTimeout;
globalThis.clearTimeout = _vlt_clearTimeout;
globalThis.setImmediate = _vlt_setImmediate;
globalThis.clearImmediate = _vlt_clearImmediate;
globalThis.setInterval = _vlt_setInterval;
globalThis.clearInterval = _vlt_clearInterval;
import {createRequire as _vlt_createRequire} from "node:module";
var require = _vlt_createRequire(import.meta.filename);
import {
  require_lib
} from "./chunk-AZLX27EM.js";
import {
  createHostContextsMap
} from "./chunk-IWQKSXJL.js";
import {
  Query,
  actual
} from "./chunk-EHD7YJKI.js";
import {
  SecurityArchive
} from "./chunk-K4X2TU3S.js";
import "./chunk-VVTZN4QQ.js";
import {
  commandUsage
} from "./chunk-5E5GX4G6.js";
import {
  PackageInfoClient
} from "./chunk-EXOVNNE6.js";
import "./chunk-FI5TUER7.js";
import "./chunk-KRZRGALT.js";
import {
  urlOpen
} from "./chunk-D7U7KDEM.js";
import "./chunk-Z76BQOEV.js";
import "./chunk-BGQCUUCA.js";
import "./chunk-E74WGW5C.js";
import {
  Spec2 as Spec
} from "./chunk-FEV5BCW7.js";
import "./chunk-VCSVHRCS.js";
import "./chunk-D27QPHKI.js";
import "./chunk-JLJKOF75.js";
import "./chunk-KXBF4HVG.js";
import "./chunk-HTOTG4TS.js";
import "./chunk-XNLSTHDK.js";
import {
  error
} from "./chunk-WZWDS3W4.js";
import {
  __toESM
} from "./chunk-PZLD7RTK.js";

// ../../src/cli-sdk/src/commands/repo.ts
var import_hosted_git_info = __toESM(require_lib(), 1);
var { fromUrl: hostedGitInfoFromUrl } = import_hosted_git_info.default;
var usage = () => commandUsage({
  command: "repo",
  usage: ["[<spec>]", "[--target=<query>]"],
  description: `Open repository page for a package in a web browser.
                  Reads repository information from package.json or fetches
                  manifest data for the specified package.`,
  options: {
    target: {
      value: "<query>",
      description: "Query selector to filter packages using DSS syntax."
    }
  },
  examples: {
    "": {
      description: "Open repo for the current package (reads local package.json)"
    },
    "abbrev@2.0.0": {
      description: "Open repo for a specific package version"
    },
    '--target=":root > *"': {
      description: "List repository URLs for all direct dependencies"
    }
  }
});
var views = {
  human: (r) => {
    if (Array.isArray(r)) {
      let msg = "Multiple package repositories found:\n";
      msg += r.map((item) => `\u2022 ${item.name}: ${item.url}`).join("\n");
      return msg;
    }
    return "";
  },
  json: (r) => r
};
var getUrlFromManifest = (manifest) => {
  const { name, repository, homepage } = manifest;
  if (!name) {
    throw error("No package name found");
  }
  let url;
  if (repository) {
    const repoUrl = typeof repository === "string" ? repository : typeof repository === "object" && "url" in repository ? repository.url : (
      /* c8 ignore next */
      void 0
    );
    if (repoUrl) {
      const info = hostedGitInfoFromUrl(repoUrl.replace(/^git\+/, ""));
      if (info?.browse && typeof info.browse === "function") {
        url = info.browse();
      } else {
        url = repoUrl.replace(/^git\+/, "");
      }
    }
  }
  if (!url && homepage) {
    url = homepage;
  }
  if (!url) {
    url = `https://vlt.io/explore/npm/${name}/overview`;
  }
  return url;
};
var command = async (conf) => {
  const { projectRoot, packageJson } = conf.options;
  const targetOption = conf.get("target");
  if (targetOption) {
    const mainManifest = packageJson.maybeRead(projectRoot);
    if (!mainManifest) {
      throw error("No package.json found in project root", {
        path: projectRoot
      });
    }
    const graph = actual.load({
      ...conf.options,
      mainManifest,
      monorepo: conf.options.monorepo,
      loadManifests: true
    });
    const securityArchive = Query.hasSecuritySelectors(targetOption) ? await SecurityArchive.start({
      nodes: [...graph.nodes.values()]
    }) : void 0;
    const hostContexts = await createHostContextsMap(conf);
    const query = new Query({
      nodes: new Set(graph.nodes.values()),
      edges: graph.edges,
      importers: graph.importers,
      securityArchive,
      hostContexts
    });
    const { nodes } = await query.search(targetOption, {
      signal: new AbortController().signal
    });
    const results = [];
    for (const node of nodes) {
      if (!node.manifest) continue;
      const url2 = getUrlFromManifest(node.manifest);
      results.push({
        url: url2,
        name: node.name ?? "(unknown)"
      });
    }
    if (results.length === 0) {
      throw error("No packages found matching target query", {
        found: targetOption
      });
    }
    if (results.length === 1) {
      const result = results[0];
      if (!result) {
        throw error("Unexpected empty result");
      }
      await urlOpen(result.url);
      return result;
    }
    return results;
  }
  const specArg = conf.positionals[0];
  const manifest = conf.positionals.length === 0 ? packageJson.read(projectRoot) : specArg ? await new PackageInfoClient(conf.options).manifest(
    Spec.parseArgs(specArg, conf.options)
  ) : (
    /* c8 ignore next */
    packageJson.read(projectRoot)
  );
  const url = getUrlFromManifest(manifest);
  const { name } = manifest;
  if (!name) {
    throw error("No package name found");
  }
  await urlOpen(url);
  return { url, name };
};
export {
  command,
  usage,
  views
};
