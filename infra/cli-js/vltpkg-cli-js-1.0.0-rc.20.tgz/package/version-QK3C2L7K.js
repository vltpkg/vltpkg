var global = globalThis;
import {Buffer} from "node:buffer";
import {setTimeout as _vlt_setTimeout,clearTimeout as _vlt_clearTimeout,setImmediate as _vlt_setImmediate,clearImmediate as _vlt_clearImmediate,setInterval as _vlt_setInterval,clearInterval as _vlt_clearInterval} from "node:timers";
globalThis.setTimeout = _vlt_setTimeout;
globalThis.clearTimeout = _vlt_clearTimeout;
globalThis.setImmediate = _vlt_setImmediate;
globalThis.clearImmediate = _vlt_clearImmediate;
globalThis.setInterval = _vlt_setInterval;
globalThis.clearInterval = _vlt_clearInterval;
import {createRequire as _vlt_createRequire} from "node:module";
var require = _vlt_createRequire(import.meta.filename);
import {
  createHostContextsMap
} from "./chunk-IWQKSXJL.js";
import {
  Query,
  actual
} from "./chunk-EHD7YJKI.js";
import "./chunk-K4X2TU3S.js";
import "./chunk-VVTZN4QQ.js";
import {
  commandUsage
} from "./chunk-5E5GX4G6.js";
import {
  is,
  isClean,
  minimatch,
  spawn
} from "./chunk-Z76BQOEV.js";
import "./chunk-BGQCUUCA.js";
import "./chunk-E74WGW5C.js";
import "./chunk-FEV5BCW7.js";
import "./chunk-VCSVHRCS.js";
import "./chunk-D27QPHKI.js";
import "./chunk-JLJKOF75.js";
import {
  asError,
  inc,
  parse,
  versionIncrements
} from "./chunk-KXBF4HVG.js";
import "./chunk-HTOTG4TS.js";
import "./chunk-XNLSTHDK.js";
import {
  error
} from "./chunk-WZWDS3W4.js";
import "./chunk-PZLD7RTK.js";

// ../../src/cli-sdk/src/commands/version.ts
import { dirname, resolve } from "node:path";
import assert from "node:assert";
var isValidVersionIncrement = (value) => versionIncrements.includes(value);
var version = async (conf, increment, cwd, {
  // Hardcode happy path options for now.
  // TODO: make these config definitions
  prereleaseId = "pre",
  commit = true,
  tag = true,
  message = "v%s",
  tagMessage = "v%s",
  includeNameInCommit = false,
  includeNameInTag = false
} = {}) => {
  assert(
    increment,
    error("Version increment argument is required", {
      code: "EUSAGE",
      validOptions: versionIncrements
    })
  );
  const manifestPath = conf.options.packageJson.find(cwd);
  assert(
    manifestPath,
    error("No package.json found", {
      code: "ENOENT",
      path: cwd
    })
  );
  const spawn2 = (args, opts) => spawn(args, { cwd: manifestDir, ...opts });
  const manifestDir = dirname(manifestPath);
  const manifest = conf.options.packageJson.read(manifestDir);
  assert(
    manifest.name,
    error("No name field found in package.json", {
      path: manifestPath
    })
  );
  assert(
    manifest.version,
    error("No version field found in package.json", {
      path: manifestPath
    })
  );
  const oldVersion = manifest.version;
  let newVersion;
  const parsedIncrement = parse(increment);
  if (parsedIncrement) {
    newVersion = parsedIncrement.toString();
  } else if (isValidVersionIncrement(increment)) {
    const incrementType = increment;
    try {
      const result2 = inc(oldVersion, incrementType, prereleaseId);
      newVersion = result2.toString();
    } catch (err) {
      throw error(
        `Failed to increment version from ${oldVersion} with ${increment}`,
        { version: oldVersion, wanted: increment, cause: err }
      );
    }
  } else {
    throw error(
      `Invalid version increment: ${increment}. Must be a valid semver version or one of: major, minor, patch, premajor, preminor, prepatch, prerelease`,
      {
        found: increment,
        validOptions: versionIncrements
      }
    );
  }
  manifest.version = newVersion;
  conf.options.packageJson.write(manifestDir, manifest);
  const result = {
    name: manifest.name,
    oldVersion,
    newVersion,
    dir: manifestDir
  };
  if (
    /* c8 ignore next -- commit and tag are always true for now */
    (commit || tag) && await is({ cwd: conf.options.projectRoot })
  ) {
    if (!await isClean({ cwd: conf.options.projectRoot })) {
      try {
        const gitResult = await spawn2([
          "diff",
          "--name-only",
          "HEAD",
          "--",
          "."
        ]);
        const changedFiles = gitResult.stdout.trim().split("\n").filter(Boolean).map((f) => resolve(conf.options.projectRoot, f));
        const nonPackageJsonChanges = changedFiles.filter(
          (file) => file !== resolve(manifestDir, "package.json")
        );
        assert(
          nonPackageJsonChanges.length === 0,
          error(
            "Git working directory not clean. Please commit or stash your changes first.",
            { found: nonPackageJsonChanges }
          )
        );
      } catch (err) {
        throw error(
          "Git working directory not clean. Please commit or stash your changes first.",
          asError(err)
        );
      }
    }
    if (commit) {
      try {
        const files = ["package.json"];
        await spawn2(["add", ...files]);
        await spawn2([
          "commit",
          "-m",
          `${includeNameInCommit ? `${manifest.name}: ` : ""}${message.replace(
            "%s",
            newVersion
          )}`
        ]);
        result.committed = files.map((f) => resolve(manifestDir, f));
      } catch (err) {
        throw error("Failed to commit version changes", {
          version: newVersion,
          cause: err
        });
      }
    }
    if (tag) {
      try {
        const tagName = (includeNameInTag ? `${manifest.name.replace("/", "-").replace("@", "")}-` : "") + `v${newVersion}`;
        await spawn2([
          "tag",
          tagName,
          "-m",
          (includeNameInTag ? `${manifest.name}: ` : "") + tagMessage.replace("%s", newVersion)
        ]);
        result.tag = tagName;
      } catch (err) {
        throw error("Failed to create git tag", {
          version: newVersion,
          cause: err
        });
      }
    }
  }
  return result;
};
var usage = () => {
  return commandUsage({
    command: "version",
    usage: "[<newversion> | major | minor | patch | premajor | preminor | prepatch | prerelease]",
    description: `Bump a package's version.

    Run in a package directory to bump the version and write the new data back to package.json.

    The \`<newversion>\` argument should be a valid semver string or a valid increment type (one of patch, minor, major, prepatch, preminor, premajor, prerelease).

    If run in a git repository, it will also create a version commit and tag.`,
    options: {
      scope: {
        value: "<query>",
        description: "Filter version bump targets using a DSS query."
      },
      workspace: {
        value: "<path|glob>",
        description: "Limit version bump targets to matching workspaces."
      },
      "workspace-group": {
        value: "<name>",
        description: "Limit version bump targets to workspace groups."
      },
      recursive: {
        description: "Run version bump across all workspaces in the monorepo."
      }
    }
  });
};
var views = {
  json: (result) => result,
  human: (results) => {
    const item = (result) => {
      let output = `${result.name}: v${result.newVersion}`;
      if (result.committed) {
        output += ` +commit`;
      }
      if (result.tag) {
        output += ` +tag`;
      }
      return output;
    };
    return Array.isArray(results) ? results.map(item).join("\n") : item(results);
  }
};
var command = async (conf) => {
  const { positionals, options, projectRoot } = conf;
  const queryString = conf.get("scope");
  const paths = conf.get("workspace");
  const groups = conf.get("workspace-group");
  const recursive = conf.get("recursive");
  const locations = [];
  if (queryString) {
    const mainManifest = options.packageJson.maybeRead(projectRoot);
    let graph;
    if (mainManifest) {
      graph = actual.load({
        ...options,
        mainManifest,
        monorepo: options.monorepo,
        loadManifests: false
      });
    }
    const hostContexts = await createHostContextsMap(conf);
    const query = new Query({
      /* c8 ignore next */
      nodes: graph ? new Set(graph.nodes.values()) : /* @__PURE__ */ new Set(),
      edges: graph?.edges ?? /* @__PURE__ */ new Set(),
      importers: graph?.importers ?? /* @__PURE__ */ new Set(),
      securityArchive: void 0,
      hostContexts
    });
    const { nodes } = await query.search(queryString, {
      signal: new AbortController().signal
    });
    for (const node of nodes) {
      const location = node.location;
      assert(
        location,
        error(`node ${node.id} has no location`, {
          found: node
        })
      );
      locations.push(resolve(node.projectRoot, location));
    }
  } else if (paths?.length || groups?.length || recursive) {
    for (const workspace of options.monorepo ?? []) {
      if (paths?.length) {
        const matches = paths.some(
          (p) => workspace.path === p || workspace.name === p || workspace.fullpath === p || resolve(projectRoot, p) === workspace.fullpath || minimatch(workspace.path, p)
        );
        if (!matches) continue;
      }
      locations.push(workspace.fullpath);
    }
  } else {
    const cwd = options.packageJson.find(process.cwd()) ?? projectRoot;
    return version(conf, positionals[0], cwd);
  }
  assert(
    locations.length > 0,
    error("No workspaces or query results found")
  );
  const results = [];
  for (const location of locations) {
    results.push(
      await version(conf, positionals[0], location, {
        includeNameInCommit: true,
        includeNameInTag: true
      })
    );
  }
  return results;
};
export {
  command,
  usage,
  views
};
