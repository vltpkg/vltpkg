var global = globalThis;
import {Buffer} from "node:buffer";
import {setTimeout as _vlt_setTimeout,clearTimeout as _vlt_clearTimeout,setImmediate as _vlt_setImmediate,clearImmediate as _vlt_clearImmediate,setInterval as _vlt_setInterval,clearInterval as _vlt_clearInterval} from "node:timers";
globalThis.setTimeout = _vlt_setTimeout;
globalThis.clearTimeout = _vlt_clearTimeout;
globalThis.setImmediate = _vlt_setImmediate;
globalThis.clearImmediate = _vlt_clearImmediate;
globalThis.setInterval = _vlt_setInterval;
globalThis.clearInterval = _vlt_clearInterval;
import {createRequire as _vlt_createRequire} from "node:module";
var require = _vlt_createRequire(import.meta.filename);
import {
  commandUsage
} from "./chunk-5E5GX4G6.js";
import {
  RegistryClient
} from "./chunk-KRZRGALT.js";
import "./chunk-D7U7KDEM.js";
import "./chunk-BGQCUUCA.js";
import "./chunk-E74WGW5C.js";
import "./chunk-VCSVHRCS.js";
import "./chunk-D27QPHKI.js";
import "./chunk-JLJKOF75.js";
import "./chunk-KXBF4HVG.js";
import "./chunk-XNLSTHDK.js";
import "./chunk-WZWDS3W4.js";
import "./chunk-PZLD7RTK.js";

// ../../src/cli-sdk/src/commands/whoami.ts
var usage = () => commandUsage({
  command: "whoami",
  usage: [""],
  description: `Look up the username for the currently active token,
                  when logged into a registry.`,
  options: {
    registry: {
      value: "<url>",
      description: "Registry URL to query for authenticated user info."
    },
    identity: {
      value: "<name>",
      description: "Identity namespace used to look up auth tokens."
    }
  }
});
var views = {
  human: (r) => r.username,
  json: (r) => r
};
var command = async (conf) => {
  const rc = new RegistryClient(conf.options);
  const response = await rc.request(
    new URL("-/whoami", conf.options.registry),
    { useCache: false }
  );
  const { username } = response.json();
  return { username };
};
export {
  command,
  usage,
  views
};
