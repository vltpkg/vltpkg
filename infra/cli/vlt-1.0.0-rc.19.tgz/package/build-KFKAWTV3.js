var global = globalThis;
import {Buffer} from "node:buffer";
import {setTimeout as _vlt_setTimeout,clearTimeout as _vlt_clearTimeout,setImmediate as _vlt_setImmediate,clearImmediate as _vlt_clearImmediate,setInterval as _vlt_setInterval,clearInterval as _vlt_clearInterval} from "node:timers";
globalThis.setTimeout = _vlt_setTimeout;
globalThis.clearTimeout = _vlt_clearTimeout;
globalThis.setImmediate = _vlt_setImmediate;
globalThis.clearImmediate = _vlt_clearImmediate;
globalThis.setInterval = _vlt_setInterval;
globalThis.clearInterval = _vlt_clearInterval;
import {createRequire as _vlt_createRequire} from "node:module";
var require = _vlt_createRequire(import.meta.filename);
import {
  build
} from "./chunk-3Y3TZ5SX.js";
import "./chunk-K4X2TU3S.js";
import "./chunk-EXVKZ662.js";
import {
  commandUsage
} from "./chunk-5E5GX4G6.js";
import "./chunk-2TOZR3L2.js";
import "./chunk-BGQCUUCA.js";
import "./chunk-E74WGW5C.js";
import "./chunk-FEV5BCW7.js";
import "./chunk-VCSVHRCS.js";
import "./chunk-D27QPHKI.js";
import "./chunk-JLJKOF75.js";
import {
  isErrorWithCause
} from "./chunk-KXBF4HVG.js";
import "./chunk-HTOTG4TS.js";
import "./chunk-XNLSTHDK.js";
import {
  error
} from "./chunk-WZWDS3W4.js";
import "./chunk-PZLD7RTK.js";

// ../../src/cli-sdk/src/commands/build.ts
var views = {
  human: (result) => {
    const successCount = result.success.length;
    const failureCount = result.failure.length;
    const messages = [];
    if (successCount > 0) {
      messages.push(
        `\u{1F528} Built ${successCount} package${successCount === 1 ? "" : "s"} successfully.`
      );
    } else {
      messages.push("\u{1F4E6} All packages are already built.");
    }
    if (failureCount > 0) {
      messages.push(
        `\u{1F50E} ${failureCount} optional package${/* c8 ignore next */
        failureCount === 1 ? "" : "s"} failed to build.`
      );
    }
    return messages.join("\n");
  },
  json: (result) => {
    const successList = result.success.map((node) => ({
      id: node.id,
      name: node.name,
      version: node.version
    }));
    const failureList = result.failure.map((node) => ({
      id: node.id,
      name: node.name,
      version: node.version
    }));
    return {
      success: successList,
      failure: failureList,
      message: successList.length > 0 ? `Built ${successList.length} package${successList.length === 1 ? "" : "s"}.` : "No packages needed building."
    };
  }
};
var usage = () => commandUsage({
  command: "build",
  usage: ["[query]", "[--target=<query>]"],
  description: `Build the project based on the current dependency graph.

    This command processes the installed packages in node_modules and runs
    any necessary build steps, such as lifecycle scripts and binary linking.
    
    The build process is idempotent and will only perform work that is
    actually needed based on the current state of the dependency graph.
    
    Use --target option or provide a query as a positional argument to filter
    packages using DSS query language syntax, otherwise it will target
    all packages with scripts (:scripts) by default.`,
  options: {
    target: {
      value: "<query>",
      description: "Query selector to filter packages using DSS syntax."
    }
  }
});
var isGraphRunError = (error2) => typeof error2 === "object" && error2 !== null && "code" in error2 && error2.code === "GRAPHRUN_TRAVERSAL" && "node" in error2;
var command = async (conf) => {
  const { options, projectRoot } = conf;
  try {
    const targetOption = conf.get("target");
    const targetPositional = conf.positionals[0];
    const target = targetOption || targetPositional || ":scripts:not(:built):not(:malware)";
    const result = await build({
      ...options,
      projectRoot,
      packageJson: options.packageJson,
      monorepo: options.monorepo,
      scurry: options.scurry,
      target
    });
    return result;
  } catch (cause) {
    const graphRunError = isErrorWithCause(cause) && isGraphRunError(cause.cause) ? cause.cause : void 0;
    if (graphRunError?.code === "GRAPHRUN_TRAVERSAL") {
      throw error(
        `Build failed:
  Failed to build package: ${graphRunError.node.name}@${graphRunError.node.version}`,
        { cause }
      );
    }
    throw error("Build failed", { cause });
  }
};
export {
  command,
  usage,
  views
};
