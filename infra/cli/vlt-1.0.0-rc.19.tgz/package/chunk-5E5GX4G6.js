var global = globalThis;
import {Buffer} from "node:buffer";
import {setTimeout as _vlt_setTimeout,clearTimeout as _vlt_clearTimeout,setImmediate as _vlt_setImmediate,clearImmediate as _vlt_clearImmediate,setInterval as _vlt_setInterval,clearInterval as _vlt_clearInterval} from "node:timers";
globalThis.setTimeout = _vlt_setTimeout;
globalThis.clearTimeout = _vlt_clearTimeout;
globalThis.setImmediate = _vlt_setImmediate;
globalThis.clearImmediate = _vlt_clearImmediate;
globalThis.setInterval = _vlt_setInterval;
globalThis.clearInterval = _vlt_clearInterval;
import {createRequire as _vlt_createRequire} from "node:module";
var require = _vlt_createRequire(import.meta.filename);
import {
  commandAliases,
  jack
} from "./chunk-D27QPHKI.js";

// ../../src/cli-sdk/src/config/usage.ts
var toArr = (v) => Array.isArray(v) ? v : [v];
var code = (v) => [v, { pre: true }];
var join = (args, joiner = " ") => args.filter(Boolean).join(joiner);
var commandUsage = ({
  command,
  usage,
  description,
  subcommands,
  examples,
  options
}) => {
  const vlt = (s) => join([`vlt`, command, s]);
  const joinUsage = (usages) => toArr(usages).map(vlt).filter(Boolean).join("\n");
  const j = jack({ usage: joinUsage(usage) }).description(description);
  const aliases = commandAliases.get(command);
  if (aliases) {
    j.heading("Aliases", 2).description(aliases.join(", "), {
      pre: true
    });
  }
  if (subcommands) {
    j.heading("Subcommands", 2);
    for (const [k, v] of Object.entries(subcommands)) {
      j.heading(k, 3).description(v.description).description(
        ...code(joinUsage(toArr(v.usage).map((u) => join([k, u]))))
      );
    }
  }
  if (examples) {
    j.heading("Examples", 2);
    for (const [k, v] of Object.entries(examples)) {
      j.description(v.description).description(...code(vlt(k)));
    }
  }
  if (options) {
    j.heading("Options", 2);
    for (const [k, v] of Object.entries(options)) {
      j.heading(k, 3).description(v.description).description(
        ...code(
          join(["--", k, v.value ? "=" : void 0, v.value], "")
        )
      );
    }
  }
  return j;
};

export {
  commandUsage
};
