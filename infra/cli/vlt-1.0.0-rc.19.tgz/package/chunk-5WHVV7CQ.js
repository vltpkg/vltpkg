var global = globalThis;
import {Buffer} from "node:buffer";
import {setTimeout as _vlt_setTimeout,clearTimeout as _vlt_clearTimeout,setImmediate as _vlt_setImmediate,clearImmediate as _vlt_clearImmediate,setInterval as _vlt_setInterval,clearInterval as _vlt_clearInterval} from "node:timers";
globalThis.setTimeout = _vlt_setTimeout;
globalThis.clearTimeout = _vlt_clearTimeout;
globalThis.setImmediate = _vlt_setImmediate;
globalThis.clearImmediate = _vlt_clearImmediate;
globalThis.setInterval = _vlt_setInterval;
globalThis.clearInterval = _vlt_clearInterval;
import {createRequire as _vlt_createRequire} from "node:module";
var require = _vlt_createRequire(import.meta.filename);
import {
  isError,
  isObject
} from "./chunk-KXBF4HVG.js";

// ../../src/output/src/error.ts
var parseError = (err) => {
  if (!isError(err)) {
    return null;
  }
  const enumerable = Object.fromEntries(Object.entries(err));
  if (Object.keys(enumerable).length) {
    err.cause = enumerable;
    return err;
  }
  if (isObject(err.cause)) {
    if (isError(err.cause.cause)) {
      err.cause.cause = parseError(err.cause.cause);
    }
  } else if (isError(err.cause)) {
    err.cause = parseError(err.cause);
  }
  return err;
};
var findRootError = (v, match) => {
  const err = parseError(v);
  return !err || match?.code && err.cause?.code !== match.code ? null : err;
};
var asRootError = (v, match) => {
  const err = findRootError(v, match);
  if (!err) throw v;
  err.cause = err.cause ?? {};
  return err;
};

export {
  parseError,
  asRootError
};
