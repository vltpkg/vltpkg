var global = globalThis;
import {Buffer} from "node:buffer";
import {setTimeout as _vlt_setTimeout,clearTimeout as _vlt_clearTimeout,setImmediate as _vlt_setImmediate,clearImmediate as _vlt_clearImmediate,setInterval as _vlt_setInterval,clearInterval as _vlt_clearInterval} from "node:timers";
globalThis.setTimeout = _vlt_setTimeout;
globalThis.clearTimeout = _vlt_clearTimeout;
globalThis.setImmediate = _vlt_setImmediate;
globalThis.clearImmediate = _vlt_clearImmediate;
globalThis.setInterval = _vlt_setInterval;
globalThis.clearInterval = _vlt_clearInterval;
import {createRequire as _vlt_createRequire} from "node:module";
var require = _vlt_createRequire(import.meta.filename);
import {
  __commonJS,
  __require
} from "./chunk-PZLD7RTK.js";

// ../../node_modules/.vlt/~npm~lru-cache@11.2.7/node_modules/lru-cache/dist/commonjs/index.min.js
var require_index_min = __commonJS({
  "../../node_modules/.vlt/~npm~lru-cache@11.2.7/node_modules/lru-cache/dist/commonjs/index.min.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.LRUCache = void 0;
    var G = typeof performance == "object" && performance && typeof performance.now == "function" ? performance : Date;
    var U = /* @__PURE__ */ new Set();
    var R = typeof process == "object" && process ? process : {};
    var I = (c, t, e, i) => {
      typeof R.emitWarning == "function" ? R.emitWarning(c, t, e, i) : console.error(`[${e}] ${t}: ${c}`);
    };
    var C = globalThis.AbortController;
    var L = globalThis.AbortSignal;
    if (typeof C > "u") {
      L = class {
        onabort;
        _onabort = [];
        reason;
        aborted = false;
        addEventListener(i, s) {
          this._onabort.push(s);
        }
      }, C = class {
        constructor() {
          t();
        }
        signal = new L();
        abort(i) {
          if (!this.signal.aborted) {
            this.signal.reason = i, this.signal.aborted = true;
            for (let s of this.signal._onabort) s(i);
            this.signal.onabort?.(i);
          }
        }
      };
      let c = R.env?.LRU_CACHE_IGNORE_AC_WARNING !== "1", t = () => {
        c && (c = false, I("AbortController is not defined. If using lru-cache in node 14, load an AbortController polyfill from the `node-abort-controller` package. A minimal polyfill is provided for use by LRUCache.fetch(), but it should not be relied upon in other contexts (eg, passing it to other APIs that use AbortController/AbortSignal might have undesirable effects). You may disable this with LRU_CACHE_IGNORE_AC_WARNING=1 in the env.", "NO_ABORT_CONTROLLER", "ENOTSUP", t));
      };
    }
    var x = (c) => !U.has(c);
    var y = (c) => c && c === Math.floor(c) && c > 0 && isFinite(c);
    var M = (c) => y(c) ? c <= Math.pow(2, 8) ? Uint8Array : c <= Math.pow(2, 16) ? Uint16Array : c <= Math.pow(2, 32) ? Uint32Array : c <= Number.MAX_SAFE_INTEGER ? z : null : null;
    var z = class extends Array {
      constructor(t) {
        super(t), this.fill(0);
      }
    };
    var W = class c {
      heap;
      length;
      static #o = false;
      static create(t) {
        let e = M(t);
        if (!e) return [];
        c.#o = true;
        let i = new c(t, e);
        return c.#o = false, i;
      }
      constructor(t, e) {
        if (!c.#o) throw new TypeError("instantiate Stack using Stack.create(n)");
        this.heap = new e(t), this.length = 0;
      }
      push(t) {
        this.heap[this.length++] = t;
      }
      pop() {
        return this.heap[--this.length];
      }
    };
    var D = class c {
      #o;
      #c;
      #w;
      #C;
      #S;
      #L;
      #U;
      #m;
      get perf() {
        return this.#m;
      }
      ttl;
      ttlResolution;
      ttlAutopurge;
      updateAgeOnGet;
      updateAgeOnHas;
      allowStale;
      noDisposeOnSet;
      noUpdateTTL;
      maxEntrySize;
      sizeCalculation;
      noDeleteOnFetchRejection;
      noDeleteOnStaleGet;
      allowStaleOnFetchAbort;
      allowStaleOnFetchRejection;
      ignoreFetchAbort;
      #n;
      #_;
      #s;
      #i;
      #t;
      #a;
      #u;
      #l;
      #h;
      #b;
      #r;
      #y;
      #A;
      #d;
      #g;
      #T;
      #v;
      #f;
      #I;
      static unsafeExposeInternals(t) {
        return { starts: t.#A, ttls: t.#d, autopurgeTimers: t.#g, sizes: t.#y, keyMap: t.#s, keyList: t.#i, valList: t.#t, next: t.#a, prev: t.#u, get head() {
          return t.#l;
        }, get tail() {
          return t.#h;
        }, free: t.#b, isBackgroundFetch: (e) => t.#e(e), backgroundFetch: (e, i, s, n) => t.#x(e, i, s, n), moveToTail: (e) => t.#D(e), indexes: (e) => t.#F(e), rindexes: (e) => t.#O(e), isStale: (e) => t.#p(e) };
      }
      get max() {
        return this.#o;
      }
      get maxSize() {
        return this.#c;
      }
      get calculatedSize() {
        return this.#_;
      }
      get size() {
        return this.#n;
      }
      get fetchMethod() {
        return this.#L;
      }
      get memoMethod() {
        return this.#U;
      }
      get dispose() {
        return this.#w;
      }
      get onInsert() {
        return this.#C;
      }
      get disposeAfter() {
        return this.#S;
      }
      constructor(t) {
        let { max: e = 0, ttl: i, ttlResolution: s = 1, ttlAutopurge: n, updateAgeOnGet: o, updateAgeOnHas: h, allowStale: r, dispose: a, onInsert: w, disposeAfter: f, noDisposeOnSet: d, noUpdateTTL: g, maxSize: A = 0, maxEntrySize: p = 0, sizeCalculation: _, fetchMethod: l, memoMethod: S, noDeleteOnFetchRejection: b, noDeleteOnStaleGet: m, allowStaleOnFetchRejection: u, allowStaleOnFetchAbort: T, ignoreFetchAbort: F, perf: v } = t;
        if (v !== void 0 && typeof v?.now != "function") throw new TypeError("perf option must have a now() method if specified");
        if (this.#m = v ?? G, e !== 0 && !y(e)) throw new TypeError("max option must be a nonnegative integer");
        let O = e ? M(e) : Array;
        if (!O) throw new Error("invalid max value: " + e);
        if (this.#o = e, this.#c = A, this.maxEntrySize = p || this.#c, this.sizeCalculation = _, this.sizeCalculation) {
          if (!this.#c && !this.maxEntrySize) throw new TypeError("cannot set sizeCalculation without setting maxSize or maxEntrySize");
          if (typeof this.sizeCalculation != "function") throw new TypeError("sizeCalculation set to non-function");
        }
        if (S !== void 0 && typeof S != "function") throw new TypeError("memoMethod must be a function if defined");
        if (this.#U = S, l !== void 0 && typeof l != "function") throw new TypeError("fetchMethod must be a function if specified");
        if (this.#L = l, this.#v = !!l, this.#s = /* @__PURE__ */ new Map(), this.#i = new Array(e).fill(void 0), this.#t = new Array(e).fill(void 0), this.#a = new O(e), this.#u = new O(e), this.#l = 0, this.#h = 0, this.#b = W.create(e), this.#n = 0, this.#_ = 0, typeof a == "function" && (this.#w = a), typeof w == "function" && (this.#C = w), typeof f == "function" ? (this.#S = f, this.#r = []) : (this.#S = void 0, this.#r = void 0), this.#T = !!this.#w, this.#I = !!this.#C, this.#f = !!this.#S, this.noDisposeOnSet = !!d, this.noUpdateTTL = !!g, this.noDeleteOnFetchRejection = !!b, this.allowStaleOnFetchRejection = !!u, this.allowStaleOnFetchAbort = !!T, this.ignoreFetchAbort = !!F, this.maxEntrySize !== 0) {
          if (this.#c !== 0 && !y(this.#c)) throw new TypeError("maxSize must be a positive integer if specified");
          if (!y(this.maxEntrySize)) throw new TypeError("maxEntrySize must be a positive integer if specified");
          this.#B();
        }
        if (this.allowStale = !!r, this.noDeleteOnStaleGet = !!m, this.updateAgeOnGet = !!o, this.updateAgeOnHas = !!h, this.ttlResolution = y(s) || s === 0 ? s : 1, this.ttlAutopurge = !!n, this.ttl = i || 0, this.ttl) {
          if (!y(this.ttl)) throw new TypeError("ttl must be a positive integer if specified");
          this.#j();
        }
        if (this.#o === 0 && this.ttl === 0 && this.#c === 0) throw new TypeError("At least one of max, maxSize, or ttl is required");
        if (!this.ttlAutopurge && !this.#o && !this.#c) {
          let E = "LRU_CACHE_UNBOUNDED";
          x(E) && (U.add(E), I("TTL caching without ttlAutopurge, max, or maxSize can result in unbounded memory consumption.", "UnboundedCacheWarning", E, c));
        }
      }
      getRemainingTTL(t) {
        return this.#s.has(t) ? 1 / 0 : 0;
      }
      #j() {
        let t = new z(this.#o), e = new z(this.#o);
        this.#d = t, this.#A = e;
        let i = this.ttlAutopurge ? new Array(this.#o) : void 0;
        this.#g = i, this.#N = (h, r, a = this.#m.now()) => {
          e[h] = r !== 0 ? a : 0, t[h] = r, s(h, r);
        }, this.#R = (h) => {
          e[h] = t[h] !== 0 ? this.#m.now() : 0, s(h, t[h]);
        };
        let s = this.ttlAutopurge ? (h, r) => {
          if (i?.[h] && (clearTimeout(i[h]), i[h] = void 0), r && r !== 0 && i) {
            let a = setTimeout(() => {
              this.#p(h) && this.#E(this.#i[h], "expire");
            }, r + 1);
            a.unref && a.unref(), i[h] = a;
          }
        } : () => {
        };
        this.#z = (h, r) => {
          if (t[r]) {
            let a = t[r], w = e[r];
            if (!a || !w) return;
            h.ttl = a, h.start = w, h.now = n || o();
            let f = h.now - w;
            h.remainingTTL = a - f;
          }
        };
        let n = 0, o = () => {
          let h = this.#m.now();
          if (this.ttlResolution > 0) {
            n = h;
            let r = setTimeout(() => n = 0, this.ttlResolution);
            r.unref && r.unref();
          }
          return h;
        };
        this.getRemainingTTL = (h) => {
          let r = this.#s.get(h);
          if (r === void 0) return 0;
          let a = t[r], w = e[r];
          if (!a || !w) return 1 / 0;
          let f = (n || o()) - w;
          return a - f;
        }, this.#p = (h) => {
          let r = e[h], a = t[h];
          return !!a && !!r && (n || o()) - r > a;
        };
      }
      #R = () => {
      };
      #z = () => {
      };
      #N = () => {
      };
      #p = () => false;
      #B() {
        let t = new z(this.#o);
        this.#_ = 0, this.#y = t, this.#W = (e) => {
          this.#_ -= t[e], t[e] = 0;
        }, this.#P = (e, i, s, n) => {
          if (this.#e(i)) return 0;
          if (!y(s)) if (n) {
            if (typeof n != "function") throw new TypeError("sizeCalculation must be a function");
            if (s = n(i, e), !y(s)) throw new TypeError("sizeCalculation return invalid (expect positive integer)");
          } else throw new TypeError("invalid size value (must be positive integer). When maxSize or maxEntrySize is used, sizeCalculation or size must be set.");
          return s;
        }, this.#M = (e, i, s) => {
          if (t[e] = i, this.#c) {
            let n = this.#c - t[e];
            for (; this.#_ > n; ) this.#G(true);
          }
          this.#_ += t[e], s && (s.entrySize = i, s.totalCalculatedSize = this.#_);
        };
      }
      #W = (t) => {
      };
      #M = (t, e, i) => {
      };
      #P = (t, e, i, s) => {
        if (i || s) throw new TypeError("cannot set size without setting maxSize or maxEntrySize on cache");
        return 0;
      };
      *#F({ allowStale: t = this.allowStale } = {}) {
        if (this.#n) for (let e = this.#h; !(!this.#H(e) || ((t || !this.#p(e)) && (yield e), e === this.#l)); ) e = this.#u[e];
      }
      *#O({ allowStale: t = this.allowStale } = {}) {
        if (this.#n) for (let e = this.#l; !(!this.#H(e) || ((t || !this.#p(e)) && (yield e), e === this.#h)); ) e = this.#a[e];
      }
      #H(t) {
        return t !== void 0 && this.#s.get(this.#i[t]) === t;
      }
      *entries() {
        for (let t of this.#F()) this.#t[t] !== void 0 && this.#i[t] !== void 0 && !this.#e(this.#t[t]) && (yield [this.#i[t], this.#t[t]]);
      }
      *rentries() {
        for (let t of this.#O()) this.#t[t] !== void 0 && this.#i[t] !== void 0 && !this.#e(this.#t[t]) && (yield [this.#i[t], this.#t[t]]);
      }
      *keys() {
        for (let t of this.#F()) {
          let e = this.#i[t];
          e !== void 0 && !this.#e(this.#t[t]) && (yield e);
        }
      }
      *rkeys() {
        for (let t of this.#O()) {
          let e = this.#i[t];
          e !== void 0 && !this.#e(this.#t[t]) && (yield e);
        }
      }
      *values() {
        for (let t of this.#F()) this.#t[t] !== void 0 && !this.#e(this.#t[t]) && (yield this.#t[t]);
      }
      *rvalues() {
        for (let t of this.#O()) this.#t[t] !== void 0 && !this.#e(this.#t[t]) && (yield this.#t[t]);
      }
      [Symbol.iterator]() {
        return this.entries();
      }
      [Symbol.toStringTag] = "LRUCache";
      find(t, e = {}) {
        for (let i of this.#F()) {
          let s = this.#t[i], n = this.#e(s) ? s.__staleWhileFetching : s;
          if (n !== void 0 && t(n, this.#i[i], this)) return this.get(this.#i[i], e);
        }
      }
      forEach(t, e = this) {
        for (let i of this.#F()) {
          let s = this.#t[i], n = this.#e(s) ? s.__staleWhileFetching : s;
          n !== void 0 && t.call(e, n, this.#i[i], this);
        }
      }
      rforEach(t, e = this) {
        for (let i of this.#O()) {
          let s = this.#t[i], n = this.#e(s) ? s.__staleWhileFetching : s;
          n !== void 0 && t.call(e, n, this.#i[i], this);
        }
      }
      purgeStale() {
        let t = false;
        for (let e of this.#O({ allowStale: true })) this.#p(e) && (this.#E(this.#i[e], "expire"), t = true);
        return t;
      }
      info(t) {
        let e = this.#s.get(t);
        if (e === void 0) return;
        let i = this.#t[e], s = this.#e(i) ? i.__staleWhileFetching : i;
        if (s === void 0) return;
        let n = { value: s };
        if (this.#d && this.#A) {
          let o = this.#d[e], h = this.#A[e];
          if (o && h) {
            let r = o - (this.#m.now() - h);
            n.ttl = r, n.start = Date.now();
          }
        }
        return this.#y && (n.size = this.#y[e]), n;
      }
      dump() {
        let t = [];
        for (let e of this.#F({ allowStale: true })) {
          let i = this.#i[e], s = this.#t[e], n = this.#e(s) ? s.__staleWhileFetching : s;
          if (n === void 0 || i === void 0) continue;
          let o = { value: n };
          if (this.#d && this.#A) {
            o.ttl = this.#d[e];
            let h = this.#m.now() - this.#A[e];
            o.start = Math.floor(Date.now() - h);
          }
          this.#y && (o.size = this.#y[e]), t.unshift([i, o]);
        }
        return t;
      }
      load(t) {
        this.clear();
        for (let [e, i] of t) {
          if (i.start) {
            let s = Date.now() - i.start;
            i.start = this.#m.now() - s;
          }
          this.set(e, i.value, i);
        }
      }
      set(t, e, i = {}) {
        if (e === void 0) return this.delete(t), this;
        let { ttl: s = this.ttl, start: n, noDisposeOnSet: o = this.noDisposeOnSet, sizeCalculation: h = this.sizeCalculation, status: r } = i, { noUpdateTTL: a = this.noUpdateTTL } = i, w = this.#P(t, e, i.size || 0, h);
        if (this.maxEntrySize && w > this.maxEntrySize) return r && (r.set = "miss", r.maxEntrySizeExceeded = true), this.#E(t, "set"), this;
        let f = this.#n === 0 ? void 0 : this.#s.get(t);
        if (f === void 0) f = this.#n === 0 ? this.#h : this.#b.length !== 0 ? this.#b.pop() : this.#n === this.#o ? this.#G(false) : this.#n, this.#i[f] = t, this.#t[f] = e, this.#s.set(t, f), this.#a[this.#h] = f, this.#u[f] = this.#h, this.#h = f, this.#n++, this.#M(f, w, r), r && (r.set = "add"), a = false, this.#I && this.#C?.(e, t, "add");
        else {
          this.#D(f);
          let d = this.#t[f];
          if (e !== d) {
            if (this.#v && this.#e(d)) {
              d.__abortController.abort(new Error("replaced"));
              let { __staleWhileFetching: g } = d;
              g !== void 0 && !o && (this.#T && this.#w?.(g, t, "set"), this.#f && this.#r?.push([g, t, "set"]));
            } else o || (this.#T && this.#w?.(d, t, "set"), this.#f && this.#r?.push([d, t, "set"]));
            if (this.#W(f), this.#M(f, w, r), this.#t[f] = e, r) {
              r.set = "replace";
              let g = d && this.#e(d) ? d.__staleWhileFetching : d;
              g !== void 0 && (r.oldValue = g);
            }
          } else r && (r.set = "update");
          this.#I && this.onInsert?.(e, t, e === d ? "update" : "replace");
        }
        if (s !== 0 && !this.#d && this.#j(), this.#d && (a || this.#N(f, s, n), r && this.#z(r, f)), !o && this.#f && this.#r) {
          let d = this.#r, g;
          for (; g = d?.shift(); ) this.#S?.(...g);
        }
        return this;
      }
      pop() {
        try {
          for (; this.#n; ) {
            let t = this.#t[this.#l];
            if (this.#G(true), this.#e(t)) {
              if (t.__staleWhileFetching) return t.__staleWhileFetching;
            } else if (t !== void 0) return t;
          }
        } finally {
          if (this.#f && this.#r) {
            let t = this.#r, e;
            for (; e = t?.shift(); ) this.#S?.(...e);
          }
        }
      }
      #G(t) {
        let e = this.#l, i = this.#i[e], s = this.#t[e];
        return this.#v && this.#e(s) ? s.__abortController.abort(new Error("evicted")) : (this.#T || this.#f) && (this.#T && this.#w?.(s, i, "evict"), this.#f && this.#r?.push([s, i, "evict"])), this.#W(e), this.#g?.[e] && (clearTimeout(this.#g[e]), this.#g[e] = void 0), t && (this.#i[e] = void 0, this.#t[e] = void 0, this.#b.push(e)), this.#n === 1 ? (this.#l = this.#h = 0, this.#b.length = 0) : this.#l = this.#a[e], this.#s.delete(i), this.#n--, e;
      }
      has(t, e = {}) {
        let { updateAgeOnHas: i = this.updateAgeOnHas, status: s } = e, n = this.#s.get(t);
        if (n !== void 0) {
          let o = this.#t[n];
          if (this.#e(o) && o.__staleWhileFetching === void 0) return false;
          if (this.#p(n)) s && (s.has = "stale", this.#z(s, n));
          else return i && this.#R(n), s && (s.has = "hit", this.#z(s, n)), true;
        } else s && (s.has = "miss");
        return false;
      }
      peek(t, e = {}) {
        let { allowStale: i = this.allowStale } = e, s = this.#s.get(t);
        if (s === void 0 || !i && this.#p(s)) return;
        let n = this.#t[s];
        return this.#e(n) ? n.__staleWhileFetching : n;
      }
      #x(t, e, i, s) {
        let n = e === void 0 ? void 0 : this.#t[e];
        if (this.#e(n)) return n;
        let o = new C(), { signal: h } = i;
        h?.addEventListener("abort", () => o.abort(h.reason), { signal: o.signal });
        let r = { signal: o.signal, options: i, context: s }, a = (p, _ = false) => {
          let { aborted: l } = o.signal, S = i.ignoreFetchAbort && p !== void 0, b = i.ignoreFetchAbort || !!(i.allowStaleOnFetchAbort && p !== void 0);
          if (i.status && (l && !_ ? (i.status.fetchAborted = true, i.status.fetchError = o.signal.reason, S && (i.status.fetchAbortIgnored = true)) : i.status.fetchResolved = true), l && !S && !_) return f(o.signal.reason, b);
          let m = g, u = this.#t[e];
          return (u === g || S && _ && u === void 0) && (p === void 0 ? m.__staleWhileFetching !== void 0 ? this.#t[e] = m.__staleWhileFetching : this.#E(t, "fetch") : (i.status && (i.status.fetchUpdated = true), this.set(t, p, r.options))), p;
        }, w = (p) => (i.status && (i.status.fetchRejected = true, i.status.fetchError = p), f(p, false)), f = (p, _) => {
          let { aborted: l } = o.signal, S = l && i.allowStaleOnFetchAbort, b = S || i.allowStaleOnFetchRejection, m = b || i.noDeleteOnFetchRejection, u = g;
          if (this.#t[e] === g && (!m || !_ && u.__staleWhileFetching === void 0 ? this.#E(t, "fetch") : S || (this.#t[e] = u.__staleWhileFetching)), b) return i.status && u.__staleWhileFetching !== void 0 && (i.status.returnedStale = true), u.__staleWhileFetching;
          if (u.__returned === u) throw p;
        }, d = (p, _) => {
          let l = this.#L?.(t, n, r);
          l && l instanceof Promise && l.then((S) => p(S === void 0 ? void 0 : S), _), o.signal.addEventListener("abort", () => {
            (!i.ignoreFetchAbort || i.allowStaleOnFetchAbort) && (p(void 0), i.allowStaleOnFetchAbort && (p = (S) => a(S, true)));
          });
        };
        i.status && (i.status.fetchDispatched = true);
        let g = new Promise(d).then(a, w), A = Object.assign(g, { __abortController: o, __staleWhileFetching: n, __returned: void 0 });
        return e === void 0 ? (this.set(t, A, { ...r.options, status: void 0 }), e = this.#s.get(t)) : this.#t[e] = A, A;
      }
      #e(t) {
        if (!this.#v) return false;
        let e = t;
        return !!e && e instanceof Promise && e.hasOwnProperty("__staleWhileFetching") && e.__abortController instanceof C;
      }
      async fetch(t, e = {}) {
        let { allowStale: i = this.allowStale, updateAgeOnGet: s = this.updateAgeOnGet, noDeleteOnStaleGet: n = this.noDeleteOnStaleGet, ttl: o = this.ttl, noDisposeOnSet: h = this.noDisposeOnSet, size: r = 0, sizeCalculation: a = this.sizeCalculation, noUpdateTTL: w = this.noUpdateTTL, noDeleteOnFetchRejection: f = this.noDeleteOnFetchRejection, allowStaleOnFetchRejection: d = this.allowStaleOnFetchRejection, ignoreFetchAbort: g = this.ignoreFetchAbort, allowStaleOnFetchAbort: A = this.allowStaleOnFetchAbort, context: p, forceRefresh: _ = false, status: l, signal: S } = e;
        if (!this.#v) return l && (l.fetch = "get"), this.get(t, { allowStale: i, updateAgeOnGet: s, noDeleteOnStaleGet: n, status: l });
        let b = { allowStale: i, updateAgeOnGet: s, noDeleteOnStaleGet: n, ttl: o, noDisposeOnSet: h, size: r, sizeCalculation: a, noUpdateTTL: w, noDeleteOnFetchRejection: f, allowStaleOnFetchRejection: d, allowStaleOnFetchAbort: A, ignoreFetchAbort: g, status: l, signal: S }, m = this.#s.get(t);
        if (m === void 0) {
          l && (l.fetch = "miss");
          let u = this.#x(t, m, b, p);
          return u.__returned = u;
        } else {
          let u = this.#t[m];
          if (this.#e(u)) {
            let E = i && u.__staleWhileFetching !== void 0;
            return l && (l.fetch = "inflight", E && (l.returnedStale = true)), E ? u.__staleWhileFetching : u.__returned = u;
          }
          let T = this.#p(m);
          if (!_ && !T) return l && (l.fetch = "hit"), this.#D(m), s && this.#R(m), l && this.#z(l, m), u;
          let F = this.#x(t, m, b, p), O = F.__staleWhileFetching !== void 0 && i;
          return l && (l.fetch = T ? "stale" : "refresh", O && T && (l.returnedStale = true)), O ? F.__staleWhileFetching : F.__returned = F;
        }
      }
      async forceFetch(t, e = {}) {
        let i = await this.fetch(t, e);
        if (i === void 0) throw new Error("fetch() returned undefined");
        return i;
      }
      memo(t, e = {}) {
        let i = this.#U;
        if (!i) throw new Error("no memoMethod provided to constructor");
        let { context: s, forceRefresh: n, ...o } = e, h = this.get(t, o);
        if (!n && h !== void 0) return h;
        let r = i(t, h, { options: o, context: s });
        return this.set(t, r, o), r;
      }
      get(t, e = {}) {
        let { allowStale: i = this.allowStale, updateAgeOnGet: s = this.updateAgeOnGet, noDeleteOnStaleGet: n = this.noDeleteOnStaleGet, status: o } = e, h = this.#s.get(t);
        if (h !== void 0) {
          let r = this.#t[h], a = this.#e(r);
          return o && this.#z(o, h), this.#p(h) ? (o && (o.get = "stale"), a ? (o && i && r.__staleWhileFetching !== void 0 && (o.returnedStale = true), i ? r.__staleWhileFetching : void 0) : (n || this.#E(t, "expire"), o && i && (o.returnedStale = true), i ? r : void 0)) : (o && (o.get = "hit"), a ? r.__staleWhileFetching : (this.#D(h), s && this.#R(h), r));
        } else o && (o.get = "miss");
      }
      #k(t, e) {
        this.#u[e] = t, this.#a[t] = e;
      }
      #D(t) {
        t !== this.#h && (t === this.#l ? this.#l = this.#a[t] : this.#k(this.#u[t], this.#a[t]), this.#k(this.#h, t), this.#h = t);
      }
      delete(t) {
        return this.#E(t, "delete");
      }
      #E(t, e) {
        let i = false;
        if (this.#n !== 0) {
          let s = this.#s.get(t);
          if (s !== void 0) if (this.#g?.[s] && (clearTimeout(this.#g?.[s]), this.#g[s] = void 0), i = true, this.#n === 1) this.#V(e);
          else {
            this.#W(s);
            let n = this.#t[s];
            if (this.#e(n) ? n.__abortController.abort(new Error("deleted")) : (this.#T || this.#f) && (this.#T && this.#w?.(n, t, e), this.#f && this.#r?.push([n, t, e])), this.#s.delete(t), this.#i[s] = void 0, this.#t[s] = void 0, s === this.#h) this.#h = this.#u[s];
            else if (s === this.#l) this.#l = this.#a[s];
            else {
              let o = this.#u[s];
              this.#a[o] = this.#a[s];
              let h = this.#a[s];
              this.#u[h] = this.#u[s];
            }
            this.#n--, this.#b.push(s);
          }
        }
        if (this.#f && this.#r?.length) {
          let s = this.#r, n;
          for (; n = s?.shift(); ) this.#S?.(...n);
        }
        return i;
      }
      clear() {
        return this.#V("delete");
      }
      #V(t) {
        for (let e of this.#O({ allowStale: true })) {
          let i = this.#t[e];
          if (this.#e(i)) i.__abortController.abort(new Error("deleted"));
          else {
            let s = this.#i[e];
            this.#T && this.#w?.(i, s, t), this.#f && this.#r?.push([i, s, t]);
          }
        }
        if (this.#s.clear(), this.#t.fill(void 0), this.#i.fill(void 0), this.#d && this.#A) {
          this.#d.fill(0), this.#A.fill(0);
          for (let e of this.#g ?? []) e !== void 0 && clearTimeout(e);
          this.#g?.fill(void 0);
        }
        if (this.#y && this.#y.fill(0), this.#l = 0, this.#h = 0, this.#b.length = 0, this.#_ = 0, this.#n = 0, this.#f && this.#r) {
          let e = this.#r, i;
          for (; i = e?.shift(); ) this.#S?.(...i);
        }
      }
    };
    exports.LRUCache = D;
  }
});

// ../../node_modules/.vlt/~npm~hosted-git-info@9.0.2/node_modules/hosted-git-info/lib/hosts.js
var require_hosts = __commonJS({
  "../../node_modules/.vlt/~npm~hosted-git-info@9.0.2/node_modules/hosted-git-info/lib/hosts.js"(exports, module) {
    "use strict";
    var maybeJoin = (...args) => args.every((arg) => arg) ? args.join("") : "";
    var maybeEncode = (arg) => arg ? encodeURIComponent(arg) : "";
    var formatHashFragment = (f) => f.toLowerCase().replace(/^\W+/g, "").replace(/(?<!\W)\W+$/, "").replace(/\//g, "").replace(/\W+/g, "-");
    var defaults = {
      sshtemplate: ({ domain, user, project, committish }) => `git@${domain}:${user}/${project}.git${maybeJoin("#", committish)}`,
      sshurltemplate: ({ domain, user, project, committish }) => `git+ssh://git@${domain}/${user}/${project}.git${maybeJoin("#", committish)}`,
      edittemplate: ({ domain, user, project, committish, editpath, path }) => `https://${domain}/${user}/${project}${maybeJoin("/", editpath, "/", maybeEncode(committish || "HEAD"), "/", path)}`,
      browsetemplate: ({ domain, user, project, committish, treepath }) => `https://${domain}/${user}/${project}${maybeJoin("/", treepath, "/", maybeEncode(committish))}`,
      browsetreetemplate: ({ domain, user, project, committish, treepath, path, fragment, hashformat }) => `https://${domain}/${user}/${project}/${treepath}/${maybeEncode(committish || "HEAD")}/${path}${maybeJoin("#", hashformat(fragment || ""))}`,
      browseblobtemplate: ({ domain, user, project, committish, blobpath, path, fragment, hashformat }) => `https://${domain}/${user}/${project}/${blobpath}/${maybeEncode(committish || "HEAD")}/${path}${maybeJoin("#", hashformat(fragment || ""))}`,
      docstemplate: ({ domain, user, project, treepath, committish }) => `https://${domain}/${user}/${project}${maybeJoin("/", treepath, "/", maybeEncode(committish))}#readme`,
      httpstemplate: ({ auth, domain, user, project, committish }) => `git+https://${maybeJoin(auth, "@")}${domain}/${user}/${project}.git${maybeJoin("#", committish)}`,
      filetemplate: ({ domain, user, project, committish, path }) => `https://${domain}/${user}/${project}/raw/${maybeEncode(committish || "HEAD")}/${path}`,
      shortcuttemplate: ({ type, user, project, committish }) => `${type}:${user}/${project}${maybeJoin("#", committish)}`,
      pathtemplate: ({ user, project, committish }) => `${user}/${project}${maybeJoin("#", committish)}`,
      bugstemplate: ({ domain, user, project }) => `https://${domain}/${user}/${project}/issues`,
      hashformat: formatHashFragment
    };
    var hosts = {};
    hosts.github = {
      // First two are insecure and generally shouldn't be used any more, but
      // they are still supported.
      protocols: ["git:", "http:", "git+ssh:", "git+https:", "ssh:", "https:"],
      domain: "github.com",
      treepath: "tree",
      blobpath: "blob",
      editpath: "edit",
      filetemplate: ({ auth, user, project, committish, path }) => `https://${maybeJoin(auth, "@")}raw.githubusercontent.com/${user}/${project}/${maybeEncode(committish || "HEAD")}/${path}`,
      gittemplate: ({ auth, domain, user, project, committish }) => `git://${maybeJoin(auth, "@")}${domain}/${user}/${project}.git${maybeJoin("#", committish)}`,
      tarballtemplate: ({ domain, user, project, committish }) => `https://codeload.${domain}/${user}/${project}/tar.gz/${maybeEncode(committish || "HEAD")}`,
      extract: (url) => {
        let [, user, project, type, committish] = url.pathname.split("/", 5);
        if (type && type !== "tree") {
          return;
        }
        if (!type) {
          committish = url.hash.slice(1);
        }
        if (project && project.endsWith(".git")) {
          project = project.slice(0, -4);
        }
        if (!user || !project) {
          return;
        }
        return { user, project, committish };
      }
    };
    hosts.bitbucket = {
      protocols: ["git+ssh:", "git+https:", "ssh:", "https:"],
      domain: "bitbucket.org",
      treepath: "src",
      blobpath: "src",
      editpath: "?mode=edit",
      edittemplate: ({ domain, user, project, committish, treepath, path, editpath }) => `https://${domain}/${user}/${project}${maybeJoin("/", treepath, "/", maybeEncode(committish || "HEAD"), "/", path, editpath)}`,
      tarballtemplate: ({ domain, user, project, committish }) => `https://${domain}/${user}/${project}/get/${maybeEncode(committish || "HEAD")}.tar.gz`,
      extract: (url) => {
        let [, user, project, aux] = url.pathname.split("/", 4);
        if (["get"].includes(aux)) {
          return;
        }
        if (project && project.endsWith(".git")) {
          project = project.slice(0, -4);
        }
        if (!user || !project) {
          return;
        }
        return { user, project, committish: url.hash.slice(1) };
      }
    };
    hosts.gitlab = {
      protocols: ["git+ssh:", "git+https:", "ssh:", "https:"],
      domain: "gitlab.com",
      treepath: "tree",
      blobpath: "tree",
      editpath: "-/edit",
      tarballtemplate: ({ domain, user, project, committish }) => `https://${domain}/${user}/${project}/repository/archive.tar.gz?ref=${maybeEncode(committish || "HEAD")}`,
      extract: (url) => {
        const path = url.pathname.slice(1);
        if (path.includes("/-/") || path.includes("/archive.tar.gz")) {
          return;
        }
        const segments = path.split("/");
        let project = segments.pop();
        if (project.endsWith(".git")) {
          project = project.slice(0, -4);
        }
        const user = segments.join("/");
        if (!user || !project) {
          return;
        }
        return { user, project, committish: url.hash.slice(1) };
      }
    };
    hosts.gist = {
      protocols: ["git:", "git+ssh:", "git+https:", "ssh:", "https:"],
      domain: "gist.github.com",
      editpath: "edit",
      sshtemplate: ({ domain, project, committish }) => `git@${domain}:${project}.git${maybeJoin("#", committish)}`,
      sshurltemplate: ({ domain, project, committish }) => `git+ssh://git@${domain}/${project}.git${maybeJoin("#", committish)}`,
      edittemplate: ({ domain, user, project, committish, editpath }) => `https://${domain}/${user}/${project}${maybeJoin("/", maybeEncode(committish))}/${editpath}`,
      browsetemplate: ({ domain, project, committish }) => `https://${domain}/${project}${maybeJoin("/", maybeEncode(committish))}`,
      browsetreetemplate: ({ domain, project, committish, path, hashformat }) => `https://${domain}/${project}${maybeJoin("/", maybeEncode(committish))}${maybeJoin("#", hashformat(path))}`,
      browseblobtemplate: ({ domain, project, committish, path, hashformat }) => `https://${domain}/${project}${maybeJoin("/", maybeEncode(committish))}${maybeJoin("#", hashformat(path))}`,
      docstemplate: ({ domain, project, committish }) => `https://${domain}/${project}${maybeJoin("/", maybeEncode(committish))}`,
      httpstemplate: ({ domain, project, committish }) => `git+https://${domain}/${project}.git${maybeJoin("#", committish)}`,
      filetemplate: ({ user, project, committish, path }) => `https://gist.githubusercontent.com/${user}/${project}/raw${maybeJoin("/", maybeEncode(committish))}/${path}`,
      shortcuttemplate: ({ type, project, committish }) => `${type}:${project}${maybeJoin("#", committish)}`,
      pathtemplate: ({ project, committish }) => `${project}${maybeJoin("#", committish)}`,
      bugstemplate: ({ domain, project }) => `https://${domain}/${project}`,
      gittemplate: ({ domain, project, committish }) => `git://${domain}/${project}.git${maybeJoin("#", committish)}`,
      tarballtemplate: ({ project, committish }) => `https://codeload.github.com/gist/${project}/tar.gz/${maybeEncode(committish || "HEAD")}`,
      extract: (url) => {
        let [, user, project, aux] = url.pathname.split("/", 4);
        if (aux === "raw") {
          return;
        }
        if (!project) {
          if (!user) {
            return;
          }
          project = user;
          user = null;
        }
        if (project.endsWith(".git")) {
          project = project.slice(0, -4);
        }
        return { user, project, committish: url.hash.slice(1) };
      },
      hashformat: function(fragment) {
        return fragment && "file-" + formatHashFragment(fragment);
      }
    };
    hosts.sourcehut = {
      protocols: ["git+ssh:", "https:"],
      domain: "git.sr.ht",
      treepath: "tree",
      blobpath: "tree",
      filetemplate: ({ domain, user, project, committish, path }) => `https://${domain}/${user}/${project}/blob/${maybeEncode(committish) || "HEAD"}/${path}`,
      httpstemplate: ({ domain, user, project, committish }) => `https://${domain}/${user}/${project}.git${maybeJoin("#", committish)}`,
      tarballtemplate: ({ domain, user, project, committish }) => `https://${domain}/${user}/${project}/archive/${maybeEncode(committish) || "HEAD"}.tar.gz`,
      bugstemplate: () => null,
      extract: (url) => {
        let [, user, project, aux] = url.pathname.split("/", 4);
        if (["archive"].includes(aux)) {
          return;
        }
        if (project && project.endsWith(".git")) {
          project = project.slice(0, -4);
        }
        if (!user || !project) {
          return;
        }
        return { user, project, committish: url.hash.slice(1) };
      }
    };
    for (const [name, host] of Object.entries(hosts)) {
      hosts[name] = Object.assign({}, defaults, host);
    }
    module.exports = hosts;
  }
});

// ../../node_modules/.vlt/~npm~hosted-git-info@9.0.2/node_modules/hosted-git-info/lib/parse-url.js
var require_parse_url = __commonJS({
  "../../node_modules/.vlt/~npm~hosted-git-info@9.0.2/node_modules/hosted-git-info/lib/parse-url.js"(exports, module) {
    var url = __require("node:url");
    var lastIndexOfBefore = (str, char, beforeChar) => {
      const startPosition = str.indexOf(beforeChar);
      return str.lastIndexOf(char, startPosition > -1 ? startPosition : Infinity);
    };
    var safeUrl = (u) => {
      try {
        return new url.URL(u);
      } catch {
      }
    };
    var correctProtocol = (arg, protocols) => {
      const firstColon = arg.indexOf(":");
      const proto = arg.slice(0, firstColon + 1);
      if (Object.prototype.hasOwnProperty.call(protocols, proto)) {
        return arg;
      }
      if (arg.substr(firstColon, 3) === "://") {
        return arg;
      }
      const firstAt = arg.indexOf("@");
      if (firstAt > -1) {
        if (firstAt > firstColon) {
          return `git+ssh://${arg}`;
        } else {
          return arg;
        }
      }
      return `${arg.slice(0, firstColon + 1)}//${arg.slice(firstColon + 1)}`;
    };
    var correctUrl = (giturl) => {
      const firstAt = lastIndexOfBefore(giturl, "@", "#");
      const lastColonBeforeHash = lastIndexOfBefore(giturl, ":", "#");
      if (lastColonBeforeHash > firstAt) {
        giturl = giturl.slice(0, lastColonBeforeHash) + "/" + giturl.slice(lastColonBeforeHash + 1);
      }
      if (lastIndexOfBefore(giturl, ":", "#") === -1 && giturl.indexOf("//") === -1) {
        giturl = `git+ssh://${giturl}`;
      }
      return giturl;
    };
    module.exports = (giturl, protocols) => {
      const withProtocol = protocols ? correctProtocol(giturl, protocols) : giturl;
      return safeUrl(withProtocol) || safeUrl(correctUrl(withProtocol));
    };
  }
});

// ../../node_modules/.vlt/~npm~hosted-git-info@9.0.2/node_modules/hosted-git-info/lib/from-url.js
var require_from_url = __commonJS({
  "../../node_modules/.vlt/~npm~hosted-git-info@9.0.2/node_modules/hosted-git-info/lib/from-url.js"(exports, module) {
    "use strict";
    var parseUrl = require_parse_url();
    var isGitHubShorthand = (arg) => {
      const firstHash = arg.indexOf("#");
      const firstSlash = arg.indexOf("/");
      const secondSlash = arg.indexOf("/", firstSlash + 1);
      const firstColon = arg.indexOf(":");
      const firstSpace = /\s/.exec(arg);
      const firstAt = arg.indexOf("@");
      const spaceOnlyAfterHash = !firstSpace || firstHash > -1 && firstSpace.index > firstHash;
      const atOnlyAfterHash = firstAt === -1 || firstHash > -1 && firstAt > firstHash;
      const colonOnlyAfterHash = firstColon === -1 || firstHash > -1 && firstColon > firstHash;
      const secondSlashOnlyAfterHash = secondSlash === -1 || firstHash > -1 && secondSlash > firstHash;
      const hasSlash = firstSlash > 0;
      const doesNotEndWithSlash = firstHash > -1 ? arg[firstHash - 1] !== "/" : !arg.endsWith("/");
      const doesNotStartWithDot = !arg.startsWith(".");
      return spaceOnlyAfterHash && hasSlash && doesNotEndWithSlash && doesNotStartWithDot && atOnlyAfterHash && colonOnlyAfterHash && secondSlashOnlyAfterHash;
    };
    module.exports = (giturl, opts, { gitHosts, protocols }) => {
      if (!giturl) {
        return;
      }
      const correctedUrl = isGitHubShorthand(giturl) ? `github:${giturl}` : giturl;
      const parsed = parseUrl(correctedUrl, protocols);
      if (!parsed) {
        return;
      }
      const gitHostShortcut = gitHosts.byShortcut[parsed.protocol];
      const gitHostDomain = gitHosts.byDomain[parsed.hostname.startsWith("www.") ? parsed.hostname.slice(4) : parsed.hostname];
      const gitHostName = gitHostShortcut || gitHostDomain;
      if (!gitHostName) {
        return;
      }
      const gitHostInfo = gitHosts[gitHostShortcut || gitHostDomain];
      let auth = null;
      if (protocols[parsed.protocol]?.auth && (parsed.username || parsed.password)) {
        auth = `${parsed.username}${parsed.password ? ":" + parsed.password : ""}`;
      }
      let committish = null;
      let user = null;
      let project = null;
      let defaultRepresentation = null;
      try {
        if (gitHostShortcut) {
          let pathname = parsed.pathname.startsWith("/") ? parsed.pathname.slice(1) : parsed.pathname;
          const firstAt = pathname.indexOf("@");
          if (firstAt > -1) {
            pathname = pathname.slice(firstAt + 1);
          }
          const lastSlash = pathname.lastIndexOf("/");
          if (lastSlash > -1) {
            user = decodeURIComponent(pathname.slice(0, lastSlash));
            if (!user) {
              user = null;
            }
            project = decodeURIComponent(pathname.slice(lastSlash + 1));
          } else {
            project = decodeURIComponent(pathname);
          }
          if (project.endsWith(".git")) {
            project = project.slice(0, -4);
          }
          if (parsed.hash) {
            committish = decodeURIComponent(parsed.hash.slice(1));
          }
          defaultRepresentation = "shortcut";
        } else {
          if (!gitHostInfo.protocols.includes(parsed.protocol)) {
            return;
          }
          const segments = gitHostInfo.extract(parsed);
          if (!segments) {
            return;
          }
          user = segments.user && decodeURIComponent(segments.user);
          project = decodeURIComponent(segments.project);
          committish = decodeURIComponent(segments.committish);
          defaultRepresentation = protocols[parsed.protocol]?.name || parsed.protocol.slice(0, -1);
        }
      } catch (err) {
        if (err instanceof URIError) {
          return;
        } else {
          throw err;
        }
      }
      return [gitHostName, user, auth, project, committish, defaultRepresentation, opts];
    };
  }
});

// ../../node_modules/.vlt/~npm~hosted-git-info@9.0.2/node_modules/hosted-git-info/lib/index.js
var require_lib = __commonJS({
  "../../node_modules/.vlt/~npm~hosted-git-info@9.0.2/node_modules/hosted-git-info/lib/index.js"(exports, module) {
    "use strict";
    var { LRUCache } = require_index_min();
    var hosts = require_hosts();
    var fromUrl = require_from_url();
    var parseUrl = require_parse_url();
    var cache = new LRUCache({ max: 1e3 });
    function unknownHostedUrl(url) {
      try {
        const {
          protocol,
          hostname,
          pathname
        } = new URL(url);
        if (!hostname) {
          return null;
        }
        const proto = /(?:git\+)http:$/.test(protocol) ? "http:" : "https:";
        const path = pathname.replace(/\.git$/, "");
        return `${proto}//${hostname}${path}`;
      } catch {
        return null;
      }
    }
    var GitHost = class _GitHost {
      constructor(type, user, auth, project, committish, defaultRepresentation, opts = {}) {
        Object.assign(this, _GitHost.#gitHosts[type], {
          type,
          user,
          auth,
          project,
          committish,
          default: defaultRepresentation,
          opts
        });
      }
      static #gitHosts = { byShortcut: {}, byDomain: {} };
      static #protocols = {
        "git+ssh:": { name: "sshurl" },
        "ssh:": { name: "sshurl" },
        "git+https:": { name: "https", auth: true },
        "git:": { auth: true },
        "http:": { auth: true },
        "https:": { auth: true },
        "git+http:": { auth: true }
      };
      static addHost(name, host) {
        _GitHost.#gitHosts[name] = host;
        _GitHost.#gitHosts.byDomain[host.domain] = name;
        _GitHost.#gitHosts.byShortcut[`${name}:`] = name;
        _GitHost.#protocols[`${name}:`] = { name };
      }
      static fromUrl(giturl, opts) {
        if (typeof giturl !== "string") {
          return;
        }
        const key = giturl + JSON.stringify(opts || {});
        if (!cache.has(key)) {
          const hostArgs = fromUrl(giturl, opts, {
            gitHosts: _GitHost.#gitHosts,
            protocols: _GitHost.#protocols
          });
          cache.set(key, hostArgs ? new _GitHost(...hostArgs) : void 0);
        }
        return cache.get(key);
      }
      static fromManifest(manifest, opts = {}) {
        if (!manifest || typeof manifest !== "object") {
          return;
        }
        const r = manifest.repository;
        const rurl = r && (typeof r === "string" ? r : typeof r === "object" && typeof r.url === "string" ? r.url : null);
        if (!rurl) {
          throw new Error("no repository");
        }
        const info = rurl && _GitHost.fromUrl(rurl.replace(/^git\+/, ""), opts) || null;
        if (info) {
          return info;
        }
        const unk = unknownHostedUrl(rurl);
        return _GitHost.fromUrl(unk, opts) || unk;
      }
      static parseUrl(url) {
        return parseUrl(url);
      }
      #fill(template, opts) {
        if (typeof template !== "function") {
          return null;
        }
        const options = { ...this, ...this.opts, ...opts };
        if (!options.path) {
          options.path = "";
        }
        if (options.path.startsWith("/")) {
          options.path = options.path.slice(1);
        }
        if (options.noCommittish) {
          options.committish = null;
        }
        const result = template(options);
        return options.noGitPlus && result.startsWith("git+") ? result.slice(4) : result;
      }
      hash() {
        return this.committish ? `#${this.committish}` : "";
      }
      ssh(opts) {
        return this.#fill(this.sshtemplate, opts);
      }
      sshurl(opts) {
        return this.#fill(this.sshurltemplate, opts);
      }
      browse(path, ...args) {
        if (typeof path !== "string") {
          return this.#fill(this.browsetemplate, path);
        }
        if (typeof args[0] !== "string") {
          return this.#fill(this.browsetreetemplate, { ...args[0], path });
        }
        return this.#fill(this.browsetreetemplate, { ...args[1], fragment: args[0], path });
      }
      // If the path is known to be a file, then browseFile should be used. For some hosts
      // the url is the same as browse, but for others like GitHub a file can use both `/tree/`
      // and `/blob/` in the path. When using a default committish of `HEAD` then the `/tree/`
      // path will redirect to a specific commit. Using the `/blob/` path avoids this and
      // does not redirect to a different commit.
      browseFile(path, ...args) {
        if (typeof args[0] !== "string") {
          return this.#fill(this.browseblobtemplate, { ...args[0], path });
        }
        return this.#fill(this.browseblobtemplate, { ...args[1], fragment: args[0], path });
      }
      docs(opts) {
        return this.#fill(this.docstemplate, opts);
      }
      bugs(opts) {
        return this.#fill(this.bugstemplate, opts);
      }
      https(opts) {
        return this.#fill(this.httpstemplate, opts);
      }
      git(opts) {
        return this.#fill(this.gittemplate, opts);
      }
      shortcut(opts) {
        return this.#fill(this.shortcuttemplate, opts);
      }
      path(opts) {
        return this.#fill(this.pathtemplate, opts);
      }
      tarball(opts) {
        return this.#fill(this.tarballtemplate, { ...opts, noCommittish: false });
      }
      file(path, opts) {
        return this.#fill(this.filetemplate, { ...opts, path });
      }
      edit(path, opts) {
        return this.#fill(this.edittemplate, { ...opts, path });
      }
      getDefaultRepresentation() {
        return this.default;
      }
      toString(opts) {
        if (this.default && typeof this[this.default] === "function") {
          return this[this.default](opts);
        }
        return this.sshurl(opts);
      }
    };
    for (const [name, host] of Object.entries(hosts)) {
      GitHost.addHost(name, host);
    }
    module.exports = GitHost;
  }
});

export {
  require_lib
};
