var global = globalThis;
import {Buffer} from "node:buffer";
import {setTimeout as _vlt_setTimeout,clearTimeout as _vlt_clearTimeout,setImmediate as _vlt_setImmediate,clearImmediate as _vlt_clearImmediate,setInterval as _vlt_setInterval,clearInterval as _vlt_clearInterval} from "node:timers";
globalThis.setTimeout = _vlt_setTimeout;
globalThis.clearTimeout = _vlt_clearTimeout;
globalThis.setImmediate = _vlt_setImmediate;
globalThis.clearImmediate = _vlt_clearImmediate;
globalThis.setInterval = _vlt_setInterval;
globalThis.clearInterval = _vlt_clearInterval;
import {createRequire as _vlt_createRequire} from "node:module";
var require = _vlt_createRequire(import.meta.filename);
import {
  Ze,
  ts
} from "./chunk-VCSVHRCS.js";

// ../../node_modules/.vlt/~npm~rimraf@6.1.3/node_modules/rimraf/dist/esm/opt-arg.js
var typeOrUndef = (val, t) => typeof val === "undefined" || typeof val === t;
var isRimrafOptions = (o) => !!o && typeof o === "object" && typeOrUndef(o.preserveRoot, "boolean") && typeOrUndef(o.tmp, "string") && typeOrUndef(o.maxRetries, "number") && typeOrUndef(o.retryDelay, "number") && typeOrUndef(o.backoff, "number") && typeOrUndef(o.maxBackoff, "number") && (typeOrUndef(o.glob, "boolean") || o.glob && typeof o.glob === "object") && typeOrUndef(o.filter, "function");
var assertRimrafOptions = (o) => {
  if (!isRimrafOptions(o)) {
    throw new Error("invalid rimraf options");
  }
};
var optArgT = (opt) => {
  assertRimrafOptions(opt);
  const { glob, ...options } = opt;
  if (!glob) {
    return options;
  }
  const globOpt = glob === true ? opt.signal ? { signal: opt.signal } : {} : opt.signal ? {
    signal: opt.signal,
    ...glob
  } : glob;
  return {
    ...options,
    glob: {
      ...globOpt,
      // always get absolute paths from glob, to ensure
      // that we are referencing the correct thing.
      absolute: true,
      withFileTypes: false
    }
  };
};
var optArg = (opt = {}) => optArgT(opt);
var optArgSync = (opt = {}) => optArgT(opt);

// ../../node_modules/.vlt/~npm~rimraf@6.1.3/node_modules/rimraf/dist/esm/path-arg.js
import { parse, resolve } from "node:path";
import { inspect } from "node:util";
var pathArg = (path, opt = {}) => {
  const type = typeof path;
  if (type !== "string") {
    const ctor = path && type === "object" && path.constructor;
    const received = ctor && ctor.name ? `an instance of ${ctor.name}` : type === "object" ? inspect(path) : `type ${type} ${path}`;
    const msg = `The "path" argument must be of type string. Received ${received}`;
    throw Object.assign(new TypeError(msg), {
      path,
      code: "ERR_INVALID_ARG_TYPE"
    });
  }
  if (/\0/.test(path)) {
    const msg = "path must be a string without null bytes";
    throw Object.assign(new TypeError(msg), {
      path,
      code: "ERR_INVALID_ARG_VALUE"
    });
  }
  path = resolve(path);
  const { root } = parse(path);
  if (path === root && opt.preserveRoot !== false) {
    const msg = "refusing to remove root directory without preserveRoot:false";
    throw Object.assign(new Error(msg), {
      path,
      code: "ERR_PRESERVE_ROOT"
    });
  }
  if (process.platform === "win32") {
    const badWinChars = /[*|"<>?:]/;
    const { root: root2 } = parse(path);
    if (badWinChars.test(path.substring(root2.length))) {
      throw Object.assign(new Error("Illegal characters in path."), {
        path,
        code: "EINVAL"
      });
    }
  }
  return path;
};
var path_arg_default = pathArg;

// ../../node_modules/.vlt/~npm~rimraf@6.1.3/node_modules/rimraf/dist/esm/fs.js
import { readdirSync as rdSync } from "node:fs";
import fsPromises from "node:fs/promises";
import { chmodSync, mkdirSync, renameSync, rmdirSync, rmSync, statSync, lstatSync, unlinkSync } from "node:fs";
var readdirSync = (path) => rdSync(path, { withFileTypes: true });
var promises = {
  chmod: fsPromises.chmod,
  mkdir: fsPromises.mkdir,
  readdir: (path) => fsPromises.readdir(path, { withFileTypes: true }),
  rename: fsPromises.rename,
  rm: fsPromises.rm,
  rmdir: fsPromises.rmdir,
  stat: fsPromises.stat,
  lstat: fsPromises.lstat,
  unlink: fsPromises.unlink
};

// ../../node_modules/.vlt/~npm~rimraf@6.1.3/node_modules/rimraf/dist/esm/rimraf-posix.js
import { parse as parse2, resolve as resolve2 } from "node:path";

// ../../node_modules/.vlt/~npm~rimraf@6.1.3/node_modules/rimraf/dist/esm/readdir-or-error.js
var { readdir } = promises;
var readdirOrError = (path) => readdir(path).catch((er) => er);
var readdirOrErrorSync = (path) => {
  try {
    return readdirSync(path);
  } catch (er) {
    return er;
  }
};

// ../../node_modules/.vlt/~npm~rimraf@6.1.3/node_modules/rimraf/dist/esm/error.js
var isRecord = (o) => !!o && typeof o === "object";
var hasString = (o, key) => key in o && typeof o[key] === "string";
var isFsError = (o) => isRecord(o) && hasString(o, "code") && hasString(o, "path");
var errorCode = (er) => isRecord(er) && hasString(er, "code") ? er.code : null;

// ../../node_modules/.vlt/~npm~rimraf@6.1.3/node_modules/rimraf/dist/esm/ignore-enoent.js
var ignoreENOENT = async (p, rethrow) => p.catch((er) => {
  if (errorCode(er) === "ENOENT") {
    return;
  }
  throw rethrow ?? er;
});
var ignoreENOENTSync = (fn, rethrow) => {
  try {
    return fn();
  } catch (er) {
    if (errorCode(er) === "ENOENT") {
      return;
    }
    throw rethrow ?? er;
  }
};

// ../../node_modules/.vlt/~npm~rimraf@6.1.3/node_modules/rimraf/dist/esm/rimraf-posix.js
var { lstat, rmdir, unlink } = promises;
var rimrafPosix = async (path, opt) => {
  opt?.signal?.throwIfAborted();
  return await ignoreENOENT(lstat(path).then((stat2) => rimrafPosixDir(path, opt, stat2))) ?? true;
};
var rimrafPosixSync = (path, opt) => {
  opt?.signal?.throwIfAborted();
  return ignoreENOENTSync(() => rimrafPosixDirSync(path, opt, lstatSync(path))) ?? true;
};
var rimrafPosixDir = async (path, opt, ent) => {
  opt?.signal?.throwIfAborted();
  const entries = ent.isDirectory() ? await readdirOrError(path) : null;
  if (!Array.isArray(entries)) {
    if (entries) {
      if (errorCode(entries) === "ENOENT") {
        return true;
      }
      if (errorCode(entries) !== "ENOTDIR") {
        throw entries;
      }
    }
    if (opt.filter && !await opt.filter(path, ent)) {
      return false;
    }
    await ignoreENOENT(unlink(path));
    return true;
  }
  const removedAll = (await Promise.all(entries.map((ent2) => rimrafPosixDir(resolve2(path, ent2.name), opt, ent2)))).every((v) => v === true);
  if (!removedAll) {
    return false;
  }
  if (opt.preserveRoot === false && path === parse2(path).root) {
    return false;
  }
  if (opt.filter && !await opt.filter(path, ent)) {
    return false;
  }
  await ignoreENOENT(rmdir(path));
  return true;
};
var rimrafPosixDirSync = (path, opt, ent) => {
  opt?.signal?.throwIfAborted();
  const entries = ent.isDirectory() ? readdirOrErrorSync(path) : null;
  if (!Array.isArray(entries)) {
    if (entries) {
      if (errorCode(entries) === "ENOENT") {
        return true;
      }
      if (errorCode(entries) !== "ENOTDIR") {
        throw entries;
      }
    }
    if (opt.filter && !opt.filter(path, ent)) {
      return false;
    }
    ignoreENOENTSync(() => unlinkSync(path));
    return true;
  }
  let removedAll = true;
  for (const ent2 of entries) {
    const p = resolve2(path, ent2.name);
    removedAll = rimrafPosixDirSync(p, opt, ent2) && removedAll;
  }
  if (opt.preserveRoot === false && path === parse2(path).root) {
    return false;
  }
  if (!removedAll) {
    return false;
  }
  if (opt.filter && !opt.filter(path, ent)) {
    return false;
  }
  ignoreENOENTSync(() => rmdirSync(path));
  return true;
};

// ../../node_modules/.vlt/~npm~rimraf@6.1.3/node_modules/rimraf/dist/esm/rimraf-windows.js
import { parse as parse5, resolve as resolve5 } from "node:path";

// ../../node_modules/.vlt/~npm~rimraf@6.1.3/node_modules/rimraf/dist/esm/fix-eperm.js
var { chmod } = promises;
var fixEPERM = (fn) => async (path) => {
  try {
    return void await ignoreENOENT(fn(path));
  } catch (er) {
    if (errorCode(er) === "EPERM") {
      if (!await ignoreENOENT(chmod(path, 438).then(() => true), er)) {
        return;
      }
      return void await fn(path);
    }
    throw er;
  }
};
var fixEPERMSync = (fn) => (path) => {
  try {
    return void ignoreENOENTSync(() => fn(path));
  } catch (er) {
    if (errorCode(er) === "EPERM") {
      if (!ignoreENOENTSync(() => (chmodSync(path, 438), true), er)) {
        return;
      }
      return void fn(path);
    }
    throw er;
  }
};

// ../../node_modules/.vlt/~npm~rimraf@6.1.3/node_modules/rimraf/dist/esm/retry-busy.js
import { setTimeout } from "node:timers/promises";
var MAXBACKOFF = 200;
var RATE = 1.2;
var MAXRETRIES = 10;
var codes = /* @__PURE__ */ new Set(["EMFILE", "ENFILE", "EBUSY"]);
var retryBusy = (fn) => {
  const method = async (path, opt, backoff = 1, total = 0) => {
    const mbo = opt.maxBackoff || MAXBACKOFF;
    const rate = opt.backoff || RATE;
    const max = opt.maxRetries || MAXRETRIES;
    let retries = 0;
    while (true) {
      try {
        return await fn(path);
      } catch (er) {
        if (isFsError(er) && er.path === path && codes.has(er.code)) {
          backoff = Math.ceil(backoff * rate);
          total = backoff + total;
          if (total < mbo) {
            await setTimeout(backoff);
            return method(path, opt, backoff, total);
          }
          if (retries < max) {
            retries++;
            continue;
          }
        }
        throw er;
      }
    }
  };
  return method;
};
var retryBusySync = (fn) => {
  const method = (path, opt) => {
    const max = opt.maxRetries || MAXRETRIES;
    let retries = 0;
    while (true) {
      try {
        return fn(path);
      } catch (er) {
        if (isFsError(er) && er.path === path && codes.has(er.code) && retries < max) {
          retries++;
          continue;
        }
        throw er;
      }
    }
  };
  return method;
};

// ../../node_modules/.vlt/~npm~rimraf@6.1.3/node_modules/rimraf/dist/esm/rimraf-move-remove.js
import { basename, parse as parse4, resolve as resolve4 } from "node:path";

// ../../node_modules/.vlt/~npm~rimraf@6.1.3/node_modules/rimraf/dist/esm/default-tmp.js
import { tmpdir } from "node:os";
import { parse as parse3, resolve as resolve3 } from "node:path";
var { stat } = promises;
var isDirSync = (path) => {
  try {
    return statSync(path).isDirectory();
  } catch {
    return false;
  }
};
var isDir = (path) => stat(path).then((st) => st.isDirectory(), () => false);
var win32DefaultTmp = async (path) => {
  const { root } = parse3(path);
  const tmp = tmpdir();
  const { root: tmpRoot } = parse3(tmp);
  if (root.toLowerCase() === tmpRoot.toLowerCase()) {
    return tmp;
  }
  const driveTmp = resolve3(root, "/temp");
  if (await isDir(driveTmp)) {
    return driveTmp;
  }
  return root;
};
var win32DefaultTmpSync = (path) => {
  const { root } = parse3(path);
  const tmp = tmpdir();
  const { root: tmpRoot } = parse3(tmp);
  if (root.toLowerCase() === tmpRoot.toLowerCase()) {
    return tmp;
  }
  const driveTmp = resolve3(root, "/temp");
  if (isDirSync(driveTmp)) {
    return driveTmp;
  }
  return root;
};
var posixDefaultTmp = async () => tmpdir();
var posixDefaultTmpSync = () => tmpdir();
var defaultTmp = process.platform === "win32" ? win32DefaultTmp : posixDefaultTmp;
var defaultTmpSync = process.platform === "win32" ? win32DefaultTmpSync : posixDefaultTmpSync;

// ../../node_modules/.vlt/~npm~rimraf@6.1.3/node_modules/rimraf/dist/esm/rimraf-move-remove.js
var { lstat: lstat2, rename, unlink: unlink2, rmdir: rmdir2 } = promises;
var uniqueFilename = (path) => `.${basename(path)}.${Math.random()}`;
var unlinkFixEPERM = fixEPERM(unlink2);
var unlinkFixEPERMSync = fixEPERMSync(unlinkSync);
var rimrafMoveRemove = async (path, opt) => {
  opt?.signal?.throwIfAborted();
  return await ignoreENOENT(lstat2(path).then((stat2) => rimrafMoveRemoveDir(path, opt, stat2))) ?? true;
};
var rimrafMoveRemoveDir = async (path, opt, ent) => {
  opt?.signal?.throwIfAborted();
  if (!opt.tmp) {
    return rimrafMoveRemoveDir(path, { ...opt, tmp: await defaultTmp(path) }, ent);
  }
  if (path === opt.tmp && parse4(path).root !== path) {
    throw new Error("cannot delete temp directory used for deletion");
  }
  const entries = ent.isDirectory() ? await readdirOrError(path) : null;
  if (!Array.isArray(entries)) {
    if (entries) {
      if (errorCode(entries) === "ENOENT") {
        return true;
      }
      if (errorCode(entries) !== "ENOTDIR") {
        throw entries;
      }
    }
    if (opt.filter && !await opt.filter(path, ent)) {
      return false;
    }
    await ignoreENOENT(tmpUnlink(path, opt.tmp, unlinkFixEPERM));
    return true;
  }
  const removedAll = (await Promise.all(entries.map((ent2) => rimrafMoveRemoveDir(resolve4(path, ent2.name), opt, ent2)))).every((v) => v === true);
  if (!removedAll) {
    return false;
  }
  if (opt.preserveRoot === false && path === parse4(path).root) {
    return false;
  }
  if (opt.filter && !await opt.filter(path, ent)) {
    return false;
  }
  await ignoreENOENT(tmpUnlink(path, opt.tmp, rmdir2));
  return true;
};
var tmpUnlink = async (path, tmp, rm2) => {
  const tmpFile = resolve4(tmp, uniqueFilename(path));
  await rename(path, tmpFile);
  return await rm2(tmpFile);
};
var rimrafMoveRemoveSync = (path, opt) => {
  opt?.signal?.throwIfAborted();
  return ignoreENOENTSync(() => rimrafMoveRemoveDirSync(path, opt, lstatSync(path))) ?? true;
};
var rimrafMoveRemoveDirSync = (path, opt, ent) => {
  opt?.signal?.throwIfAborted();
  if (!opt.tmp) {
    return rimrafMoveRemoveDirSync(path, { ...opt, tmp: defaultTmpSync(path) }, ent);
  }
  const tmp = opt.tmp;
  if (path === opt.tmp && parse4(path).root !== path) {
    throw new Error("cannot delete temp directory used for deletion");
  }
  const entries = ent.isDirectory() ? readdirOrErrorSync(path) : null;
  if (!Array.isArray(entries)) {
    if (entries) {
      if (errorCode(entries) === "ENOENT") {
        return true;
      }
      if (errorCode(entries) !== "ENOTDIR") {
        throw entries;
      }
    }
    if (opt.filter && !opt.filter(path, ent)) {
      return false;
    }
    ignoreENOENTSync(() => tmpUnlinkSync(path, tmp, unlinkFixEPERMSync));
    return true;
  }
  let removedAll = true;
  for (const ent2 of entries) {
    const p = resolve4(path, ent2.name);
    removedAll = rimrafMoveRemoveDirSync(p, opt, ent2) && removedAll;
  }
  if (!removedAll) {
    return false;
  }
  if (opt.preserveRoot === false && path === parse4(path).root) {
    return false;
  }
  if (opt.filter && !opt.filter(path, ent)) {
    return false;
  }
  ignoreENOENTSync(() => tmpUnlinkSync(path, tmp, rmdirSync));
  return true;
};
var tmpUnlinkSync = (path, tmp, rmSync2) => {
  const tmpFile = resolve4(tmp, uniqueFilename(path));
  renameSync(path, tmpFile);
  return rmSync2(tmpFile);
};

// ../../node_modules/.vlt/~npm~rimraf@6.1.3/node_modules/rimraf/dist/esm/rimraf-windows.js
var { unlink: unlink3, rmdir: rmdir3, lstat: lstat3 } = promises;
var rimrafWindowsFile = retryBusy(fixEPERM(unlink3));
var rimrafWindowsFileSync = retryBusySync(fixEPERMSync(unlinkSync));
var rimrafWindowsDirRetry = retryBusy(fixEPERM(rmdir3));
var rimrafWindowsDirRetrySync = retryBusySync(fixEPERMSync(rmdirSync));
var rimrafWindowsDirMoveRemoveFallback = async (path, { filter, ...opt }) => {
  opt?.signal?.throwIfAborted();
  try {
    await rimrafWindowsDirRetry(path, opt);
    return true;
  } catch (er) {
    if (errorCode(er) === "ENOTEMPTY") {
      return rimrafMoveRemove(path, opt);
    }
    throw er;
  }
};
var rimrafWindowsDirMoveRemoveFallbackSync = (path, { filter, ...opt }) => {
  opt?.signal?.throwIfAborted();
  try {
    rimrafWindowsDirRetrySync(path, opt);
    return true;
  } catch (er) {
    if (errorCode(er) === "ENOTEMPTY") {
      return rimrafMoveRemoveSync(path, opt);
    }
    throw er;
  }
};
var START = /* @__PURE__ */ Symbol("start");
var CHILD = /* @__PURE__ */ Symbol("child");
var FINISH = /* @__PURE__ */ Symbol("finish");
var rimrafWindows = async (path, opt) => {
  opt?.signal?.throwIfAborted();
  return await ignoreENOENT(lstat3(path).then((stat2) => rimrafWindowsDir(path, opt, stat2, START))) ?? true;
};
var rimrafWindowsSync = (path, opt) => {
  opt?.signal?.throwIfAborted();
  return ignoreENOENTSync(() => rimrafWindowsDirSync(path, opt, lstatSync(path), START)) ?? true;
};
var rimrafWindowsDir = async (path, opt, ent, state = START) => {
  opt?.signal?.throwIfAborted();
  const entries = ent.isDirectory() ? await readdirOrError(path) : null;
  if (!Array.isArray(entries)) {
    if (entries) {
      if (errorCode(entries) === "ENOENT") {
        return true;
      }
      if (errorCode(entries) !== "ENOTDIR") {
        throw entries;
      }
    }
    if (opt.filter && !await opt.filter(path, ent)) {
      return false;
    }
    await ignoreENOENT(rimrafWindowsFile(path, opt));
    return true;
  }
  const s = state === START ? CHILD : state;
  const removedAll = (await Promise.all(entries.map((ent2) => rimrafWindowsDir(resolve5(path, ent2.name), opt, ent2, s)))).every((v) => v === true);
  if (state === START) {
    return rimrafWindowsDir(path, opt, ent, FINISH);
  } else if (state === FINISH) {
    if (opt.preserveRoot === false && path === parse5(path).root) {
      return false;
    }
    if (!removedAll) {
      return false;
    }
    if (opt.filter && !await opt.filter(path, ent)) {
      return false;
    }
    await ignoreENOENT(rimrafWindowsDirMoveRemoveFallback(path, opt));
  }
  return true;
};
var rimrafWindowsDirSync = (path, opt, ent, state = START) => {
  const entries = ent.isDirectory() ? readdirOrErrorSync(path) : null;
  if (!Array.isArray(entries)) {
    if (entries) {
      if (errorCode(entries) === "ENOENT") {
        return true;
      }
      if (errorCode(entries) !== "ENOTDIR") {
        throw entries;
      }
    }
    if (opt.filter && !opt.filter(path, ent)) {
      return false;
    }
    ignoreENOENTSync(() => rimrafWindowsFileSync(path, opt));
    return true;
  }
  let removedAll = true;
  for (const ent2 of entries) {
    const s = state === START ? CHILD : state;
    const p = resolve5(path, ent2.name);
    removedAll = rimrafWindowsDirSync(p, opt, ent2, s) && removedAll;
  }
  if (state === START) {
    return rimrafWindowsDirSync(path, opt, ent, FINISH);
  } else if (state === FINISH) {
    if (opt.preserveRoot === false && path === parse5(path).root) {
      return false;
    }
    if (!removedAll) {
      return false;
    }
    if (opt.filter && !opt.filter(path, ent)) {
      return false;
    }
    ignoreENOENTSync(() => rimrafWindowsDirMoveRemoveFallbackSync(path, opt));
  }
  return true;
};

// ../../node_modules/.vlt/~npm~rimraf@6.1.3/node_modules/rimraf/dist/esm/rimraf-manual.js
var rimrafManual = process.platform === "win32" ? rimrafWindows : rimrafPosix;
var rimrafManualSync = process.platform === "win32" ? rimrafWindowsSync : rimrafPosixSync;

// ../../node_modules/.vlt/~npm~rimraf@6.1.3/node_modules/rimraf/dist/esm/rimraf-native.js
var { rm } = promises;
var rimrafNative = async (path, opt) => {
  await rm(path, {
    ...opt,
    force: true,
    recursive: true
  });
  return true;
};
var rimrafNativeSync = (path, opt) => {
  rmSync(path, {
    ...opt,
    force: true,
    recursive: true
  });
  return true;
};

// ../../node_modules/.vlt/~npm~rimraf@6.1.3/node_modules/rimraf/dist/esm/use-native.js
var [major = 0, minor = 0] = process.version.replace(/^v/, "").split(".").map((v) => parseInt(v, 10));
var hasNative = major > 14 || major === 14 && minor >= 14;
var useNative = !hasNative || process.platform === "win32" ? () => false : (opt) => !opt?.signal && !opt?.filter;
var useNativeSync = !hasNative || process.platform === "win32" ? () => false : (opt) => !opt?.signal && !opt?.filter;

// ../../node_modules/.vlt/~npm~rimraf@6.1.3/node_modules/rimraf/dist/esm/index.js
var wrap = (fn) => async (path, opt) => {
  const options = optArg(opt);
  if (options.glob) {
    path = await Ze(path, options.glob);
  }
  if (Array.isArray(path)) {
    return !!(await Promise.all(path.map((p) => fn(path_arg_default(p, options), options)))).reduce((a, b) => a && b, true);
  } else {
    return !!await fn(path_arg_default(path, options), options);
  }
};
var wrapSync = (fn) => (path, opt) => {
  const options = optArgSync(opt);
  if (options.glob) {
    path = ts(path, options.glob);
  }
  if (Array.isArray(path)) {
    return !!path.map((p) => fn(path_arg_default(p, options), options)).reduce((a, b) => a && b, true);
  } else {
    return !!fn(path_arg_default(path, options), options);
  }
};
var nativeSync = wrapSync(rimrafNativeSync);
var native = Object.assign(wrap(rimrafNative), {
  sync: nativeSync
});
var manualSync = wrapSync(rimrafManualSync);
var manual = Object.assign(wrap(rimrafManual), {
  sync: manualSync
});
var windowsSync = wrapSync(rimrafWindowsSync);
var windows = Object.assign(wrap(rimrafWindows), {
  sync: windowsSync
});
var posixSync = wrapSync(rimrafPosixSync);
var posix = Object.assign(wrap(rimrafPosix), { sync: posixSync });
var moveRemoveSync = wrapSync(rimrafMoveRemoveSync);
var moveRemove = Object.assign(wrap(rimrafMoveRemove), {
  sync: moveRemoveSync
});
var rimrafSync = wrapSync((path, opt) => useNativeSync(opt) ? rimrafNativeSync(path, opt) : rimrafManualSync(path, opt));
var rimraf_ = wrap((path, opt) => useNative(opt) ? rimrafNative(path, opt) : rimrafManual(path, opt));
var rimraf = Object.assign(rimraf_, {
  rimraf: rimraf_,
  sync: rimrafSync,
  rimrafSync,
  manual,
  manualSync,
  native,
  nativeSync,
  posix,
  posixSync,
  windows,
  windowsSync,
  moveRemove,
  moveRemoveSync
});
rimraf.rimraf = rimraf;

export {
  rimraf
};
