var global = globalThis;
import {Buffer} from "node:buffer";
import {setTimeout as _vlt_setTimeout,clearTimeout as _vlt_clearTimeout,setImmediate as _vlt_setImmediate,clearImmediate as _vlt_clearImmediate,setInterval as _vlt_setInterval,clearInterval as _vlt_clearInterval} from "node:timers";
globalThis.setTimeout = _vlt_setTimeout;
globalThis.clearTimeout = _vlt_clearTimeout;
globalThis.setImmediate = _vlt_setImmediate;
globalThis.clearImmediate = _vlt_clearImmediate;
globalThis.setInterval = _vlt_setInterval;
globalThis.clearInterval = _vlt_clearInterval;
import {createRequire as _vlt_createRequire} from "node:module";
var require = _vlt_createRequire(import.meta.filename);
import {
  actual,
  callLimit,
  createVirtualRoot
} from "./chunk-3Y3TZ5SX.js";
import {
  SecurityArchive
} from "./chunk-K4X2TU3S.js";
import {
  error
} from "./chunk-WZWDS3W4.js";

// ../../src/cli-sdk/src/query-host-contexts.ts
import { homedir as homedir2 } from "node:os";
import { parse, posix } from "node:path";

// ../../src/cli-sdk/src/read-project-folders.ts
import { availableParallelism, homedir } from "node:os";
import { dirname } from "node:path";
var limit = Math.max(availableParallelism() - 1, 1) * 8;
var home;
try {
  home = homedir();
} catch {
  home = dirname(process.cwd());
}
var ignoredHomedirFolderNames = [
  "downloads",
  "movies",
  "music",
  "pictures",
  "private",
  "library",
  "dropbox"
].concat(
  process.platform === "darwin" ? [
    "public",
    "private",
    "applications",
    "applications (parallels)",
    "sites",
    "sync"
  ] : process.platform === "win32" ? [
    "appdata",
    "application data",
    "favorites",
    "links",
    "videos",
    "contacts",
    "searches"
  ] : ["videos", "public"]
);
var readProjectFolders = async ({
  path = home,
  scurry,
  userDefinedProjectPaths
}, maxDepth = 7) => {
  const result = [];
  const homeEntry = scurry.cwd.resolve(home);
  const paths = userDefinedProjectPaths.length ? userDefinedProjectPaths : [path];
  const step = (entry, depth) => async () => {
    try {
      for (const child of await entry.readdir()) {
        if (await collectResult(
          child,
          result,
          scurry,
          entry === homeEntry,
          depth,
          maxDepth
        )) {
          traverse.push(step(child, depth + 1));
        }
      }
    } catch {
    }
  };
  let traverse = (await Promise.all(paths.map((path2) => scurry.lstat(path2)))).filter((p) => !!p).map((p) => step(p, 0));
  let t;
  do {
    t = traverse;
    traverse = [];
    await callLimit(t, { limit });
  } while (traverse.length);
  return result;
};
var collectResult = async (entry, result, scurry, fromHome, depth, maxDepth) => {
  if (!entry.isDirectory() || entry.isSymbolicLink() || entry.name === "node_modules" || fromHome && ignoredHomedirFolderNames.includes(entry.name.toLowerCase()) || entry.name.startsWith(".") || depth > maxDepth) {
    return false;
  }
  const resolved = entry.fullpath();
  const statPackageJson = await scurry.lstat(`${resolved}/package.json`).catch(() => {
  });
  const hasValidPackageJson = statPackageJson && statPackageJson.isFile() && !statPackageJson.isSymbolicLink();
  if (hasValidPackageJson) result.push(entry);
  return !hasValidPackageJson;
};

// ../../src/cli-sdk/src/reload-config.ts
var reloadConfig = async (folder) => {
  try {
    const { unload } = await import("./src-JC3ZUYWO.js");
    unload("user");
    unload("project");
  } catch {
  }
  const { Config } = await import("./config-ZE3CG7MN.js");
  return Config.load(folder, process.argv, true);
};

// ../../src/cli-sdk/src/query-host-contexts.ts
var foundHome;
try {
  foundHome = posix.format(parse(homedir2()));
} catch {
}
var home2 = foundHome ?? posix.dirname(posix.format(parse(process.cwd())));
var isVltInstalled = (folder) => !!folder.resolve("node_modules/.vlt").lstatSync()?.isDirectory() || !!folder.resolve("node_modules/.vlt-lock.json").lstatSync()?.isFile();
var getPossibleProjectKeys = (folder, scurry) => {
  const relativePath = posix.relative(
    scurry.cwd.fullpathPosix(),
    folder.fullpathPosix()
  );
  const absolutePath = folder.fullpathPosix();
  const homeRelativePath = posix.relative(
    scurry.resolvePosix(home2),
    folder.fullpathPosix()
  );
  const dotRelativeKey = relativePath === "" ? "file:." : `file:./${relativePath}`;
  const relativeKey = `file:${relativePath}`;
  const absoluteKey = `file:${absolutePath}`;
  const homeRelativeKey = `file:~/${homeRelativePath}`;
  const keys = [
    relativeKey,
    dotRelativeKey,
    absoluteKey,
    homeRelativeKey,
    `${relativeKey}/`,
    `${dotRelativeKey}/`,
    `${absoluteKey}/`,
    `${homeRelativeKey}/`
  ];
  return new Set(keys);
};
var createHostContextsMap = async (conf) => {
  const hostContexts = /* @__PURE__ */ new Map();
  const { scurry } = conf.options;
  const projectFolders = await readProjectFolders({
    scurry,
    userDefinedProjectPaths: conf.options["dashboard-root"] ?? []
  });
  for (const folder of projectFolders) {
    const retrieveProjectGraph = async () => {
      const initialEdges = [];
      const initialNodes = [];
      const config = await reloadConfig(folder.fullpath());
      const graph = actual.load({
        ...config.options,
        projectRoot: folder.fullpath(),
        skipLoadingNodesOnModifiersChange: false
      });
      initialEdges.push(...graph.edges);
      initialNodes.push(...graph.nodes.values());
      const securityArchive = await SecurityArchive.start({
        nodes: initialNodes
      });
      return {
        initialEdges,
        initialNodes,
        edges: [],
        nodes: [graph.mainImporter],
        securityArchive
      };
    };
    for (const path of getPossibleProjectKeys(folder, scurry)) {
      if (!hostContexts.has(path)) {
        hostContexts.set(path, retrieveProjectGraph);
      }
    }
  }
  hostContexts.set("local", async () => {
    const initialEdges = [];
    const initialNodes = [];
    const mainImporters = [];
    for (const folder of projectFolders) {
      try {
        const config = await reloadConfig(folder.fullpath());
        if (!isVltInstalled(folder)) {
          continue;
        }
        const graph = actual.load({
          ...config.options,
          projectRoot: folder.fullpath(),
          skipLoadingNodesOnModifiersChange: false
        });
        initialEdges.push(...graph.edges);
        initialNodes.push(...graph.nodes.values());
        mainImporters.push(graph.mainImporter);
      } catch (_error) {
        continue;
      }
    }
    const securityArchive = await SecurityArchive.start({
      nodes: initialNodes
    });
    const virtualRoot = createVirtualRoot(
      "local",
      conf.options,
      mainImporters
    );
    if (!virtualRoot) {
      throw error("Failed to create virtual root for local context");
    }
    return {
      initialEdges,
      initialNodes,
      edges: [],
      nodes: [virtualRoot],
      securityArchive
    };
  });
  return hostContexts;
};

export {
  createHostContextsMap
};
