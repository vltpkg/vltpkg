var global = globalThis;
import {Buffer} from "node:buffer";
import {setTimeout as _vlt_setTimeout,clearTimeout as _vlt_clearTimeout,setImmediate as _vlt_setImmediate,clearImmediate as _vlt_clearImmediate,setInterval as _vlt_setInterval,clearInterval as _vlt_clearInterval} from "node:timers";
globalThis.setTimeout = _vlt_setTimeout;
globalThis.clearTimeout = _vlt_clearTimeout;
globalThis.setImmediate = _vlt_setImmediate;
globalThis.clearImmediate = _vlt_clearImmediate;
globalThis.setInterval = _vlt_setInterval;
globalThis.clearInterval = _vlt_clearInterval;
import {createRequire as _vlt_createRequire} from "node:module";
var require = _vlt_createRequire(import.meta.filename);
import {
  XDG
} from "./chunk-XNLSTHDK.js";
import {
  error
} from "./chunk-WZWDS3W4.js";

// ../../node_modules/.vlt/~npm~jackspeak@4.2.3/node_modules/jackspeak/dist/esm/index.js
import { inspect, parseArgs } from "node:util";

// ../../node_modules/.vlt/~npm~@isaacs+cliui@9.0.0/node_modules/@isaacs/cliui/dist/esm/index.min.js
var $ = ({ onlyFirst: F = false } = {}) => {
  let t = "(?:\\u001B\\][\\s\\S]*?(?:\\u0007|\\u001B\\u005C|\\u009C))|[\\u001B\\u009B][[\\]()#;?]*(?:\\d{1,4}(?:[;:]\\d{0,4})*)?[\\dA-PR-TZcf-nq-uy=><~]";
  return new RegExp(t, F ? void 0 : "g");
};
var R = $();
var o = (F) => F.replace(R, "");
var y = (F) => {
  var u = F.charCodeAt(0), C = F.length == 2 ? F.charCodeAt(1) : 0, D = u;
  return 55296 <= u && u <= 56319 && 56320 <= C && C <= 57343 && (u &= 1023, C &= 1023, D = u << 10 | C, D += 65536), D == 12288 || 65281 <= D && D <= 65376 || 65504 <= D && D <= 65510 ? "F" : D == 8361 || 65377 <= D && D <= 65470 || 65474 <= D && D <= 65479 || 65482 <= D && D <= 65487 || 65490 <= D && D <= 65495 || 65498 <= D && D <= 65500 || 65512 <= D && D <= 65518 ? "H" : 4352 <= D && D <= 4447 || 4515 <= D && D <= 4519 || 4602 <= D && D <= 4607 || 9001 <= D && D <= 9002 || 11904 <= D && D <= 11929 || 11931 <= D && D <= 12019 || 12032 <= D && D <= 12245 || 12272 <= D && D <= 12283 || 12289 <= D && D <= 12350 || 12353 <= D && D <= 12438 || 12441 <= D && D <= 12543 || 12549 <= D && D <= 12589 || 12593 <= D && D <= 12686 || 12688 <= D && D <= 12730 || 12736 <= D && D <= 12771 || 12784 <= D && D <= 12830 || 12832 <= D && D <= 12871 || 12880 <= D && D <= 13054 || 13056 <= D && D <= 19903 || 19968 <= D && D <= 42124 || 42128 <= D && D <= 42182 || 43360 <= D && D <= 43388 || 44032 <= D && D <= 55203 || 55216 <= D && D <= 55238 || 55243 <= D && D <= 55291 || 63744 <= D && D <= 64255 || 65040 <= D && D <= 65049 || 65072 <= D && D <= 65106 || 65108 <= D && D <= 65126 || 65128 <= D && D <= 65131 || 110592 <= D && D <= 110593 || 127488 <= D && D <= 127490 || 127504 <= D && D <= 127546 || 127552 <= D && D <= 127560 || 127568 <= D && D <= 127569 || 131072 <= D && D <= 194367 || 177984 <= D && D <= 196605 || 196608 <= D && D <= 262141 ? "W" : 32 <= D && D <= 126 || 162 <= D && D <= 163 || 165 <= D && D <= 166 || D == 172 || D == 175 || 10214 <= D && D <= 10221 || 10629 <= D && D <= 10630 ? "Na" : D == 161 || D == 164 || 167 <= D && D <= 168 || D == 170 || 173 <= D && D <= 174 || 176 <= D && D <= 180 || 182 <= D && D <= 186 || 188 <= D && D <= 191 || D == 198 || D == 208 || 215 <= D && D <= 216 || 222 <= D && D <= 225 || D == 230 || 232 <= D && D <= 234 || 236 <= D && D <= 237 || D == 240 || 242 <= D && D <= 243 || 247 <= D && D <= 250 || D == 252 || D == 254 || D == 257 || D == 273 || D == 275 || D == 283 || 294 <= D && D <= 295 || D == 299 || 305 <= D && D <= 307 || D == 312 || 319 <= D && D <= 322 || D == 324 || 328 <= D && D <= 331 || D == 333 || 338 <= D && D <= 339 || 358 <= D && D <= 359 || D == 363 || D == 462 || D == 464 || D == 466 || D == 468 || D == 470 || D == 472 || D == 474 || D == 476 || D == 593 || D == 609 || D == 708 || D == 711 || 713 <= D && D <= 715 || D == 717 || D == 720 || 728 <= D && D <= 731 || D == 733 || D == 735 || 768 <= D && D <= 879 || 913 <= D && D <= 929 || 931 <= D && D <= 937 || 945 <= D && D <= 961 || 963 <= D && D <= 969 || D == 1025 || 1040 <= D && D <= 1103 || D == 1105 || D == 8208 || 8211 <= D && D <= 8214 || 8216 <= D && D <= 8217 || 8220 <= D && D <= 8221 || 8224 <= D && D <= 8226 || 8228 <= D && D <= 8231 || D == 8240 || 8242 <= D && D <= 8243 || D == 8245 || D == 8251 || D == 8254 || D == 8308 || D == 8319 || 8321 <= D && D <= 8324 || D == 8364 || D == 8451 || D == 8453 || D == 8457 || D == 8467 || D == 8470 || 8481 <= D && D <= 8482 || D == 8486 || D == 8491 || 8531 <= D && D <= 8532 || 8539 <= D && D <= 8542 || 8544 <= D && D <= 8555 || 8560 <= D && D <= 8569 || D == 8585 || 8592 <= D && D <= 8601 || 8632 <= D && D <= 8633 || D == 8658 || D == 8660 || D == 8679 || D == 8704 || 8706 <= D && D <= 8707 || 8711 <= D && D <= 8712 || D == 8715 || D == 8719 || D == 8721 || D == 8725 || D == 8730 || 8733 <= D && D <= 8736 || D == 8739 || D == 8741 || 8743 <= D && D <= 8748 || D == 8750 || 8756 <= D && D <= 8759 || 8764 <= D && D <= 8765 || D == 8776 || D == 8780 || D == 8786 || 8800 <= D && D <= 8801 || 8804 <= D && D <= 8807 || 8810 <= D && D <= 8811 || 8814 <= D && D <= 8815 || 8834 <= D && D <= 8835 || 8838 <= D && D <= 8839 || D == 8853 || D == 8857 || D == 8869 || D == 8895 || D == 8978 || 9312 <= D && D <= 9449 || 9451 <= D && D <= 9547 || 9552 <= D && D <= 9587 || 9600 <= D && D <= 9615 || 9618 <= D && D <= 9621 || 9632 <= D && D <= 9633 || 9635 <= D && D <= 9641 || 9650 <= D && D <= 9651 || 9654 <= D && D <= 9655 || 9660 <= D && D <= 9661 || 9664 <= D && D <= 9665 || 9670 <= D && D <= 9672 || D == 9675 || 9678 <= D && D <= 9681 || 9698 <= D && D <= 9701 || D == 9711 || 9733 <= D && D <= 9734 || D == 9737 || 9742 <= D && D <= 9743 || 9748 <= D && D <= 9749 || D == 9756 || D == 9758 || D == 9792 || D == 9794 || 9824 <= D && D <= 9825 || 9827 <= D && D <= 9829 || 9831 <= D && D <= 9834 || 9836 <= D && D <= 9837 || D == 9839 || 9886 <= D && D <= 9887 || 9918 <= D && D <= 9919 || 9924 <= D && D <= 9933 || 9935 <= D && D <= 9953 || D == 9955 || 9960 <= D && D <= 9983 || D == 10045 || D == 10071 || 10102 <= D && D <= 10111 || 11093 <= D && D <= 11097 || 12872 <= D && D <= 12879 || 57344 <= D && D <= 63743 || 65024 <= D && D <= 65039 || D == 65533 || 127232 <= D && D <= 127242 || 127248 <= D && D <= 127277 || 127280 <= D && D <= 127337 || 127344 <= D && D <= 127386 || 917760 <= D && D <= 917999 || 983040 <= D && D <= 1048573 || 1048576 <= D && D <= 1114109 ? "A" : "N";
};
var W = () => /\uD83C\uDFF4\uDB40\uDC67\uDB40\uDC62(?:\uDB40\uDC77\uDB40\uDC6C\uDB40\uDC73|\uDB40\uDC73\uDB40\uDC63\uDB40\uDC74|\uDB40\uDC65\uDB40\uDC6E\uDB40\uDC67)\uDB40\uDC7F|(?:\uD83E\uDDD1\uD83C\uDFFF\u200D\u2764\uFE0F\u200D(?:\uD83D\uDC8B\u200D)?\uD83E\uDDD1|\uD83D\uDC69\uD83C\uDFFF\u200D\uD83E\uDD1D\u200D(?:\uD83D[\uDC68\uDC69]))(?:\uD83C[\uDFFB-\uDFFE])|(?:\uD83E\uDDD1\uD83C\uDFFE\u200D\u2764\uFE0F\u200D(?:\uD83D\uDC8B\u200D)?\uD83E\uDDD1|\uD83D\uDC69\uD83C\uDFFE\u200D\uD83E\uDD1D\u200D(?:\uD83D[\uDC68\uDC69]))(?:\uD83C[\uDFFB-\uDFFD\uDFFF])|(?:\uD83E\uDDD1\uD83C\uDFFD\u200D\u2764\uFE0F\u200D(?:\uD83D\uDC8B\u200D)?\uD83E\uDDD1|\uD83D\uDC69\uD83C\uDFFD\u200D\uD83E\uDD1D\u200D(?:\uD83D[\uDC68\uDC69]))(?:\uD83C[\uDFFB\uDFFC\uDFFE\uDFFF])|(?:\uD83E\uDDD1\uD83C\uDFFC\u200D\u2764\uFE0F\u200D(?:\uD83D\uDC8B\u200D)?\uD83E\uDDD1|\uD83D\uDC69\uD83C\uDFFC\u200D\uD83E\uDD1D\u200D(?:\uD83D[\uDC68\uDC69]))(?:\uD83C[\uDFFB\uDFFD-\uDFFF])|(?:\uD83E\uDDD1\uD83C\uDFFB\u200D\u2764\uFE0F\u200D(?:\uD83D\uDC8B\u200D)?\uD83E\uDDD1|\uD83D\uDC69\uD83C\uDFFB\u200D\uD83E\uDD1D\u200D(?:\uD83D[\uDC68\uDC69]))(?:\uD83C[\uDFFC-\uDFFF])|\uD83D\uDC68(?:\uD83C\uDFFB(?:\u200D(?:\u2764\uFE0F\u200D(?:\uD83D\uDC8B\u200D\uD83D\uDC68(?:\uD83C[\uDFFB-\uDFFF])|\uD83D\uDC68(?:\uD83C[\uDFFB-\uDFFF]))|\uD83E\uDD1D\u200D\uD83D\uDC68(?:\uD83C[\uDFFC-\uDFFF])|[\u2695\u2696\u2708]\uFE0F|\uD83C[\uDF3E\uDF73\uDF7C\uDF93\uDFA4\uDFA8\uDFEB\uDFED]|\uD83D[\uDCBB\uDCBC\uDD27\uDD2C\uDE80\uDE92]|\uD83E[\uDDAF-\uDDB3\uDDBC\uDDBD]))?|(?:\uD83C[\uDFFC-\uDFFF])\u200D\u2764\uFE0F\u200D(?:\uD83D\uDC8B\u200D\uD83D\uDC68(?:\uD83C[\uDFFB-\uDFFF])|\uD83D\uDC68(?:\uD83C[\uDFFB-\uDFFF]))|\u200D(?:\u2764\uFE0F\u200D(?:\uD83D\uDC8B\u200D)?\uD83D\uDC68|(?:\uD83D[\uDC68\uDC69])\u200D(?:\uD83D\uDC66\u200D\uD83D\uDC66|\uD83D\uDC67\u200D(?:\uD83D[\uDC66\uDC67]))|\uD83D\uDC66\u200D\uD83D\uDC66|\uD83D\uDC67\u200D(?:\uD83D[\uDC66\uDC67])|\uD83C[\uDF3E\uDF73\uDF7C\uDF93\uDFA4\uDFA8\uDFEB\uDFED]|\uD83D[\uDCBB\uDCBC\uDD27\uDD2C\uDE80\uDE92]|\uD83E[\uDDAF-\uDDB3\uDDBC\uDDBD])|\uD83C\uDFFF\u200D(?:\uD83E\uDD1D\u200D\uD83D\uDC68(?:\uD83C[\uDFFB-\uDFFE])|\uD83C[\uDF3E\uDF73\uDF7C\uDF93\uDFA4\uDFA8\uDFEB\uDFED]|\uD83D[\uDCBB\uDCBC\uDD27\uDD2C\uDE80\uDE92]|\uD83E[\uDDAF-\uDDB3\uDDBC\uDDBD])|\uD83C\uDFFE\u200D(?:\uD83E\uDD1D\u200D\uD83D\uDC68(?:\uD83C[\uDFFB-\uDFFD\uDFFF])|\uD83C[\uDF3E\uDF73\uDF7C\uDF93\uDFA4\uDFA8\uDFEB\uDFED]|\uD83D[\uDCBB\uDCBC\uDD27\uDD2C\uDE80\uDE92]|\uD83E[\uDDAF-\uDDB3\uDDBC\uDDBD])|\uD83C\uDFFD\u200D(?:\uD83E\uDD1D\u200D\uD83D\uDC68(?:\uD83C[\uDFFB\uDFFC\uDFFE\uDFFF])|\uD83C[\uDF3E\uDF73\uDF7C\uDF93\uDFA4\uDFA8\uDFEB\uDFED]|\uD83D[\uDCBB\uDCBC\uDD27\uDD2C\uDE80\uDE92]|\uD83E[\uDDAF-\uDDB3\uDDBC\uDDBD])|\uD83C\uDFFC\u200D(?:\uD83E\uDD1D\u200D\uD83D\uDC68(?:\uD83C[\uDFFB\uDFFD-\uDFFF])|\uD83C[\uDF3E\uDF73\uDF7C\uDF93\uDFA4\uDFA8\uDFEB\uDFED]|\uD83D[\uDCBB\uDCBC\uDD27\uDD2C\uDE80\uDE92]|\uD83E[\uDDAF-\uDDB3\uDDBC\uDDBD])|(?:\uD83C\uDFFF\u200D[\u2695\u2696\u2708]|\uD83C\uDFFE\u200D[\u2695\u2696\u2708]|\uD83C\uDFFD\u200D[\u2695\u2696\u2708]|\uD83C\uDFFC\u200D[\u2695\u2696\u2708]|\u200D[\u2695\u2696\u2708])\uFE0F|\u200D(?:(?:\uD83D[\uDC68\uDC69])\u200D(?:\uD83D[\uDC66\uDC67])|\uD83D[\uDC66\uDC67])|\uD83C\uDFFF|\uD83C\uDFFE|\uD83C\uDFFD|\uD83C\uDFFC)?|(?:\uD83D\uDC69(?:\uD83C\uDFFB\u200D\u2764\uFE0F\u200D(?:\uD83D\uDC8B\u200D(?:\uD83D[\uDC68\uDC69])|\uD83D[\uDC68\uDC69])|(?:\uD83C[\uDFFC-\uDFFF])\u200D\u2764\uFE0F\u200D(?:\uD83D\uDC8B\u200D(?:\uD83D[\uDC68\uDC69])|\uD83D[\uDC68\uDC69]))|\uD83E\uDDD1(?:\uD83C[\uDFFB-\uDFFF])\u200D\uD83E\uDD1D\u200D\uD83E\uDDD1)(?:\uD83C[\uDFFB-\uDFFF])|\uD83D\uDC69\u200D\uD83D\uDC69\u200D(?:\uD83D\uDC66\u200D\uD83D\uDC66|\uD83D\uDC67\u200D(?:\uD83D[\uDC66\uDC67]))|\uD83D\uDC69(?:\u200D(?:\u2764\uFE0F\u200D(?:\uD83D\uDC8B\u200D(?:\uD83D[\uDC68\uDC69])|\uD83D[\uDC68\uDC69])|\uD83C[\uDF3E\uDF73\uDF7C\uDF93\uDFA4\uDFA8\uDFEB\uDFED]|\uD83D[\uDCBB\uDCBC\uDD27\uDD2C\uDE80\uDE92]|\uD83E[\uDDAF-\uDDB3\uDDBC\uDDBD])|\uD83C\uDFFF\u200D(?:\uD83C[\uDF3E\uDF73\uDF7C\uDF93\uDFA4\uDFA8\uDFEB\uDFED]|\uD83D[\uDCBB\uDCBC\uDD27\uDD2C\uDE80\uDE92]|\uD83E[\uDDAF-\uDDB3\uDDBC\uDDBD])|\uD83C\uDFFE\u200D(?:\uD83C[\uDF3E\uDF73\uDF7C\uDF93\uDFA4\uDFA8\uDFEB\uDFED]|\uD83D[\uDCBB\uDCBC\uDD27\uDD2C\uDE80\uDE92]|\uD83E[\uDDAF-\uDDB3\uDDBC\uDDBD])|\uD83C\uDFFD\u200D(?:\uD83C[\uDF3E\uDF73\uDF7C\uDF93\uDFA4\uDFA8\uDFEB\uDFED]|\uD83D[\uDCBB\uDCBC\uDD27\uDD2C\uDE80\uDE92]|\uD83E[\uDDAF-\uDDB3\uDDBC\uDDBD])|\uD83C\uDFFC\u200D(?:\uD83C[\uDF3E\uDF73\uDF7C\uDF93\uDFA4\uDFA8\uDFEB\uDFED]|\uD83D[\uDCBB\uDCBC\uDD27\uDD2C\uDE80\uDE92]|\uD83E[\uDDAF-\uDDB3\uDDBC\uDDBD])|\uD83C\uDFFB\u200D(?:\uD83C[\uDF3E\uDF73\uDF7C\uDF93\uDFA4\uDFA8\uDFEB\uDFED]|\uD83D[\uDCBB\uDCBC\uDD27\uDD2C\uDE80\uDE92]|\uD83E[\uDDAF-\uDDB3\uDDBC\uDDBD]))|\uD83E\uDDD1(?:\u200D(?:\uD83E\uDD1D\u200D\uD83E\uDDD1|\uD83C[\uDF3E\uDF73\uDF7C\uDF84\uDF93\uDFA4\uDFA8\uDFEB\uDFED]|\uD83D[\uDCBB\uDCBC\uDD27\uDD2C\uDE80\uDE92]|\uD83E[\uDDAF-\uDDB3\uDDBC\uDDBD])|\uD83C\uDFFF\u200D(?:\uD83C[\uDF3E\uDF73\uDF7C\uDF84\uDF93\uDFA4\uDFA8\uDFEB\uDFED]|\uD83D[\uDCBB\uDCBC\uDD27\uDD2C\uDE80\uDE92]|\uD83E[\uDDAF-\uDDB3\uDDBC\uDDBD])|\uD83C\uDFFE\u200D(?:\uD83C[\uDF3E\uDF73\uDF7C\uDF84\uDF93\uDFA4\uDFA8\uDFEB\uDFED]|\uD83D[\uDCBB\uDCBC\uDD27\uDD2C\uDE80\uDE92]|\uD83E[\uDDAF-\uDDB3\uDDBC\uDDBD])|\uD83C\uDFFD\u200D(?:\uD83C[\uDF3E\uDF73\uDF7C\uDF84\uDF93\uDFA4\uDFA8\uDFEB\uDFED]|\uD83D[\uDCBB\uDCBC\uDD27\uDD2C\uDE80\uDE92]|\uD83E[\uDDAF-\uDDB3\uDDBC\uDDBD])|\uD83C\uDFFC\u200D(?:\uD83C[\uDF3E\uDF73\uDF7C\uDF84\uDF93\uDFA4\uDFA8\uDFEB\uDFED]|\uD83D[\uDCBB\uDCBC\uDD27\uDD2C\uDE80\uDE92]|\uD83E[\uDDAF-\uDDB3\uDDBC\uDDBD])|\uD83C\uDFFB\u200D(?:\uD83C[\uDF3E\uDF73\uDF7C\uDF84\uDF93\uDFA4\uDFA8\uDFEB\uDFED]|\uD83D[\uDCBB\uDCBC\uDD27\uDD2C\uDE80\uDE92]|\uD83E[\uDDAF-\uDDB3\uDDBC\uDDBD]))|\uD83D\uDC69\u200D\uD83D\uDC66\u200D\uD83D\uDC66|\uD83D\uDC69\u200D\uD83D\uDC69\u200D(?:\uD83D[\uDC66\uDC67])|\uD83D\uDC69\u200D\uD83D\uDC67\u200D(?:\uD83D[\uDC66\uDC67])|(?:\uD83D\uDC41\uFE0F\u200D\uD83D\uDDE8|\uD83E\uDDD1(?:\uD83C\uDFFF\u200D[\u2695\u2696\u2708]|\uD83C\uDFFE\u200D[\u2695\u2696\u2708]|\uD83C\uDFFD\u200D[\u2695\u2696\u2708]|\uD83C\uDFFC\u200D[\u2695\u2696\u2708]|\uD83C\uDFFB\u200D[\u2695\u2696\u2708]|\u200D[\u2695\u2696\u2708])|\uD83D\uDC69(?:\uD83C\uDFFF\u200D[\u2695\u2696\u2708]|\uD83C\uDFFE\u200D[\u2695\u2696\u2708]|\uD83C\uDFFD\u200D[\u2695\u2696\u2708]|\uD83C\uDFFC\u200D[\u2695\u2696\u2708]|\uD83C\uDFFB\u200D[\u2695\u2696\u2708]|\u200D[\u2695\u2696\u2708])|\uD83D\uDE36\u200D\uD83C\uDF2B|\uD83C\uDFF3\uFE0F\u200D\u26A7|\uD83D\uDC3B\u200D\u2744|(?:(?:\uD83C[\uDFC3\uDFC4\uDFCA]|\uD83D[\uDC6E\uDC70\uDC71\uDC73\uDC77\uDC81\uDC82\uDC86\uDC87\uDE45-\uDE47\uDE4B\uDE4D\uDE4E\uDEA3\uDEB4-\uDEB6]|\uD83E[\uDD26\uDD35\uDD37-\uDD39\uDD3D\uDD3E\uDDB8\uDDB9\uDDCD-\uDDCF\uDDD4\uDDD6-\uDDDD])(?:\uD83C[\uDFFB-\uDFFF])|\uD83D\uDC6F|\uD83E[\uDD3C\uDDDE\uDDDF])\u200D[\u2640\u2642]|(?:\u26F9|\uD83C[\uDFCB\uDFCC]|\uD83D\uDD75)(?:\uFE0F|\uD83C[\uDFFB-\uDFFF])\u200D[\u2640\u2642]|\uD83C\uDFF4\u200D\u2620|(?:\uD83C[\uDFC3\uDFC4\uDFCA]|\uD83D[\uDC6E\uDC70\uDC71\uDC73\uDC77\uDC81\uDC82\uDC86\uDC87\uDE45-\uDE47\uDE4B\uDE4D\uDE4E\uDEA3\uDEB4-\uDEB6]|\uD83E[\uDD26\uDD35\uDD37-\uDD39\uDD3D\uDD3E\uDDB8\uDDB9\uDDCD-\uDDCF\uDDD4\uDDD6-\uDDDD])\u200D[\u2640\u2642]|[\xA9\xAE\u203C\u2049\u2122\u2139\u2194-\u2199\u21A9\u21AA\u2328\u23CF\u23ED-\u23EF\u23F1\u23F2\u23F8-\u23FA\u24C2\u25AA\u25AB\u25B6\u25C0\u25FB\u25FC\u2600-\u2604\u260E\u2611\u2618\u2620\u2622\u2623\u2626\u262A\u262E\u262F\u2638-\u263A\u2640\u2642\u265F\u2660\u2663\u2665\u2666\u2668\u267B\u267E\u2692\u2694-\u2697\u2699\u269B\u269C\u26A0\u26A7\u26B0\u26B1\u26C8\u26CF\u26D1\u26D3\u26E9\u26F0\u26F1\u26F4\u26F7\u26F8\u2702\u2708\u2709\u270F\u2712\u2714\u2716\u271D\u2721\u2733\u2734\u2744\u2747\u2763\u27A1\u2934\u2935\u2B05-\u2B07\u3030\u303D\u3297\u3299]|\uD83C[\uDD70\uDD71\uDD7E\uDD7F\uDE02\uDE37\uDF21\uDF24-\uDF2C\uDF36\uDF7D\uDF96\uDF97\uDF99-\uDF9B\uDF9E\uDF9F\uDFCD\uDFCE\uDFD4-\uDFDF\uDFF5\uDFF7]|\uD83D[\uDC3F\uDCFD\uDD49\uDD4A\uDD6F\uDD70\uDD73\uDD76-\uDD79\uDD87\uDD8A-\uDD8D\uDDA5\uDDA8\uDDB1\uDDB2\uDDBC\uDDC2-\uDDC4\uDDD1-\uDDD3\uDDDC-\uDDDE\uDDE1\uDDE3\uDDE8\uDDEF\uDDF3\uDDFA\uDECB\uDECD-\uDECF\uDEE0-\uDEE5\uDEE9\uDEF0\uDEF3])\uFE0F|\uD83C\uDFF3\uFE0F\u200D\uD83C\uDF08|\uD83D\uDC69\u200D\uD83D\uDC67|\uD83D\uDC69\u200D\uD83D\uDC66|\uD83D\uDE35\u200D\uD83D\uDCAB|\uD83D\uDE2E\u200D\uD83D\uDCA8|\uD83D\uDC15\u200D\uD83E\uDDBA|\uD83E\uDDD1(?:\uD83C\uDFFF|\uD83C\uDFFE|\uD83C\uDFFD|\uD83C\uDFFC|\uD83C\uDFFB)?|\uD83D\uDC69(?:\uD83C\uDFFF|\uD83C\uDFFE|\uD83C\uDFFD|\uD83C\uDFFC|\uD83C\uDFFB)?|\uD83C\uDDFD\uD83C\uDDF0|\uD83C\uDDF6\uD83C\uDDE6|\uD83C\uDDF4\uD83C\uDDF2|\uD83D\uDC08\u200D\u2B1B|\u2764\uFE0F\u200D(?:\uD83D\uDD25|\uD83E\uDE79)|\uD83D\uDC41\uFE0F|\uD83C\uDFF3\uFE0F|\uD83C\uDDFF(?:\uD83C[\uDDE6\uDDF2\uDDFC])|\uD83C\uDDFE(?:\uD83C[\uDDEA\uDDF9])|\uD83C\uDDFC(?:\uD83C[\uDDEB\uDDF8])|\uD83C\uDDFB(?:\uD83C[\uDDE6\uDDE8\uDDEA\uDDEC\uDDEE\uDDF3\uDDFA])|\uD83C\uDDFA(?:\uD83C[\uDDE6\uDDEC\uDDF2\uDDF3\uDDF8\uDDFE\uDDFF])|\uD83C\uDDF9(?:\uD83C[\uDDE6\uDDE8\uDDE9\uDDEB-\uDDED\uDDEF-\uDDF4\uDDF7\uDDF9\uDDFB\uDDFC\uDDFF])|\uD83C\uDDF8(?:\uD83C[\uDDE6-\uDDEA\uDDEC-\uDDF4\uDDF7-\uDDF9\uDDFB\uDDFD-\uDDFF])|\uD83C\uDDF7(?:\uD83C[\uDDEA\uDDF4\uDDF8\uDDFA\uDDFC])|\uD83C\uDDF5(?:\uD83C[\uDDE6\uDDEA-\uDDED\uDDF0-\uDDF3\uDDF7-\uDDF9\uDDFC\uDDFE])|\uD83C\uDDF3(?:\uD83C[\uDDE6\uDDE8\uDDEA-\uDDEC\uDDEE\uDDF1\uDDF4\uDDF5\uDDF7\uDDFA\uDDFF])|\uD83C\uDDF2(?:\uD83C[\uDDE6\uDDE8-\uDDED\uDDF0-\uDDFF])|\uD83C\uDDF1(?:\uD83C[\uDDE6-\uDDE8\uDDEE\uDDF0\uDDF7-\uDDFB\uDDFE])|\uD83C\uDDF0(?:\uD83C[\uDDEA\uDDEC-\uDDEE\uDDF2\uDDF3\uDDF5\uDDF7\uDDFC\uDDFE\uDDFF])|\uD83C\uDDEF(?:\uD83C[\uDDEA\uDDF2\uDDF4\uDDF5])|\uD83C\uDDEE(?:\uD83C[\uDDE8-\uDDEA\uDDF1-\uDDF4\uDDF6-\uDDF9])|\uD83C\uDDED(?:\uD83C[\uDDF0\uDDF2\uDDF3\uDDF7\uDDF9\uDDFA])|\uD83C\uDDEC(?:\uD83C[\uDDE6\uDDE7\uDDE9-\uDDEE\uDDF1-\uDDF3\uDDF5-\uDDFA\uDDFC\uDDFE])|\uD83C\uDDEB(?:\uD83C[\uDDEE-\uDDF0\uDDF2\uDDF4\uDDF7])|\uD83C\uDDEA(?:\uD83C[\uDDE6\uDDE8\uDDEA\uDDEC\uDDED\uDDF7-\uDDFA])|\uD83C\uDDE9(?:\uD83C[\uDDEA\uDDEC\uDDEF\uDDF0\uDDF2\uDDF4\uDDFF])|\uD83C\uDDE8(?:\uD83C[\uDDE6\uDDE8\uDDE9\uDDEB-\uDDEE\uDDF0-\uDDF5\uDDF7\uDDFA-\uDDFF])|\uD83C\uDDE7(?:\uD83C[\uDDE6\uDDE7\uDDE9-\uDDEF\uDDF1-\uDDF4\uDDF6-\uDDF9\uDDFB\uDDFC\uDDFE\uDDFF])|\uD83C\uDDE6(?:\uD83C[\uDDE8-\uDDEC\uDDEE\uDDF1\uDDF2\uDDF4\uDDF6-\uDDFA\uDDFC\uDDFD\uDDFF])|[#\*0-9]\uFE0F\u20E3|\u2764\uFE0F|(?:\uD83C[\uDFC3\uDFC4\uDFCA]|\uD83D[\uDC6E\uDC70\uDC71\uDC73\uDC77\uDC81\uDC82\uDC86\uDC87\uDE45-\uDE47\uDE4B\uDE4D\uDE4E\uDEA3\uDEB4-\uDEB6]|\uD83E[\uDD26\uDD35\uDD37-\uDD39\uDD3D\uDD3E\uDDB8\uDDB9\uDDCD-\uDDCF\uDDD4\uDDD6-\uDDDD])(?:\uD83C[\uDFFB-\uDFFF])|(?:\u26F9|\uD83C[\uDFCB\uDFCC]|\uD83D\uDD75)(?:\uFE0F|\uD83C[\uDFFB-\uDFFF])|\uD83C\uDFF4|(?:[\u270A\u270B]|\uD83C[\uDF85\uDFC2\uDFC7]|\uD83D[\uDC42\uDC43\uDC46-\uDC50\uDC66\uDC67\uDC6B-\uDC6D\uDC72\uDC74-\uDC76\uDC78\uDC7C\uDC83\uDC85\uDC8F\uDC91\uDCAA\uDD7A\uDD95\uDD96\uDE4C\uDE4F\uDEC0\uDECC]|\uD83E[\uDD0C\uDD0F\uDD18-\uDD1C\uDD1E\uDD1F\uDD30-\uDD34\uDD36\uDD77\uDDB5\uDDB6\uDDBB\uDDD2\uDDD3\uDDD5])(?:\uD83C[\uDFFB-\uDFFF])|(?:[\u261D\u270C\u270D]|\uD83D[\uDD74\uDD90])(?:\uFE0F|\uD83C[\uDFFB-\uDFFF])|[\u270A\u270B]|\uD83C[\uDF85\uDFC2\uDFC7]|\uD83D[\uDC08\uDC15\uDC3B\uDC42\uDC43\uDC46-\uDC50\uDC66\uDC67\uDC6B-\uDC6D\uDC72\uDC74-\uDC76\uDC78\uDC7C\uDC83\uDC85\uDC8F\uDC91\uDCAA\uDD7A\uDD95\uDD96\uDE2E\uDE35\uDE36\uDE4C\uDE4F\uDEC0\uDECC]|\uD83E[\uDD0C\uDD0F\uDD18-\uDD1C\uDD1E\uDD1F\uDD30-\uDD34\uDD36\uDD77\uDDB5\uDDB6\uDDBB\uDDD2\uDDD3\uDDD5]|\uD83C[\uDFC3\uDFC4\uDFCA]|\uD83D[\uDC6E\uDC70\uDC71\uDC73\uDC77\uDC81\uDC82\uDC86\uDC87\uDE45-\uDE47\uDE4B\uDE4D\uDE4E\uDEA3\uDEB4-\uDEB6]|\uD83E[\uDD26\uDD35\uDD37-\uDD39\uDD3D\uDD3E\uDDB8\uDDB9\uDDCD-\uDDCF\uDDD4\uDDD6-\uDDDD]|\uD83D\uDC6F|\uD83E[\uDD3C\uDDDE\uDDDF]|[\u231A\u231B\u23E9-\u23EC\u23F0\u23F3\u25FD\u25FE\u2614\u2615\u2648-\u2653\u267F\u2693\u26A1\u26AA\u26AB\u26BD\u26BE\u26C4\u26C5\u26CE\u26D4\u26EA\u26F2\u26F3\u26F5\u26FA\u26FD\u2705\u2728\u274C\u274E\u2753-\u2755\u2757\u2795-\u2797\u27B0\u27BF\u2B1B\u2B1C\u2B50\u2B55]|\uD83C[\uDC04\uDCCF\uDD8E\uDD91-\uDD9A\uDE01\uDE1A\uDE2F\uDE32-\uDE36\uDE38-\uDE3A\uDE50\uDE51\uDF00-\uDF20\uDF2D-\uDF35\uDF37-\uDF7C\uDF7E-\uDF84\uDF86-\uDF93\uDFA0-\uDFC1\uDFC5\uDFC6\uDFC8\uDFC9\uDFCF-\uDFD3\uDFE0-\uDFF0\uDFF8-\uDFFF]|\uD83D[\uDC00-\uDC07\uDC09-\uDC14\uDC16-\uDC3A\uDC3C-\uDC3E\uDC40\uDC44\uDC45\uDC51-\uDC65\uDC6A\uDC79-\uDC7B\uDC7D-\uDC80\uDC84\uDC88-\uDC8E\uDC90\uDC92-\uDCA9\uDCAB-\uDCFC\uDCFF-\uDD3D\uDD4B-\uDD4E\uDD50-\uDD67\uDDA4\uDDFB-\uDE2D\uDE2F-\uDE34\uDE37-\uDE44\uDE48-\uDE4A\uDE80-\uDEA2\uDEA4-\uDEB3\uDEB7-\uDEBF\uDEC1-\uDEC5\uDED0-\uDED2\uDED5-\uDED7\uDEEB\uDEEC\uDEF4-\uDEFC\uDFE0-\uDFEB]|\uD83E[\uDD0D\uDD0E\uDD10-\uDD17\uDD1D\uDD20-\uDD25\uDD27-\uDD2F\uDD3A\uDD3F-\uDD45\uDD47-\uDD76\uDD78\uDD7A-\uDDB4\uDDB7\uDDBA\uDDBC-\uDDCB\uDDD0\uDDE0-\uDDFF\uDE70-\uDE74\uDE78-\uDE7A\uDE80-\uDE86\uDE90-\uDEA8\uDEB0-\uDEB6\uDEC0-\uDEC2\uDED0-\uDED6]|(?:[\u231A\u231B\u23E9-\u23EC\u23F0\u23F3\u25FD\u25FE\u2614\u2615\u2648-\u2653\u267F\u2693\u26A1\u26AA\u26AB\u26BD\u26BE\u26C4\u26C5\u26CE\u26D4\u26EA\u26F2\u26F3\u26F5\u26FA\u26FD\u2705\u270A\u270B\u2728\u274C\u274E\u2753-\u2755\u2757\u2795-\u2797\u27B0\u27BF\u2B1B\u2B1C\u2B50\u2B55]|\uD83C[\uDC04\uDCCF\uDD8E\uDD91-\uDD9A\uDDE6-\uDDFF\uDE01\uDE1A\uDE2F\uDE32-\uDE36\uDE38-\uDE3A\uDE50\uDE51\uDF00-\uDF20\uDF2D-\uDF35\uDF37-\uDF7C\uDF7E-\uDF93\uDFA0-\uDFCA\uDFCF-\uDFD3\uDFE0-\uDFF0\uDFF4\uDFF8-\uDFFF]|\uD83D[\uDC00-\uDC3E\uDC40\uDC42-\uDCFC\uDCFF-\uDD3D\uDD4B-\uDD4E\uDD50-\uDD67\uDD7A\uDD95\uDD96\uDDA4\uDDFB-\uDE4F\uDE80-\uDEC5\uDECC\uDED0-\uDED2\uDED5-\uDED7\uDEEB\uDEEC\uDEF4-\uDEFC\uDFE0-\uDFEB]|\uD83E[\uDD0C-\uDD3A\uDD3C-\uDD45\uDD47-\uDD78\uDD7A-\uDDCB\uDDCD-\uDDFF\uDE70-\uDE74\uDE78-\uDE7A\uDE80-\uDE86\uDE90-\uDEA8\uDEB0-\uDEB6\uDEC0-\uDEC2\uDED0-\uDED6])|(?:[#\*0-9\xA9\xAE\u203C\u2049\u2122\u2139\u2194-\u2199\u21A9\u21AA\u231A\u231B\u2328\u23CF\u23E9-\u23F3\u23F8-\u23FA\u24C2\u25AA\u25AB\u25B6\u25C0\u25FB-\u25FE\u2600-\u2604\u260E\u2611\u2614\u2615\u2618\u261D\u2620\u2622\u2623\u2626\u262A\u262E\u262F\u2638-\u263A\u2640\u2642\u2648-\u2653\u265F\u2660\u2663\u2665\u2666\u2668\u267B\u267E\u267F\u2692-\u2697\u2699\u269B\u269C\u26A0\u26A1\u26A7\u26AA\u26AB\u26B0\u26B1\u26BD\u26BE\u26C4\u26C5\u26C8\u26CE\u26CF\u26D1\u26D3\u26D4\u26E9\u26EA\u26F0-\u26F5\u26F7-\u26FA\u26FD\u2702\u2705\u2708-\u270D\u270F\u2712\u2714\u2716\u271D\u2721\u2728\u2733\u2734\u2744\u2747\u274C\u274E\u2753-\u2755\u2757\u2763\u2764\u2795-\u2797\u27A1\u27B0\u27BF\u2934\u2935\u2B05-\u2B07\u2B1B\u2B1C\u2B50\u2B55\u3030\u303D\u3297\u3299]|\uD83C[\uDC04\uDCCF\uDD70\uDD71\uDD7E\uDD7F\uDD8E\uDD91-\uDD9A\uDDE6-\uDDFF\uDE01\uDE02\uDE1A\uDE2F\uDE32-\uDE3A\uDE50\uDE51\uDF00-\uDF21\uDF24-\uDF93\uDF96\uDF97\uDF99-\uDF9B\uDF9E-\uDFF0\uDFF3-\uDFF5\uDFF7-\uDFFF]|\uD83D[\uDC00-\uDCFD\uDCFF-\uDD3D\uDD49-\uDD4E\uDD50-\uDD67\uDD6F\uDD70\uDD73-\uDD7A\uDD87\uDD8A-\uDD8D\uDD90\uDD95\uDD96\uDDA4\uDDA5\uDDA8\uDDB1\uDDB2\uDDBC\uDDC2-\uDDC4\uDDD1-\uDDD3\uDDDC-\uDDDE\uDDE1\uDDE3\uDDE8\uDDEF\uDDF3\uDDFA-\uDE4F\uDE80-\uDEC5\uDECB-\uDED2\uDED5-\uDED7\uDEE0-\uDEE5\uDEE9\uDEEB\uDEEC\uDEF0\uDEF3-\uDEFC\uDFE0-\uDFEB]|\uD83E[\uDD0C-\uDD3A\uDD3C-\uDD45\uDD47-\uDD78\uDD7A-\uDDCB\uDDCD-\uDDFF\uDE70-\uDE74\uDE78-\uDE7A\uDE80-\uDE86\uDE90-\uDEA8\uDEB0-\uDEB6\uDEC0-\uDEC2\uDED0-\uDED6])\uFE0F|(?:[\u261D\u26F9\u270A-\u270D]|\uD83C[\uDF85\uDFC2-\uDFC4\uDFC7\uDFCA-\uDFCC]|\uD83D[\uDC42\uDC43\uDC46-\uDC50\uDC66-\uDC78\uDC7C\uDC81-\uDC83\uDC85-\uDC87\uDC8F\uDC91\uDCAA\uDD74\uDD75\uDD7A\uDD90\uDD95\uDD96\uDE45-\uDE47\uDE4B-\uDE4F\uDEA3\uDEB4-\uDEB6\uDEC0\uDECC]|\uD83E[\uDD0C\uDD0F\uDD18-\uDD1F\uDD26\uDD30-\uDD39\uDD3C-\uDD3E\uDD77\uDDB5\uDDB6\uDDB8\uDDB9\uDDBB\uDDCD-\uDDCF\uDDD1-\uDDDD])/g;
function f(F, u = {}) {
  if (typeof F != "string" || F.length === 0 || (u = { ambiguousIsNarrow: true, ...u }, F = o(F), F.length === 0)) return 0;
  F = F.replace(W(), "  ");
  let C = u.ambiguousIsNarrow ? 1 : 2, D = 0;
  for (let t of F) {
    let E = t.codePointAt(0);
    if (!E || E <= 31 || E >= 127 && E <= 159 || E >= 768 && E <= 879) continue;
    switch (y(t)) {
      case "F":
      case "W":
        D += 2;
        break;
      case "A":
        D += C;
        break;
      default:
        D += 1;
    }
  }
  return D;
}
var A = { modifier: { reset: [0, 0], bold: [1, 22], dim: [2, 22], italic: [3, 23], underline: [4, 24], overline: [53, 55], inverse: [7, 27], hidden: [8, 28], strikethrough: [9, 29] }, color: { black: [30, 39], red: [31, 39], green: [32, 39], yellow: [33, 39], blue: [34, 39], magenta: [35, 39], cyan: [36, 39], white: [37, 39], blackBright: [90, 39], gray: [90, 39], grey: [90, 39], redBright: [91, 39], greenBright: [92, 39], yellowBright: [93, 39], blueBright: [94, 39], magentaBright: [95, 39], cyanBright: [96, 39], whiteBright: [97, 39] }, bgColor: { bgBlack: [40, 49], bgRed: [41, 49], bgGreen: [42, 49], bgYellow: [43, 49], bgBlue: [44, 49], bgMagenta: [45, 49], bgCyan: [46, 49], bgWhite: [47, 49], bgBlackBright: [100, 49], bgGray: [100, 49], bgGrey: [100, 49], bgRedBright: [101, 49], bgGreenBright: [102, 49], bgYellowBright: [103, 49], bgBlueBright: [104, 49], bgMagentaBright: [105, 49], bgCyanBright: [106, 49], bgWhiteBright: [107, 49] } };
var xD = Object.keys(A.modifier);
var I = Object.keys(A.color);
var O = Object.keys(A.bgColor);
var rD = [...I, ...O];
var d = class {
};
var T = /* @__PURE__ */ new Map();
var p = (F) => Object.fromEntries(Object.entries(F).map(([u, [C, D]]) => (T.set(C, D), [u, d.prototype[u] = { open: `\x1B[${C}m`, close: `\x1B[${D}m` }])));
var M = new class extends d {
  codes = T;
  modifier = p(A.modifier);
  color = { ...p(A.color), close: "\x1B[39m", ansi: (F) => `\x1B[${F}m`, ansi256: (F) => `\x1B[38;5;${F}m`, ansi16m: (F, u, C) => `\x1B[38;2;${F};${u};${C}m` };
  bgColor = { ...p(A.bgColor), close: "\x1B[49m", ansi: (F) => `\x1B[${F + 10}m`, ansi256: (F) => `\x1B[48;5;${F}m`, ansi16m: (F, u, C) => `\x1B[48;2;${F};${u};${C}m` };
  rgbToAnsi256(F, u, C) {
    return F === u && u === C ? F < 8 ? 16 : F > 248 ? 231 : Math.round((F - 8) / 247 * 24) + 232 : 16 + 36 * Math.round(F / 255 * 5) + 6 * Math.round(u / 255 * 5) + Math.round(C / 255 * 5);
  }
  hexToRgb(F) {
    let u = /[a-f\d]{6}|[a-f\d]{3}/i.exec(F.toString(16));
    if (!u) return [0, 0, 0];
    let [C] = u;
    C.length === 3 && (C = [...C].map((t) => t + t).join(""));
    let D = Number.parseInt(C, 16);
    return [D >> 16 & 255, D >> 8 & 255, D & 255];
  }
  hexToAnsi256(F) {
    return this.rgbToAnsi256(...this.hexToRgb(F));
  }
  ansi256ToAnsi(F) {
    if (F < 8) return 30 + F;
    if (F < 16) return 90 + (F - 8);
    let u, C, D;
    if (F >= 232) u = ((F - 232) * 10 + 8) / 255, C = u, D = u;
    else {
      F -= 16;
      let e = F % 36;
      u = Math.floor(F / 36) / 5, C = Math.floor(e / 6) / 5, D = e % 6 / 5;
    }
    let t = Math.max(u, C, D) * 2;
    if (t === 0) return 30;
    let E = 30 + (Math.round(D) << 2 | Math.round(C) << 1 | Math.round(u));
    return t === 2 && (E += 60), E;
  }
  rgbToAnsi(F, u, C) {
    return this.ansi256ToAnsi(this.rgbToAnsi256(F, u, C));
  }
  hexToAnsi(F) {
    return this.ansi256ToAnsi(this.hexToAnsi256(F));
  }
}();
var c = /* @__PURE__ */ new Set(["\x1B", "\x9B"]);
var _ = 39;
var m = "\x07";
var j = "[";
var G = "]";
var k = "m";
var w = `${G}8;;`;
var N = (F) => `${c.values().next().value}${j}${F}${k}`;
var v = (F) => `${c.values().next().value}${w}${F}${m}`;
var z = (F) => F.split(" ").map((u) => f(u));
var b = (F, u, C) => {
  let D = [...u], t = false, E = false, e = f(o(String(F[F.length - 1])));
  for (let [x, r] of D.entries()) {
    let a = f(r);
    if (e + a <= C ? F[F.length - 1] += r : (F.push(r), e = 0), c.has(r) && (t = true, E = D.slice(x + 1).join("").startsWith(w)), t) {
      E ? r === m && (t = false, E = false) : r === k && (t = false);
      continue;
    }
    e += a, e === C && x < D.length - 1 && (F.push(""), e = 0);
  }
  !e && String(F[F.length - 1]).length > 0 && F.length > 1 && (F[F.length - 2] = String(F[F.length - 1]) + F.pop());
};
var H = (F) => {
  let u = F.split(" "), C = u.length;
  for (; C > 0 && !(f(String(u[C - 1])) > 0); ) C--;
  return C === u.length ? F : u.slice(0, C).join(" ") + u.slice(C).join("");
};
var V = (F, u, C = {}) => {
  if (C.trim !== false && F.trim() === "") return "";
  let D = "", t, E, e = z(F), x = [""];
  for (let [a, i] of F.split(" ").entries()) {
    C.trim !== false && (x[x.length - 1] = String(x[x.length - 1]).trimStart());
    let n = f(String(x[x.length - 1]));
    a !== 0 && (n >= u && (C.wordWrap === false || C.trim === false) && (x.push(""), n = 0), (n > 0 || C.trim === false) && (x[x.length - 1] += " ", n++));
    let B = Number(e[a]);
    if (C.hard && B > u) {
      let s = u - n, l = 1 + Math.floor((B - s - 1) / u);
      Math.floor((B - 1) / u) < l && x.push(""), b(x, i, u);
      continue;
    }
    if (n + B > u && n > 0 && B > 0) {
      if (C.wordWrap === false && n < u) {
        b(x, i, u);
        continue;
      }
      x.push("");
    }
    if (n + B > u && C.wordWrap === false) {
      b(x, i, u);
      continue;
    }
    x[x.length - 1] += i;
  }
  C.trim !== false && (x = x.map((a) => H(a)));
  let r = [...x.join(`
`)];
  for (let [a, i] of r.entries()) {
    if (D += i, c.has(i)) {
      let { groups: B } = new RegExp(`(?:\\${j}(?<code>\\d+)m|\\${w}(?<uri>.*)${m})`).exec(r.slice(a).join("")) || { groups: {} };
      if (B.code !== void 0) {
        let s = Number.parseFloat(B.code);
        t = s === _ ? void 0 : s;
      } else B.uri !== void 0 && (E = B.uri.length === 0 ? void 0 : B.uri);
    }
    let n = M.codes.get(Number(t));
    r[a + 1] === `
` ? (E && (D += v("")), t && n && (D += N(n))) : i === `
` && (t && n && (D += N(t)), E && (D += v(E)));
  }
  return D;
};
var L = (F, u, C) => String(F).normalize().replace(/\r\n/g, `
`).split(`
`).map((D) => V(D, u, C)).join(`
`);
var Y = { right: (F, u) => `${" ".repeat(Math.max(0, u - f(F)))}${F}`, center: (F, u) => `${" ".repeat(Math.max(0, u - f(F)) >> 1)}${F}` };
var q = 0;
var h = 1;
var K = 2;
var g = 3;
var S = class {
  width;
  wrap;
  rows;
  constructor(u) {
    this.width = u.width, this.wrap = u.wrap ?? true, this.rows = [];
  }
  span(...u) {
    let C = this.div(...u);
    C.span = true;
  }
  resetOutput() {
    this.rows = [];
  }
  div(...u) {
    if (u.length === 0 && this.div(""), this.wrap && this.shouldApplyLayoutDSL(...u) && typeof u[0] == "string") return this.applyLayoutDSL(u[0]);
    let C = Object.assign(u.map((D) => typeof D == "string" ? this.colFromString(D) : D), { span: false });
    return this.rows.push(C), C;
  }
  shouldApplyLayoutDSL(...u) {
    return u.length === 1 && typeof u[0] == "string" && /[\t\n]/.test(u[0]);
  }
  applyLayoutDSL(u) {
    let C = u.split(`
`).map((E) => E.split("	")), D = 0;
    C.forEach((E) => {
      E.length > 1 && f(String(E[0])) > D && (D = Math.min(Math.floor(this.width * 0.5), f(String(E[0]))));
    }), C.forEach((E) => {
      this.div(...E.map((e, x) => ({ text: e.trim(), padding: this.measurePadding(e), width: x === 0 && E.length > 1 ? D : void 0 })));
    });
    let t = this.rows[this.rows.length - 1];
    if (!t) throw new Error("no rows found");
    return t;
  }
  colFromString(u) {
    return { text: u, padding: this.measurePadding(u) };
  }
  measurePadding(u) {
    let C = o(u), [D = "", t = ""] = [C.match(/\s*$/)?.[0], C.match(/^\s*/)?.[0]];
    return [0, D.length, 0, t.length];
  }
  toString() {
    let u = [];
    return this.rows.forEach((C) => {
      this.rowToString(C, u);
    }), u.filter((C) => !C.hidden).map((C) => C.text).join(`
`);
  }
  rowToString(u, C) {
    return this.rasterize(u).forEach((D, t) => {
      let E = "";
      D.forEach((e, x) => {
        let r = u[x], { width: a } = r, i = this.negatePadding(r), n = e;
        if (i > f(e) && (n += " ".repeat(i - f(e))), r.align && r.align !== "left" && this.wrap) {
          let s = Y[r.align];
          if (n = s(n.trim(), i), f(n) < i) {
            let l = a || 0;
            n += " ".repeat(l - f(n) - 1);
          }
        }
        let B = r.padding || [0, 0, 0, 0];
        if (B[g] && (E += " ".repeat(B[g])), E += P(r, n, "| "), E += n, E += P(r, n, " |"), B[h] && (E += " ".repeat(B[h])), t === 0 && C.length > 0) {
          let s = C[C.length - 1];
          if (!s) throw new Error("last line not found");
          E = this.renderInline(E, s);
        }
      }), C.push({ text: E.replace(/ +$/, ""), span: u.span });
    }), C;
  }
  renderInline(u, C) {
    let D = u.match(/^ */), t = D ? D[0].length : 0, E = C.text, e = f(E.trimEnd());
    return C.span ? this.wrap ? t < e ? u : (C.hidden = true, E.trimEnd() + " ".repeat(t - e) + u.trimStart()) : (C.hidden = true, E + u) : u;
  }
  rasterize(u) {
    let C = [], D = this.columnWidths(u), t;
    return u.forEach((E, e) => {
      E.width = D[e], this.wrap ? t = L(E.text, this.negatePadding(E), { hard: true }).split(`
`) : t = E.text.split(`
`), E.border && (t.unshift("." + "-".repeat(this.negatePadding(E) + 2) + "."), t.push("'" + "-".repeat(this.negatePadding(E) + 2) + "'")), E.padding && (t.unshift(...new Array(E.padding[q] || 0).fill("")), t.push(...new Array(E.padding[K] || 0).fill(""))), t.forEach((x, r) => {
        C[r] || C.push([]);
        let a = C[r] ?? [];
        for (let i = 0; i < e; i++) a[i] === void 0 && a.push("");
        a.push(x);
      });
    }), C;
  }
  negatePadding(u) {
    let C = u.width || 0;
    return u.padding && (C -= (u.padding[g] || 0) + (u.padding[h] || 0)), u.border && (C -= 4), C;
  }
  columnWidths(u) {
    if (!this.wrap) return u.map((e) => e.width || f(e.text));
    let C = u.length, D = this.width, t = u.map((e) => {
      if (e.width) return C--, D -= e.width, e.width;
    }), E = C ? Math.floor(D / C) : 0;
    return t.map((e, x) => {
      if (e === void 0) {
        let r = u[x] ?? { text: "", padding: [] };
        return Math.max(E, Z(r));
      }
      return e;
    });
  }
};
var P = (F, u, C) => F.border ? /[.']-+[.']/.test(u) ? "" : u.trim().length !== 0 ? C : "  " : "";
var Z = (F) => {
  let u = F.padding || [], C = 1 + (u[g] || 0) + (u[h] || 0);
  return F.border ? C + 4 : C;
};
var J = () => typeof process == "object" && process.stdout && process.stdout.columns ? process.stdout.columns : 80;
var cD = (F = {}) => new S({ width: F?.width || J(), wrap: F?.wrap });

// ../../node_modules/.vlt/~npm~jackspeak@4.2.3/node_modules/jackspeak/dist/esm/index.js
import { basename } from "node:path";
var isConfigType = (t) => typeof t === "string" && (t === "string" || t === "number" || t === "boolean");
var isValidValue = (v2, type, multi) => {
  if (multi) {
    if (!Array.isArray(v2))
      return false;
    return !v2.some((v3) => !isValidValue(v3, type, false));
  }
  if (Array.isArray(v2))
    return false;
  return typeof v2 === type;
};
var isValidOption = (v2, vo) => !!vo && (Array.isArray(v2) ? v2.every((x) => isValidOption(x, vo)) : vo.includes(v2));
var isConfigOptionOfType = (o2, type, multi) => !!o2 && typeof o2 === "object" && "type" in o2 && isConfigType(o2.type) && o2.type === type && !!o2.multiple === multi;
var isConfigOption = (o2, type, multi) => isConfigOptionOfType(o2, type, multi) && undefOrType(o2.short, "string") && undefOrType(o2.description, "string") && undefOrType(o2.hint, "string") && undefOrType(o2.validate, "function") && (o2.type === "boolean" ? o2.validOptions === void 0 : undefOrTypeArray(o2.validOptions, o2.type)) && (o2.default === void 0 || isValidValue(o2.default, type, multi));
var isHeading = (r) => r.type === "heading";
var isDescription = (r) => r.type === "description";
var width = Math.min(process?.stdout?.columns ?? 80, 80);
var indent = (n) => (n - 1) * 2;
var toEnvKey = (pref, key) => [pref, key.replace(/[^a-zA-Z0-9]+/g, " ")].join(" ").trim().toUpperCase().replace(/ /g, "_");
var toEnvVal = (value, delim = "\n") => {
  const str = typeof value === "string" ? value : typeof value === "boolean" ? value ? "1" : "0" : typeof value === "number" ? String(value) : Array.isArray(value) ? value.map((v2) => toEnvVal(v2)).join(delim) : (
    /* c8 ignore start */
    void 0
  );
  if (typeof str !== "string") {
    throw new Error(`could not serialize value to environment: ${JSON.stringify(value)}`, { cause: { code: "JACKSPEAK" } });
  }
  return str;
};
var fromEnvVal = (env, type, multiple, delim = "\n") => multiple ? env ? env.split(delim).map((v2) => fromEnvVal(v2, type, false)) : [] : type === "string" ? env : type === "boolean" ? env === "1" : +env.trim();
var undefOrType = (v2, t) => v2 === void 0 || typeof v2 === t;
var undefOrTypeArray = (v2, t) => v2 === void 0 || Array.isArray(v2) && v2.every((x) => typeof x === t);
var valueType = (v2) => typeof v2 === "string" ? "string" : typeof v2 === "boolean" ? "boolean" : typeof v2 === "number" ? "number" : Array.isArray(v2) ? `${joinTypes([...new Set(v2.map((v3) => valueType(v3)))])}[]` : `${v2.type}${v2.multiple ? "[]" : ""}`;
var joinTypes = (types) => types.length === 1 && typeof types[0] === "string" ? types[0] : `(${types.join("|")})`;
var validateFieldMeta = (field, fieldMeta) => {
  if (fieldMeta) {
    if (field.type !== void 0 && field.type !== fieldMeta.type) {
      throw new TypeError(`invalid type`, {
        cause: {
          found: field.type,
          wanted: [fieldMeta.type, void 0]
        }
      });
    }
    if (field.multiple !== void 0 && !!field.multiple !== fieldMeta.multiple) {
      throw new TypeError(`invalid multiple`, {
        cause: {
          found: field.multiple,
          wanted: [fieldMeta.multiple, void 0]
        }
      });
    }
    return fieldMeta;
  }
  if (!isConfigType(field.type)) {
    throw new TypeError(`invalid type`, {
      cause: {
        found: field.type,
        wanted: ["string", "number", "boolean"]
      }
    });
  }
  return {
    type: field.type,
    multiple: !!field.multiple
  };
};
var validateField = (o2, type, multiple) => {
  const validateValidOptions = (def, validOptions) => {
    if (!undefOrTypeArray(validOptions, type)) {
      throw new TypeError("invalid validOptions", {
        cause: {
          found: validOptions,
          wanted: valueType({ type, multiple: true })
        }
      });
    }
    if (def !== void 0 && validOptions !== void 0) {
      const valid = Array.isArray(def) ? def.every((v2) => validOptions.includes(v2)) : validOptions.includes(def);
      if (!valid) {
        throw new TypeError("invalid default value not in validOptions", {
          cause: {
            found: def,
            wanted: validOptions
          }
        });
      }
    }
  };
  if (o2.default !== void 0 && !isValidValue(o2.default, type, multiple)) {
    throw new TypeError("invalid default value", {
      cause: {
        found: o2.default,
        wanted: valueType({ type, multiple })
      }
    });
  }
  if (isConfigOptionOfType(o2, "number", false) || isConfigOptionOfType(o2, "number", true)) {
    validateValidOptions(o2.default, o2.validOptions);
  } else if (isConfigOptionOfType(o2, "string", false) || isConfigOptionOfType(o2, "string", true)) {
    validateValidOptions(o2.default, o2.validOptions);
  } else if (isConfigOptionOfType(o2, "boolean", false) || isConfigOptionOfType(o2, "boolean", true)) {
    if (o2.hint !== void 0) {
      throw new TypeError("cannot provide hint for flag");
    }
    if (o2.validOptions !== void 0) {
      throw new TypeError("cannot provide validOptions for flag");
    }
  }
  return o2;
};
var toParseArgsOptionsConfig = (options) => {
  return Object.entries(options).reduce((acc, [longOption, o2]) => {
    const p2 = {
      type: "string",
      multiple: !!o2.multiple,
      ...typeof o2.short === "string" ? { short: o2.short } : void 0
    };
    const setNoBool = () => {
      if (!longOption.startsWith("no-") && !options[`no-${longOption}`]) {
        acc[`no-${longOption}`] = {
          type: "boolean",
          multiple: !!o2.multiple
        };
      }
    };
    const setDefault = (def, fn) => {
      if (def !== void 0) {
        p2.default = fn(def);
      }
    };
    if (isConfigOption(o2, "number", false)) {
      setDefault(o2.default, String);
    } else if (isConfigOption(o2, "number", true)) {
      setDefault(o2.default, (d2) => d2.map((v2) => String(v2)));
    } else if (isConfigOption(o2, "string", false) || isConfigOption(o2, "string", true)) {
      setDefault(o2.default, (v2) => v2);
    } else if (isConfigOption(o2, "boolean", false) || isConfigOption(o2, "boolean", true)) {
      p2.type = "boolean";
      setDefault(o2.default, (v2) => v2);
      setNoBool();
    }
    acc[longOption] = p2;
    return acc;
  }, {});
};
var Jack = class {
  #configSet;
  #shorts;
  #options;
  #fields = [];
  #env;
  #envPrefix;
  #allowPositionals;
  #usage;
  #usageMarkdown;
  constructor(options = {}) {
    this.#options = options;
    this.#allowPositionals = options.allowPositionals !== false;
    this.#env = this.#options.env === void 0 ? process.env : this.#options.env;
    this.#envPrefix = options.envPrefix;
    this.#configSet = /* @__PURE__ */ Object.create(null);
    this.#shorts = /* @__PURE__ */ Object.create(null);
  }
  /**
   * Resulting definitions, suitable to be passed to Node's `util.parseArgs`,
   * but also including `description` and `short` fields, if set.
   */
  get definitions() {
    return this.#configSet;
  }
  /** map of `{ <short>: <long> }` strings for each short name defined */
  get shorts() {
    return this.#shorts;
  }
  /**
   * options passed to the {@link Jack} constructor
   */
  get jackOptions() {
    return this.#options;
  }
  /**
   * the data used to generate {@link Jack#usage} and
   * {@link Jack#usageMarkdown} content.
   */
  get usageFields() {
    return this.#fields;
  }
  /**
   * Set the default value (which will still be overridden by env or cli)
   * as if from a parsed config file. The optional `source` param, if
   * provided, will be included in error messages if a value is invalid or
   * unknown.
   */
  setConfigValues(values, source = "") {
    try {
      this.validate(values);
    } catch (er) {
      if (source && er instanceof Error) {
        const cause = typeof er.cause === "object" ? er.cause : {};
        er.cause = { ...cause, path: source };
        Error.captureStackTrace(er, this.setConfigValues);
      }
      throw er;
    }
    for (const [field, value] of Object.entries(values)) {
      const my = this.#configSet[field];
      if (!my) {
        throw new Error("unexpected field in config set: " + field, {
          cause: {
            code: "JACKSPEAK",
            found: field
          }
        });
      }
      my.default = value;
    }
    return this;
  }
  /**
   * Parse a string of arguments, and return the resulting
   * `{ values, positionals }` object.
   *
   * If an {@link JackOptions#envPrefix} is set, then it will read default
   * values from the environment, and write the resulting values back
   * to the environment as well.
   *
   * Environment values always take precedence over any other value, except
   * an explicit CLI setting.
   */
  parse(args = process.argv) {
    this.loadEnvDefaults();
    const p2 = this.parseRaw(args);
    this.applyDefaults(p2);
    this.writeEnv(p2);
    return p2;
  }
  loadEnvDefaults() {
    if (this.#envPrefix) {
      for (const [field, my] of Object.entries(this.#configSet)) {
        const ek = toEnvKey(this.#envPrefix, field);
        const env = this.#env[ek];
        if (env !== void 0) {
          my.default = fromEnvVal(env, my.type, !!my.multiple, my.delim);
        }
      }
    }
  }
  applyDefaults(p2) {
    for (const [field, c2] of Object.entries(this.#configSet)) {
      if (c2.default !== void 0 && !(field in p2.values)) {
        p2.values[field] = c2.default;
      }
    }
  }
  /**
   * Only parse the command line arguments passed in.
   * Does not strip off the `node script.js` bits, so it must be just the
   * arguments you wish to have parsed.
   * Does not read from or write to the environment, or set defaults.
   */
  parseRaw(args) {
    if (args === process.argv) {
      args = args.slice(process._eval !== void 0 ? 1 : 2);
    }
    const result = parseArgs({
      args,
      options: toParseArgsOptionsConfig(this.#configSet),
      // always strict, but using our own logic
      strict: false,
      allowPositionals: this.#allowPositionals,
      tokens: true
    });
    const p2 = {
      values: {},
      positionals: []
    };
    for (const token of result.tokens) {
      if (token.kind === "positional") {
        p2.positionals.push(token.value);
        if (this.#options.stopAtPositional || this.#options.stopAtPositionalTest?.(token.value)) {
          p2.positionals.push(...args.slice(token.index + 1));
          break;
        }
      } else if (token.kind === "option") {
        let value = void 0;
        if (token.name.startsWith("no-")) {
          const my2 = this.#configSet[token.name];
          const pname = token.name.substring("no-".length);
          const pos = this.#configSet[pname];
          if (pos && pos.type === "boolean" && (!my2 || my2.type === "boolean" && !!my2.multiple === !!pos.multiple)) {
            value = false;
            token.name = pname;
          }
        }
        const my = this.#configSet[token.name];
        if (!my) {
          throw new Error(`Unknown option '${token.rawName}'. To specify a positional argument starting with a '-', place it at the end of the command after '--', as in '-- ${token.rawName}'`, {
            cause: {
              code: "JACKSPEAK",
              found: token.rawName + (token.value ? `=${token.value}` : "")
            }
          });
        }
        if (value === void 0) {
          if (token.value === void 0) {
            if (my.type !== "boolean") {
              throw new Error(`No value provided for ${token.rawName}, expected ${my.type}`, {
                cause: {
                  code: "JACKSPEAK",
                  name: token.rawName,
                  wanted: valueType(my)
                }
              });
            }
            value = true;
          } else {
            if (my.type === "boolean") {
              throw new Error(`Flag ${token.rawName} does not take a value, received '${token.value}'`, { cause: { code: "JACKSPEAK", found: token } });
            }
            if (my.type === "string") {
              value = token.value;
            } else {
              value = +token.value;
              if (value !== value) {
                throw new Error(`Invalid value '${token.value}' provided for '${token.rawName}' option, expected number`, {
                  cause: {
                    code: "JACKSPEAK",
                    name: token.rawName,
                    found: token.value,
                    wanted: "number"
                  }
                });
              }
            }
          }
        }
        if (my.multiple) {
          const pv = p2.values;
          const tn = pv[token.name] ?? [];
          pv[token.name] = tn;
          tn.push(value);
        } else {
          const pv = p2.values;
          pv[token.name] = value;
        }
      }
    }
    for (const [field, value] of Object.entries(p2.values)) {
      const valid = this.#configSet[field]?.validate;
      const validOptions = this.#configSet[field]?.validOptions;
      const cause = validOptions && !isValidOption(value, validOptions) ? { name: field, found: value, validOptions } : valid && !valid(value) ? { name: field, found: value } : void 0;
      if (cause) {
        throw new Error(`Invalid value provided for --${field}: ${JSON.stringify(value)}`, { cause: { ...cause, code: "JACKSPEAK" } });
      }
    }
    return p2;
  }
  /**
   * do not set fields as 'no-foo' if 'foo' exists and both are bools
   * just set foo.
   */
  #noNoFields(f2, val, s = f2) {
    if (!f2.startsWith("no-") || typeof val !== "boolean")
      return;
    const yes = f2.substring("no-".length);
    this.#noNoFields(yes, val, s);
    if (this.#configSet[yes]?.type === "boolean") {
      throw new Error(`do not set '${s}', instead set '${yes}' as desired.`, { cause: { code: "JACKSPEAK", found: s, wanted: yes } });
    }
  }
  /**
   * Validate that any arbitrary object is a valid configuration `values`
   * object.  Useful when loading config files or other sources.
   */
  validate(o2) {
    if (!o2 || typeof o2 !== "object") {
      throw new Error("Invalid config: not an object", {
        cause: { code: "JACKSPEAK", found: o2 }
      });
    }
    const opts = o2;
    for (const field in o2) {
      const value = opts[field];
      if (value === void 0)
        continue;
      this.#noNoFields(field, value);
      const config = this.#configSet[field];
      if (!config) {
        throw new Error(`Unknown config option: ${field}`, {
          cause: { code: "JACKSPEAK", found: field }
        });
      }
      if (!isValidValue(value, config.type, !!config.multiple)) {
        throw new Error(`Invalid value ${valueType(value)} for ${field}, expected ${valueType(config)}`, {
          cause: {
            code: "JACKSPEAK",
            name: field,
            found: value,
            wanted: valueType(config)
          }
        });
      }
      const cause = config.validOptions && !isValidOption(value, config.validOptions) ? { name: field, found: value, validOptions: config.validOptions } : config.validate && !config.validate(value) ? { name: field, found: value } : void 0;
      if (cause) {
        throw new Error(`Invalid config value for ${field}: ${JSON.stringify(value)}`, {
          cause: { ...cause, code: "JACKSPEAK" }
        });
      }
    }
  }
  writeEnv(p2) {
    if (!this.#env || !this.#envPrefix)
      return;
    for (const [field, value] of Object.entries(p2.values)) {
      const my = this.#configSet[field];
      this.#env[toEnvKey(this.#envPrefix, field)] = toEnvVal(value, my?.delim);
    }
  }
  /**
   * Add a heading to the usage output banner
   */
  heading(text, level, { pre = false } = {}) {
    if (level === void 0) {
      level = this.#fields.some((r) => isHeading(r)) ? 2 : 1;
    }
    this.#fields.push({ type: "heading", text, level, pre });
    return this;
  }
  /**
   * Add a long-form description to the usage output at this position.
   */
  description(text, { pre } = {}) {
    this.#fields.push({ type: "description", text, pre });
    return this;
  }
  /**
   * Add one or more number fields.
   */
  num(fields) {
    return this.#addFieldsWith(fields, "number", false);
  }
  /**
   * Add one or more multiple number fields.
   */
  numList(fields) {
    return this.#addFieldsWith(fields, "number", true);
  }
  /**
   * Add one or more string option fields.
   */
  opt(fields) {
    return this.#addFieldsWith(fields, "string", false);
  }
  /**
   * Add one or more multiple string option fields.
   */
  optList(fields) {
    return this.#addFieldsWith(fields, "string", true);
  }
  /**
   * Add one or more flag fields.
   */
  flag(fields) {
    return this.#addFieldsWith(fields, "boolean", false);
  }
  /**
   * Add one or more multiple flag fields.
   */
  flagList(fields) {
    return this.#addFieldsWith(fields, "boolean", true);
  }
  /**
   * Generic field definition method. Similar to flag/flagList/number/etc,
   * but you must specify the `type` (and optionally `multiple` and `delim`)
   * fields on each one, or Jack won't know how to define them.
   */
  addFields(fields) {
    return this.#addFields(this, fields);
  }
  #addFieldsWith(fields, type, multiple) {
    return this.#addFields(this, fields, {
      type,
      multiple
    });
  }
  #addFields(next, fields, opt) {
    Object.assign(next.#configSet, Object.fromEntries(Object.entries(fields).map(([name, field]) => {
      this.#validateName(name, field);
      const { type, multiple } = validateFieldMeta(field, opt);
      const value = { ...field, type, multiple };
      validateField(value, type, multiple);
      next.#fields.push({ type: "config", name, value });
      return [name, value];
    })));
    return next;
  }
  #validateName(name, field) {
    if (!/^[a-zA-Z0-9]([a-zA-Z0-9-]*[a-zA-Z0-9])?$/.test(name)) {
      throw new TypeError(`Invalid option name: ${name}, must be '-' delimited ASCII alphanumeric`);
    }
    if (this.#configSet[name]) {
      throw new TypeError(`Cannot redefine option ${name}`);
    }
    if (this.#shorts[name]) {
      throw new TypeError(`Cannot redefine option ${name}, already in use for ${this.#shorts[name]}`);
    }
    if (field.short) {
      if (!/^[a-zA-Z0-9]$/.test(field.short)) {
        throw new TypeError(`Invalid ${name} short option: ${field.short}, must be 1 ASCII alphanumeric character`);
      }
      if (this.#shorts[field.short]) {
        throw new TypeError(`Invalid ${name} short option: ${field.short}, already in use for ${this.#shorts[field.short]}`);
      }
      this.#shorts[field.short] = name;
      this.#shorts[name] = name;
    }
  }
  /**
   * Return the usage banner for the given configuration
   */
  usage() {
    if (this.#usage)
      return this.#usage;
    let headingLevel = 1;
    const ui = cD({ width });
    const first = this.#fields[0];
    let start = first?.type === "heading" ? 1 : 0;
    if (first?.type === "heading") {
      ui.div({
        padding: [0, 0, 0, 0],
        text: normalize(first.text)
      });
    }
    ui.div({ padding: [0, 0, 0, 0], text: "Usage:" });
    if (this.#options.usage) {
      ui.div({
        text: this.#options.usage,
        padding: [0, 0, 0, 2]
      });
    } else {
      const cmd = basename(String(process.argv[1]));
      const shortFlags = [];
      const shorts = [];
      const flags = [];
      const opts = [];
      for (const [field, config] of Object.entries(this.#configSet)) {
        if (config.short) {
          if (config.type === "boolean")
            shortFlags.push(config.short);
          else
            shorts.push([config.short, config.hint || field]);
        } else {
          if (config.type === "boolean")
            flags.push(field);
          else
            opts.push([field, config.hint || field]);
        }
      }
      const sf = shortFlags.length ? " -" + shortFlags.join("") : "";
      const so = shorts.map(([k2, v2]) => ` --${k2}=<${v2}>`).join("");
      const lf = flags.map((k2) => ` --${k2}`).join("");
      const lo = opts.map(([k2, v2]) => ` --${k2}=<${v2}>`).join("");
      const usage = `${cmd}${sf}${so}${lf}${lo}`.trim();
      ui.div({
        text: usage,
        padding: [0, 0, 0, 2]
      });
    }
    ui.div({ padding: [0, 0, 0, 0], text: "" });
    const maybeDesc = this.#fields[start];
    if (maybeDesc && isDescription(maybeDesc)) {
      const print = normalize(maybeDesc.text, maybeDesc.pre);
      start++;
      ui.div({ padding: [0, 0, 0, 0], text: print });
      ui.div({ padding: [0, 0, 0, 0], text: "" });
    }
    const { rows, maxWidth } = this.#usageRows(start);
    for (const row of rows) {
      if (row.left) {
        const configIndent = indent(Math.max(headingLevel, 2));
        if (row.left.length > maxWidth - 3) {
          ui.div({ text: row.left, padding: [0, 0, 0, configIndent] });
          ui.div({ text: row.text, padding: [0, 0, 0, maxWidth] });
        } else {
          ui.div({
            text: row.left,
            padding: [0, 1, 0, configIndent],
            width: maxWidth
          }, { padding: [0, 0, 0, 0], text: row.text });
        }
        if (row.skipLine) {
          ui.div({ padding: [0, 0, 0, 0], text: "" });
        }
      } else {
        if (isHeading(row)) {
          const { level } = row;
          headingLevel = level;
          const b2 = level <= 2 ? 1 : 0;
          ui.div({ ...row, padding: [0, 0, b2, indent(level)] });
        } else {
          ui.div({ ...row, padding: [0, 0, 1, indent(headingLevel + 1)] });
        }
      }
    }
    return this.#usage = ui.toString();
  }
  /**
   * Return the usage banner markdown for the given configuration
   */
  usageMarkdown() {
    if (this.#usageMarkdown)
      return this.#usageMarkdown;
    const out = [];
    let headingLevel = 1;
    const first = this.#fields[0];
    let start = first?.type === "heading" ? 1 : 0;
    if (first?.type === "heading") {
      out.push(`# ${normalizeOneLine(first.text)}`);
    }
    out.push("Usage:");
    if (this.#options.usage) {
      out.push(normalizeMarkdown(this.#options.usage, true));
    } else {
      const cmd = basename(String(process.argv[1]));
      const shortFlags = [];
      const shorts = [];
      const flags = [];
      const opts = [];
      for (const [field, config] of Object.entries(this.#configSet)) {
        if (config.short) {
          if (config.type === "boolean")
            shortFlags.push(config.short);
          else
            shorts.push([config.short, config.hint || field]);
        } else {
          if (config.type === "boolean")
            flags.push(field);
          else
            opts.push([field, config.hint || field]);
        }
      }
      const sf = shortFlags.length ? " -" + shortFlags.join("") : "";
      const so = shorts.map(([k2, v2]) => ` --${k2}=<${v2}>`).join("");
      const lf = flags.map((k2) => ` --${k2}`).join("");
      const lo = opts.map(([k2, v2]) => ` --${k2}=<${v2}>`).join("");
      const usage = `${cmd}${sf}${so}${lf}${lo}`.trim();
      out.push(normalizeMarkdown(usage, true));
    }
    const maybeDesc = this.#fields[start];
    if (maybeDesc && isDescription(maybeDesc)) {
      out.push(normalizeMarkdown(maybeDesc.text, maybeDesc.pre));
      start++;
    }
    const { rows } = this.#usageRows(start);
    for (const row of rows) {
      if (row.left) {
        out.push("#".repeat(headingLevel + 1) + " " + normalizeOneLine(row.left, true));
        if (row.text)
          out.push(normalizeMarkdown(row.text));
      } else if (isHeading(row)) {
        const { level } = row;
        headingLevel = level;
        out.push(`${"#".repeat(headingLevel)} ${normalizeOneLine(row.text, row.pre)}`);
      } else {
        out.push(normalizeMarkdown(row.text, !!row.pre));
      }
    }
    return this.#usageMarkdown = out.join("\n\n") + "\n";
  }
  #usageRows(start) {
    const maxMax = Math.max(12, Math.min(26, Math.floor(width / 3)));
    let maxWidth = 8;
    let prev = void 0;
    const rows = [];
    for (const field of this.#fields.slice(start)) {
      if (field.type !== "config") {
        if (prev?.type === "config")
          prev.skipLine = true;
        prev = void 0;
        field.text = normalize(field.text, !!field.pre);
        rows.push(field);
        continue;
      }
      const { value } = field;
      const desc = value.description || "";
      const mult = value.multiple ? "Can be set multiple times" : "";
      const opts = value.validOptions?.length ? "Valid options: " + value.validOptions.map((v2) => JSON.stringify(v2)).join(", ") : "";
      const dmDelim = desc.includes("\n") ? "\n\n" : "\n";
      const extra = [opts, mult].join(dmDelim).trim();
      const text = (normalize(desc) + dmDelim + extra).trim();
      const hint = value.hint || (value.type === "number" ? "n" : value.type === "string" ? field.name : void 0);
      const short = !value.short ? "" : value.type === "boolean" ? `-${value.short} ` : `-${value.short}<${hint}> `;
      const left = value.type === "boolean" ? `${short}--${field.name}` : `${short}--${field.name}=<${hint}>`;
      const row = { text, left, type: "config" };
      if (text.length > width - maxMax) {
        row.skipLine = true;
      }
      if (prev && left.length > maxMax)
        prev.skipLine = true;
      prev = row;
      const len = left.length + 4;
      if (len > maxWidth && len < maxMax) {
        maxWidth = len;
      }
      rows.push(row);
    }
    return { rows, maxWidth };
  }
  /**
   * Return the configuration options as a plain object
   */
  toJSON() {
    return Object.fromEntries(Object.entries(this.#configSet).map(([field, def]) => [
      field,
      {
        type: def.type,
        ...def.multiple ? { multiple: true } : {},
        ...def.delim ? { delim: def.delim } : {},
        ...def.short ? { short: def.short } : {},
        ...def.description ? { description: normalize(def.description) } : {},
        ...def.validate ? { validate: def.validate } : {},
        ...def.validOptions ? { validOptions: def.validOptions } : {},
        ...def.default !== void 0 ? { default: def.default } : {},
        ...def.hint ? { hint: def.hint } : {}
      }
    ]));
  }
  /**
   * Custom printer for `util.inspect`
   */
  [inspect.custom](_2, options) {
    return `Jack ${inspect(this.toJSON(), options)}`;
  }
};
var jack = (options = {}) => new Jack(options);
var normalize = (s, pre = false) => {
  if (pre)
    return s.split("\n").map((l) => `\u200B${l}`).join("\n");
  return s.split(/^\s*```\s*$/gm).map((s2, i) => {
    if (i % 2 === 1) {
      if (!s2.trim()) {
        return `\`\`\`
\`\`\`
`;
      }
      const split = s2.split("\n");
      split.pop();
      split.shift();
      const si = split.reduce((shortest, l) => {
        const ind = l.match(/^\s*/)?.[0] ?? "";
        if (ind.length)
          return Math.min(ind.length, shortest);
        else
          return shortest;
      }, Infinity);
      const i2 = isFinite(si) ? si : 0;
      return "\n```\n" + split.map((s3) => `\u200B${s3.substring(i2)}`).join("\n") + "\n```\n";
    }
    return s2.replace(/([^\n])\n[ \t]*([^\n])/g, (_2, $1, $2) => !/^[-*]/.test($2) ? `${$1} ${$2}` : `${$1}
${$2}`).replace(/([^\n])[ \t]+([^\n])/g, "$1 $2").replace(/\n{3,}/g, "\n\n").replace(/\n[ \t]+/g, "\n").trim();
  }).join("\n");
};
var normalizeMarkdown = (s, pre = false) => {
  const n = normalize(s, pre).replace(/\\/g, "\\\\");
  return pre ? `\`\`\`
${n.replace(/\u200b/g, "")}
\`\`\`` : n.replace(/\n +/g, "\n").trim();
};
var normalizeOneLine = (s, pre = false) => {
  const n = normalize(s, pre).replace(/[\s\u200b]+/g, " ").trim();
  return pre ? `\`${n}\`` : n;
};

// ../../src/cli-sdk/src/config/definition.ts
var defaultView = (
  // If stdout is a TTY, use human output
  process.stdout.isTTY ? "human" : process.env.CI ? "human" : "json"
);
var defaultEditor = () => process.env.EDITOR || process.env.VISUAL || (process.platform === "win32" ? `${process.env.SYSTEMROOT}\\notepad.exe` : "vi");
var canonicalCommands = {
  bugs: "bugs",
  build: "build",
  cache: "cache",
  ci: "ci",
  config: "config",
  create: "create",
  docs: "docs",
  exec: "exec",
  "exec-local": "exec-local",
  help: "help",
  init: "init",
  install: "install",
  login: "login",
  logout: "logout",
  list: "list",
  ls: "ls",
  pack: "pack",
  ping: "ping",
  pkg: "pkg",
  publish: "publish",
  query: "query",
  repo: "repo",
  "run-exec": "run-exec",
  run: "run",
  token: "token",
  uninstall: "uninstall",
  update: "update",
  "exec-cache": "exec-cache",
  version: "version",
  view: "view",
  whoami: "whoami"
};
var aliases = {
  i: "install",
  add: "install",
  rm: "uninstall",
  u: "update",
  p: "pkg",
  pub: "publish",
  q: "query",
  b: "build",
  r: "run",
  "run-script": "run",
  rx: "run-exec",
  x: "exec",
  xl: "exec-local",
  h: "help",
  "?": "help",
  info: "view",
  ls: "list",
  show: "view",
  xc: "exec-cache"
};
var commands = {
  ...canonicalCommands,
  ...aliases
};
var commandAliases = Object.entries(aliases).reduce(
  (acc, [alias, canonical]) => {
    const commandAliases2 = acc.get(canonical);
    if (commandAliases2) {
      commandAliases2.push(alias);
    } else {
      acc.set(canonical, [alias]);
    }
    return acc;
  },
  /* @__PURE__ */ new Map()
);
var getCommand = (s) => s && s in commands ? commands[s] : void 0;
var xdg = new XDG("vlt");
var cacheDir = xdg.cache();
var recordFields = [
  "git-hosts",
  "registries",
  "git-host-archives",
  "scope-registries",
  "jsr-registries"
];
var isRecordField = (s) => recordFields.includes(s);
var stopParsingCommands = [
  "create",
  "run",
  "run-exec",
  "exec-local",
  "exec"
];
var stopParsing = void 0;
var j2 = jack({
  envPrefix: "VLT",
  allowPositionals: true,
  usage: `vlt [<options>] [<cmd> [<args> ...]]`,
  stopAtPositionalTest: (arg) => {
    if (stopParsing) return true;
    const a = arg;
    if (stopParsingCommands.includes(commands[a])) {
      stopParsing = true;
    }
    return false;
  }
}).heading("vlt").description(
  `More documentation available at <https://docs.vlt.sh>`
).heading("Subcommands");
j2.description(Object.keys(canonicalCommands).join(", "), {
  pre: true
}).description(
  "Run `vlt <cmd> --help` for more information about a specific command"
);
var definition = j2.heading("Configuration").description(
  `If a \`vlt.json\` file is present in the root of the current project,
     then that will be used as a source of configuration information.

     Next, the \`vlt.json\` file in the XDG specified config directory
     will be checked, and loaded for any fields not set in the local project.

     Object type values will be merged together. Set a field to \`null\` in
     the JSON configuration to explicitly remove it.

     Command-specific fields may be set in a nested \`command\` object that
     overrides any options defined at the top level.
    `
).flag({
  color: {
    short: "c",
    description: "Use colors (Default for TTY)"
  },
  "no-color": {
    short: "C",
    description: "Do not use colors (Default for non-TTY)"
  }
}).opt({
  registry: {
    hint: "url",
    default: "https://registry.npmjs.org/",
    description: `Sets the registry for fetching packages, when no registry
                    is explicitly set on a specifier.

                    For example, \`express@latest\` will be resolved by looking
                    up the metadata from this registry.

                    Note that alias specifiers starting with \`npm:\` will
                    still map to \`https://registry.npmjs.org/\` if this is
                    changed, unless the a new mapping is created via the
                    \`--registries\` option.
      `
  }
}).optList({
  registries: {
    hint: "name=url",
    description: `Specify named registry hosts by their prefix. To set the
                    default registry used for non-namespaced specifiers,
                    use the \`--registry\` option.

                    Prefixes can be used as a package alias. For example:

                    \`\`\`
                    vlt --registries loc=http://reg.local install foo@loc:foo@1.x
                    \`\`\`

                    By default, the public npm registry is registered to the
                    \`npm:\` prefix. It is not recommended to change this
                    mapping in most cases.
                    `
  },
  "scope-registries": {
    hint: "@scope=url",
    description: `Map package name scopes to registry URLs.

                    For example,
                    \`--scope-registries @acme=https://registry.acme/\`
                    would tell vlt to fetch any packages named
                    \`@acme/...\` from the \`https://registry.acme/\`
                    registry.

                    Note: this way of specifying registries is more ambiguous,
                    compared with using the \`--registries\` field and explicit
                    prefixes, because instead of failing when the configuration
                    is absent, it will instead attempt to fetch from the
                    default registry.

                    By comparison, using
                    \`--registries acme=https://registry.acme/\` and then
                    specifying dependencies such as \`"foo": "acme:foo@1.x"\`
                    means that regardless of the name, the package will be
                    fetched from the explicitly named registry, or fail if
                    no registry is defined with that name.

                    However, custom registry aliases are not supported by other
                    package managers.`
  },
  "jsr-registries": {
    hint: "name=url",
    description: `Map alias names to JSR.io registry urls.

                    For example,
                    \`--jsr-registries acme=https://jsr.acme.io/\` would
                    tell vlt to fetch any packages with the \`acme:\` registry
                    prefix from the \`https://jsr.acme.io/\` registry, using
                    the "npm Compatibility" translation. So for example,
                    the package \`acme:@foo/bar\` would fetch the
                    \`@jsr/foo__bar\` package from the \`jsr.acme.io\`
                    registry.

                    By default the \`jsr\` alias is always mapped to
                    \`https://npm.jsr.io/\`, so existing \`jsr:\` packages will
                    be fetched from the public \`jsr\` registry appropriately.
                   `
  },
  "git-hosts": {
    hint: `name=template`,
    short: "G",
    description: `Map a shorthand name to a git remote URL template.

                    The \`template\` may contain placeholders, which will be
                    swapped with the relevant values.

                    \`$1\`, \`$2\`, etc. are replaced with the appropriate
                    n-th path portion. For example, \`github:user/project\`
                    would replace the \`$1\` in the template with \`user\`,
                    and \`$2\` with \`project\`.`
  },
  "git-host-archives": {
    hint: `name=template`,
    short: "A",
    description: `Similar to the \`--git-host <name>=<template>\` option,
                    this option can define a template string that will be
                    expanded to provide the URL to download a pre-built
                    tarball of the git repository.

                    In addition to the n-th path portion expansions performed
                    by \`--git-host\`, this field will also expand the
                    string \`$committish\` in the template, replacing it with
                    the resolved git committish value to be fetched.`
  }
}).opt({
  cache: {
    hint: "path",
    description: `
        Location of the vlt on-disk cache. Defaults to the platform-specific
        directory recommended by the XDG specification.
      `,
    default: cacheDir
  },
  tag: {
    description: `Default \`dist-tag\` to install or publish`,
    default: "latest"
  },
  before: {
    hint: "date",
    description: `Do not install any packages published after this date`
  },
  os: {
    description: `The operating system to use as the selector when choosing
                    packages based on their \`os\` value.`,
    default: process.platform
  },
  arch: {
    description: `CPU architecture to use as the selector when choosing
                    packages based on their \`cpu\` value.`,
    default: process.arch
  },
  libc: {
    description: `Override the libc family to use as the selector when choosing
                    packages based on their \`libc\` value (e.g. glibc, musl).
                    By default, this is auto-detected on Linux systems.`
  },
  "node-version": {
    hint: "version",
    description: `Node version to use when choosing packages based on
                    their \`engines.node\` value.`,
    default: process.version
  }
}).flag({
  "git-shallow": {
    description: `Set to force \`--depth=1\` on all git clone actions.
                    When set explicitly to false with --no-git-shallow,
                    then \`--depth=1\` will not be used.

                    When not set explicitly, \`--depth=1\` will be used for
                    git hosts known to support this behavior.`
  }
}).num({
  "fetch-retries": {
    hint: "n",
    description: `Number of retries to perform when encountering network
                    errors or likely-transient errors from git hosts.`,
    default: 3
  },
  "fetch-retry-factor": {
    hint: "n",
    description: `The exponential backoff factor to use when retrying
                    requests due to network issues.`,
    default: 2
  },
  "fetch-retry-mintimeout": {
    hint: "n",
    description: `Number of milliseconds before starting first retry`,
    default: 0
  },
  "fetch-retry-maxtimeout": {
    hint: "n",
    description: `Maximum number of milliseconds between two retries`,
    default: 3e4
  },
  "stale-while-revalidate-factor": {
    hint: "n",
    default: 60,
    description: `If the server does not serve a \`stale-while-revalidate\`
                    value in the \`cache-control\` header, then this multiplier
                    is applied to the \`max-age\` or \`s-maxage\` values.

                    By default, this is \`60\`, so for example a response that
                    is cacheable for 5 minutes will allow a stale response
                    while revalidating for up to 5 hours.

                    If the server *does* provide a \`stale-while-revalidate\`
                    value, then that is always used.

                    Set to 0 to prevent any \`stale-while-revalidate\` behavior
                    unless explicitly allowed by the server's \`cache-control\`
                    header.
      `
  }
}).opt({
  identity: {
    short: "i",
    validate: (v2) => typeof v2 === "string" && /^[a-z0-9]*$/.test(v2),
    hint: "name",
    default: "",
    description: `Provide a string to define an identity for storing auth
                    information when logging into registries.

                    Authentication tokens will be stored in the XDG data
                    directory, in \`vlt/auth/\${identity}/keychain.json\`.

                    If no identity is provided, then the default \`''\` will
                    be used, storing the file at \`vlt/auth/keychain.json\`.

                    May only contain lowercase alphanumeric characters.
                    `
  }
}).optList({
  workspace: {
    hint: "ws",
    short: "w",
    description: `Set to limit the spaces being worked on when working on
                    workspaces.

                    Can be paths or glob patterns matching paths.

                    Specifying workspaces by package.json name is not
                    supported.`
  },
  "workspace-group": {
    description: `Specify named workspace group names to load and operate on
                    when doing recursive operations on workspaces.`
  }
}).opt({
  scope: {
    short: "s",
    hint: "query",
    description: "Set to filter the scope of an operation using a DSS Query."
  },
  target: {
    short: "t",
    hint: "query",
    description: "Set to select packages using a DSS Query selector."
  }
}).flag({
  "if-present": {
    description: `When running scripts across multiple packages,
                    only include packages that have the script.

                    If this is not set, then the run will fail if any
                    packages do not have the script.

                    This will default to true if --scope, --workspace,
                    --workspace-group, or --recursive is set. Otherwise,
                    it will default to false.`
  }
}).flag({
  recursive: {
    short: "r",
    description: `Run an operation across multiple workspaces.

                    No effect when used in non-monorepo projects.

                    Implied by setting --workspace or --workspace-group. If
                    not set, then the action is run on the project root.`
  },
  bail: {
    short: "b",
    description: `When running scripts across multiple workspaces, stop
                    on the first failure.`,
    default: true
  },
  "no-bail": {
    short: "B",
    description: `When running scripts across multiple workspaces, continue
                    on failure, running the script for all workspaces.`
  }
}).opt({
  config: {
    hint: "all | user | project",
    description: `Specify which configuration to show or operate on when running
                    \`vlt config\` commands. For read operations (get, pick, list):
                    \`all\` shows merged configuration from both user and project
                    files (default). For write operations (set, delete, edit):
                    defaults to \`project\`. \`user\` shows/modifies only user-level
                    configuration, \`project\` shows/modifies only project-level
                    configuration.`,
    validOptions: ["all", "user", "project"],
    default: "all"
  },
  editor: {
    hint: "program",
    description: `The blocking editor to use for \`vlt config edit\` and
                    any other cases where a file should be opened for
                    editing.

                    Defaults to the \`EDITOR\` or \`VISUAL\` env if set, or
                    \`notepad.exe\` on Windows, or \`vi\` elsewhere.`,
    default: defaultEditor()
  },
  "script-shell": {
    hint: "program",
    description: `The shell to use when executing \`package.json#scripts\`.

                    For \`vlt exec\` and \`vlt exec-local\`, this is never set,
                    meaning that command arguments are run exactly as provided.

                    For \`vlt run\` (and other things that run lifecycle
                    scripts in \`package.json#scripts\`), the entire command
                    with all arguments is provided as a single string, meaning
                    that some value must be provided for shell interpretation,
                    and so for these contexts, the \`script-shell\` value will
                    default to \`/bin/sh\` on POSIX systems or \`cmd.exe\` on
                    Windows.
      `
  },
  "fallback-command": {
    hint: "command",
    description: `The command to run when the first argument doesn't
                    match any known commands.

                    For pnpm-style behavior, set this to 'run-exec'. e.g:
                    \`\`\`
                    vlt config set fallback-command=run-exec
                    \`\`\``,
    default: "help",
    validOptions: Object.keys(canonicalCommands)
  }
}).opt({
  package: {
    hint: "p",
    description: `When running \`vlt exec\`, this allows you to explicitly
                    set the package to search for bins. If not provided, then
                    vlt will interpret the first argument as the package, and
                    attempt to run the default executable.`
  }
}).opt({
  call: {
    hint: "cmd",
    description: `When running \`vlt exec\`, provide an arbitrary command
                    string to execute after installing and adding any specified
                    package bins to the PATH.

                    If a package is specified (via positionals or
                    \`--package\`), it will be installed and its executables
                    added to the PATH before the \`--call\` command runs.

                    The command string is executed via the configured
                    \`script-shell\`, or the \`SHELL\` environment variable,
                    falling back to \`/bin/sh\` on Unix or \`cmd.exe\` on
                    Windows. On Unix, the shell is invoked with \`-c\`; on
                    Windows with \`/c\`.

                    Example:
                    \`vlt exec create-react-app --call="echo $PWD"\`
                    \`vlt exec --call="echo $PWD" --scope=":workspace"\``
  }
}).opt({
  view: {
    hint: "output",
    default: defaultView,
    description: `Configures the output format for commands.

                    Defaults to \`human\` if stdout is a TTY, or \`json\`
                    if it is not.

                    - human: Maximally ergonomic output reporting for human
                      consumption.
                    - json: Parseable JSON output for machines.
                    - inspect: Output results with \`util.inspect\`.
                    - mermaid: Output mermaid diagramming syntax. (Only
                      relevant for certain commands.)
                    - svg: Render the dependency graph as an SVG image and
                      open it. (Only relevant for certain commands.)
                    - png: Render the dependency graph as a PNG image and
                      open it. (Only relevant for certain commands.)
                    - count: Output the number of dependency relationships in
                      the result set.
                    - silent: Suppress all output to stdout.

                    If the requested view format is not supported for the
                    current command, or if no option is provided, then it
                    will fall back to the default.
      `,
    validOptions: [
      "human",
      "json",
      "mermaid",
      "svg",
      "png",
      "count",
      "inspect",
      "silent"
    ]
  }
}).optList({
  "dashboard-root": {
    hint: "path",
    description: `The root directory to use for the dashboard browser-based UI.
                    If not set, the user home directory is used.`
  }
}).flag({
  "save-dev": {
    short: "D",
    description: `Save installed packages to a package.json file as
                    devDependencies`
  },
  "save-optional": {
    short: "O",
    description: `Save installed packages to a package.json file as
                    optionalDependencies`
  },
  "save-peer": {
    description: `Save installed packages to a package.json file as
                    peerDependencies`
  },
  "save-prod": {
    short: "P",
    description: `Save installed packages into dependencies specifically.
                    This is useful if a package already exists in
                    devDependencies or optionalDependencies, but you want to
                    move it to be a non-optional production dependency.`
  }
}).opt({
  "expect-results": {
    hint: "value",
    validate: (v2) => typeof v2 === "string" && /^([<>]=?)?[0-9]+$/.test(v2),
    description: `When running \`vlt query\`, this option allows you to
                    set a expected number of resulting items.

                    Accepted values are numbers and strings.

                    Strings starting with \`>\`, \`<\`, \`>=\` or \`<=\`
                    followed by a number can be used to check if the result
                    is greater than or less than a specific number.`
  }
}).flag({
  "dry-run": {
    description: "Run command without making any changes"
  },
  "expect-lockfile": {
    description: "Fail if lockfile is missing or out of date. Used by ci command to enforce lockfile integrity."
  },
  "frozen-lockfile": {
    description: "Fail if lockfile is missing or out of sync with package.json. Prevents any lockfile modifications."
  },
  "lockfile-only": {
    description: "Only update the lockfile (vlt-lock.json) and package.json files, skip all node_modules operations including package extraction and filesystem changes."
  }
}).opt({
  "allow-scripts": {
    hint: "query",
    description: `Filter which packages are allowed to run lifecycle scripts using DSS query syntax.
                    When provided, only packages matching the query will execute their
                    install, preinstall, postinstall, prepare, preprepare, and postprepare scripts.
                    Defaults to ':not(*)' which means no scripts will be run.
                    
                    Example: --allow-scripts=":root > *, #my-package"
                    Runs scripts only for direct dependencies of the current project and any occurrences
                    of a specific dependency with the name "my-package" anywhere in the dependency graph.`
  }
}).opt({
  access: {
    description: "Set the access level of the package",
    validOptions: ["public", "restricted"]
  }
}).opt({
  otp: {
    description: `Provide an OTP to use when publishing a package.`
  },
  "publish-directory": {
    hint: "path",
    description: `Directory to use for pack and publish operations instead of the current directory.
                    The directory must exist and nothing will be copied to it.`
  }
}).flag({
  yes: {
    short: "y",
    description: `Automatically accept any confirmation prompts`
  },
  version: {
    short: "v",
    description: "Print the version"
  },
  help: {
    short: "h",
    description: "Print helpful information"
  },
  all: {
    short: "a",
    description: "Show all commands, bins, and flags"
  }
});
var getSortedCliOptions = () => {
  const defs = definition.toJSON();
  return getSortedKeys().map((k2) => {
    const def = defs[k2];
    if (!def) throw error("invalid key found", { found: k2 });
    if (def.type === "boolean") return `--${k2}`;
    return `--${k2}=<${def.hint ?? k2}>`;
  });
};
var getSortedKeys = () => Object.keys(definition.toJSON()).sort((a, b2) => a.localeCompare(b2));

export {
  jack,
  defaultView,
  commands,
  commandAliases,
  getCommand,
  recordFields,
  isRecordField,
  definition,
  getSortedCliOptions,
  getSortedKeys
};
