var global = globalThis;
import {Buffer} from "node:buffer";
import {setTimeout as _vlt_setTimeout,clearTimeout as _vlt_clearTimeout,setImmediate as _vlt_setImmediate,clearImmediate as _vlt_clearImmediate,setInterval as _vlt_setInterval,clearInterval as _vlt_clearInterval} from "node:timers";
globalThis.setTimeout = _vlt_setTimeout;
globalThis.clearTimeout = _vlt_clearTimeout;
globalThis.setImmediate = _vlt_setImmediate;
globalThis.clearImmediate = _vlt_clearImmediate;
globalThis.setInterval = _vlt_setInterval;
globalThis.clearInterval = _vlt_clearInterval;
import {createRequire as _vlt_createRequire} from "node:module";
var require = _vlt_createRequire(import.meta.filename);
import {
  promiseSpawn,
  which
} from "./chunk-VCSVHRCS.js";

// ../../src/url-open/src/index.ts
import { release } from "node:os";
var { platform } = process;
if (platform === "linux" && release().toLowerCase().includes("microsoft")) {
  platform = "win32";
}
var log = (msg) => console.error(msg);
var urlOpen = async (url, { signal } = {}) => {
  const cmd = platform === "win32" ? "start" : platform === "darwin" ? "open" : "xdg-open";
  const args = [url];
  const link = process.stderr.isTTY ? `\x1B]8;;${url}\x1B\\${url}\x1B]8;;\x1B\\` : url;
  if (
    // Use stdin.isTTY to detect if we should attempt to open
    // a browser or not
    !process.stdin.isTTY || // Also check if the command is available since we don't
    // want the process to exit if we aren't able to open a browser.
    await which(cmd, { nothrow: true }) === null
  ) {
    log(`Could not open a browser. Please open ${link} manually.`);
    return;
  }
  log(`Opening a web browser to: ${link}`);
  return promiseSpawn(
    platform === "win32" ? `${cmd} ""` : cmd,
    platform === "win32" ? ['""', ...args] : args,
    {
      signal,
      shell: true,
      stdio: "inherit"
    }
  );
};

export {
  urlOpen
};
