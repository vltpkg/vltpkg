var global = globalThis;
import {Buffer} from "node:buffer";
import {setTimeout as _vlt_setTimeout,clearTimeout as _vlt_clearTimeout,setImmediate as _vlt_setImmediate,clearImmediate as _vlt_clearImmediate,setInterval as _vlt_setInterval,clearInterval as _vlt_clearInterval} from "node:timers";
globalThis.setTimeout = _vlt_setTimeout;
globalThis.clearTimeout = _vlt_clearTimeout;
globalThis.setImmediate = _vlt_setImmediate;
globalThis.clearImmediate = _vlt_clearImmediate;
globalThis.setInterval = _vlt_setInterval;
globalThis.clearInterval = _vlt_clearInterval;
import {createRequire as _vlt_createRequire} from "node:module";
var require = _vlt_createRequire(import.meta.filename);

// ../../src/dot-prop/src/index.ts
var DISALLOWED_KEYS = /* @__PURE__ */ new Set([
  "__proto__",
  "prototype",
  "constructor"
]);
var DIGITS = new Set("0123456789");
var ARRAY_PUSH = /* @__PURE__ */ Symbol("ARRAY_PUSH");
var Characters = {
  Escape: "\\",
  Dot: ".",
  Empty: "",
  LeftBracket: "[",
  RightBracket: "]"
};
var Parts = {
  Start: "start",
  Index: "index",
  IndexEnd: "indexEnd",
  Property: "property"
};
var checkInvalidCharacter = (part, current, msg) => {
  if (current === part) {
    if (msg === void 0) {
      switch (current) {
        case Parts.Index:
          msg = "character in an index";
          break;
        case Parts.IndexEnd:
          msg = "character after an index";
          break;
        /* c8 ignore next 3 */
        default:
          msg = "";
          break;
      }
    }
    throw new Error(`Invalid ${msg}`.trim());
  }
};
var getPathSegments = (path, allowEmptyIndex = false) => {
  const segments = [];
  let currentSegment = Characters.Empty;
  let currentPart = Parts.Start;
  let isIgnoring = false;
  for (const character of path.split("")) {
    switch (character) {
      case Characters.Escape: {
        checkInvalidCharacter(Parts.Index, currentPart);
        checkInvalidCharacter(Parts.IndexEnd, currentPart);
        if (isIgnoring) currentSegment += character;
        currentPart = Parts.Property;
        isIgnoring = !isIgnoring;
        break;
      }
      case Characters.Dot: {
        checkInvalidCharacter(Parts.Index, currentPart);
        if (currentPart === Parts.IndexEnd) {
          currentPart = Parts.Property;
          break;
        }
        if (isIgnoring) {
          isIgnoring = false;
          currentSegment += character;
          break;
        }
        if (DISALLOWED_KEYS.has(currentSegment)) return [];
        segments.push(currentSegment);
        currentSegment = Characters.Empty;
        currentPart = Parts.Property;
        break;
      }
      case Characters.LeftBracket: {
        checkInvalidCharacter(Parts.Index, currentPart);
        if (currentPart === Parts.IndexEnd) {
          currentPart = Parts.Index;
          break;
        }
        if (isIgnoring) {
          isIgnoring = false;
          currentSegment += character;
          break;
        }
        if (currentPart === Parts.Property) {
          if (DISALLOWED_KEYS.has(currentSegment)) return [];
          segments.push(currentSegment);
          currentSegment = Characters.Empty;
        }
        currentPart = Parts.Index;
        break;
      }
      case Characters.RightBracket: {
        if (currentPart === Parts.Index) {
          if (allowEmptyIndex)
            checkInvalidCharacter(
              Characters.Empty,
              currentSegment,
              "empty index"
            );
          segments.push(
            currentSegment === Characters.Empty ? ARRAY_PUSH : Number.parseInt(currentSegment, 10)
          );
          currentPart = Parts.IndexEnd;
          currentSegment = Characters.Empty;
          break;
        }
      }
      default: {
        if (!DIGITS.has(character))
          checkInvalidCharacter(Parts.Index, currentPart);
        checkInvalidCharacter(Parts.IndexEnd, currentPart);
        if (currentPart === Parts.Start) currentPart = Parts.Property;
        if (isIgnoring) {
          isIgnoring = false;
          currentSegment += Characters.Escape;
        }
        currentSegment += character;
      }
    }
  }
  if (isIgnoring) currentSegment += Characters.Escape;
  checkInvalidCharacter(
    Parts.Index,
    currentPart,
    "index was not closed"
  );
  if (currentPart === Parts.Property) {
    if (DISALLOWED_KEYS.has(currentSegment)) return [];
    segments.push(currentSegment);
  } else if (currentPart === Parts.Start) {
    segments.push(Characters.Empty);
  }
  return segments;
};
var isObject = (value) => value !== null && typeof value === "object";
var isLast = (arr, i) => i === arr.length - 1;
var isStringIndex = (object, key) => {
  if (typeof key !== "symbol" && typeof key !== "number" && Array.isArray(object)) {
    const index = Number.parseInt(key, 10);
    return Number.isInteger(index) && object[index] === object[key];
  }
  return false;
};
var assertNotStringIndex = (object, key) => {
  if (isStringIndex(object, key)) {
    throw new Error("Cannot use string index");
  }
};
var get = (ogObject, path, defaultValue) => {
  let object = ogObject;
  const pathArray = getPathSegments(path, true);
  if (!pathArray.length) {
    return defaultValue;
  }
  for (const [index, key] of pathArray.entries()) {
    if (isStringIndex(object, key)) {
      object = isLast(pathArray, index) ? void 0 : null;
    } else {
      object = object[key];
    }
    if ((object === void 0 || object === null) && !isLast(pathArray, index)) {
      return defaultValue;
    }
  }
  return object === void 0 ? defaultValue : object;
};
var set = (object, path, value) => {
  const root = object;
  const pathArray = getPathSegments(path);
  for (const [index, key] of pathArray.entries()) {
    assertNotStringIndex(object, key);
    if (isLast(pathArray, index)) {
      if (key === ARRAY_PUSH) {
        ;
        object.push(value);
      } else {
        ;
        object[key] = value;
      }
    } else if (!isObject(object[key])) {
      const next = pathArray[index + 1];
      object[key] = typeof next === "number" || next === ARRAY_PUSH ? [] : {};
    }
    object = object[key];
  }
  return root;
};
var del = (object, path) => {
  const pathArray = getPathSegments(path);
  for (const [index, key] of pathArray.entries()) {
    assertNotStringIndex(object, key);
    if (isLast(pathArray, index)) {
      if (Array.isArray(object)) {
        object.splice(key, 1);
      } else {
        delete object[key];
      }
      return true;
    }
    object = object[key];
    if (!isObject(object)) {
      return false;
    }
  }
  return false;
};

export {
  get,
  set,
  del
};
