var global = globalThis;
import {Buffer} from "node:buffer";
import {setTimeout as _vlt_setTimeout,clearTimeout as _vlt_clearTimeout,setImmediate as _vlt_setImmediate,clearImmediate as _vlt_clearImmediate,setInterval as _vlt_setInterval,clearInterval as _vlt_clearInterval} from "node:timers";
globalThis.setTimeout = _vlt_setTimeout;
globalThis.clearTimeout = _vlt_clearTimeout;
globalThis.setImmediate = _vlt_setImmediate;
globalThis.clearImmediate = _vlt_clearImmediate;
globalThis.setInterval = _vlt_setInterval;
globalThis.clearInterval = _vlt_clearInterval;
import {createRequire as _vlt_createRequire} from "node:module";
var require = _vlt_createRequire(import.meta.filename);
import {
  require_lib,
  zn
} from "./chunk-FI5TUER7.js";
import {
  RegistryClient
} from "./chunk-YOCFBK4Y.js";
import {
  Monorepo,
  PackageJson,
  clone,
  pickManifest,
  resolve,
  revs
} from "./chunk-Z76BQOEV.js";
import {
  rimraf
} from "./chunk-BGQCUUCA.js";
import {
  Spec2 as Spec
} from "./chunk-FEV5BCW7.js";
import {
  asError,
  asPackument,
  isIntegrity
} from "./chunk-KXBF4HVG.js";
import {
  XDG
} from "./chunk-XNLSTHDK.js";
import {
  error
} from "./chunk-WZWDS3W4.js";
import {
  __toESM
} from "./chunk-PZLD7RTK.js";

// ../../src/tar/src/unpack.ts
import { randomBytes } from "node:crypto";
import { lstat, mkdir, rename, writeFile } from "node:fs/promises";
import { basename as basename2, dirname, resolve as resolve2, sep } from "node:path";

// ../../node_modules/.vlt/~npm~tar@7.5.11/node_modules/tar/dist/esm/header.js
import { posix as pathModule } from "node:path";

// ../../node_modules/.vlt/~npm~tar@7.5.11/node_modules/tar/dist/esm/large-numbers.js
var encode = (num, buf) => {
  if (!Number.isSafeInteger(num)) {
    throw Error("cannot encode number outside of javascript safe integer range");
  } else if (num < 0) {
    encodeNegative(num, buf);
  } else {
    encodePositive(num, buf);
  }
  return buf;
};
var encodePositive = (num, buf) => {
  buf[0] = 128;
  for (var i = buf.length; i > 1; i--) {
    buf[i - 1] = num & 255;
    num = Math.floor(num / 256);
  }
};
var encodeNegative = (num, buf) => {
  buf[0] = 255;
  var flipped = false;
  num = num * -1;
  for (var i = buf.length; i > 1; i--) {
    var byte = num & 255;
    num = Math.floor(num / 256);
    if (flipped) {
      buf[i - 1] = onesComp(byte);
    } else if (byte === 0) {
      buf[i - 1] = 0;
    } else {
      flipped = true;
      buf[i - 1] = twosComp(byte);
    }
  }
};
var parse = (buf) => {
  const pre = buf[0];
  const value = pre === 128 ? pos(buf.subarray(1, buf.length)) : pre === 255 ? twos(buf) : null;
  if (value === null) {
    throw Error("invalid base256 encoding");
  }
  if (!Number.isSafeInteger(value)) {
    throw Error("parsed number outside of javascript safe integer range");
  }
  return value;
};
var twos = (buf) => {
  var len = buf.length;
  var sum = 0;
  var flipped = false;
  for (var i = len - 1; i > -1; i--) {
    var byte = Number(buf[i]);
    var f;
    if (flipped) {
      f = onesComp(byte);
    } else if (byte === 0) {
      f = byte;
    } else {
      flipped = true;
      f = twosComp(byte);
    }
    if (f !== 0) {
      sum -= f * Math.pow(256, len - i - 1);
    }
  }
  return sum;
};
var pos = (buf) => {
  var len = buf.length;
  var sum = 0;
  for (var i = len - 1; i > -1; i--) {
    var byte = Number(buf[i]);
    if (byte !== 0) {
      sum += byte * Math.pow(256, len - i - 1);
    }
  }
  return sum;
};
var onesComp = (byte) => (255 ^ byte) & 255;
var twosComp = (byte) => (255 ^ byte) + 1 & 255;

// ../../node_modules/.vlt/~npm~tar@7.5.11/node_modules/tar/dist/esm/types.js
var isCode = (c) => name.has(c);
var name = /* @__PURE__ */ new Map([
  ["0", "File"],
  // same as File
  ["", "OldFile"],
  ["1", "Link"],
  ["2", "SymbolicLink"],
  // Devices and FIFOs aren't fully supported
  // they are parsed, but skipped when unpacking
  ["3", "CharacterDevice"],
  ["4", "BlockDevice"],
  ["5", "Directory"],
  ["6", "FIFO"],
  // same as File
  ["7", "ContiguousFile"],
  // pax headers
  ["g", "GlobalExtendedHeader"],
  ["x", "ExtendedHeader"],
  // vendor-specific stuff
  // skip
  ["A", "SolarisACL"],
  // like 5, but with data, which should be skipped
  ["D", "GNUDumpDir"],
  // metadata only, skip
  ["I", "Inode"],
  // data = link path of next file
  ["K", "NextFileHasLongLinkpath"],
  // data = path of next file
  ["L", "NextFileHasLongPath"],
  // skip
  ["M", "ContinuationFile"],
  // like L
  ["N", "OldGnuLongPath"],
  // skip
  ["S", "SparseFile"],
  // skip
  ["V", "TapeVolumeHeader"],
  // like x
  ["X", "OldExtendedHeader"]
]);
var code = new Map(Array.from(name).map((kv) => [kv[1], kv[0]]));

// ../../node_modules/.vlt/~npm~tar@7.5.11/node_modules/tar/dist/esm/header.js
var Header = class {
  cksumValid = false;
  needPax = false;
  nullBlock = false;
  block;
  path;
  mode;
  uid;
  gid;
  size;
  cksum;
  #type = "Unsupported";
  linkpath;
  uname;
  gname;
  devmaj = 0;
  devmin = 0;
  atime;
  ctime;
  mtime;
  charset;
  comment;
  constructor(data, off = 0, ex, gex) {
    if (Buffer.isBuffer(data)) {
      this.decode(data, off || 0, ex, gex);
    } else if (data) {
      this.#slurp(data);
    }
  }
  decode(buf, off, ex, gex) {
    if (!off) {
      off = 0;
    }
    if (!buf || !(buf.length >= off + 512)) {
      throw new Error("need 512 bytes for header");
    }
    this.path = ex?.path ?? decString(buf, off, 100);
    this.mode = ex?.mode ?? gex?.mode ?? decNumber(buf, off + 100, 8);
    this.uid = ex?.uid ?? gex?.uid ?? decNumber(buf, off + 108, 8);
    this.gid = ex?.gid ?? gex?.gid ?? decNumber(buf, off + 116, 8);
    this.size = ex?.size ?? gex?.size ?? decNumber(buf, off + 124, 12);
    this.mtime = ex?.mtime ?? gex?.mtime ?? decDate(buf, off + 136, 12);
    this.cksum = decNumber(buf, off + 148, 12);
    if (gex)
      this.#slurp(gex, true);
    if (ex)
      this.#slurp(ex);
    const t = decString(buf, off + 156, 1);
    if (isCode(t)) {
      this.#type = t || "0";
    }
    if (this.#type === "0" && this.path.slice(-1) === "/") {
      this.#type = "5";
    }
    if (this.#type === "5") {
      this.size = 0;
    }
    this.linkpath = decString(buf, off + 157, 100);
    if (buf.subarray(off + 257, off + 265).toString() === "ustar\x0000") {
      this.uname = ex?.uname ?? gex?.uname ?? decString(buf, off + 265, 32);
      this.gname = ex?.gname ?? gex?.gname ?? decString(buf, off + 297, 32);
      this.devmaj = ex?.devmaj ?? gex?.devmaj ?? decNumber(buf, off + 329, 8) ?? 0;
      this.devmin = ex?.devmin ?? gex?.devmin ?? decNumber(buf, off + 337, 8) ?? 0;
      if (buf[off + 475] !== 0) {
        const prefix = decString(buf, off + 345, 155);
        this.path = prefix + "/" + this.path;
      } else {
        const prefix = decString(buf, off + 345, 130);
        if (prefix) {
          this.path = prefix + "/" + this.path;
        }
        this.atime = ex?.atime ?? gex?.atime ?? decDate(buf, off + 476, 12);
        this.ctime = ex?.ctime ?? gex?.ctime ?? decDate(buf, off + 488, 12);
      }
    }
    let sum = 8 * 32;
    for (let i = off; i < off + 148; i++) {
      sum += buf[i];
    }
    for (let i = off + 156; i < off + 512; i++) {
      sum += buf[i];
    }
    this.cksumValid = sum === this.cksum;
    if (this.cksum === void 0 && sum === 8 * 32) {
      this.nullBlock = true;
    }
  }
  #slurp(ex, gex = false) {
    Object.assign(this, Object.fromEntries(Object.entries(ex).filter(([k, v]) => {
      return !(v === null || v === void 0 || k === "path" && gex || k === "linkpath" && gex || k === "global");
    })));
  }
  encode(buf, off = 0) {
    if (!buf) {
      buf = this.block = Buffer.alloc(512);
    }
    if (this.#type === "Unsupported") {
      this.#type = "0";
    }
    if (!(buf.length >= off + 512)) {
      throw new Error("need 512 bytes for header");
    }
    const prefixSize = this.ctime || this.atime ? 130 : 155;
    const split = splitPrefix(this.path || "", prefixSize);
    const path = split[0];
    const prefix = split[1];
    this.needPax = !!split[2];
    this.needPax = encString(buf, off, 100, path) || this.needPax;
    this.needPax = encNumber(buf, off + 100, 8, this.mode) || this.needPax;
    this.needPax = encNumber(buf, off + 108, 8, this.uid) || this.needPax;
    this.needPax = encNumber(buf, off + 116, 8, this.gid) || this.needPax;
    this.needPax = encNumber(buf, off + 124, 12, this.size) || this.needPax;
    this.needPax = encDate(buf, off + 136, 12, this.mtime) || this.needPax;
    buf[off + 156] = this.#type.charCodeAt(0);
    this.needPax = encString(buf, off + 157, 100, this.linkpath) || this.needPax;
    buf.write("ustar\x0000", off + 257, 8);
    this.needPax = encString(buf, off + 265, 32, this.uname) || this.needPax;
    this.needPax = encString(buf, off + 297, 32, this.gname) || this.needPax;
    this.needPax = encNumber(buf, off + 329, 8, this.devmaj) || this.needPax;
    this.needPax = encNumber(buf, off + 337, 8, this.devmin) || this.needPax;
    this.needPax = encString(buf, off + 345, prefixSize, prefix) || this.needPax;
    if (buf[off + 475] !== 0) {
      this.needPax = encString(buf, off + 345, 155, prefix) || this.needPax;
    } else {
      this.needPax = encString(buf, off + 345, 130, prefix) || this.needPax;
      this.needPax = encDate(buf, off + 476, 12, this.atime) || this.needPax;
      this.needPax = encDate(buf, off + 488, 12, this.ctime) || this.needPax;
    }
    let sum = 8 * 32;
    for (let i = off; i < off + 148; i++) {
      sum += buf[i];
    }
    for (let i = off + 156; i < off + 512; i++) {
      sum += buf[i];
    }
    this.cksum = sum;
    encNumber(buf, off + 148, 8, this.cksum);
    this.cksumValid = true;
    return this.needPax;
  }
  get type() {
    return this.#type === "Unsupported" ? this.#type : name.get(this.#type);
  }
  get typeKey() {
    return this.#type;
  }
  set type(type) {
    const c = String(code.get(type));
    if (isCode(c) || c === "Unsupported") {
      this.#type = c;
    } else if (isCode(type)) {
      this.#type = type;
    } else {
      throw new TypeError("invalid entry type: " + type);
    }
  }
};
var splitPrefix = (p, prefixSize) => {
  const pathSize = 100;
  let pp = p;
  let prefix = "";
  let ret = void 0;
  const root = pathModule.parse(p).root || ".";
  if (Buffer.byteLength(pp) < pathSize) {
    ret = [pp, prefix, false];
  } else {
    prefix = pathModule.dirname(pp);
    pp = pathModule.basename(pp);
    do {
      if (Buffer.byteLength(pp) <= pathSize && Buffer.byteLength(prefix) <= prefixSize) {
        ret = [pp, prefix, false];
      } else if (Buffer.byteLength(pp) > pathSize && Buffer.byteLength(prefix) <= prefixSize) {
        ret = [pp.slice(0, pathSize - 1), prefix, true];
      } else {
        pp = pathModule.join(pathModule.basename(prefix), pp);
        prefix = pathModule.dirname(prefix);
      }
    } while (prefix !== root && ret === void 0);
    if (!ret) {
      ret = [p.slice(0, pathSize - 1), "", true];
    }
  }
  return ret;
};
var decString = (buf, off, size) => buf.subarray(off, off + size).toString("utf8").replace(/\0.*/, "");
var decDate = (buf, off, size) => numToDate(decNumber(buf, off, size));
var numToDate = (num) => num === void 0 ? void 0 : new Date(num * 1e3);
var decNumber = (buf, off, size) => Number(buf[off]) & 128 ? parse(buf.subarray(off, off + size)) : decSmallNumber(buf, off, size);
var nanUndef = (value) => isNaN(value) ? void 0 : value;
var decSmallNumber = (buf, off, size) => nanUndef(parseInt(buf.subarray(off, off + size).toString("utf8").replace(/\0.*$/, "").trim(), 8));
var MAXNUM = {
  12: 8589934591,
  8: 2097151
};
var encNumber = (buf, off, size, num) => num === void 0 ? false : num > MAXNUM[size] || num < 0 ? (encode(num, buf.subarray(off, off + size)), true) : (encSmallNumber(buf, off, size, num), false);
var encSmallNumber = (buf, off, size, num) => buf.write(octalString(num, size), off, size, "ascii");
var octalString = (num, size) => padOctal(Math.floor(num).toString(8), size);
var padOctal = (str, size) => (str.length === size - 1 ? str : new Array(size - str.length - 1).join("0") + str + " ") + "\0";
var encDate = (buf, off, size, date) => date === void 0 ? false : encNumber(buf, off, size, date.getTime() / 1e3);
var NULLS = new Array(156).join("\0");
var encString = (buf, off, size, str) => str === void 0 ? false : (buf.write(str + NULLS, off, size, "utf8"), str.length !== Buffer.byteLength(str) || str.length > size);

// ../../node_modules/.vlt/~npm~tar@7.5.11/node_modules/tar/dist/esm/pax.js
import { basename } from "node:path";
var Pax = class _Pax {
  atime;
  mtime;
  ctime;
  charset;
  comment;
  gid;
  uid;
  gname;
  uname;
  linkpath;
  dev;
  ino;
  nlink;
  path;
  size;
  mode;
  global;
  constructor(obj, global = false) {
    this.atime = obj.atime;
    this.charset = obj.charset;
    this.comment = obj.comment;
    this.ctime = obj.ctime;
    this.dev = obj.dev;
    this.gid = obj.gid;
    this.global = global;
    this.gname = obj.gname;
    this.ino = obj.ino;
    this.linkpath = obj.linkpath;
    this.mtime = obj.mtime;
    this.nlink = obj.nlink;
    this.path = obj.path;
    this.size = obj.size;
    this.uid = obj.uid;
    this.uname = obj.uname;
  }
  encode() {
    const body = this.encodeBody();
    if (body === "") {
      return Buffer.allocUnsafe(0);
    }
    const bodyLen = Buffer.byteLength(body);
    const bufLen = 512 * Math.ceil(1 + bodyLen / 512);
    const buf = Buffer.allocUnsafe(bufLen);
    for (let i = 0; i < 512; i++) {
      buf[i] = 0;
    }
    new Header({
      // XXX split the path
      // then the path should be PaxHeader + basename, but less than 99,
      // prepend with the dirname
      /* c8 ignore start */
      path: ("PaxHeader/" + basename(this.path ?? "")).slice(0, 99),
      /* c8 ignore stop */
      mode: this.mode || 420,
      uid: this.uid,
      gid: this.gid,
      size: bodyLen,
      mtime: this.mtime,
      type: this.global ? "GlobalExtendedHeader" : "ExtendedHeader",
      linkpath: "",
      uname: this.uname || "",
      gname: this.gname || "",
      devmaj: 0,
      devmin: 0,
      atime: this.atime,
      ctime: this.ctime
    }).encode(buf);
    buf.write(body, 512, bodyLen, "utf8");
    for (let i = bodyLen + 512; i < buf.length; i++) {
      buf[i] = 0;
    }
    return buf;
  }
  encodeBody() {
    return this.encodeField("path") + this.encodeField("ctime") + this.encodeField("atime") + this.encodeField("dev") + this.encodeField("ino") + this.encodeField("nlink") + this.encodeField("charset") + this.encodeField("comment") + this.encodeField("gid") + this.encodeField("gname") + this.encodeField("linkpath") + this.encodeField("mtime") + this.encodeField("size") + this.encodeField("uid") + this.encodeField("uname");
  }
  encodeField(field) {
    if (this[field] === void 0) {
      return "";
    }
    const r = this[field];
    const v = r instanceof Date ? r.getTime() / 1e3 : r;
    const s = " " + (field === "dev" || field === "ino" || field === "nlink" ? "SCHILY." : "") + field + "=" + v + "\n";
    const byteLen = Buffer.byteLength(s);
    let digits = Math.floor(Math.log(byteLen) / Math.log(10)) + 1;
    if (byteLen + digits >= Math.pow(10, digits)) {
      digits += 1;
    }
    const len = digits + byteLen;
    return len + s;
  }
  static parse(str, ex, g = false) {
    return new _Pax(merge(parseKV(str), ex), g);
  }
};
var merge = (a, b) => b ? Object.assign({}, b, a) : a;
var parseKV = (str) => str.replace(/\n$/, "").split("\n").reduce(parseKVLine, /* @__PURE__ */ Object.create(null));
var parseKVLine = (set, line) => {
  const n = parseInt(line, 10);
  if (n !== Buffer.byteLength(line) + 1) {
    return set;
  }
  line = line.slice((n + " ").length);
  const kv = line.split("=");
  const r = kv.shift();
  if (!r) {
    return set;
  }
  const k = r.replace(/^SCHILY\.(dev|ino|nlink)/, "$1");
  const v = kv.join("=");
  set[k] = /^([A-Z]+\.)?([mac]|birth|creation)time$/.test(k) ? new Date(Number(v) * 1e3) : /^[0-9]+$/.test(v) ? +v : v;
  return set;
};

// ../../src/tar/src/unpack.ts
import { unzip as unzipCB } from "node:zlib";

// ../../src/tar/src/find-tar-dir.ts
var findTarDir = (path, tarDir) => {
  if (tarDir !== void 0) return tarDir;
  if (!path) return void 0;
  const i = path.indexOf("/", path.startsWith("./") ? 2 : 0);
  if (i === -1) return void 0;
  const chomp = path.substring(0, i);
  if (chomp === "." || chomp === ".." || chomp === "" || chomp === "./." || chomp === "./.." || chomp === "./") {
    return void 0;
  }
  return chomp + "/";
};

// ../../src/tar/src/unpack.ts
var unzip = async (input) => new Promise(
  (res, rej) => (
    /* c8 ignore start */
    unzipCB(input, (er, result) => er ? rej(er) : res(result))
  )
  /* c8 ignore stop */
);
var exists = async (path) => {
  try {
    await lstat(path);
    return true;
  } catch {
    return false;
  }
};
var id = 1;
var tmp = randomBytes(6).toString("hex") + ".";
var tmpSuffix = () => tmp + String(id++);
var checkFs = (h, tarDir, target) => {
  if (!h.path) return false;
  if (!tarDir) return false;
  h.path = h.path.replace(/[\\/]+/g, "/");
  if (!h.path.startsWith(tarDir)) return false;
  const absoluteBasePath = target;
  const itemAbsolutePath = resolve2(
    target,
    h.path.slice(tarDir.length)
  );
  if (!itemAbsolutePath.startsWith(absoluteBasePath)) {
    return false;
  }
  return true;
};
var write = async (path, body, executable = false) => {
  await mkdirp(dirname(path));
  await writeFile(path, body, {
    mode: executable ? 511 : 438
  });
};
var made = /* @__PURE__ */ new Set();
var making = /* @__PURE__ */ new Map();
var mkdirp = async (d) => {
  if (!made.has(d)) {
    const m = making.get(d) ?? mkdir(d, { recursive: true, mode: 511 }).then(
      () => making.delete(d)
    );
    making.set(d, m);
    await m;
    made.add(d);
  }
};
var unpack = async (tarData, target) => {
  const isGzip = tarData[0] === 31 && tarData[1] === 139;
  await unpackUnzipped(
    isGzip ? await unzip(tarData) : tarData,
    target
  );
};
var unpackUnzipped = async (buffer, target) => {
  const isGzip = buffer[0] === 31 && buffer[1] === 139;
  if (isGzip) {
    throw error("still gzipped after unzipping", {
      found: isGzip,
      wanted: false
    });
  }
  if (buffer.length % 512 !== 0) {
    throw error("Invalid tarball: length not divisible by 512", {
      found: buffer.length
    });
  }
  if (buffer.length < 1024) {
    throw error(
      "Invalid tarball: not terminated by 1024 null bytes",
      { found: buffer.length }
    );
  }
  for (let i = buffer.length - 1024; i < buffer.length; i++) {
    if (buffer[i] !== 0) {
      throw error(
        "Invalid tarball: not terminated by 1024 null bytes",
        { found: buffer.subarray(i, i + 10) }
      );
    }
  }
  const tmp2 = dirname(target) + sep + "." + basename2(target) + "." + tmpSuffix();
  const og = tmp2 + ".ORIGINAL";
  await Promise.all([rimraf(tmp2), rimraf(og)]);
  let succeeded = false;
  try {
    let tarDir = void 0;
    let offset = 0;
    let h;
    let ex = void 0;
    let gex = void 0;
    while (offset < buffer.length && !(h = new Header(buffer, offset, ex, gex)).nullBlock) {
      offset += 512;
      ex = void 0;
      gex = void 0;
      const size = h.size ?? 0;
      const body = buffer.subarray(offset, offset + size);
      if (!h.cksumValid) continue;
      offset += 512 * Math.ceil(size / 512);
      switch (h.type) {
        case "File":
          if (!tarDir) tarDir = findTarDir(h.path, tarDir);
          if (!tarDir) continue;
          if (!checkFs(h, tarDir, tmp2)) continue;
          await write(
            resolve2(tmp2, h.path.substring(tarDir.length)),
            body,
            // if it's world-executable, it's an executable
            // otherwise, make it read-only.
            1 === ((h.mode ?? 1638) & 1)
          );
          break;
        case "Directory":
          if (!tarDir) tarDir = findTarDir(h.path, tarDir);
          if (!tarDir) continue;
          if (!checkFs(h, tarDir, tmp2)) continue;
          await mkdirp(resolve2(tmp2, h.path.substring(tarDir.length)));
          break;
        case "GlobalExtendedHeader":
          gex = Pax.parse(body.toString(), gex, true);
          break;
        case "ExtendedHeader":
        case "OldExtendedHeader":
          ex = Pax.parse(body.toString(), ex, false);
          break;
        case "NextFileHasLongPath":
        case "OldGnuLongPath":
          ex ??= /* @__PURE__ */ Object.create(null);
          ex.path = body.toString().replace(/\0.*/, "");
          break;
      }
    }
    const targetExists = await exists(target);
    if (targetExists) await rename(target, og);
    await rename(tmp2, target);
    if (targetExists) await rimraf(og);
    succeeded = true;
  } finally {
    if (!succeeded) {
      if (await exists(og)) {
        await rimraf(target);
        await rename(og, target);
      }
      await rimraf(tmp2);
    }
  }
};

// ../../src/tar/src/pool.ts
import os from "node:os";

// ../../src/tar/src/unpack-request.ts
var ID = 1;
var UnpackRequest = class {
  id = ID++;
  tarData;
  target;
  resolve;
  reject;
  promise = new Promise((res, rej) => {
    this.resolve = res;
    this.reject = rej;
  });
  constructor(tarData, target) {
    this.tarData = tarData;
    this.target = target;
  }
};

// ../../src/tar/src/worker.ts
var isObj = (o) => !!o && typeof o === "object";
var isResponseOK = (o) => isObj(o) && typeof o.id === "number" && o.ok === true;
var Worker = class {
  onMessage;
  constructor(onMessage) {
    this.onMessage = onMessage;
  }
  async process(req) {
    const { target, tarData, id: id2 } = req;
    try {
      await unpack(tarData, target);
      const m = { id: id2, ok: true };
      this.onMessage(m);
    } catch (error2) {
      const m = { id: id2, error: error2 };
      this.onMessage(m);
    }
  }
};

// ../../src/tar/src/pool.ts
var Pool = class {
  /**
   * Number of workers to emplly. Defaults to 1 less than the number of
   * CPUs, or 1.
   */
  /* c8 ignore next */
  jobs = 8 * (Math.max(os.availableParallelism(), 2) - 1);
  /**
   * Set of currently active worker threads
   */
  workers = /* @__PURE__ */ new Set();
  /**
   * Queue of requests awaiting an available worker
   */
  queue = [];
  /**
   * Requests that have been assigned to a worker, but have not yet
   * been confirmed completed.
   */
  pending = /* @__PURE__ */ new Map();
  // handle a message from the worker
  #onMessage(w, m) {
    const { id: id2 } = m;
    const ur = this.pending.get(id2);
    if (!ur) return;
    if (isResponseOK(m)) {
      ur.resolve();
    } else {
      ur.reject(
        error(
          asError(m.error, "failed without error message").message,
          {
            found: m,
            cause: m.error
          }
        )
      );
    }
    const next = this.queue.shift();
    if (!next) {
      this.workers.delete(w);
    } else {
      void w.process(next);
    }
  }
  // create a new worker
  #createWorker(req) {
    const w = new Worker(
      (m) => this.#onMessage(w, m)
    );
    this.workers.add(w);
    void w.process(req);
  }
  /**
   * Provide the tardata to be unpacked, and the location where it's to be
   * placed. Will create a new worker up to the `jobs` value, and then start
   * pushing in the queue for workers to pick up as they become available.
   *
   * Returned promise resolves when the provided tarball has been extracted.
   */
  async unpack(tarData, target) {
    const ur = new UnpackRequest(tarData, target);
    this.pending.set(ur.id, ur);
    if (this.workers.size < this.jobs) {
      this.#createWorker(ur);
    } else {
      this.queue.push(ur);
    }
    return ur.promise;
  }
};

// ../../src/package-info/src/index.ts
var import_ssri = __toESM(require_lib(), 1);
import { randomBytes as randomBytes2 } from "node:crypto";
import {
  mkdir as mkdir2,
  readFile,
  rm as rm2,
  stat,
  symlink,
  unlink,
  writeFile as writeFile2
} from "node:fs/promises";
import {
  basename as basename3,
  dirname as dirname2,
  resolve as pathResolve,
  relative
} from "node:path";

// ../../src/package-info/src/rename.ts
import { rename as fsRename, rm } from "node:fs/promises";
var { platform } = process;
var rename2 = platform !== "win32" ? fsRename : (async function(oldPath, newPath) {
  let retries = 3;
  const retry = async (er) => {
    if (retries > 0 && er.code === "EPERM") {
      retries--;
      await rm(newPath, { recursive: true, force: true });
      return fsRename(oldPath, newPath).then(() => {
      }, retry);
    } else {
      throw er;
    }
  };
  return fsRename(oldPath, newPath).then(() => {
  }, retry);
});

// ../../src/package-info/src/index.ts
var xdg = new XDG("vlt");
var delimiter = "~";
var manifestCacheMaxAge = 5 * 60 * 1e3;
var PackageInfoClient = class {
  #registryClient;
  #projectRoot;
  #tarPool;
  options;
  #resolutions = /* @__PURE__ */ new Map();
  packageJson;
  monorepo;
  #trustedIntegrities = /* @__PURE__ */ new Map();
  #manifestCacheMinAge = Date.now() - manifestCacheMaxAge;
  #cachePath;
  get registryClient() {
    if (!this.#registryClient) {
      this.#registryClient = new RegistryClient(this.options);
    }
    return this.#registryClient;
  }
  get tarPool() {
    if (!this.#tarPool) this.#tarPool = new Pool();
    return this.#tarPool;
  }
  constructor(options = {}) {
    this.options = options;
    this.#projectRoot = options.projectRoot || process.cwd();
    this.packageJson = options.packageJson ?? new PackageJson();
    const wsLoad = {
      ...options.workspace?.length && { paths: options.workspace },
      ...options["workspace-group"]?.length && {
        groups: options["workspace-group"]
      }
    };
    this.monorepo = options.monorepo ?? Monorepo.maybeLoad(this.#projectRoot, {
      load: wsLoad,
      packageJson: this.packageJson
    });
    this.#cachePath = options.cache ?? xdg.cache();
    void mkdir2(pathResolve(this.#cachePath, "package-info"), {
      recursive: true
    }).catch(() => {
    });
  }
  async extract(spec, target, options = {}) {
    if (typeof spec === "string")
      spec = Spec.parse(spec, this.options);
    const { from = this.#projectRoot, integrity, resolved } = options;
    const f = spec.final;
    const r = integrity && resolved ? { resolved, integrity, spec } : await this.resolve(spec, options);
    switch (f.type) {
      case "git": {
        const {
          gitRemote,
          gitCommittish,
          remoteURL,
          gitSelectorParsed
        } = f;
        if (!remoteURL) {
          if (!gitRemote)
            throw this.#resolveError(
              spec,
              options,
              "no remote on git: specifier"
            );
          const { path } = gitSelectorParsed ?? {};
          if (path !== void 0) {
            const tmp2 = pathResolve(
              dirname2(target),
              `.TEMP.${basename3(target)}-${randomBytes2(6).toString("hex")}`
            );
            await clone(gitRemote, gitCommittish, tmp2, { spec });
            const src = pathResolve(tmp2, path);
            await rename2(src, target);
            void rm2(tmp2, { recursive: true, force: true });
          } else {
            await clone(gitRemote, gitCommittish, target, { spec });
            void rm2(target + "/.git", { recursive: true });
          }
          return r;
        }
      }
      case "registry": {
        const trustIntegrity = this.#trustedIntegrities.get(r.resolved) === r.integrity;
        const response = await this.registryClient.request(
          r.resolved,
          {
            integrity: r.integrity,
            trustIntegrity
          }
        );
        if (response.statusCode !== 200) {
          throw this.#resolveError(
            spec,
            options,
            "failed to fetch tarball",
            {
              url: r.resolved,
              response
            }
          );
        }
        if (!trustIntegrity && response.checkIntegrity({ spec, url: resolved })) {
          this.#trustedIntegrities.set(r.resolved, response.integrity);
        }
        try {
          await this.tarPool.unpack(response.buffer(), target);
        } catch (er) {
          throw this.#resolveError(
            spec,
            options,
            "tar unpack failed",
            { cause: er }
          );
        }
        return r;
      }
      case "remote": {
        const response = await this.registryClient.request(r.resolved);
        if (response.statusCode !== 200) {
          throw this.#resolveError(
            spec,
            options,
            "failed to fetch remote tarball",
            {
              url: r.resolved,
              response
            }
          );
        }
        const buf = response.buffer();
        const computed = import_ssri.default.fromData(buf, { algorithms: ["sha512"] }).toString();
        if (r.integrity && r.integrity !== computed) {
          throw error("Integrity check failure", {
            code: "EINTEGRITY",
            spec,
            url: r.resolved,
            wanted: r.integrity,
            found: computed
          });
        }
        r.integrity = computed;
        try {
          await this.tarPool.unpack(buf, target);
        } catch (er) {
          throw this.#resolveError(
            spec,
            options,
            "remote tar unpack failed",
            { cause: er }
          );
        }
        return r;
      }
      case "file": {
        const { file } = f;
        if (file === void 0)
          throw this.#resolveError(spec, options, "no file path");
        const path = pathResolve(from, file);
        const st = await stat(path);
        if (st.isFile()) {
          try {
            await this.tarPool.unpack(
              await this.tarball(spec, options),
              target
            );
          } catch (er) {
            throw this.#resolveError(
              spec,
              options,
              "tar unpack failed",
              { cause: er }
            );
          }
        } else if (st.isDirectory()) {
          const rel = relative(dirname2(target), path);
          await symlink(rel, target, "dir");
        } else {
          throw this.#resolveError(
            spec,
            options,
            "file: specifier does not resolve to directory or tarball"
          );
        }
        return r;
      }
      case "workspace": {
        const ws = this.#getWS(spec, options);
        const rel = relative(dirname2(target), ws.fullpath);
        await symlink(rel, target, "dir");
        return r;
      }
    }
  }
  #getWS(spec, options) {
    const { workspace } = spec;
    if (workspace === void 0)
      throw this.#resolveError(spec, options, "no workspace ID");
    if (!this.monorepo) {
      throw this.#resolveError(
        spec,
        options,
        "Not in a monorepo, cannot resolve workspace spec"
      );
    }
    const ws = this.monorepo.get(workspace);
    if (!ws) {
      throw this.#resolveError(spec, options, "workspace not found", {
        wanted: workspace
      });
    }
    return ws;
  }
  /**
   * Return the manifest cache key for a spec and the current options.
   */
  #manifestCacheKey(spec, options) {
    let extra = "";
    if (options["node-version"]) {
      extra += `${delimiter}node-version:${options["node-version"]}`;
    }
    if (options.os) {
      extra += `${delimiter}os:${options.os}`;
    }
    if (options.arch) {
      extra += `${delimiter}arch:${options.arch}`;
    }
    return encodeURIComponent(
      `${spec.registry}${delimiter}${spec}${extra}`
    );
  }
  /**
   * Conditionally return the path to the manifest cache file. The logic
   * to determine if caching should be skipped aligns with `pickManifest`
   * and is used to avoid caching manifest results that can be variable.
   */
  _manifestCachePath(spec, options) {
    if (options.before) {
      return;
    }
    const f = spec.final;
    if (f.distTag || f.range?.isAny) {
      return;
    }
    const key = this.#manifestCacheKey(f, options);
    return pathResolve(this.#cachePath, "package-info", key);
  }
  async #registryManifestRequest(spec, options) {
    const { registry, name: name2, registrySpec } = spec.final;
    if (!spec.range?.isSingle || !registrySpec) {
      throw this.#resolveError(
        spec,
        options,
        "failed to request manifest",
        { spec }
      );
    }
    const possibleLeadingChars = ["=", "^", "~", "v"];
    const hasLeadingRange = possibleLeadingChars.some(
      (char) => registrySpec.startsWith(char)
    );
    const version = hasLeadingRange ? registrySpec.slice(1) : registrySpec;
    const pakuURL = new URL(`${name2}/${version}`, registry);
    const response = await this.registryClient.request(pakuURL, {
      headers: {
        accept: "application/json"
      }
    });
    if (response.statusCode !== 200) {
      throw this.#resolveError(
        spec,
        options,
        "failed to fetch manifest",
        {
          url: pakuURL,
          response
        }
      );
    }
    return response.json();
  }
  async tarball(spec, options = {}) {
    if (typeof spec === "string")
      spec = Spec.parse(spec, this.options);
    const f = spec.final;
    switch (f.type) {
      case "registry": {
        const { dist } = await this.manifest(spec, options);
        if (!dist)
          throw this.#resolveError(
            spec,
            options,
            "no dist object found in manifest"
          );
        const { tarball, integrity } = dist;
        if (!tarball) {
          throw this.#resolveError(
            spec,
            options,
            "no tarball found in manifest.dist"
          );
        }
        const trustIntegrity = this.#trustedIntegrities.get(tarball) === integrity;
        const response = await this.registryClient.request(tarball, {
          ...options,
          integrity,
          trustIntegrity
        });
        if (response.statusCode !== 200) {
          throw this.#resolveError(
            spec,
            options,
            "failed to fetch tarball",
            { response, url: tarball }
          );
        }
        if (!trustIntegrity && response.checkIntegrity({ spec, url: tarball })) {
          this.#trustedIntegrities.set(tarball, response.integrity);
        }
        return response.buffer();
      }
      case "git": {
        const {
          remoteURL,
          gitRemote,
          gitCommittish,
          gitSelectorParsed
        } = f;
        const s = spec;
        if (!remoteURL) {
          if (!gitRemote) {
            throw this.#resolveError(
              spec,
              options,
              "no remote on git: specifier"
            );
          }
          const { path } = gitSelectorParsed ?? {};
          return await this.#tmpdir(async (dir) => {
            await clone(gitRemote, gitCommittish, dir + "/package", {
              spec: s
            });
            let cwd = dir;
            if (path !== void 0) {
              const src = pathResolve(dir, "package", path);
              cwd = dirname2(src);
              const pkg = pathResolve(cwd, "package");
              if (src !== pkg) {
                const rand = randomBytes2(6).toString("hex");
                await rename2(pkg, pkg + rand).catch(() => {
                });
                await rename2(src, pkg);
              }
            }
            return zn({ cwd, gzip: true }, ["package"]).concat();
          });
        }
      }
      case "remote": {
        const { remoteURL } = f;
        if (!remoteURL) {
          throw this.#resolveError(spec, options);
        }
        const response = await this.registryClient.request(remoteURL);
        if (response.statusCode !== 200) {
          throw this.#resolveError(
            spec,
            options,
            "failed to fetch URL",
            { response, url: remoteURL }
          );
        }
        return response.buffer();
      }
      case "file": {
        const { file } = f;
        if (file === void 0)
          throw this.#resolveError(spec, options, "no file path");
        const { from = this.#projectRoot } = options;
        const path = pathResolve(from, file);
        const st = await stat(path);
        if (st.isDirectory()) {
          const p = dirname2(path);
          const b = basename3(path);
          return zn({ cwd: p, gzip: true }, [b]).concat();
        }
        return readFile(path);
      }
      case "workspace": {
        const ws = this.#getWS(spec, options);
        const p = dirname2(ws.fullpath);
        const b = basename3(ws.fullpath);
        return zn({ cwd: p, gzip: true }, [b]).concat();
      }
    }
  }
  async manifest(spec, options = {}) {
    const { from = this.#projectRoot } = options;
    if (typeof spec === "string")
      spec = Spec.parse(spec, this.options);
    const f = spec.final;
    switch (f.type) {
      case "registry": {
        const cachePath = this._manifestCachePath(spec, options);
        if (cachePath) {
          try {
            const cached = await readFile(cachePath, "utf8");
            const json = JSON.parse(cached);
            const timestamp = json.__VLT_MANIFEST_CACHE_TIMESTAMP;
            delete json.__VLT_MANIFEST_CACHE_TIMESTAMP;
            if (timestamp != null && timestamp < this.#manifestCacheMinAge) {
              void unlink(cachePath).catch(() => {
              });
              throw new Error("manifest cache expired");
            }
            return json;
          } catch {
          }
        }
        const mani = spec.range?.isSingle ? await this.#registryManifestRequest(spec, options) : pickManifest(
          await this.packument(f, options),
          spec,
          options
        );
        if (!mani) throw this.#resolveError(spec, options);
        const { integrity, tarball } = mani.dist ?? /* c8 ignore next */
        {};
        if (isIntegrity(integrity) && tarball) {
          const registryOrigin = new URL(String(f.registry)).origin;
          const tgzOrigin = new URL(tarball).origin;
          if (tgzOrigin === registryOrigin) {
            this.#trustedIntegrities.set(tarball, integrity);
          }
        }
        if (cachePath) {
          const json = JSON.stringify({
            ...mani,
            // append a timestamp to the manifest so that we can quickly
            // check if the cache is still valid when loading it
            __VLT_MANIFEST_CACHE_TIMESTAMP: Date.now()
          });
          void writeFile2(cachePath, json, "utf8").catch(
            (err) => {
              if (err instanceof Error && "code" in err && err.code === "ENOENT") {
                void mkdir2(dirname2(cachePath), {
                  recursive: true
                }).then(() => {
                  void writeFile2(cachePath, json, "utf8");
                });
              }
            }
          );
        }
        return mani;
      }
      case "git": {
        const {
          gitRemote,
          gitCommittish,
          remoteURL,
          gitSelectorParsed
        } = f;
        if (!remoteURL) {
          const s = spec;
          if (!gitRemote)
            throw this.#resolveError(spec, options, "no git remote");
          return await this.#tmpdir(async (dir) => {
            await clone(gitRemote, gitCommittish, dir, { spec: s });
            const { path } = gitSelectorParsed ?? {};
            const pkgDir = path !== void 0 ? pathResolve(dir, path) : dir;
            return this.packageJson.read(pkgDir);
          });
        }
      }
      case "remote": {
        const { remoteURL } = f;
        if (!remoteURL) {
          throw this.#resolveError(
            spec,
            options,
            "no remoteURL on remote specifier"
          );
        }
        const s = spec;
        return await this.#tmpdir(async (dir) => {
          const response = await this.registryClient.request(remoteURL);
          if (response.statusCode !== 200) {
            throw this.#resolveError(
              s,
              options,
              "failed to fetch URL",
              { response, url: remoteURL }
            );
          }
          const buf = response.buffer();
          const computed = import_ssri.default.fromData(buf, { algorithms: ["sha512"] }).toString();
          try {
            await this.tarPool.unpack(buf, dir);
          } catch (er) {
            throw this.#resolveError(
              s,
              options,
              "tar unpack failed",
              { cause: er }
            );
          }
          const mani = this.packageJson.read(dir);
          mani.dist = { integrity: computed };
          return mani;
        });
      }
      case "file": {
        const { file } = f;
        if (file === void 0)
          throw this.#resolveError(spec, options, "no file path");
        const path = pathResolve(from, file);
        const st = await stat(path);
        if (st.isDirectory()) {
          return this.packageJson.read(path);
        }
        const s = spec;
        return await this.#tmpdir(async (dir) => {
          try {
            await this.tarPool.unpack(await readFile(path), dir);
          } catch (er) {
            throw this.#resolveError(
              s,
              options,
              "tar unpack failed",
              { cause: er }
            );
          }
          return this.packageJson.read(dir);
        });
      }
      case "workspace": {
        return this.#getWS(spec, options).manifest;
      }
    }
  }
  async packument(spec, options = {}) {
    if (typeof spec === "string")
      spec = Spec.parse(spec, this.options);
    const f = spec.final;
    switch (f.type) {
      // RevDoc is the equivalent of a packument for a git repo
      case "git": {
        const { gitRemote } = f;
        if (!gitRemote) {
          throw this.#resolveError(
            spec,
            options,
            "git remote could not be determined"
          );
        }
        const revDoc = await revs(gitRemote, {
          cwd: this.options.projectRoot
        });
        if (!revDoc) throw this.#resolveError(spec, options);
        return asPackument(revDoc);
      }
      // these are all faked packuments
      case "file":
      case "workspace":
      case "remote": {
        const manifest = await this.manifest(f, options);
        return {
          name: manifest.name ?? "",
          "dist-tags": {
            latest: manifest.version ?? ""
          },
          versions: {
            [manifest.version ?? ""]: manifest
          }
        };
      }
      case "registry": {
        const { registry, name: name2 } = f;
        const pakuURL = new URL(name2, registry);
        const response = await this.registryClient.request(pakuURL, {
          headers: {
            accept: "application/json"
          }
        });
        if (response.statusCode !== 200) {
          throw this.#resolveError(
            spec,
            options,
            "failed to fetch packument",
            {
              url: pakuURL,
              response
            }
          );
        }
        return response.json();
      }
    }
  }
  async resolve(spec, options = {}) {
    const memoKey = String(spec);
    if (typeof spec === "string")
      spec = Spec.parse(spec, this.options);
    const memo = this.#resolutions.get(memoKey);
    if (memo) return memo;
    const f = spec.final;
    switch (f.type) {
      case "file": {
        const { file } = f;
        if (!file || !f.file) {
          throw this.#resolveError(
            spec,
            options,
            "no path on file: specifier"
          );
        }
        const { from = this.#projectRoot } = options;
        const resolved = pathResolve(from, f.file);
        const r = { resolved, spec };
        this.#resolutions.set(memoKey, r);
        return r;
      }
      case "remote": {
        const { remoteURL } = f;
        if (!remoteURL)
          throw this.#resolveError(
            spec,
            options,
            "no URL in remote specifier"
          );
        const r = { resolved: remoteURL, spec };
        this.#resolutions.set(memoKey, r);
        return r;
      }
      case "workspace": {
        const ws = this.#getWS(spec, options);
        return {
          resolved: ws.fullpath,
          spec
        };
      }
      case "registry": {
        const mani = await this.manifest(spec, options);
        if (mani.dist) {
          const { integrity, tarball, signatures } = mani.dist;
          if (tarball) {
            const r = {
              resolved: tarball,
              integrity,
              signatures,
              spec
            };
            this.#resolutions.set(memoKey, r);
            return r;
          }
        }
        throw this.#resolveError(spec, options);
      }
      case "git": {
        const { gitRemote, remoteURL, gitSelectorParsed } = f;
        if (remoteURL && gitSelectorParsed?.path === void 0) {
          const r = { resolved: remoteURL, spec };
          this.#resolutions.set(memoKey, r);
          return r;
        }
        if (!gitRemote) {
          throw this.#resolveError(
            spec,
            options,
            "no remote on git specifier"
          );
        }
        const rev = await resolve(gitRemote, f.gitCommittish, {
          spec
        });
        if (rev) {
          const r = {
            resolved: `${gitRemote}#${rev.sha}`,
            spec
          };
          if (gitSelectorParsed) {
            r.resolved += Object.entries(gitSelectorParsed).filter(([_, v]) => v).map(([k, v]) => `::${k}:${v}`).join("");
          }
          this.#resolutions.set(memoKey, r);
          return r;
        }
        const s = spec;
        return this.#tmpdir(async (tmpdir) => {
          const sha = await clone(
            gitRemote,
            s.gitCommittish,
            tmpdir,
            {
              spec: s
            }
          );
          const r = {
            resolved: `${gitRemote}#${sha}`,
            spec: s
          };
          this.#resolutions.set(memoKey, r);
          return r;
        });
      }
    }
  }
  async #tmpdir(fn) {
    const p = `package-info/${randomBytes2(6).toString("hex")}`;
    const dir = xdg.runtime(p);
    try {
      return await fn(dir);
    } finally {
      void rm2(dir, { recursive: true, force: true });
    }
  }
  // error resolving
  #resolveError(spec, options = {}, message = "Could not resolve", extra = {}) {
    const { from = this.#projectRoot } = options;
    const er = error(
      message,
      {
        code: "ERESOLVE",
        spec,
        from,
        ...extra
      },
      this.#resolveError
    );
    return er;
  }
};

export {
  PackageInfoClient
};
