var global = globalThis;
import {Buffer} from "node:buffer";
import {setTimeout as _vlt_setTimeout,clearTimeout as _vlt_clearTimeout,setImmediate as _vlt_setImmediate,clearImmediate as _vlt_clearImmediate,setInterval as _vlt_setInterval,clearInterval as _vlt_clearInterval} from "node:timers";
globalThis.setTimeout = _vlt_setTimeout;
globalThis.clearTimeout = _vlt_clearTimeout;
globalThis.setImmediate = _vlt_setImmediate;
globalThis.clearImmediate = _vlt_clearImmediate;
globalThis.setInterval = _vlt_setInterval;
globalThis.clearInterval = _vlt_clearInterval;
import {createRequire as _vlt_createRequire} from "node:module";
var require = _vlt_createRequire(import.meta.filename);

// ../../node_modules/.vlt/~npm~package-json-from-dist@1.0.1/node_modules/package-json-from-dist/dist/esm/index.js
import { readFileSync } from "node:fs";
import { dirname, resolve, sep } from "node:path";
import { fileURLToPath } from "node:url";
var NM = `${sep}node_modules${sep}`;
var STORE = `.store${sep}`;
var PKG = `${sep}package${sep}`;
var DIST = `${sep}dist${sep}`;
var findPackageJson = (from, pathFromSrc = "../package.json") => {
  const f = typeof from === "object" || from.startsWith("file://") ? fileURLToPath(from) : from;
  const __dirname = dirname(f);
  const nms = __dirname.lastIndexOf(NM);
  if (nms !== -1) {
    const nm = __dirname.substring(0, nms + NM.length);
    const pkgDir = __dirname.substring(nms + NM.length);
    if (pkgDir.startsWith(STORE)) {
      const pkg = pkgDir.indexOf(PKG, STORE.length);
      if (pkg) {
        return resolve(nm, pkgDir.substring(0, pkg + PKG.length), "package.json");
      }
    }
    const pkgName = pkgDir.startsWith("@") ? pkgDir.split(sep, 2).join(sep) : String(pkgDir.split(sep)[0]);
    return resolve(nm, pkgName, "package.json");
  } else {
    const d = __dirname.lastIndexOf(DIST);
    if (d !== -1) {
      return resolve(__dirname.substring(0, d), "package.json");
    } else {
      return resolve(__dirname, pathFromSrc);
    }
  }
};
var loadPackageJson = (from, pathFromSrc = "../package.json") => JSON.parse(readFileSync(findPackageJson(from, pathFromSrc), "utf8"));

export {
  loadPackageJson
};
