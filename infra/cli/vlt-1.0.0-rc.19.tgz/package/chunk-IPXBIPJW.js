var global = globalThis;
import {Buffer} from "node:buffer";
import {setTimeout as _vlt_setTimeout,clearTimeout as _vlt_clearTimeout,setImmediate as _vlt_setImmediate,clearImmediate as _vlt_clearImmediate,setInterval as _vlt_setInterval,clearInterval as _vlt_clearInterval} from "node:timers";
globalThis.setTimeout = _vlt_setTimeout;
globalThis.clearTimeout = _vlt_clearTimeout;
globalThis.setImmediate = _vlt_setImmediate;
globalThis.clearImmediate = _vlt_clearImmediate;
globalThis.setInterval = _vlt_setInterval;
globalThis.clearInterval = _vlt_clearInterval;
import {createRequire as _vlt_createRequire} from "node:module";
var require = _vlt_createRequire(import.meta.filename);
import {
  error
} from "./chunk-WZWDS3W4.js";
import {
  __glob
} from "./chunk-PZLD7RTK.js";

// import("./commands/**/*.ts") in ../../src/cli-sdk/src/load-command.ts
var globImport_commands_ts = __glob({
  "./commands/bugs.ts": () => import("./bugs-22BOJXFB.js"),
  "./commands/build.ts": () => import("./build-R53AIRYP.js"),
  "./commands/cache.ts": () => import("./cache-6E2ZK2LW.js"),
  "./commands/ci.ts": () => import("./ci-ZN23NAON.js"),
  "./commands/config.ts": () => import("./config-OBWILVWF.js"),
  "./commands/create.ts": () => import("./create-56MEFFUF.js"),
  "./commands/docs.ts": () => import("./docs-DNMMMR3I.js"),
  "./commands/exec-cache.ts": () => import("./exec-cache-GUF7QW2S.js"),
  "./commands/exec-local.ts": () => import("./exec-local-KU37632F.js"),
  "./commands/exec.ts": () => import("./exec-QCIS6DMH.js"),
  "./commands/help.ts": () => import("./help-5NRJZWIU.js"),
  "./commands/init.ts": () => import("./init-32T4YJZ5.js"),
  "./commands/install.ts": () => import("./install-CP6762EI.js"),
  "./commands/install/reporter.ts": () => import("./reporter-2NY7CSTJ.js"),
  "./commands/list.ts": () => import("./list-IZEZYXWD.js"),
  "./commands/login.ts": () => import("./login-X25TMUUH.js"),
  "./commands/logout.ts": () => import("./logout-TAFT6UT5.js"),
  "./commands/pack.ts": () => import("./pack-AFUG3O4P.js"),
  "./commands/ping.ts": () => import("./ping-RHW2XIEI.js"),
  "./commands/pkg.ts": () => import("./pkg-RBVUEK2W.js"),
  "./commands/publish.ts": () => import("./publish-A67I3TNG.js"),
  "./commands/query.ts": () => import("./query-3ARTSBHQ.js"),
  "./commands/repo.ts": () => import("./repo-Y6TI6AGP.js"),
  "./commands/run-exec.ts": () => import("./run-exec-22O534IT.js"),
  "./commands/run.ts": () => import("./run-BWEOP33M.js"),
  "./commands/token.ts": () => import("./token-PXWXYYAB.js"),
  "./commands/uninstall.ts": () => import("./uninstall-WLKETZ53.js"),
  "./commands/update.ts": () => import("./update-25PY5I26.js"),
  "./commands/version.ts": () => import("./version-UWYJHNXG.js"),
  "./commands/view.ts": () => import("./view-XI5Q727O.js"),
  "./commands/whoami.ts": () => import("./whoami-VCHHV3CC.js")
});

// ../../src/cli-sdk/src/load-command.ts
var loadCommand = async (command) => {
  try {
    return await globImport_commands_ts(`./commands/${command}.ts`);
  } catch (e) {
    throw error("Could not load command", {
      found: command,
      cause: e
    });
  }
};

export {
  loadCommand
};
