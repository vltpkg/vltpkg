var global = globalThis;
import {Buffer} from "node:buffer";
import {setTimeout as _vlt_setTimeout,clearTimeout as _vlt_clearTimeout,setImmediate as _vlt_setImmediate,clearImmediate as _vlt_clearImmediate,setInterval as _vlt_setInterval,clearInterval as _vlt_clearInterval} from "node:timers";
globalThis.setTimeout = _vlt_setTimeout;
globalThis.clearTimeout = _vlt_clearTimeout;
globalThis.setImmediate = _vlt_setImmediate;
globalThis.clearImmediate = _vlt_clearImmediate;
globalThis.setInterval = _vlt_setInterval;
globalThis.clearInterval = _vlt_clearInterval;
import {createRequire as _vlt_createRequire} from "node:module";
var require = _vlt_createRequire(import.meta.filename);

// ../../src/output/src/index.ts
import EventEmitter from "node:events";
var OutputEmitter = class {
  emitter = new EventEmitter();
  emit(eventName, payload) {
    this.emitter.emit(eventName, payload);
  }
  on(eventName, handler) {
    this.emitter.on(eventName, handler);
  }
  off(eventName, handler) {
    this.emitter.off(eventName, handler);
  }
};
var emitter = new OutputEmitter();
var logRequest = (url, state) => {
  emitter.emit("request", { url, state });
};
var graphStep = (step) => {
  emitter.emit("graphStep", { step, state: "start" });
  return () => emitter.emit("graphStep", { step, state: "stop" });
};

export {
  emitter,
  logRequest,
  graphStep
};
