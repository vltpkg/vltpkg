var global = globalThis;
import {Buffer} from "node:buffer";
import {setTimeout as _vlt_setTimeout,clearTimeout as _vlt_clearTimeout,setImmediate as _vlt_setImmediate,clearImmediate as _vlt_clearImmediate,setInterval as _vlt_setInterval,clearInterval as _vlt_clearInterval} from "node:timers";
globalThis.setTimeout = _vlt_setTimeout;
globalThis.clearTimeout = _vlt_clearTimeout;
globalThis.setImmediate = _vlt_setImmediate;
globalThis.clearImmediate = _vlt_clearImmediate;
globalThis.setInterval = _vlt_setInterval;
globalThis.clearInterval = _vlt_clearInterval;
import {createRequire as _vlt_createRequire} from "node:module";
var require = _vlt_createRequire(import.meta.filename);
import {
  loadPackageJson
} from "./chunk-E74WGW5C.js";
import {
  asDepID,
  baseDepID,
  splitDepID
} from "./chunk-FEV5BCW7.js";
import {
  L
} from "./chunk-VCSVHRCS.js";
import {
  XDG
} from "./chunk-XNLSTHDK.js";
import {
  error
} from "./chunk-WZWDS3W4.js";

// ../../src/security-archive/src/index.ts
import { DatabaseSync } from "node:sqlite";
import { mkdirSync } from "node:fs";
import { dirname } from "node:path";

// ../../node_modules/.vlt/~npm~is-network-error@1.3.1/node_modules/is-network-error/index.js
var objectToString = Object.prototype.toString;
var isError = (value) => objectToString.call(value) === "[object Error]";
var errorMessages = /* @__PURE__ */ new Set([
  "network error",
  // Chrome
  "NetworkError when attempting to fetch resource.",
  // Firefox
  "The Internet connection appears to be offline.",
  // Safari 16
  "Network request failed",
  // `cross-fetch`
  "fetch failed",
  // Undici (Node.js)
  "terminated",
  // Undici (Node.js)
  " A network error occurred.",
  // Bun (WebKit)
  "Network connection lost"
  // Cloudflare Workers (fetch)
]);
function isNetworkError(error2) {
  const isValid = error2 && isError(error2) && error2.name === "TypeError" && typeof error2.message === "string";
  if (!isValid) {
    return false;
  }
  const { message, stack } = error2;
  if (message === "Load failed") {
    return stack === void 0 || "__sentry_captured__" in error2;
  }
  if (message.startsWith("error sending request for url")) {
    return true;
  }
  if (message === "Failed to fetch" || message.startsWith("Failed to fetch (") && message.endsWith(")")) {
    return true;
  }
  return errorMessages.has(message);
}

// ../../node_modules/.vlt/~npm~p-retry@7.1.1/node_modules/p-retry/index.js
function validateRetries(retries) {
  if (typeof retries === "number") {
    if (retries < 0) {
      throw new TypeError("Expected `retries` to be a non-negative number.");
    }
    if (Number.isNaN(retries)) {
      throw new TypeError("Expected `retries` to be a valid number or Infinity, got NaN.");
    }
  } else if (retries !== void 0) {
    throw new TypeError("Expected `retries` to be a number or Infinity.");
  }
}
function validateNumberOption(name, value, { min = 0, allowInfinity = false } = {}) {
  if (value === void 0) {
    return;
  }
  if (typeof value !== "number" || Number.isNaN(value)) {
    throw new TypeError(`Expected \`${name}\` to be a number${allowInfinity ? " or Infinity" : ""}.`);
  }
  if (!allowInfinity && !Number.isFinite(value)) {
    throw new TypeError(`Expected \`${name}\` to be a finite number.`);
  }
  if (value < min) {
    throw new TypeError(`Expected \`${name}\` to be \u2265 ${min}.`);
  }
}
var AbortError = class extends Error {
  constructor(message) {
    super();
    if (message instanceof Error) {
      this.originalError = message;
      ({ message } = message);
    } else {
      this.originalError = new Error(message);
      this.originalError.stack = this.stack;
    }
    this.name = "AbortError";
    this.message = message;
  }
};
function calculateDelay(retriesConsumed, options) {
  const attempt = Math.max(1, retriesConsumed + 1);
  const random = options.randomize ? Math.random() + 1 : 1;
  let timeout = Math.round(random * options.minTimeout * options.factor ** (attempt - 1));
  timeout = Math.min(timeout, options.maxTimeout);
  return timeout;
}
function calculateRemainingTime(start, max) {
  if (!Number.isFinite(max)) {
    return max;
  }
  return max - (performance.now() - start);
}
async function onAttemptFailure({ error: error2, attemptNumber, retriesConsumed, startTime, options }) {
  const normalizedError = error2 instanceof Error ? error2 : new TypeError(`Non-error was thrown: "${error2}". You should only throw errors.`);
  if (normalizedError instanceof AbortError) {
    throw normalizedError.originalError;
  }
  const retriesLeft = Number.isFinite(options.retries) ? Math.max(0, options.retries - retriesConsumed) : options.retries;
  const maxRetryTime = options.maxRetryTime ?? Number.POSITIVE_INFINITY;
  const context = Object.freeze({
    error: normalizedError,
    attemptNumber,
    retriesLeft,
    retriesConsumed
  });
  await options.onFailedAttempt(context);
  if (calculateRemainingTime(startTime, maxRetryTime) <= 0) {
    throw normalizedError;
  }
  const consumeRetry = await options.shouldConsumeRetry(context);
  const remainingTime = calculateRemainingTime(startTime, maxRetryTime);
  if (remainingTime <= 0 || retriesLeft <= 0) {
    throw normalizedError;
  }
  if (normalizedError instanceof TypeError && !isNetworkError(normalizedError)) {
    if (consumeRetry) {
      throw normalizedError;
    }
    options.signal?.throwIfAborted();
    return false;
  }
  if (!await options.shouldRetry(context)) {
    throw normalizedError;
  }
  if (!consumeRetry) {
    options.signal?.throwIfAborted();
    return false;
  }
  const delayTime = calculateDelay(retriesConsumed, options);
  const finalDelay = Math.min(delayTime, remainingTime);
  options.signal?.throwIfAborted();
  if (finalDelay > 0) {
    await new Promise((resolve, reject) => {
      const onAbort = () => {
        clearTimeout(timeoutToken);
        options.signal?.removeEventListener("abort", onAbort);
        reject(options.signal.reason);
      };
      const timeoutToken = setTimeout(() => {
        options.signal?.removeEventListener("abort", onAbort);
        resolve();
      }, finalDelay);
      if (options.unref) {
        timeoutToken.unref?.();
      }
      options.signal?.addEventListener("abort", onAbort, { once: true });
    });
  }
  options.signal?.throwIfAborted();
  return true;
}
async function pRetry(input, options = {}) {
  options = { ...options };
  validateRetries(options.retries);
  if (Object.hasOwn(options, "forever")) {
    throw new Error("The `forever` option is no longer supported. For many use-cases, you can set `retries: Infinity` instead.");
  }
  options.retries ??= 10;
  options.factor ??= 2;
  options.minTimeout ??= 1e3;
  options.maxTimeout ??= Number.POSITIVE_INFINITY;
  options.maxRetryTime ??= Number.POSITIVE_INFINITY;
  options.randomize ??= false;
  options.onFailedAttempt ??= () => {
  };
  options.shouldRetry ??= () => true;
  options.shouldConsumeRetry ??= () => true;
  validateNumberOption("factor", options.factor, { min: 0, allowInfinity: false });
  validateNumberOption("minTimeout", options.minTimeout, { min: 0, allowInfinity: false });
  validateNumberOption("maxTimeout", options.maxTimeout, { min: 0, allowInfinity: true });
  validateNumberOption("maxRetryTime", options.maxRetryTime, { min: 0, allowInfinity: true });
  if (!(options.factor > 0)) {
    options.factor = 1;
  }
  options.signal?.throwIfAborted();
  let attemptNumber = 0;
  let retriesConsumed = 0;
  const startTime = performance.now();
  while (Number.isFinite(options.retries) ? retriesConsumed <= options.retries : true) {
    attemptNumber++;
    try {
      options.signal?.throwIfAborted();
      const result = await input(attemptNumber);
      options.signal?.throwIfAborted();
      return result;
    } catch (error2) {
      if (await onAttemptFailure({
        error: error2,
        attemptNumber,
        retriesConsumed,
        startTime,
        options
      })) {
        retriesConsumed++;
      }
    }
  }
  throw new Error("Retry attempts exhausted without throwing an error.");
}

// ../../src/security-archive/src/types.ts
var isPackageReportData = (o) => typeof o === "object" && o != null && "id" in o && "type" in o && "name" in o && "version" in o && "alerts" in o && "score" in o && o.type === "npm";
var asPackageReportData = (o) => {
  if (!isPackageReportData(o)) {
    throw error("Invalid package report data", { found: o });
  }
  return o;
};

// ../../src/security-archive/src/index.ts
var SOCKET_API_V0_URL = "https://api.socket.dev/v0/purl?alerts=true";
var SOCKET_PUBLIC_API_TOKEN = "sktsec_t_--RAN5U4ivauy4w37-6aoKyYPDt5ZbaT5JBVMqiwKo_api";
var targetSecurityRegisty = "https://registry.npmjs.org/";
var usesTargetRegistry = (node) => {
  const depID = node.id;
  const specOptions = node.options;
  const [nodeType, nodeRegistry] = splitDepID(depID);
  if (nodeType !== "registry") {
    return false;
  }
  const reg = specOptions.registries?.[nodeRegistry];
  return reg === targetSecurityRegisty;
};
var { version } = loadPackageJson(
  import.meta.filename,
  "cli-package.json"
);
var SecurityArchive = class _SecurityArchive extends L {
  #expired = /* @__PURE__ */ new Set();
  #pUpdateExpired;
  #path;
  #retries;
  #nodesByName = /* @__PURE__ */ new Map();
  #nodesByID = /* @__PURE__ */ new Map();
  /**
   * True if the refresh process was successful and report data is available
   * for all public registry packages from the initial list of nodes.
   */
  ok = false;
  /**
   * Creates a new security archive instance and starts the refresh process.
   */
  static async start(options) {
    const archive = new _SecurityArchive(options);
    await archive.refresh(options);
    return archive;
  }
  /**
   * By default, limits to 100K entries in the in-memory archive.
   */
  static get defaultMax() {
    return 1e5;
  }
  /**
   * By default, entries are cached for 3 hours.
   */
  static get defaultTtl() {
    return 1e3 * 60 * 60 * 3;
  }
  constructor(options = {}) {
    super({
      max: _SecurityArchive.defaultMax,
      ttl: _SecurityArchive.defaultTtl,
      ...options,
      allowStale: true
    });
    this.#path = options.path ?? new XDG("vlt").cache("security-archive.db");
    this.#retries = options.retries ?? 3;
  }
  /**
   * Retrieves a node using its name and version.
   */
  #retrieveNodeByNameVersion(name, version2) {
    for (const node of this.#nodesByName.get(name) ?? []) {
      if (node.version === version2) {
        return node;
      }
    }
  }
  /**
   * Opens a connection to the database at the given path.
   */
  #openDatabase() {
    mkdirSync(dirname(this.#path), { recursive: true });
    const db = new DatabaseSync(this.#path);
    db.exec(
      "CREATE TABLE IF NOT EXISTS cache (depID TEXT PRIMARY KEY, report TEXT, ttl INTEGER, start INTEGER) WITHOUT ROWID"
    );
    db.exec("PRAGMA journal_mode = WAL");
    db.exec("PRAGMA synchronous = NORMAL");
    return db;
  }
  /**
   * Loads all valid items found in the database into the in-memory cache.
   */
  #loadItemsFromDatabase(db, nodes) {
    const depIDs = [];
    for (const node of nodes) {
      depIDs.push(`'${baseDepID(node.id)}'`);
    }
    const dbRead = db.prepare(
      `SELECT depID, report, start, ttl, (SELECT UNIXEPOCH('subsecond') * 1000) as now FROM cache WHERE depID IN (${depIDs.join(",")})`
    );
    this.#expired.clear();
    for (const entry of dbRead.all()) {
      const { depID, now, report, start, ttl } = entry;
      const id = baseDepID(asDepID(depID));
      try {
        this.set(id, asPackageReportData(JSON.parse(report)), {
          ttl,
          start
        });
        if (start + ttl < now) {
          this.#expired.add(id);
        }
      } catch {
        db.prepare("DELETE FROM cache WHERE depID = ?").run(depID);
      }
    }
    this.#pUpdateExpired = this.#updateExpired(db);
  }
  /**
   * Updates the database with renewed entries for expired packages.
   */
  async #updateExpired(db) {
    const expiredQueue = /* @__PURE__ */ new Set();
    for (const depID of this.#expired) {
      const node = this.#nodesByID.get(baseDepID(depID));
      if (!node?.version) {
        continue;
      }
      const purl = `pkg:npm/${node.name}@${node.version}`;
      expiredQueue.add({ purl });
    }
    if (expiredQueue.size > 0) {
      const res = await pRetry(
        () => this.#retrieveRemoteData(expiredQueue),
        { retries: this.#retries }
      );
      const ids = this.#loadFromNDJSON(res);
      this.#storeNewItemsToDatabase(db, ids);
    }
  }
  /**
   * Queues up all required packages that are missing from the archive.
   */
  #queueUpRequiredPackages() {
    const queue = /* @__PURE__ */ new Set();
    for (const node of this.#nodesByID.values()) {
      const normalizedId = baseDepID(node.id);
      if (usesTargetRegistry(node) && !this.has(normalizedId) && !this.#expired.has(normalizedId)) {
        const purl = `pkg:npm/${node.name}@${node.version}`;
        queue.add({ purl });
      }
    }
    return queue;
  }
  /**
   * Fetches security information from the socket.dev API.
   * Returns a string of NDJSON data.
   */
  async #retrieveRemoteData(queue) {
    const req = await fetch(SOCKET_API_V0_URL, {
      method: "POST",
      headers: {
        Authorization: `Basic ${Buffer.from(`${SOCKET_PUBLIC_API_TOKEN}:`).toString("base64url")}`,
        "User-Agent": `@vltpkg/security-archive/${version}`
      },
      body: JSON.stringify({
        components: Array.from(queue)
      })
    });
    if (req.status === 404) {
      throw new AbortError("Missing API");
    }
    if (!req.ok || !(req.status >= 200 && req.status <= 299)) {
      throw error("Failed to fetch security data", { response: req });
    }
    const str = await req.text();
    return str.trim() + "\n";
  }
  /**
   * Parses and load NDJSON data into the in-memory cache.
   * Returns a set of dep ids that were successfully loaded.
   */
  #loadFromNDJSON(str) {
    const fetchedDepIDs = /* @__PURE__ */ new Set();
    const json = str.split("}\n");
    for (const line of json) {
      if (!line.trim()) continue;
      const data = JSON.parse(line + "}");
      const scope = data.namespace ? `${data.namespace}/` : "";
      const name = `${scope}${data.name}`;
      const node = this.#retrieveNodeByNameVersion(name, data.version);
      if (node) {
        const normalizedId = baseDepID(node.id);
        fetchedDepIDs.add(baseDepID(node.id));
        const scoreComponents = [
          data.score.license,
          data.score.maintenance,
          data.score.quality,
          data.score.supplyChain,
          data.score.vulnerability
        ];
        const newAverageScore = Number(
          (scoreComponents.reduce((sum, score) => sum + score, 0) / scoreComponents.length).toFixed(2)
        );
        const scoreWithNewAverage = {
          ...data.score,
          overall: newAverageScore
        };
        this.set(
          normalizedId,
          asPackageReportData({
            ...data,
            score: scoreWithNewAverage
          })
        );
      } else {
        console.warn(
          `security-archive: failed to find node for ${scope}${data.name}@${data.version} found in the response.`
        );
      }
    }
    return fetchedDepIDs;
  }
  /**
   * Store new in-memory items to the database.
   */
  #storeNewItemsToDatabase(db, depIDs) {
    const insertData = [];
    for (const depID of depIDs) {
      const entry = this.info(depID);
      if (entry?.start && entry.ttl) {
        insertData.push([
          depID,
          JSON.stringify(entry.value),
          entry.start,
          entry.ttl
        ]);
      }
    }
    const dbWrite = db.prepare(
      "INSERT OR REPLACE INTO cache (depID, report, start, ttl) VALUES (?, ?, ?, ?)"
    );
    for (const data of insertData) {
      dbWrite.run(...data);
    }
  }
  /**
   * Validates that all public-registry packages in the nodes
   * have a valid report data in the current in-memory cache.
   */
  #validateReportData() {
    for (const node of this.#nodesByID.values()) {
      if (usesTargetRegistry(node)) {
        if (!this.has(baseDepID(node.id))) {
          this.ok = false;
          return;
        }
      }
    }
    this.ok = true;
  }
  /**
   * Starts the security archive by providing an array of {@link NodeLike} instances,
   * its registry-based nodes are going to be used as valid potential entries.
   *
   * Any entry that is missing from the persisted cached values are going
   * to be requested in a batch-request to the remote socket.dev API.
   */
  async refresh({ nodes }) {
    this.clear();
    const db = this.#openDatabase();
    this.#nodesByName.clear();
    this.#nodesByID.clear();
    for (const node of nodes) {
      const setByName = this.#nodesByName.get(node.name ?? "") ?? /* @__PURE__ */ new Set();
      setByName.add(node);
      this.#nodesByName.set(node.name ?? "", setByName);
      this.#nodesByID.set(baseDepID(node.id), node);
    }
    try {
      this.#loadItemsFromDatabase(db, nodes);
      const queue = this.#queueUpRequiredPackages();
      if (queue.size > 0) {
        const res = await pRetry(
          () => this.#retrieveRemoteData(queue),
          { retries: this.#retries }
        );
        const ids = this.#loadFromNDJSON(res);
        this.#storeNewItemsToDatabase(db, ids);
      }
      this.#validateReportData();
    } finally {
      void this.#close(db);
    }
  }
  /**
   * Closes the database connection and cleans up the internal state.
   */
  async #close(db) {
    await this.#pUpdateExpired;
    db.exec("PRAGMA optimize");
    db.close();
    this.#expired.clear();
    this.#pUpdateExpired = void 0;
  }
  /**
   * Outputs the current in-memory cache as a JSON object.
   */
  toJSON() {
    const obj = {};
    for (const [key, value] of this.dump()) {
      obj[key] = value.value;
    }
    return obj;
  }
};

export {
  AbortError,
  pRetry,
  SecurityArchive
};
