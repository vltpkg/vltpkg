var global = globalThis;
import {Buffer} from "node:buffer";
import {setTimeout as _vlt_setTimeout,clearTimeout as _vlt_clearTimeout,setImmediate as _vlt_setImmediate,clearImmediate as _vlt_clearImmediate,setInterval as _vlt_setInterval,clearInterval as _vlt_clearInterval} from "node:timers";
globalThis.setTimeout = _vlt_setTimeout;
globalThis.clearTimeout = _vlt_clearTimeout;
globalThis.setImmediate = _vlt_setImmediate;
globalThis.clearImmediate = _vlt_clearImmediate;
globalThis.setInterval = _vlt_setInterval;
globalThis.clearInterval = _vlt_clearInterval;
import {createRequire as _vlt_createRequire} from "node:module";
var require = _vlt_createRequire(import.meta.filename);
import {
  error,
  syntaxError,
  typeError
} from "./chunk-WZWDS3W4.js";

// ../../src/fast-split/src/index.ts
function fastSplit(str, delim, limit = -1, onPart) {
  let i = 0;
  let p = 0;
  const l = delim.length;
  const parts = [];
  while (i !== -1) {
    i = str.indexOf(delim, p);
    const part = i === -1 || parts.length === limit - 1 ? str.substring(p) : str.substring(p, i);
    parts.push(onPart?.(part, parts, i) ?? part);
    if (parts.length === limit) {
      return parts;
    }
    p = i + l;
  }
  return parts;
}

// ../../src/semver/src/version.ts
var maybeNumber = (s) => {
  if (!/^[0-9]+$/.test(s)) return s;
  const n = Number(s);
  return n <= Number.MAX_SAFE_INTEGER ? n : s;
};
var safeNumber = (s, version, field) => {
  const n = Number(s);
  if (n > Number.MAX_SAFE_INTEGER) {
    throw invalidVersion(
      version,
      `invalid ${field}, must be <= ${Number.MAX_SAFE_INTEGER}`
    );
  }
  return n;
};
var re = {
  prefix: /^[ v=]+/,
  main: /^(0|[1-9]\d*)\.(0|[1-9]\d*)\.(0|[1-9]\d*)/,
  prerelease: /-([0-9a-zA-Z_.-]+)(?:$|\+)/,
  build: /\+([0-9a-zA-Z_.-]+)$/,
  full: /^[ v=]*(0|[1-9]\d*)\.(0|[1-9]\d*)\.(0|[1-9]\d*)(?:-([0-9a-zA-Z_.-]+))?(?:\+([0-9a-zA-Z_.-]+))?$/
};
var invalidVersion = (version, message) => {
  const er = syntaxError(
    `invalid version: ${message}`,
    { version },
    Version
  );
  return er;
};
var versionIncrements = [
  "major",
  "minor",
  "patch",
  "pre",
  "premajor",
  "preminor",
  "prepatch",
  "prerelease"
];
var Version = class _Version {
  /** raw string provided to create this Version */
  raw;
  /**  major version number */
  major;
  /** minor version number */
  minor;
  /** patch version number */
  patch;
  /**
   * List of `'.'`-separated strings and numbers indicating that this
   * version is a prerelease.
   *
   * This is undefined if the version does not have a prerelease section.
   */
  prerelease;
  /**
   * List of `'.'`-separated strings in the `build` section.
   *
   * This is undefined if the version does not have a build.
   */
  build;
  /** Canonical strict form of this version */
  toString() {
    return `${this.major}.${this.minor}.${this.patch}${this.prerelease ? "-" + this.prerelease.join(".") : ""}${this.build ? "+" + this.build.join(".") : ""}`;
  }
  /** Generate a `Version` object from a SemVer string */
  static parse(version) {
    version = version.replace(re.prefix, "").trim();
    if (version.length > 256) {
      throw invalidVersion(
        version,
        "must be less than 256 characters"
      );
    }
    const parsed = re.full.exec(version);
    if (!parsed) {
      const main = re.main.exec(version);
      if (!main) {
        throw invalidVersion(
          version,
          "no Major.minor.patch tuple present"
        );
      } else {
        throw invalidVersion(
          version,
          "invalid build or patch section"
        );
      }
    }
    const [_, major_, minor_, patch_, prerelease, build] = parsed;
    const major2 = safeNumber(major_, version, "major");
    const minor2 = safeNumber(minor_, version, "minor");
    const patch2 = safeNumber(patch_, version, "patch");
    return new _Version(
      version,
      major2,
      minor2,
      patch2,
      prerelease,
      build
    );
  }
  constructor(version, major2, minor2, patch2, prerelease, build) {
    this.raw = version;
    this.major = major2;
    this.minor = minor2;
    this.patch = patch2;
    if (prerelease) {
      this.prerelease = fastSplit(prerelease, ".", -1, (c) => {
        if (!c) {
          throw invalidVersion(
            version,
            "invalid prerelease, empty identifiers not allowed"
          );
        }
        return maybeNumber(c);
      });
    }
    if (build) {
      this.build = fastSplit(build, ".", -1, (c) => {
        if (!c) {
          throw invalidVersion(
            version,
            "invalid build metadata, empty identifiers not allowed"
          );
        }
      });
    }
  }
  /**
   * Return 1 if this is > the provided version, -1 if we're less, or 0 if
   * they are equal.
   *
   * No special handling for prerelease versions, this is just a precedence
   * comparison.
   *
   * This can be used to sort a list of versions by precedence:
   *
   * ```ts
   * const versions: Version[] = getVersionsSomehow()
   * const sorted = versions.sort((a, b) => a.compare(b))
   * ```
   */
  compare(v) {
    if (this.major > v.major) return 1;
    if (this.major < v.major) return -1;
    if (this.minor > v.minor) return 1;
    if (this.minor < v.minor) return -1;
    if (this.patch > v.patch) return 1;
    if (this.patch < v.patch) return -1;
    if (!v.prerelease?.length)
      return !this.prerelease?.length ? 0 : -1;
    if (!this.prerelease?.length) return 1;
    const len = Math.max(this.prerelease.length, v.prerelease.length);
    const me = this.prerelease;
    const thee = v.prerelease;
    for (let i = 0; i < len; i++) {
      const m = me[i];
      const t = thee[i];
      if (m === t) continue;
      if (t === void 0) return 1;
      if (m === void 0) return -1;
      if (typeof m !== typeof t) {
        return typeof m === "string" ? 1 : -1;
      }
      return m > t ? 1 : -1;
    }
    return 0;
  }
  /**
   * The inverse of compare, for sorting version lists in reverse order
   */
  rcompare(v) {
    return -1 * this.compare(v);
  }
  /** true if this version is > the argument */
  greaterThan(v) {
    return this.compare(v) === 1;
  }
  /** true if this version is >= the argument */
  greaterThanEqual(v) {
    return this.compare(v) > -1;
  }
  /** true if this version is < the argument */
  lessThan(v) {
    return this.compare(v) === -1;
  }
  /** true if this version is &lt;= the argument */
  lessThanEqual(v) {
    return this.compare(v) < 1;
  }
  /** true if these two versions have equal SemVer precedence */
  equals(v) {
    return this.compare(v) === 0;
  }
  /** just compare the M.m.p parts of the version */
  tupleEquals(v) {
    return this.major === v.major && this.minor === v.minor && this.patch === v.patch;
  }
  /** true if this version satisfies the range */
  satisfies(r) {
    return r.test(this);
  }
  /**
   * Increment the version in place, in the manner specified.
   *
   * Part behaviors:
   *
   * - `'major'` If the version is a `M.0.0-...` version with a prerelease, then
   * simply drop the prerelease. Otherwise, set the minor and patch to 0, and
   * increment the major. So `1.0.0-beta` becomes `1.0.0`, and `1.2.3` becomes
   * `2.0.0`
   *
   * - `'minor'` If the version is a `M.m.0-...` version with a prerelease, then
   * simply drop the prerelease. Otherwise, set the patch to 0, and increment the
   * minor. So `1.2.0-beta` becomes `1.2.0`, and `1.2.3` becomes `1.3.0`.
   *
   * - `'patch'` If the version has a prerelease, then simply drop the
   * prerelease. Otherwise, increment the patch value. So `1.2.3-beta` becomes
   * `1.2.3` and `1.2.3` becomes `1.2.4`.
   *
   * - `'premajor'` Set the patch and minor versions to `0`, increment the major
   * version, and add a prerelease, using the optional identifier.
   *
   * - `'preminor'` Set the patch version to `0`, increment the minor version,
   * and add a prerelease, using the optional identifier.
   *
   * - `'prepatch'` If a prerelease is already present, increment the patch
   * version, otherwise leave it untouched, and add a prerelease, using the
   * optional identifier.
   *
   * - `'prerelease'` If a prerelease version is present, then behave the same as
   * `'prepatch'`. Otherwise, add a prerelease, using the optional identifier.
   *
   * - `'pre'` This is mostly for use by the other prerelease incrementers.
   *
   *     - If a prerelease identifier is provided:
   *
   *        Update that named portion of the prerelease. For example,
   *        `inc('1.2.3-beta.4', 'pre', 'beta')` would result in `1.2.3-beta.5`.
   *
   *        If there is no prerelease identifier by that name, then replace the
   *        prerelease with `[name]`. So `inc('1.2.3-alpha.4', 'pre', 'beta')`
   *        would result in `1.2.3-beta`.
   *
   *        If the prerelease identifer is present, but has no numeric value
   *        following it, then add `0`. So `inc('1.2.3-beta', 'pre', 'beta')`
   *        would result in `1.2.3-beta.0`.
   *
   *     - If no prerelease identifier is provided:
   *
   *       If there is no current prerelease, then set the prerelease to `0`. So,
   *       `inc('1.2.3', 'pre')` becomes `1.2.3-0`.
   *
   *       If the last item in the prerelease is numeric, then increment it. So,
   *       `inc('1.2.3-beta.3', 'pre')` becomes `1.2.3-beta.4`.
   */
  inc(part, prereleaseIdentifier) {
    switch (part) {
      case "premajor":
        this.prerelease = void 0;
        this.patch = 0;
        this.minor = 0;
        this.major++;
        this.inc("pre", prereleaseIdentifier);
        break;
      case "preminor":
        this.prerelease = void 0;
        this.patch = 0;
        this.minor++;
        this.inc("pre", prereleaseIdentifier);
        break;
      case "prepatch":
        this.prerelease = void 0;
        this.inc("patch");
        this.inc("pre", prereleaseIdentifier);
        break;
      case "prerelease":
        if (!this.prerelease?.length)
          this.inc("patch", prereleaseIdentifier);
        this.inc("pre", prereleaseIdentifier);
        break;
      case "pre": {
        if (!prereleaseIdentifier) {
          if (!this.prerelease?.length) {
            this.prerelease = [0];
            break;
          }
          const last = this.prerelease[this.prerelease.length - 1];
          if (typeof last === "number") {
            this.prerelease[this.prerelease.length - 1] = last + 1;
          } else {
            this.prerelease.push(0);
          }
          break;
        }
        if (!this.prerelease?.length) {
          this.prerelease = [prereleaseIdentifier];
          break;
        }
        const i = this.prerelease.indexOf(
          maybeNumber(prereleaseIdentifier)
        );
        if (i === -1) {
          this.prerelease = [prereleaseIdentifier];
          break;
        }
        const baseValue = this.prerelease[i + 1];
        if (typeof baseValue === "number") {
          this.prerelease[i + 1] = baseValue + 1;
          break;
        }
        if (i === this.prerelease.length - 1) {
          this.prerelease.push(0);
          break;
        }
        this.prerelease.splice(i + 1, 0, 0);
        break;
      }
      case "major":
        if (!this.prerelease?.length || this.minor || this.patch)
          this.major++;
        this.prerelease = void 0;
        this.patch = 0;
        this.minor = 0;
        break;
      case "minor":
        if (!this.prerelease?.length || this.patch) this.minor++;
        this.prerelease = void 0;
        this.patch = 0;
        break;
      case "patch":
        if (!this.prerelease?.length) this.patch++;
        this.prerelease = void 0;
        break;
      default:
        throw typeError(
          "Invalid increment identifier",
          {
            version: this,
            found: part,
            validOptions: [
              "major",
              "minor",
              "patch",
              "premajor",
              "preminor",
              "prepatch",
              "prerelease",
              "pre"
            ]
          },
          this.inc
        );
    }
    this.raw = this.toString();
    return this;
  }
};

// ../../src/semver/src/comparator.ts
var isOperator = (o) => !!o && (o === ">" || o === "<" || o === ">=" || o === "<=" || o === "" || o === "~" || o === "^" || o === "~>");
var preJunk = new Set("=v 	");
var invalidComp = (c, message) => syntaxError(
  `invalid comparator: '${c}' ${message}`,
  { found: c },
  Comparator
);
var assertNumber = (value, c, field) => {
  const n = Number(value);
  if (n !== n) {
    throw invalidComp(
      c,
      `${field} must be numeric or 'x', got: '${value}'`
    );
  }
  return n;
};
var assertVersion = (v, comp) => {
  if (!v) {
    throw invalidComp(comp, "no value provided for operator");
  }
};
var assertMissing = (value, c, field) => {
  if (value && !isX(value)) {
    throw invalidComp(
      c,
      `cannot omit '${field}' and include subsequent fields`
    );
  }
};
var MAJOR = 0;
var MINOR = 1;
var PATCH = 2;
var isX = (c) => !c || c === "X" || c === "x" || c === "*";
var isFullVersion = (parsed) => void 0 !== parsed[PATCH];
var isXPatch = (parsed) => void 0 !== parsed[MINOR] && void 0 === parsed[PATCH];
var isXMinor = (parsed) => void 0 !== parsed[MAJOR] && void 0 === parsed[MINOR];
var isXMajor = (parsed) => void 0 === parsed[MAJOR];
var Comparator = class {
  /**
   * does this range include prereleases, even when they do not
   * match the tuple in the comparator?
   */
  includePrerelease;
  /** raw string used to create this comparator */
  raw;
  /** tokens extracted from the raw string input */
  tokens;
  /**
   * Either the `any` comparator, the `none` comparator, or an operator
   * and a {@link ParsedXRange}
   */
  tuples = [];
  /** true if this comparator can not match anything */
  isNone = false;
  /**
   * true if this comparator is a `'*'` type of range.
   *
   * Note that it still will not match versions with a prerelease value,
   * unless the tuple in the version matches the tuple provided to the
   * comparator, and the comparator version also has a prerelease value,
   * unless `includePrerelease` is set.
   */
  isAny = false;
  /** the canonical strict simplified parsed form of this constructor */
  toString() {
    return this.isNone ? "<0.0.0-0" : this.isAny ? "*" : (
      /* c8 ignore next */
      this.tuples.map((c) => isAny(c) ? "*" : c.join("")).join(" ")
    );
  }
  constructor(comp, includePrerelease = false) {
    this.includePrerelease = includePrerelease;
    comp = comp.trim();
    this.raw = comp;
    let hyphen = false;
    const rawComps = fastSplit(comp, " ", -1, (part, parts, i) => {
      if (part === "-") {
        if (hyphen) {
          throw invalidComp(
            comp,
            "multiple hyphen ranges not allowed"
          );
        }
        if (parts.length !== 1 || i === -1) {
          throw invalidComp(
            comp,
            "hyphen must be between two versions"
          );
        }
        hyphen = true;
      } else if (hyphen && parts.length !== 2) {
        throw invalidComp(comp, "hyphen range must be alone");
      }
    });
    const comps = [];
    let followingOperator = false;
    let l = 0;
    for (const c of rawComps) {
      if (c === "") continue;
      if (!followingOperator) {
        followingOperator = isOperator(c);
        comps.push(c);
        l++;
        continue;
      }
      comps[l - 1] += c;
      followingOperator = false;
    }
    if (hyphen) {
      const [min, _, max] = comps;
      if (!min || !max) {
        throw invalidComp(comp, "hyphen must be between two versions");
      }
      this.#parseHyphenRange(min, max);
    } else if (!comps.length || comps.length === 1 && isX(comps[0])) {
      this.tuples.push(this.#getComparatorAny());
    } else {
      for (const c of comps) {
        this.#parse(c);
        if (this.isNone) break;
      }
    }
    this.tokens = comps;
    this.isAny = true;
    for (const c of this.tuples) {
      if (Array.isArray(c) || !c.isAny) {
        this.isAny = false;
        break;
      }
    }
  }
  // inclusive min
  #xInclusiveMin(raw) {
    const z = this.includePrerelease ? "0" : void 0;
    const [M, m = 0, p = 0, pr = z, build] = this.#parseX(raw);
    return M === void 0 ? this.#getComparatorAny() : [">=", new Version(raw, M, m, p, pr, build)];
  }
  // exclusive min
  #xExclusiveMin(raw) {
    const parsed = this.#parseX(raw);
    if (isFullVersion(parsed)) {
      return [">", new Version(raw, ...parsed)];
    }
    const z = this.includePrerelease ? "0" : void 0;
    if (isXPatch(parsed)) {
      return [
        ">=",
        new Version(
          raw,
          parsed[MAJOR],
          parsed[MINOR] + 1,
          0,
          z,
          void 0
        )
      ];
    }
    if (isXMinor(parsed)) {
      return [
        ">=",
        new Version(raw, parsed[MAJOR] + 1, 0, 0, z, void 0)
      ];
    }
    this.isNone = true;
    this.tuples.length = 0;
    return comparatorNone;
  }
  #xInclusiveMax(raw) {
    const parsed = this.#parseX(raw);
    return isFullVersion(parsed) ? ["<=", new Version(raw, ...parsed)] : isXPatch(parsed) ? [
      "<",
      new Version(
        raw,
        parsed[MAJOR],
        parsed[MINOR] + 1,
        0,
        "0",
        void 0
      )
    ] : isXMinor(parsed) ? [
      "<",
      new Version(raw, parsed[MAJOR] + 1, 0, 0, "0", void 0)
    ] : this.#getComparatorAny();
  }
  #xExclusiveMax(raw) {
    const z = this.includePrerelease ? "0" : void 0;
    const [M = 0, m = 0, p = 0, pr = z, build] = this.#parseX(raw);
    if (M === 0 && m === 0 && p === 0 && pr === "0") {
      this.isNone = true;
      this.tuples.length = 0;
      return comparatorNone;
    }
    return ["<", new Version(raw, M, m, p, pr, build)];
  }
  #validXM(raw, m, p) {
    assertMissing(m, raw, "major");
    assertMissing(p, raw, "major");
    if (m === "" || p === "") {
      throw invalidComp(raw, `(Did you mean '*'?)`);
    }
    return [];
  }
  #validXm(raw, M, m, p) {
    assertMissing(p, raw, "major");
    if (m === "" || p === "") {
      throw invalidComp(raw, `(Did you mean '${M}'?)`);
    }
    return [assertNumber(M, raw, "major")];
  }
  #validXp(raw, M, m, p) {
    if (p === "") {
      throw invalidComp(raw, `(Did you mean '${M}.${m}'?)`);
    }
    return [
      assertNumber(M, raw, "major"),
      assertNumber(m, raw, "minor")
    ];
  }
  #validTuple(raw, M, m, p) {
    return [
      assertNumber(M, raw, "major"),
      assertNumber(m, raw, "minor"),
      assertNumber(p, raw, "patch")
    ];
  }
  #validXbuild(raw, M, m, p, pl) {
    const patch2 = p.substring(0, pl);
    const build = p.substring(pl + 1);
    if (!patch2) {
      throw invalidComp(raw, "cannot specify build without patch");
    }
    if (!build) {
      throw invalidComp(raw, `encountered '+', but no build value`);
    }
    return [
      assertNumber(M, raw, "major"),
      assertNumber(m, raw, "minor"),
      assertNumber(patch2, raw, "patch"),
      void 0,
      build
    ];
  }
  #validXpr(raw, M, m, p, hy) {
    {
      const patch2 = p.substring(0, hy);
      const pr = p.substring(hy + 1);
      if (!patch2) {
        throw invalidComp(
          raw,
          "cannot specify prerelease without patch"
        );
      }
      if (!pr) {
        throw invalidComp(
          raw,
          `encountered '-', but no prerelease value`
        );
      }
      return [
        assertNumber(M, raw, "major"),
        assertNumber(m, raw, "minor"),
        assertNumber(patch2, raw, "patch"),
        pr,
        void 0
      ];
    }
  }
  #validXprbuild(raw, M, m, p, hy, pl) {
    const patch2 = p.substring(0, hy);
    const pr = p.substring(hy + 1, pl);
    const build = p.substring(pl + 1);
    if (!patch2) {
      throw invalidComp(
        raw,
        "cannot specify prerelease without patch"
      );
    }
    if (!pr) {
      throw invalidComp(
        raw,
        `encountered '-', but no prerelease value`
      );
    }
    if (!build) {
      throw invalidComp(raw, `encountered '+', but no build value`);
    }
    return [
      assertNumber(M, raw, "major"),
      assertNumber(m, raw, "minor"),
      assertNumber(patch2, raw, "patch"),
      pr,
      build
    ];
  }
  // pull the relevant values out of an X-range or version
  // return the fields for creating a Version object.
  // only call once operator is stripped off
  #parseX(raw) {
    let [M, m, p] = fastSplit(raw, ".", 3);
    let prune = 0;
    while (M && preJunk.has(M.charAt(prune))) prune++;
    if (M !== void 0 && prune !== 0) M = M.substring(prune);
    if (!M || isX(M)) return this.#validXM(raw, m, p);
    if (!m || isX(m)) return this.#validXm(raw, M, m, p);
    if (!p || isX(p)) return this.#validXp(raw, M, m, p);
    const hy = p.indexOf("-");
    const pl = p.indexOf("+");
    if (pl === -1 && hy === -1) return this.#validTuple(raw, M, m, p);
    if (pl === -1) return this.#validXpr(raw, M, m, p, hy);
    if (hy === -1) return this.#validXbuild(raw, M, m, p, pl);
    return this.#validXprbuild(raw, M, m, p, hy, pl);
  }
  #parseHyphenRange(min, max) {
    const minv = this.#xInclusiveMin(min);
    const maxv = this.#xInclusiveMax(max);
    const minAny = isAny(minv);
    const maxAny = isAny(maxv);
    if (minAny && maxAny) this.tuples.push(this.#getComparatorAny());
    else if (minAny) this.tuples.push(maxv);
    else if (maxAny) this.tuples.push(minv);
    else this.tuples.push(minv, maxv);
  }
  #parse(comp) {
    const first = comp.charAt(0);
    const first2 = comp.substring(0, 2);
    const v1 = comp.substring(1);
    const v2 = comp.substring(2);
    switch (first2) {
      case "~>":
        assertVersion(v2, comp);
        return this.#parseTilde(v2);
      case ">=":
        assertVersion(v2, comp);
        return this.tuples.push(this.#xInclusiveMin(v2));
      case "<=":
        assertVersion(v2, comp);
        return this.tuples.push(this.#xInclusiveMax(v2));
    }
    switch (first) {
      case "~":
        assertVersion(v1, comp);
        return this.#parseTilde(v1);
      case "^":
        assertVersion(v1, comp);
        return this.#parseCaret(v1);
      case ">":
        assertVersion(v1, comp);
        return this.tuples.push(this.#xExclusiveMin(v1));
      case "<":
        assertVersion(v1, comp);
        return this.tuples.push(this.#xExclusiveMax(v1));
    }
    return this.#parseEq(comp);
  }
  #parseTilde(comp) {
    const parsed = this.#parseX(comp);
    if (isXMajor(parsed)) {
      this.tuples.push(this.#getComparatorAny());
      return;
    }
    const z = this.includePrerelease ? "0" : void 0;
    if (isXMinor(parsed)) {
      const [M2] = parsed;
      this.tuples.push(
        [">=", new Version(comp, M2, 0, 0, z, void 0)],
        ["<", new Version(comp, M2 + 1, 0, 0, "0", void 0)]
      );
      return;
    }
    if (isXPatch(parsed)) {
      const [M2, m2] = parsed;
      const z2 = this.includePrerelease ? "0" : void 0;
      this.tuples.push(
        [">=", new Version(comp, M2, m2, 0, z2, void 0)],
        ["<", new Version(comp, M2, m2 + 1, 0, "0", void 0)]
      );
      return;
    }
    const [M, m, p, pr = z, build] = parsed;
    this.tuples.push(
      [">=", new Version(comp, M, m, p, pr, build)],
      ["<", new Version(comp, M, m + 1, 0, "0", build)]
    );
  }
  #parseCaret(comp) {
    const min = this.#xInclusiveMin(comp);
    if (isAny(min)) {
      this.tuples.push(min);
      return;
    }
    const minv = min[1];
    if (minv.major !== 0) {
      this.tuples.push(min, [
        "<",
        new Version(comp, minv.major + 1, 0, 0, "0", void 0)
      ]);
    } else if (minv.minor !== 0) {
      this.tuples.push(min, [
        "<",
        new Version(
          comp,
          minv.major,
          minv.minor + 1,
          0,
          "0",
          void 0
        )
      ]);
    } else if (!minv.prerelease?.length) {
      this.tuples.push(["", minv]);
    } else {
      this.tuples.push(min, [
        "<",
        new Version(
          comp,
          minv.major,
          minv.minor,
          minv.patch + 1,
          "0",
          void 0
        )
      ]);
    }
  }
  #parseEq(comp) {
    const parsed = this.#parseX(comp);
    const z = this.includePrerelease ? "0" : void 0;
    if (isFullVersion(parsed)) {
      this.tuples.push(["", new Version(comp, ...parsed)]);
    } else if (isXMajor(parsed)) {
      this.tuples.push(this.#getComparatorAny());
    } else if (isXMinor(parsed)) {
      this.tuples.push([
        ">=",
        new Version(comp, parsed[MAJOR], 0, 0, z, void 0)
      ]);
      this.tuples.push([
        "<",
        new Version(comp, parsed[MAJOR] + 1, 0, 0, "0", void 0)
      ]);
    } else if (isXPatch(parsed)) {
      this.tuples.push(
        [
          ">=",
          new Version(
            comp,
            parsed[MAJOR],
            parsed[MINOR],
            0,
            z,
            void 0
          )
        ],
        [
          "<",
          new Version(
            comp,
            parsed[MAJOR],
            parsed[MINOR] + 1,
            0,
            "0",
            void 0
          )
        ]
      );
    }
  }
  /** return true if the version is a match for this comparator */
  test(v) {
    if (this.isNone) return false;
    const ip = this.includePrerelease;
    const hasPR = !!v.prerelease?.length;
    let prOK = ip || !hasPR;
    for (const c of this.tuples) {
      if (isAny(c)) {
        continue;
      }
      const [op, cv] = c;
      prOK ||= !!cv.prerelease?.length && v.tupleEquals(cv);
      switch (op) {
        case "":
          if (!v.equals(cv)) return false;
          continue;
        case ">":
          if (!v.greaterThan(cv)) return false;
          continue;
        case ">=":
          if (!v.greaterThanEqual(cv)) return false;
          continue;
        case "<":
          if (!v.lessThan(cv)) return false;
          continue;
        case "<=":
          if (!v.lessThanEqual(cv)) return false;
          continue;
      }
    }
    return prOK;
  }
  #getComparatorAny() {
    return this.includePrerelease ? comparatorAnyPR : comparatorAny;
  }
};
var isAny = (c) => c === comparatorAny || c === comparatorAnyPR;
var comparatorAny = {
  isAny: true,
  toString: () => "*",
  includePrerelease: false,
  test: (v) => !v.prerelease?.length
};
var comparatorAnyPR = {
  isAny: true,
  toString: () => "*",
  includePrerelease: true,
  test: (_) => true
};
var comparatorNone = {
  isNone: true,
  toString: () => "<0.0.0-0",
  includePrerelease: false,
  test: (_) => false
};

// ../../src/types/src/index.ts
var normalizeFundingEntry = (item) => {
  const getTypeFromUrl = (url) => {
    try {
      const { hostname } = new URL(url);
      const domain = hostname.startsWith("www.") ? hostname.slice(4) : hostname;
      if (domain === "github.com") return "github";
      if (domain === "patreon.com") return "patreon";
      if (domain === "opencollective.com") return "opencollective";
      return "individual";
    } catch {
      return "invalid";
    }
  };
  const validateType = (url, type) => {
    const urlType = getTypeFromUrl(url);
    if (!type || ["github", "patreon", "opencollective"].includes(urlType))
      return urlType;
    if (urlType === "invalid") return void 0;
    return type;
  };
  if (typeof item === "string") {
    return { url: item, type: getTypeFromUrl(item) };
  }
  if (isObject(item) && "url" in item && typeof item.url === "string") {
    if (isNormalizedFundingEntry(item)) {
      return item;
    }
    const obj = item;
    const url = obj.url;
    const validatedType = validateType(
      url,
      obj.type
    );
    const result = { ...obj, url };
    if (validatedType) {
      result.type = validatedType;
    } else {
      delete result.type;
    }
    return result;
  }
  return { url: "", type: "individual" };
};
var normalizeFunding = (funding) => {
  if (!funding) return;
  const fundingArray = Array.isArray(funding) ? funding : [funding];
  const sources = fundingArray.map(normalizeFundingEntry);
  return sources.length > 0 ? sources : void 0;
};
var isNormalizedFundingEntry = (o) => {
  return isObject(o) && "url" in o && typeof o.url === "string" && !!o.url && "type" in o && typeof o.type === "string" && ["github", "patreon", "opencollective", "individual"].includes(
    o.type
  );
};
var isNormalizedFunding = (o) => {
  return Array.isArray(o) && o.length > 0 && o.every(isNormalizedFundingEntry);
};
var fixManifestVersion = (manifest) => {
  if (!Object.hasOwn(manifest, "version")) {
    return manifest;
  }
  if (!manifest.version) {
    throw error("version is empty", {
      manifest
    });
  }
  const version = Version.parse(manifest.version);
  manifest.version = version.toString();
  return manifest;
};
var kWriteAccess = /* @__PURE__ */ Symbol.for("writeAccess");
var kIsPublisher = /* @__PURE__ */ Symbol.for("isPublisher");
var parsePerson = (person, writeAccess, isPublisher) => {
  if (!person) return;
  if (isObject(person)) {
    if (isNormalizedContributorEntry(person)) {
      return person;
    }
    const name = typeof person.name === "string" ? person.name : void 0;
    const email = typeof person.email === "string" ? person.email : typeof person.mail === "string" ? person.mail : void 0;
    if (!name && !email) return void 0;
    return {
      name,
      email,
      [kWriteAccess]: writeAccess ?? false,
      [kIsPublisher]: isPublisher ?? false
    };
  } else if (typeof person === "string") {
    const NAME_PATTERN = /^([^(<]+)/;
    const EMAIL_PATTERN = /<([^<>]+)>/;
    const name = NAME_PATTERN.exec(person)?.[0].trim() || "";
    const email = EMAIL_PATTERN.exec(person)?.[1] || "";
    if (!name && !email) return void 0;
    return {
      name: name || void 0,
      email: email || void 0,
      [kWriteAccess]: writeAccess ?? false,
      [kIsPublisher]: isPublisher ?? false
    };
  }
  return;
};
var isNormalizedContributorEntry = (o) => {
  return isObject(o) && typeof o.name === "string" && !!o.name && typeof o.email === "string" && !!o.email && (isBoolean(o[kWriteAccess]) || isBoolean(o.writeAccess)) && (isBoolean(o[kIsPublisher]) || isBoolean(o.isPublisher));
};
var isNormalizedContributors = (o) => {
  return Array.isArray(o) && o.length > 0 && o.every(isNormalizedContributorEntry);
};
var normalizeContributors = (contributors, maintainers) => {
  if (!contributors && !maintainers) return;
  const result = [];
  if (contributors) {
    const contributorsArray = Array.isArray(contributors) ? contributors : [contributors];
    const normalizedArray = contributorsArray.every(
      isNormalizedContributorEntry
    );
    const noMaintainers = !maintainers || Array.isArray(maintainers) && maintainers.length === 0;
    if (normalizedArray) {
      if (noMaintainers) {
        return contributorsArray.length > 0 ? contributorsArray : void 0;
      } else {
        result.push(...contributorsArray);
      }
    }
    const parsedContributors = contributorsArray.map((person) => parsePerson(person)).filter((c) => c !== void 0);
    result.push(...parsedContributors);
  }
  if (maintainers) {
    const maintainersArray = Array.isArray(maintainers) ? maintainers : [maintainers];
    const parsedMaintainers = maintainersArray.map((person) => parsePerson(person, true, true)).filter((c) => c !== void 0);
    result.push(...parsedMaintainers);
  }
  return result.length > 0 ? result : void 0;
};
var normalizeSingleBug = (bug) => {
  const res = [];
  if (typeof bug === "string") {
    try {
      new URL(bug);
      res.push({ type: "link", url: bug });
    } catch {
      const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      if (emailRegex.test(bug)) {
        res.push({ type: "email", email: bug });
      } else {
        res.push({ type: "link", url: bug });
      }
    }
  } else if (isObject(bug)) {
    if (isNormalizedBugsEntry(bug)) {
      res.push(bug);
    }
    const obj = bug;
    if (obj.url) {
      res.push({ type: "link", url: obj.url });
    }
    if (obj.email) {
      res.push({ type: "email", email: obj.email });
    }
  }
  return res.length > 0 ? res : [];
};
var normalizeBugs = (bugs) => {
  if (!bugs) return;
  const result = [];
  if (Array.isArray(bugs)) {
    for (const bug of bugs) {
      result.push(...normalizeSingleBug(bug));
    }
  } else {
    result.push(...normalizeSingleBug(bugs));
  }
  return result.length > 0 ? result : void 0;
};
var isNormalizedBugsEntry = (o) => {
  return isObject(o) && "type" in o && (o.type === "email" && typeof o.email === "string" && !!o.email || o.type === "link" && typeof o.url === "string" && !!o.url);
};
var isNormalizedBugs = (o) => {
  return Array.isArray(o) && o.length > 0 && o.every(isNormalizedBugsEntry);
};
var normalizeKeywords = (keywords) => {
  if (!keywords) return;
  let keywordArray = [];
  if (typeof keywords === "string") {
    keywordArray = keywords.split(",").map((keyword) => keyword.trim()).filter((keyword) => keyword.length > 0);
  } else if (Array.isArray(keywords)) {
    if (isNormalizedKeywords(keywords)) {
      return keywords;
    }
    keywordArray = keywords.filter(
      (keyword) => typeof keyword === "string"
    ).map((keyword) => keyword.trim()).filter((keyword) => keyword.length > 0);
  } else {
    return;
  }
  return keywordArray.length > 0 ? keywordArray : void 0;
};
var isNormalizedKeywords = (o) => {
  return Array.isArray(o) && o.length > 0 && o.every(
    (keyword) => typeof keyword === "string" && !!keyword && !keyword.startsWith(" ") && !keyword.endsWith(" ")
  );
};
var normalizeEngines = (engines) => {
  if (!engines) return;
  if (isNormalizedEngines(engines)) {
    return Object.keys(engines).length === 0 ? void 0 : engines;
  }
  return;
};
var normalizeOs = (os) => {
  if (!os) return;
  let osArray = [];
  if (typeof os === "string") {
    osArray = [os.trim()].filter((item) => item.length > 0);
  } else if (Array.isArray(os)) {
    if (isNormalizedOs(os)) {
      return os;
    }
    osArray = os.filter((item) => typeof item === "string").map((item) => item.trim()).filter((item) => item.length > 0);
  } else {
    return;
  }
  return osArray.length > 0 ? osArray : void 0;
};
var normalizeCpu = (cpu) => {
  if (!cpu) return;
  let cpuArray = [];
  if (typeof cpu === "string") {
    cpuArray = [cpu.trim()].filter((item) => item.length > 0);
  } else if (Array.isArray(cpu)) {
    if (isNormalizedCpu(cpu)) {
      return cpu;
    }
    cpuArray = cpu.filter((item) => typeof item === "string").map((item) => item.trim()).filter((item) => item.length > 0);
  } else {
    return;
  }
  return cpuArray.length > 0 ? cpuArray : void 0;
};
var normalizeLibc = (libc) => {
  if (!libc) return;
  let libcArray = [];
  if (typeof libc === "string") {
    libcArray = [libc.trim()].filter((item) => item.length > 0);
  } else if (Array.isArray(libc)) {
    if (isNormalizedLibc(libc)) {
      return libc;
    }
    libcArray = libc.filter((item) => typeof item === "string").map((item) => item.trim()).filter((item) => item.length > 0);
  } else {
    return;
  }
  return libcArray.length > 0 ? libcArray : void 0;
};
var isNormalizedEngines = (o) => {
  return isRecordStringString(o);
};
var isNormalizedOs = (o) => {
  return Array.isArray(o) && o.length > 0 && o.every(
    (item) => typeof item === "string" && !!item && !item.startsWith(" ") && !item.endsWith(" ")
  );
};
var isNormalizedCpu = (o) => {
  return Array.isArray(o) && o.length > 0 && o.every(
    (item) => typeof item === "string" && !!item && !item.startsWith(" ") && !item.endsWith(" ")
  );
};
var isNormalizedLibc = (o) => {
  return Array.isArray(o) && o.length > 0 && o.every(
    (item) => typeof item === "string" && !!item && !item.startsWith(" ") && !item.endsWith(" ")
  );
};
var normalizeBinPaths = (manifest) => {
  const { name, bin } = manifest;
  if (bin) {
    if (name && typeof bin === "string") {
      const [_scope, pkg] = parseScope(name);
      return { [pkg]: bin };
    } else if (typeof bin === "object") {
      return bin;
    }
  }
};
var isBoolean = (value) => typeof value === "boolean";
var integrityRE = /^sha512-[a-zA-Z0-9/+]{86}==$/;
var isIntegrity = (i) => typeof i === "string" && integrityRE.test(i);
var asError = (er, fallbackMessage = "Unknown error") => er instanceof Error ? er : new Error(String(er) || fallbackMessage);
var isError = (er) => er instanceof Error;
var isErrorWithCause = (er) => isError(er) && "cause" in er;
var isObject = (v) => !!v && typeof v === "object" && (v.constructor === Object || v.constructor === void 0);
var maybeRecordStringString = (o) => o === void 0 || isRecordStringString(o);
var isRecordStringString = (o) => isRecordStringT(o, (s) => typeof s === "string");
var assertRecordStringString = (o) => assertRecordStringT(
  o,
  (s) => typeof s === "string",
  "Record<string, string>"
);
var isRecordStringT = (o, check) => isObject(o) && Object.entries(o).every(
  ([k, v]) => typeof k === "string" && check(v)
);
var assertRecordStringT = (o, check, wanted) => {
  if (!isRecordStringT(o, check)) {
    throw error("Invalid record", {
      found: o,
      wanted
    });
  }
};
var isRecordStringManifest = (o) => isRecordStringT(o, (v) => isManifest(v));
var maybePeerDependenciesMetaSet = (o) => o === void 0 || isRecordStringT(
  o,
  (v) => isPeerDependenciesMetaValue(v)
);
var maybeBoolean = (o) => o === void 0 || typeof o === "boolean";
var isPeerDependenciesMetaValue = (o) => isObject(o) && maybeBoolean(o.optional);
var maybeString = (a) => a === void 0 || typeof a === "string";
var maybeDist = (a) => a === void 0 || isObject(a) && maybeString(a.tarball);
var isManifest = (m) => isObject(m) && !Array.isArray(m) && maybeString(m.name) && maybeString(m.version) && maybeRecordStringString(m.dependencies) && maybeRecordStringString(m.devDependencies) && maybeRecordStringString(m.optionalDependencies) && maybeRecordStringString(m.peerDependencies) && maybeRecordStringString(m.acceptDependencies) && maybePeerDependenciesMetaSet(m.peerDependenciesMeta) && maybeDist(m.dist);
var asManifest = (m, from) => {
  if (!isManifest(m)) {
    throw error("invalid manifest", { found: m }, from ?? asManifest);
  }
  return m;
};
var normalizeManifestCache = /* @__PURE__ */ new WeakMap();
var normalizeManifest = (manifest) => {
  const cached = normalizeManifestCache.get(manifest);
  if (cached) {
    return cached;
  }
  manifest = fixManifestVersion(manifest);
  const normalizedAuthor = parsePerson(manifest.author);
  const normalizedFunding = normalizeFunding(manifest.funding);
  const normalizedContributors = normalizeContributors(
    manifest.contributors,
    manifest.maintainers
  );
  const normalizedBugs = normalizeBugs(manifest.bugs);
  const normalizedKeywords = normalizeKeywords(manifest.keywords);
  const normalizedEngines = normalizeEngines(manifest.engines);
  const normalizedOs = normalizeOs(manifest.os);
  const normalizedCpu = normalizeCpu(manifest.cpu);
  const normalizedLibc = normalizeLibc(manifest.libc);
  const normalizedBin = normalizeBinPaths(manifest);
  const normalizedManifest = manifest;
  if (normalizedAuthor) {
    normalizedManifest.author = normalizedAuthor;
  } else {
    delete normalizedManifest.author;
  }
  if (normalizedFunding) {
    normalizedManifest.funding = normalizedFunding;
  } else {
    delete normalizedManifest.funding;
  }
  if (normalizedContributors) {
    normalizedManifest.contributors = normalizedContributors;
  } else {
    delete normalizedManifest.contributors;
  }
  if (normalizedBugs) {
    normalizedManifest.bugs = normalizedBugs;
  } else {
    delete normalizedManifest.bugs;
  }
  if (normalizedKeywords) {
    normalizedManifest.keywords = normalizedKeywords;
  } else {
    delete normalizedManifest.keywords;
  }
  if (normalizedEngines) {
    normalizedManifest.engines = normalizedEngines;
  } else {
    delete normalizedManifest.engines;
  }
  if (normalizedOs) {
    normalizedManifest.os = normalizedOs;
  } else {
    delete normalizedManifest.os;
  }
  if (normalizedCpu) {
    normalizedManifest.cpu = normalizedCpu;
  } else {
    delete normalizedManifest.cpu;
  }
  if (normalizedLibc) {
    normalizedManifest.libc = normalizedLibc;
  } else {
    delete normalizedManifest.libc;
  }
  if (normalizedBin) {
    normalizedManifest.bin = normalizedBin;
  } else {
    delete normalizedManifest.bin;
  }
  if ("maintainers" in normalizedManifest && normalizedManifest.maintainers) {
    delete normalizedManifest.maintainers;
  }
  normalizeManifestCache.set(manifest, normalizedManifest);
  return normalizedManifest;
};
var isNormalizedManifest = (o) => {
  return isManifest(o) && // given that all these values are optional and potentially undefined
  // we only check their value content if they are present
  ("author" in o ? isNormalizedContributorEntry(o.author) : true) && ("contributors" in o ? isNormalizedContributors(o.contributors) : true) && ("funding" in o ? isNormalizedFunding(o.funding) : true) && ("bugs" in o ? isNormalizedBugs(o.bugs) : true) && ("keywords" in o ? isNormalizedKeywords(o.keywords) : true) && ("engines" in o ? isNormalizedEngines(o.engines) : true) && ("os" in o ? isNormalizedOs(o.os) : true) && ("cpu" in o ? isNormalizedCpu(o.cpu) : true) && ("libc" in o ? isNormalizedLibc(o.libc) : true);
};
var asNormalizedManifest = (m, from) => {
  if (!isNormalizedManifest(m)) {
    throw error(
      "invalid normalized manifest",
      { found: m },
      from ?? asNormalizedManifest
    );
  }
  return m;
};
var expandNormalizedContributorEntrySymbols = (c) => {
  return {
    ...c,
    writeAccess: c[kWriteAccess],
    isPublisher: c[kIsPublisher]
  };
};
var expandNormalizedManifestSymbols = (m) => {
  const res = { ...m };
  if (isNormalizedContributorEntry(m.author)) {
    res.author = expandNormalizedContributorEntrySymbols(m.author);
  }
  if (isNormalizedContributors(m.contributors)) {
    res.contributors = m.contributors.map(
      expandNormalizedContributorEntrySymbols
    );
  }
  return res;
};
var isPackument = (p) => {
  if (!isObject(p) || typeof p.name !== "string") return false;
  const { versions, "dist-tags": distTags, time } = p;
  return isRecordStringString(distTags) && isRecordStringManifest(versions) && maybeRecordStringString(time) && Object.values(distTags).every((v) => versions[v]?.name == p.name);
};
var asPackument = (p, from) => {
  if (!isPackument(p)) {
    throw error(
      "invalid packument",
      { found: p },
      from ?? asPackument
    );
  }
  return p;
};
var longDependencyTypes = /* @__PURE__ */ new Set([
  "dependencies",
  "devDependencies",
  "peerDependencies",
  "optionalDependencies"
]);
var shortDependencyTypes = /* @__PURE__ */ new Set([
  "prod",
  "dev",
  "optional",
  "peer",
  "peerOptional"
]);
var dependencyTypes = /* @__PURE__ */ new Map([
  ["dependencies", "prod"],
  ["devDependencies", "dev"],
  ["peerDependencies", "peer"],
  ["optionalDependencies", "optional"]
]);
var parseScope = (scoped) => {
  if (scoped.startsWith("@")) {
    const [scope, name, ...rest] = scoped.split("/");
    if (scope && name && rest.length === 0) return [scope, name];
  }
  return [void 0, scoped];
};

// ../../src/semver/src/range.ts
var isRange = (range) => {
  return range instanceof Range || typeof range === "object" && range !== null && "raw" in range && typeof range.raw === "string" && "set" in range && Array.isArray(range.set) && range.set.every((c) => c instanceof Comparator);
};
var Range = class {
  /** raw string used to create this Range */
  raw;
  /** true if the range is `*` */
  isAny;
  /** true if the range is a single semver version */
  isSingle;
  /** true if the range cannot match anything */
  /**
   * set of {@link Comparator} objects representing the `||`-separated sections
   * of the range. If at least one of these matches, then the version is a
   * match.
   */
  set = [];
  /** true if all prerelease versions should be included */
  includePrerelease;
  /** cached toString */
  #toString;
  constructor(range, includePrerelease = false) {
    this.raw = range;
    this.includePrerelease = includePrerelease;
    this.isAny = false;
    let isFirst = true;
    this.isSingle = false;
    const comparatorErrors = [];
    fastSplit(range, "||", -1, (part) => {
      if (this.isAny) return;
      const cmp = this.#maybeComparator(part, this.includePrerelease);
      if (cmp instanceof Error) {
        comparatorErrors.push(cmp);
        return;
      }
      if (cmp.isAny) {
        this.set = [cmp];
        this.isAny = true;
        return;
      }
      this.set.push(cmp);
      if (!isFirst) this.isSingle = false;
      else if (Array.isArray(cmp.tuples) && cmp.tuples.length === 1 && Array.isArray(cmp.tuples[0]) && cmp.tuples[0][0] === "") {
        this.isSingle = true;
      }
      isFirst = false;
    });
    if (!this.set.length && comparatorErrors.length) {
      if (comparatorErrors.length === 1 && comparatorErrors[0]) {
        throw comparatorErrors[0];
      }
      throw new AggregateError(comparatorErrors);
    }
  }
  #maybeComparator(part, includePrerelease) {
    try {
      return new Comparator(part, includePrerelease);
    } catch (er) {
      return asError(er);
    }
  }
  /**
   * test a {@link Version} against the range
   */
  test(v) {
    return this.set.some((c) => c.test(v));
  }
  /** return the simplified canonical form of this range */
  toString() {
    if (this.#toString) return this.#toString;
    if (this.isSingle) {
      this.#toString = String(this.set[0]);
      return this.#toString;
    }
    this.#toString = this.set.map((c) => String(c)).join(" || ");
    return this.#toString;
  }
};

// ../../src/semver/src/index.ts
var parse = (version) => {
  if (!(typeof version === "string")) return version;
  try {
    return Version.parse(version);
  } catch {
    return void 0;
  }
};
var parseRange = (range, includePrerelease = false) => {
  if (typeof range === "object") {
    if (range.includePrerelease === includePrerelease) return range;
    range = range.raw;
  }
  try {
    return new Range(range, includePrerelease);
  } catch {
    return void 0;
  }
};
var satisfies = (version, range, includePrerelease = false) => {
  if (typeof version === "string") {
    const parsed = parse(version);
    if (!parsed) return false;
    version = parsed;
  }
  if (typeof range === "string") {
    const parsed = parseRange(range, includePrerelease);
    if (!parsed) return false;
    range = parsed;
  }
  return version.satisfies(range);
};
var inc = (version, part, prereleaseIdentifier) => (typeof version === "string" ? Version.parse(version) : version).inc(part, prereleaseIdentifier);
var compare = (versionA, versionB) => {
  const a = parse(versionA);
  if (!a) {
    throw syntaxError("invalid version", { found: versionA });
  }
  const b = parse(versionB);
  if (!b) {
    throw syntaxError("invalid version", { found: versionB });
  }
  return a.compare(b);
};
var gt = (versionA, versionB) => compare(versionA, versionB) > 0;
var gte = (versionA, versionB) => compare(versionA, versionB) >= 0;
var lt = (versionA, versionB) => compare(versionA, versionB) < 0;
var lte = (versionA, versionB) => compare(versionA, versionB) <= 0;
var neq = (versionA, versionB) => compare(versionA, versionB) !== 0;
var eq = (versionA, versionB) => compare(versionA, versionB) === 0;
var major = (version) => parse(version)?.major;
var minor = (version) => parse(version)?.minor;
var patch = (version) => parse(version)?.patch;
var intersects = (r1, r2, includePrerelease) => {
  const range1 = typeof r1 === "string" ? parseRange(r1, includePrerelease) : r1;
  const range2 = typeof r2 === "string" ? parseRange(r2, includePrerelease) : r2;
  if (!range1 || !range2) return false;
  if (range1.isAny || range2.isAny) return true;
  return range1.set.some(
    (set1) => range2.set.some((set2) => intersectComparators(set1, set2))
  );
};
var intersectComparators = (comp1, comp2) => {
  const tuples1 = comp1.tuples.filter(
    (t) => Array.isArray(t)
  );
  const tuples2 = comp2.tuples.filter(
    (t) => Array.isArray(t)
  );
  return satisfiableRange(tuples1.concat(tuples2));
};
var satisfiableRange = (tuples) => {
  let lowerBound = null;
  let lowerInclusive = false;
  let upperBound = null;
  let upperInclusive = false;
  let hasExact = null;
  for (const [op, ver] of tuples) {
    switch (op) {
      case "":
        if (hasExact && !eq(hasExact, ver)) return false;
        hasExact = ver;
        break;
      case ">=":
        if (!lowerBound || gt(ver, lowerBound) || eq(ver, lowerBound) && !lowerInclusive) {
          lowerBound = ver;
          lowerInclusive = true;
        }
        break;
      case ">":
        if (!lowerBound || gt(ver, lowerBound)) {
          lowerBound = ver;
          lowerInclusive = false;
        }
        break;
      case "<=":
        if (!upperBound || lt(ver, upperBound)) {
          upperBound = ver;
          upperInclusive = true;
        }
        break;
      case "<":
        if (!upperBound || lt(ver, upperBound) || eq(ver, upperBound)) {
          upperBound = ver;
          upperInclusive = false;
        }
        break;
    }
  }
  if (hasExact) {
    if (lowerBound) {
      if (lowerInclusive ? lt(hasExact, lowerBound) : lte(hasExact, lowerBound)) {
        return false;
      }
    }
    if (upperBound) {
      if (upperInclusive ? gt(hasExact, upperBound) : gte(hasExact, upperBound)) {
        return false;
      }
    }
    return true;
  }
  if (lowerBound && upperBound) {
    if (gt(lowerBound, upperBound)) return false;
    if (eq(lowerBound, upperBound) && !(lowerInclusive && upperInclusive))
      return false;
  }
  return true;
};

export {
  fastSplit,
  versionIncrements,
  Version,
  isRange,
  Range,
  parse,
  parseRange,
  satisfies,
  inc,
  compare,
  gt,
  gte,
  lt,
  lte,
  neq,
  eq,
  major,
  minor,
  patch,
  intersects,
  isIntegrity,
  asError,
  isError,
  isErrorWithCause,
  isObject,
  isRecordStringString,
  assertRecordStringString,
  assertRecordStringT,
  asManifest,
  normalizeManifest,
  asNormalizedManifest,
  expandNormalizedManifestSymbols,
  asPackument,
  longDependencyTypes,
  shortDependencyTypes,
  dependencyTypes,
  parseScope
};
