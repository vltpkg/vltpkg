var global = globalThis;
import {Buffer} from "node:buffer";
import {setTimeout as _vlt_setTimeout,clearTimeout as _vlt_clearTimeout,setImmediate as _vlt_setImmediate,clearImmediate as _vlt_clearImmediate,setInterval as _vlt_setInterval,clearInterval as _vlt_clearInterval} from "node:timers";
globalThis.setTimeout = _vlt_setTimeout;
globalThis.clearTimeout = _vlt_clearTimeout;
globalThis.setImmediate = _vlt_setImmediate;
globalThis.clearImmediate = _vlt_clearImmediate;
globalThis.setInterval = _vlt_setInterval;
globalThis.clearInterval = _vlt_clearInterval;
import {createRequire as _vlt_createRequire} from "node:module";
var require = _vlt_createRequire(import.meta.filename);

// ../../node_modules/.vlt/~npm~pretty-bytes@7.1.0/node_modules/pretty-bytes/index.js
var BYTE_UNITS = [
  "B",
  "kB",
  "MB",
  "GB",
  "TB",
  "PB",
  "EB",
  "ZB",
  "YB"
];
var BIBYTE_UNITS = [
  "B",
  "KiB",
  "MiB",
  "GiB",
  "TiB",
  "PiB",
  "EiB",
  "ZiB",
  "YiB"
];
var BIT_UNITS = [
  "b",
  "kbit",
  "Mbit",
  "Gbit",
  "Tbit",
  "Pbit",
  "Ebit",
  "Zbit",
  "Ybit"
];
var BIBIT_UNITS = [
  "b",
  "kibit",
  "Mibit",
  "Gibit",
  "Tibit",
  "Pibit",
  "Eibit",
  "Zibit",
  "Yibit"
];
var toLocaleString = (number, locale, options) => {
  let result = number;
  if (typeof locale === "string" || Array.isArray(locale)) {
    result = number.toLocaleString(locale, options);
  } else if (locale === true || options !== void 0) {
    result = number.toLocaleString(void 0, options);
  }
  return result;
};
var log10 = (numberOrBigInt) => {
  if (typeof numberOrBigInt === "number") {
    return Math.log10(numberOrBigInt);
  }
  const string = numberOrBigInt.toString(10);
  return string.length + Math.log10(`0.${string.slice(0, 15)}`);
};
var log = (numberOrBigInt) => {
  if (typeof numberOrBigInt === "number") {
    return Math.log(numberOrBigInt);
  }
  return log10(numberOrBigInt) * Math.log(10);
};
var divide = (numberOrBigInt, divisor) => {
  if (typeof numberOrBigInt === "number") {
    return numberOrBigInt / divisor;
  }
  const integerPart = numberOrBigInt / BigInt(divisor);
  const remainder = numberOrBigInt % BigInt(divisor);
  return Number(integerPart) + Number(remainder) / divisor;
};
var applyFixedWidth = (result, fixedWidth) => {
  if (fixedWidth === void 0) {
    return result;
  }
  if (typeof fixedWidth !== "number" || !Number.isSafeInteger(fixedWidth) || fixedWidth < 0) {
    throw new TypeError(`Expected fixedWidth to be a non-negative integer, got ${typeof fixedWidth}: ${fixedWidth}`);
  }
  if (fixedWidth === 0) {
    return result;
  }
  return result.length < fixedWidth ? result.padStart(fixedWidth, " ") : result;
};
var buildLocaleOptions = (options) => {
  const { minimumFractionDigits, maximumFractionDigits } = options;
  if (minimumFractionDigits === void 0 && maximumFractionDigits === void 0) {
    return void 0;
  }
  return {
    ...minimumFractionDigits !== void 0 && { minimumFractionDigits },
    ...maximumFractionDigits !== void 0 && { maximumFractionDigits },
    roundingMode: "trunc"
  };
};
function prettyBytes(number, options) {
  if (typeof number !== "bigint" && !Number.isFinite(number)) {
    throw new TypeError(`Expected a finite number, got ${typeof number}: ${number}`);
  }
  options = {
    bits: false,
    binary: false,
    space: true,
    nonBreakingSpace: false,
    ...options
  };
  const UNITS = options.bits ? options.binary ? BIBIT_UNITS : BIT_UNITS : options.binary ? BIBYTE_UNITS : BYTE_UNITS;
  const separator = options.space ? options.nonBreakingSpace ? "\xA0" : " " : "";
  const isZero = typeof number === "number" ? number === 0 : number === 0n;
  if (options.signed && isZero) {
    const result2 = ` 0${separator}${UNITS[0]}`;
    return applyFixedWidth(result2, options.fixedWidth);
  }
  const isNegative = number < 0;
  const prefix = isNegative ? "-" : options.signed ? "+" : "";
  if (isNegative) {
    number = -number;
  }
  const localeOptions = buildLocaleOptions(options);
  let result;
  if (number < 1) {
    const numberString = toLocaleString(number, options.locale, localeOptions);
    result = prefix + numberString + separator + UNITS[0];
  } else {
    const exponent = Math.min(Math.floor(options.binary ? log(number) / Math.log(1024) : log10(number) / 3), UNITS.length - 1);
    number = divide(number, (options.binary ? 1024 : 1e3) ** exponent);
    if (!localeOptions) {
      const minPrecision = Math.max(3, Math.floor(number).toString().length);
      number = number.toPrecision(minPrecision);
    }
    const numberString = toLocaleString(Number(number), options.locale, localeOptions);
    const unit = UNITS[exponent];
    result = prefix + numberString + separator + unit;
  }
  return applyFixedWidth(result, options.fixedWidth);
}

export {
  prettyBytes
};
