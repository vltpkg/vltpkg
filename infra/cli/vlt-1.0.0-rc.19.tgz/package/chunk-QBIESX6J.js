var global = globalThis;
import {Buffer} from "node:buffer";
import {setTimeout as _vlt_setTimeout,clearTimeout as _vlt_clearTimeout,setImmediate as _vlt_setImmediate,clearImmediate as _vlt_clearImmediate,setInterval as _vlt_setInterval,clearInterval as _vlt_clearInterval} from "node:timers";
globalThis.setTimeout = _vlt_setTimeout;
globalThis.clearTimeout = _vlt_clearTimeout;
globalThis.setImmediate = _vlt_setImmediate;
globalThis.clearImmediate = _vlt_clearImmediate;
globalThis.setInterval = _vlt_setInterval;
globalThis.clearInterval = _vlt_clearInterval;
import {createRequire as _vlt_createRequire} from "node:module";
var require = _vlt_createRequire(import.meta.filename);
import {
  error
} from "./chunk-WZWDS3W4.js";
import {
  __glob
} from "./chunk-PZLD7RTK.js";

// import("./commands/**/*.ts") in ../../src/cli-sdk/src/load-command.ts
var globImport_commands_ts = __glob({
  "./commands/bugs.ts": () => import("./bugs-XADWDIB4.js"),
  "./commands/build.ts": () => import("./build-KFKAWTV3.js"),
  "./commands/cache.ts": () => import("./cache-X4IE2GOI.js"),
  "./commands/ci.ts": () => import("./ci-INPVNOS3.js"),
  "./commands/config.ts": () => import("./config-CZAEQZF2.js"),
  "./commands/create.ts": () => import("./create-HPSR7KEE.js"),
  "./commands/docs.ts": () => import("./docs-T4AEZ4I3.js"),
  "./commands/exec-cache.ts": () => import("./exec-cache-GJBQVTCE.js"),
  "./commands/exec-local.ts": () => import("./exec-local-25JMNXOQ.js"),
  "./commands/exec.ts": () => import("./exec-N2FZXB5E.js"),
  "./commands/help.ts": () => import("./help-IEKVHTPX.js"),
  "./commands/init.ts": () => import("./init-GX4ESNAM.js"),
  "./commands/install.ts": () => import("./install-GFZAGMN2.js"),
  "./commands/install/reporter.ts": () => import("./reporter-2NY7CSTJ.js"),
  "./commands/list.ts": () => import("./list-AT3YK7GE.js"),
  "./commands/login.ts": () => import("./login-FNTAL7E6.js"),
  "./commands/logout.ts": () => import("./logout-KO75U4BV.js"),
  "./commands/pack.ts": () => import("./pack-KDG3ORDE.js"),
  "./commands/ping.ts": () => import("./ping-7BOCAWDM.js"),
  "./commands/pkg.ts": () => import("./pkg-TAK76PNA.js"),
  "./commands/publish.ts": () => import("./publish-XFU6V7ZF.js"),
  "./commands/query.ts": () => import("./query-T56STK63.js"),
  "./commands/repo.ts": () => import("./repo-OPUAIHDH.js"),
  "./commands/run-exec.ts": () => import("./run-exec-56JYDP36.js"),
  "./commands/run.ts": () => import("./run-LXHP3FK2.js"),
  "./commands/token.ts": () => import("./token-LZ7OZJNT.js"),
  "./commands/uninstall.ts": () => import("./uninstall-ZAHAY334.js"),
  "./commands/update.ts": () => import("./update-WV4WJOZA.js"),
  "./commands/version.ts": () => import("./version-3IXHDYMS.js"),
  "./commands/view.ts": () => import("./view-QV44DEJW.js"),
  "./commands/whoami.ts": () => import("./whoami-XMSMXHK3.js")
});

// ../../src/cli-sdk/src/load-command.ts
var loadCommand = async (command) => {
  try {
    return await globImport_commands_ts(`./commands/${command}.ts`);
  } catch (e) {
    throw error("Could not load command", {
      found: command,
      cause: e
    });
  }
};

export {
  loadCommand
};
