var global = globalThis;
import {Buffer} from "node:buffer";
import {setTimeout as _vlt_setTimeout,clearTimeout as _vlt_clearTimeout,setImmediate as _vlt_setImmediate,clearImmediate as _vlt_clearImmediate,setInterval as _vlt_setInterval,clearInterval as _vlt_clearInterval} from "node:timers";
globalThis.setTimeout = _vlt_setTimeout;
globalThis.clearTimeout = _vlt_clearTimeout;
globalThis.setImmediate = _vlt_setImmediate;
globalThis.clearImmediate = _vlt_clearImmediate;
globalThis.setInterval = _vlt_setInterval;
globalThis.clearInterval = _vlt_clearInterval;
import {createRequire as _vlt_createRequire} from "node:module";
var require = _vlt_createRequire(import.meta.filename);
import {
  error
} from "./chunk-WZWDS3W4.js";

// ../../src/cli-sdk/src/query-diff-files.ts
import { execSync } from "node:child_process";
var VALID_COMMITISH = /^[a-zA-Z0-9_./@^~:#{}-]+$/;
var validateCommitish = (commitish) => {
  if (!commitish) {
    throw error("Missing commitish argument for :diff() selector");
  }
  if (!VALID_COMMITISH.test(commitish)) {
    throw error("Invalid commitish argument for :diff() selector", {
      found: commitish
    });
  }
  return commitish;
};
var createDiffFilesProvider = (projectRoot) => {
  const cache = /* @__PURE__ */ new Map();
  return (commitish) => {
    const cached = cache.get(commitish);
    if (cached) return cached;
    const safeCommitish = validateCommitish(commitish);
    try {
      const stdout = execSync(
        `git diff --name-only ${safeCommitish}`,
        {
          cwd: projectRoot,
          encoding: "utf8",
          stdio: ["pipe", "pipe", "pipe"],
          timeout: 3e4
        }
      );
      const files = /* @__PURE__ */ new Set();
      for (const line of stdout.split("\n")) {
        const trimmed = line.trim();
        if (trimmed) {
          files.add(trimmed);
        }
      }
      cache.set(commitish, files);
      return files;
    } catch (err) {
      throw error(
        `Failed to run git diff for commitish: ${safeCommitish}`,
        { cause: err }
      );
    }
  };
};

export {
  createDiffFilesProvider
};
