var global = globalThis;
import {Buffer} from "node:buffer";
import {setTimeout as _vlt_setTimeout,clearTimeout as _vlt_clearTimeout,setImmediate as _vlt_setImmediate,clearImmediate as _vlt_clearImmediate,setInterval as _vlt_setInterval,clearInterval as _vlt_clearInterval} from "node:timers";
globalThis.setTimeout = _vlt_setTimeout;
globalThis.clearTimeout = _vlt_clearTimeout;
globalThis.setImmediate = _vlt_setImmediate;
globalThis.clearImmediate = _vlt_clearImmediate;
globalThis.setInterval = _vlt_setInterval;
globalThis.clearInterval = _vlt_clearInterval;
import {createRequire as _vlt_createRequire} from "node:module";
var require = _vlt_createRequire(import.meta.filename);

// ../../src/cli-sdk/src/view.ts
var ViewClass = class {
  options;
  config;
  constructor(options, config) {
    this.options = options;
    this.config = config;
  }
  // TODO: maybe have start() return a flag to say "i got this, do not
  // run the command", for example to just open a web browser
  // to the page relevant to a given thing, rather than computing it twice
  start() {
  }
  async done(_result, _opts) {
    return;
  }
  error(_err) {
  }
};
var isViewClass = (view) => typeof view === "function" && "prototype" in view && view.prototype instanceof ViewClass;

export {
  ViewClass,
  isViewClass
};
