var global = globalThis;
import {Buffer} from "node:buffer";
import {setTimeout as _vlt_setTimeout,clearTimeout as _vlt_clearTimeout,setImmediate as _vlt_setImmediate,clearImmediate as _vlt_clearImmediate,setInterval as _vlt_setInterval,clearInterval as _vlt_clearInterval} from "node:timers";
globalThis.setTimeout = _vlt_setTimeout;
globalThis.clearTimeout = _vlt_clearTimeout;
globalThis.setImmediate = _vlt_setImmediate;
globalThis.clearImmediate = _vlt_clearImmediate;
globalThis.setInterval = _vlt_setInterval;
globalThis.clearInterval = _vlt_clearInterval;
import {createRequire as _vlt_createRequire} from "node:module";
var require = _vlt_createRequire(import.meta.filename);
import {
  source_default
} from "./chunk-WGDTG44V.js";
import {
  loadPackageJson
} from "./chunk-E74WGW5C.js";

// ../../src/cli-sdk/src/custom-help.ts
var { version } = loadPackageJson(
  import.meta.filename,
  "cli-package.json"
);
var customYellow = source_default.hex("#FFE15D");
var makeStyler = (colors) => {
  if (!colors) return (_, s) => s;
  return (style, text) => {
    const styles = Array.isArray(style) ? style : [style];
    let styledText = text;
    for (const s of styles) {
      switch (s) {
        case "yellow":
        case "yellowBright":
          styledText = customYellow(styledText);
          break;
        case "bold":
          styledText = source_default.bold(styledText);
          break;
        case "dim":
          styledText = source_default.dim(styledText);
          break;
        case "dark":
          styledText = source_default.gray(styledText);
          break;
        case "cyan":
          styledText = source_default.cyan(styledText);
          break;
        case "green":
          styledText = source_default.green(styledText);
          break;
        default:
          if (s in source_default && typeof source_default[s] === "function") {
            styledText = source_default[s](styledText);
          }
          break;
      }
    }
    return styledText;
  };
};
var allCommands = [
  {
    name: "bugs",
    aliases: [],
    args: "[<spec>]",
    desc: "Open the bug tracker for a package",
    showByDefault: false
  },
  {
    name: "build",
    aliases: ["b"],
    args: "<selector>",
    desc: "Build packages with lifecycle scripts",
    showByDefault: true,
    defaultOrder: 4
  },
  {
    name: "cache",
    aliases: [],
    args: "[add|ls|info|clean|delete|delete-before|delete-all]",
    desc: "Manage the package cache",
    showByDefault: false
  },
  {
    name: "ci",
    aliases: [],
    args: "",
    desc: "Clean install (frozen lockfile)",
    showByDefault: false
  },
  {
    name: "config",
    aliases: [],
    args: "[get|pick|list|set|delete|edit|location]",
    desc: "Get or set configuration",
    showByDefault: false
  },
  {
    name: "create",
    aliases: [],
    args: "<initializer> [args...]",
    desc: "Create a new project from a template",
    showByDefault: false
  },
  {
    name: "docs",
    aliases: [],
    args: "",
    desc: "Open the docs of the current project",
    showByDefault: false
  },
  {
    name: "exec",
    aliases: ["x"],
    args: "<executable>",
    desc: "Execute a package bin",
    showByDefault: true,
    defaultOrder: 6
  },
  {
    name: "exec-cache",
    aliases: ["xc"],
    args: "[ls|delete|info|install]",
    desc: "Manage the exec cache",
    showByDefault: false
  },
  {
    name: "exec-local",
    aliases: ["xl"],
    args: "<command>",
    desc: "Execute a local package bin",
    showByDefault: false
  },
  {
    name: "help",
    aliases: ["h", "?"],
    args: "[<command>]",
    desc: "Show help for a command",
    showByDefault: false
  },
  {
    name: "init",
    aliases: [],
    args: "",
    desc: "Initialize a new project",
    showByDefault: true,
    defaultOrder: 1
  },
  {
    name: "install",
    aliases: ["i", "add"],
    args: "[<package>...]",
    desc: "Install dependencies",
    showByDefault: true,
    defaultOrder: 2
  },
  {
    name: "list",
    aliases: ["ls"],
    args: "",
    desc: "List installed packages",
    showByDefault: false
  },
  {
    name: "login",
    aliases: [],
    args: "",
    desc: "Authenticate with a registry",
    showByDefault: false
  },
  {
    name: "logout",
    aliases: [],
    args: "",
    desc: "Log out from a registry",
    showByDefault: false
  },
  {
    name: "pack",
    aliases: [],
    args: "",
    desc: "Create a tarball from a package",
    showByDefault: false
  },
  {
    name: "ping",
    aliases: [],
    args: "[<registry-alias>]",
    desc: "Ping configured registries",
    showByDefault: false
  },
  {
    name: "pkg",
    aliases: ["p"],
    args: "<command>",
    desc: "Manage package metadata",
    showByDefault: true,
    defaultOrder: 7
  },
  {
    name: "publish",
    aliases: ["pub"],
    args: "",
    desc: "Publish package to registry",
    showByDefault: true,
    defaultOrder: 8
  },
  {
    name: "query",
    aliases: ["q"],
    args: "<selector>",
    desc: "Query for packages in the project",
    showByDefault: true,
    defaultOrder: 3
  },
  {
    name: "repo",
    aliases: [],
    args: "[<spec>]",
    desc: "Open the repository page for a package",
    showByDefault: false
  },
  {
    name: "run",
    aliases: ["r"],
    args: "<script>",
    desc: "Run a script defined in package.json",
    showByDefault: true,
    defaultOrder: 5
  },
  {
    name: "run-exec",
    aliases: ["rx"],
    args: "<script>",
    desc: "Run a script &/or fallback to executing a binary",
    showByDefault: false
  },
  {
    name: "token",
    aliases: [],
    args: "[add|rm]",
    desc: "Manage authentication tokens",
    showByDefault: false
  },
  {
    name: "uninstall",
    aliases: ["rm"],
    args: "[<package>...]",
    desc: "Remove dependencies",
    showByDefault: false
  },
  {
    name: "update",
    aliases: ["u"],
    args: "",
    desc: "Update package versions to latest in-range",
    showByDefault: false
  },
  {
    name: "version",
    aliases: [],
    args: "<increment>",
    desc: "Bump package version",
    showByDefault: false
  },
  {
    name: "whoami",
    aliases: [],
    args: "",
    desc: "Display the current user",
    showByDefault: false
  }
];
var generateDefaultHelp = (colors = false) => {
  const s = makeStyler(colors);
  const defaultCommands = allCommands.filter((cmd) => cmd.showByDefault).sort((a, b) => (a.defaultOrder || 0) - (b.defaultOrder || 0));
  const commandsSection = defaultCommands.map((cmd) => {
    const firstAlias = cmd.aliases.length > 0 ? cmd.aliases[0] : "";
    const aliasColumn = firstAlias ? (firstAlias + ", ").padEnd(5) : "     ";
    const nameColumn = cmd.name.padEnd(10);
    const argsColumn = cmd.args.padEnd(16);
    return `  ${s("dim", aliasColumn)}${s(["yellow", "bold"], nameColumn)}${s("dim", argsColumn)}${cmd.desc}`;
  }).join("\n");
  return `${s(["bold"], "\u26A1\uFE0F vlt")} ${s("dim", "/v\u014Dlt/")} next-gen package management ${s("dim", `v${version}`)}

${s("bold", "USAGE")}

  ${s("bold", "vlt")} ${s("dim", "<command>")}

${s("bold", "COMMON COMMANDS")}

${commandsSection}
 
${s("bold", "COMPANION BINS")}

  ${s("bold", "vlr")}            ${s("dim", "eq. vlt run")}
  ${s("bold", "vlx")}            ${s("dim", "eq. vlt exec")}
  
${s("bold", "COMMON FLAGS")}

  ${s("green", "-v, --version")}                  Log the cli version
  ${s("green", "-a, --all")}                      List all commands, bins & flags

Learn more: https://${s("bold", "vlt.sh")}
Get support: https://${s("bold", "vlt.community")}

${s("dim", `This is not the full usage information, run \`vlt -a\` for more.`)}
`;
};
var generateFullHelp = (colors = false) => {
  const s = makeStyler(colors);
  const commands = [...allCommands].sort(
    (a, b) => a.name.localeCompare(b.name)
  );
  const flags = [
    {
      shorts: ["a"],
      long: "all",
      args: "",
      desc: "Show all commands, bins, and flags"
    },
    {
      shorts: ["c"],
      long: "color",
      args: "",
      desc: "Enable color output"
    },
    {
      shorts: ["h"],
      long: "help",
      args: "",
      desc: "Print helpful information"
    },
    {
      shorts: [],
      long: "no-color",
      args: "",
      desc: "Disable color output"
    },
    {
      shorts: [],
      long: "registry",
      args: "<url>",
      desc: "Override default registry"
    },
    {
      shorts: ["v"],
      long: "version",
      args: "",
      desc: "Print the version"
    },
    {
      shorts: ["y"],
      long: "yes",
      args: "",
      desc: "Automatically accept prompts"
    }
  ];
  let commandsSection = "";
  let lastFirstLetter = "";
  commands.forEach((cmd, index) => {
    const firstLetter = cmd.name[0]?.toLowerCase() || "";
    if (firstLetter !== lastFirstLetter && index > 0) {
      commandsSection += "\n";
    }
    const aliasColumn = cmd.aliases.length > 0 ? (cmd.aliases.join(", ") + ", ").padEnd(9) : "         ";
    const nameColumn = cmd.name.padEnd(12);
    const truncatedArgs = cmd.args.length > 16 ? cmd.args.substring(0, 13) + "..." : cmd.args;
    const argsColumn = truncatedArgs.padEnd(16);
    commandsSection += `${s("dim", aliasColumn)}${s(["yellow", "bold"], nameColumn)}${s("dim", argsColumn)}${cmd.desc}`;
    if (index < commands.length - 1) {
      commandsSection += "\n";
    }
    lastFirstLetter = firstLetter;
  });
  const flagsSection = flags.map((f) => {
    const aliasColumn = f.shorts.length > 0 ? ("-" + f.shorts.join(", -") + ", ").padEnd(7) : "       ";
    const nameColumn = ("--" + f.long).padEnd(12);
    const argsColumn = (f.args || "").padEnd(17);
    return `  ${s("dim", aliasColumn)}${s("green", nameColumn)}${s("dim", argsColumn)}${f.desc}`;
  }).join("\n");
  return `${s(["bold"], "\u26A1\uFE0F vlt")} ${s("dim", "/v\u014Dlt/")} ${s("dim", "- next-gen package management")} ${s("dim", `v${version}`)}

${s("bold", "USAGE")}

  ${s("bold", "vlt")} ${s("dim", "<command>")}

${s("bold", "COMMANDS")}

${commandsSection}

${s("bold", "COMPANION BINS")}

  vlr    ${s("dim", "eq. vlt run")}
  vlx    ${s("dim", "eq. vlt exec")}

${s("bold", "FLAGS")}

${flagsSection}

Learn more: https://${s("bold", "vlt.sh")}
Get support: https://${s("bold", "vlt.community")}

${s("dim", `Run \`vlt help <command>\` for detailed information about a specific command.`)}`;
};

export {
  generateDefaultHelp,
  generateFullHelp
};
