var global = globalThis;
import {Buffer} from "node:buffer";
import {setTimeout as _vlt_setTimeout,clearTimeout as _vlt_clearTimeout,setImmediate as _vlt_setImmediate,clearImmediate as _vlt_clearImmediate,setInterval as _vlt_setInterval,clearInterval as _vlt_clearInterval} from "node:timers";
globalThis.setTimeout = _vlt_setTimeout;
globalThis.clearTimeout = _vlt_clearTimeout;
globalThis.setImmediate = _vlt_setImmediate;
globalThis.clearImmediate = _vlt_clearImmediate;
globalThis.setInterval = _vlt_setInterval;
globalThis.clearInterval = _vlt_clearInterval;
import {createRequire as _vlt_createRequire} from "node:module";
var require = _vlt_createRequire(import.meta.filename);
import {
  error
} from "./chunk-WZWDS3W4.js";

// ../../node_modules/.vlt/~npm~lru-cache@11.2.7/node_modules/lru-cache/dist/esm/index.min.js
var x = typeof performance == "object" && performance && typeof performance.now == "function" ? performance : Date;
var I = /* @__PURE__ */ new Set();
var R = typeof process == "object" && process ? process : {};
var U = (c3, t, e, i2) => {
  typeof R.emitWarning == "function" ? R.emitWarning(c3, t, e, i2) : console.error(`[${e}] ${t}: ${c3}`);
};
var C = globalThis.AbortController;
var D = globalThis.AbortSignal;
if (typeof C > "u") {
  D = class {
    onabort;
    _onabort = [];
    reason;
    aborted = false;
    addEventListener(i2, s) {
      this._onabort.push(s);
    }
  }, C = class {
    constructor() {
      t();
    }
    signal = new D();
    abort(i2) {
      if (!this.signal.aborted) {
        this.signal.reason = i2, this.signal.aborted = true;
        for (let s of this.signal._onabort) s(i2);
        this.signal.onabort?.(i2);
      }
    }
  };
  let c3 = R.env?.LRU_CACHE_IGNORE_AC_WARNING !== "1", t = () => {
    c3 && (c3 = false, U("AbortController is not defined. If using lru-cache in node 14, load an AbortController polyfill from the `node-abort-controller` package. A minimal polyfill is provided for use by LRUCache.fetch(), but it should not be relied upon in other contexts (eg, passing it to other APIs that use AbortController/AbortSignal might have undesirable effects). You may disable this with LRU_CACHE_IGNORE_AC_WARNING=1 in the env.", "NO_ABORT_CONTROLLER", "ENOTSUP", t));
  };
}
var G = (c3) => !I.has(c3);
var y = (c3) => c3 && c3 === Math.floor(c3) && c3 > 0 && isFinite(c3);
var M = (c3) => y(c3) ? c3 <= Math.pow(2, 8) ? Uint8Array : c3 <= Math.pow(2, 16) ? Uint16Array : c3 <= Math.pow(2, 32) ? Uint32Array : c3 <= Number.MAX_SAFE_INTEGER ? z : null : null;
var z = class extends Array {
  constructor(t) {
    super(t), this.fill(0);
  }
};
var W = class c {
  heap;
  length;
  static #o = false;
  static create(t) {
    let e = M(t);
    if (!e) return [];
    c.#o = true;
    let i2 = new c(t, e);
    return c.#o = false, i2;
  }
  constructor(t, e) {
    if (!c.#o) throw new TypeError("instantiate Stack using Stack.create(n)");
    this.heap = new e(t), this.length = 0;
  }
  push(t) {
    this.heap[this.length++] = t;
  }
  pop() {
    return this.heap[--this.length];
  }
};
var L = class c2 {
  #o;
  #c;
  #w;
  #C;
  #S;
  #L;
  #I;
  #m;
  get perf() {
    return this.#m;
  }
  ttl;
  ttlResolution;
  ttlAutopurge;
  updateAgeOnGet;
  updateAgeOnHas;
  allowStale;
  noDisposeOnSet;
  noUpdateTTL;
  maxEntrySize;
  sizeCalculation;
  noDeleteOnFetchRejection;
  noDeleteOnStaleGet;
  allowStaleOnFetchAbort;
  allowStaleOnFetchRejection;
  ignoreFetchAbort;
  #n;
  #_;
  #s;
  #i;
  #t;
  #a;
  #u;
  #l;
  #h;
  #b;
  #r;
  #y;
  #A;
  #d;
  #g;
  #T;
  #v;
  #f;
  #U;
  static unsafeExposeInternals(t) {
    return { starts: t.#A, ttls: t.#d, autopurgeTimers: t.#g, sizes: t.#y, keyMap: t.#s, keyList: t.#i, valList: t.#t, next: t.#a, prev: t.#u, get head() {
      return t.#l;
    }, get tail() {
      return t.#h;
    }, free: t.#b, isBackgroundFetch: (e) => t.#e(e), backgroundFetch: (e, i2, s, n7) => t.#G(e, i2, s, n7), moveToTail: (e) => t.#D(e), indexes: (e) => t.#F(e), rindexes: (e) => t.#O(e), isStale: (e) => t.#p(e) };
  }
  get max() {
    return this.#o;
  }
  get maxSize() {
    return this.#c;
  }
  get calculatedSize() {
    return this.#_;
  }
  get size() {
    return this.#n;
  }
  get fetchMethod() {
    return this.#L;
  }
  get memoMethod() {
    return this.#I;
  }
  get dispose() {
    return this.#w;
  }
  get onInsert() {
    return this.#C;
  }
  get disposeAfter() {
    return this.#S;
  }
  constructor(t) {
    let { max: e = 0, ttl: i2, ttlResolution: s = 1, ttlAutopurge: n7, updateAgeOnGet: o, updateAgeOnHas: h, allowStale: r, dispose: a2, onInsert: w2, disposeAfter: f, noDisposeOnSet: d2, noUpdateTTL: g2, maxSize: A3 = 0, maxEntrySize: p = 0, sizeCalculation: _3, fetchMethod: l, memoMethod: S2, noDeleteOnFetchRejection: b, noDeleteOnStaleGet: m2, allowStaleOnFetchRejection: u2, allowStaleOnFetchAbort: T3, ignoreFetchAbort: F3, perf: v3 } = t;
    if (v3 !== void 0 && typeof v3?.now != "function") throw new TypeError("perf option must have a now() method if specified");
    if (this.#m = v3 ?? x, e !== 0 && !y(e)) throw new TypeError("max option must be a nonnegative integer");
    let O2 = e ? M(e) : Array;
    if (!O2) throw new Error("invalid max value: " + e);
    if (this.#o = e, this.#c = A3, this.maxEntrySize = p || this.#c, this.sizeCalculation = _3, this.sizeCalculation) {
      if (!this.#c && !this.maxEntrySize) throw new TypeError("cannot set sizeCalculation without setting maxSize or maxEntrySize");
      if (typeof this.sizeCalculation != "function") throw new TypeError("sizeCalculation set to non-function");
    }
    if (S2 !== void 0 && typeof S2 != "function") throw new TypeError("memoMethod must be a function if defined");
    if (this.#I = S2, l !== void 0 && typeof l != "function") throw new TypeError("fetchMethod must be a function if specified");
    if (this.#L = l, this.#v = !!l, this.#s = /* @__PURE__ */ new Map(), this.#i = new Array(e).fill(void 0), this.#t = new Array(e).fill(void 0), this.#a = new O2(e), this.#u = new O2(e), this.#l = 0, this.#h = 0, this.#b = W.create(e), this.#n = 0, this.#_ = 0, typeof a2 == "function" && (this.#w = a2), typeof w2 == "function" && (this.#C = w2), typeof f == "function" ? (this.#S = f, this.#r = []) : (this.#S = void 0, this.#r = void 0), this.#T = !!this.#w, this.#U = !!this.#C, this.#f = !!this.#S, this.noDisposeOnSet = !!d2, this.noUpdateTTL = !!g2, this.noDeleteOnFetchRejection = !!b, this.allowStaleOnFetchRejection = !!u2, this.allowStaleOnFetchAbort = !!T3, this.ignoreFetchAbort = !!F3, this.maxEntrySize !== 0) {
      if (this.#c !== 0 && !y(this.#c)) throw new TypeError("maxSize must be a positive integer if specified");
      if (!y(this.maxEntrySize)) throw new TypeError("maxEntrySize must be a positive integer if specified");
      this.#B();
    }
    if (this.allowStale = !!r, this.noDeleteOnStaleGet = !!m2, this.updateAgeOnGet = !!o, this.updateAgeOnHas = !!h, this.ttlResolution = y(s) || s === 0 ? s : 1, this.ttlAutopurge = !!n7, this.ttl = i2 || 0, this.ttl) {
      if (!y(this.ttl)) throw new TypeError("ttl must be a positive integer if specified");
      this.#j();
    }
    if (this.#o === 0 && this.ttl === 0 && this.#c === 0) throw new TypeError("At least one of max, maxSize, or ttl is required");
    if (!this.ttlAutopurge && !this.#o && !this.#c) {
      let E = "LRU_CACHE_UNBOUNDED";
      G(E) && (I.add(E), U("TTL caching without ttlAutopurge, max, or maxSize can result in unbounded memory consumption.", "UnboundedCacheWarning", E, c2));
    }
  }
  getRemainingTTL(t) {
    return this.#s.has(t) ? 1 / 0 : 0;
  }
  #j() {
    let t = new z(this.#o), e = new z(this.#o);
    this.#d = t, this.#A = e;
    let i2 = this.ttlAutopurge ? new Array(this.#o) : void 0;
    this.#g = i2, this.#N = (h, r, a2 = this.#m.now()) => {
      e[h] = r !== 0 ? a2 : 0, t[h] = r, s(h, r);
    }, this.#R = (h) => {
      e[h] = t[h] !== 0 ? this.#m.now() : 0, s(h, t[h]);
    };
    let s = this.ttlAutopurge ? (h, r) => {
      if (i2?.[h] && (clearTimeout(i2[h]), i2[h] = void 0), r && r !== 0 && i2) {
        let a2 = setTimeout(() => {
          this.#p(h) && this.#E(this.#i[h], "expire");
        }, r + 1);
        a2.unref && a2.unref(), i2[h] = a2;
      }
    } : () => {
    };
    this.#z = (h, r) => {
      if (t[r]) {
        let a2 = t[r], w2 = e[r];
        if (!a2 || !w2) return;
        h.ttl = a2, h.start = w2, h.now = n7 || o();
        let f = h.now - w2;
        h.remainingTTL = a2 - f;
      }
    };
    let n7 = 0, o = () => {
      let h = this.#m.now();
      if (this.ttlResolution > 0) {
        n7 = h;
        let r = setTimeout(() => n7 = 0, this.ttlResolution);
        r.unref && r.unref();
      }
      return h;
    };
    this.getRemainingTTL = (h) => {
      let r = this.#s.get(h);
      if (r === void 0) return 0;
      let a2 = t[r], w2 = e[r];
      if (!a2 || !w2) return 1 / 0;
      let f = (n7 || o()) - w2;
      return a2 - f;
    }, this.#p = (h) => {
      let r = e[h], a2 = t[h];
      return !!a2 && !!r && (n7 || o()) - r > a2;
    };
  }
  #R = () => {
  };
  #z = () => {
  };
  #N = () => {
  };
  #p = () => false;
  #B() {
    let t = new z(this.#o);
    this.#_ = 0, this.#y = t, this.#W = (e) => {
      this.#_ -= t[e], t[e] = 0;
    }, this.#P = (e, i2, s, n7) => {
      if (this.#e(i2)) return 0;
      if (!y(s)) if (n7) {
        if (typeof n7 != "function") throw new TypeError("sizeCalculation must be a function");
        if (s = n7(i2, e), !y(s)) throw new TypeError("sizeCalculation return invalid (expect positive integer)");
      } else throw new TypeError("invalid size value (must be positive integer). When maxSize or maxEntrySize is used, sizeCalculation or size must be set.");
      return s;
    }, this.#M = (e, i2, s) => {
      if (t[e] = i2, this.#c) {
        let n7 = this.#c - t[e];
        for (; this.#_ > n7; ) this.#x(true);
      }
      this.#_ += t[e], s && (s.entrySize = i2, s.totalCalculatedSize = this.#_);
    };
  }
  #W = (t) => {
  };
  #M = (t, e, i2) => {
  };
  #P = (t, e, i2, s) => {
    if (i2 || s) throw new TypeError("cannot set size without setting maxSize or maxEntrySize on cache");
    return 0;
  };
  *#F({ allowStale: t = this.allowStale } = {}) {
    if (this.#n) for (let e = this.#h; !(!this.#H(e) || ((t || !this.#p(e)) && (yield e), e === this.#l)); ) e = this.#u[e];
  }
  *#O({ allowStale: t = this.allowStale } = {}) {
    if (this.#n) for (let e = this.#l; !(!this.#H(e) || ((t || !this.#p(e)) && (yield e), e === this.#h)); ) e = this.#a[e];
  }
  #H(t) {
    return t !== void 0 && this.#s.get(this.#i[t]) === t;
  }
  *entries() {
    for (let t of this.#F()) this.#t[t] !== void 0 && this.#i[t] !== void 0 && !this.#e(this.#t[t]) && (yield [this.#i[t], this.#t[t]]);
  }
  *rentries() {
    for (let t of this.#O()) this.#t[t] !== void 0 && this.#i[t] !== void 0 && !this.#e(this.#t[t]) && (yield [this.#i[t], this.#t[t]]);
  }
  *keys() {
    for (let t of this.#F()) {
      let e = this.#i[t];
      e !== void 0 && !this.#e(this.#t[t]) && (yield e);
    }
  }
  *rkeys() {
    for (let t of this.#O()) {
      let e = this.#i[t];
      e !== void 0 && !this.#e(this.#t[t]) && (yield e);
    }
  }
  *values() {
    for (let t of this.#F()) this.#t[t] !== void 0 && !this.#e(this.#t[t]) && (yield this.#t[t]);
  }
  *rvalues() {
    for (let t of this.#O()) this.#t[t] !== void 0 && !this.#e(this.#t[t]) && (yield this.#t[t]);
  }
  [Symbol.iterator]() {
    return this.entries();
  }
  [Symbol.toStringTag] = "LRUCache";
  find(t, e = {}) {
    for (let i2 of this.#F()) {
      let s = this.#t[i2], n7 = this.#e(s) ? s.__staleWhileFetching : s;
      if (n7 !== void 0 && t(n7, this.#i[i2], this)) return this.get(this.#i[i2], e);
    }
  }
  forEach(t, e = this) {
    for (let i2 of this.#F()) {
      let s = this.#t[i2], n7 = this.#e(s) ? s.__staleWhileFetching : s;
      n7 !== void 0 && t.call(e, n7, this.#i[i2], this);
    }
  }
  rforEach(t, e = this) {
    for (let i2 of this.#O()) {
      let s = this.#t[i2], n7 = this.#e(s) ? s.__staleWhileFetching : s;
      n7 !== void 0 && t.call(e, n7, this.#i[i2], this);
    }
  }
  purgeStale() {
    let t = false;
    for (let e of this.#O({ allowStale: true })) this.#p(e) && (this.#E(this.#i[e], "expire"), t = true);
    return t;
  }
  info(t) {
    let e = this.#s.get(t);
    if (e === void 0) return;
    let i2 = this.#t[e], s = this.#e(i2) ? i2.__staleWhileFetching : i2;
    if (s === void 0) return;
    let n7 = { value: s };
    if (this.#d && this.#A) {
      let o = this.#d[e], h = this.#A[e];
      if (o && h) {
        let r = o - (this.#m.now() - h);
        n7.ttl = r, n7.start = Date.now();
      }
    }
    return this.#y && (n7.size = this.#y[e]), n7;
  }
  dump() {
    let t = [];
    for (let e of this.#F({ allowStale: true })) {
      let i2 = this.#i[e], s = this.#t[e], n7 = this.#e(s) ? s.__staleWhileFetching : s;
      if (n7 === void 0 || i2 === void 0) continue;
      let o = { value: n7 };
      if (this.#d && this.#A) {
        o.ttl = this.#d[e];
        let h = this.#m.now() - this.#A[e];
        o.start = Math.floor(Date.now() - h);
      }
      this.#y && (o.size = this.#y[e]), t.unshift([i2, o]);
    }
    return t;
  }
  load(t) {
    this.clear();
    for (let [e, i2] of t) {
      if (i2.start) {
        let s = Date.now() - i2.start;
        i2.start = this.#m.now() - s;
      }
      this.set(e, i2.value, i2);
    }
  }
  set(t, e, i2 = {}) {
    if (e === void 0) return this.delete(t), this;
    let { ttl: s = this.ttl, start: n7, noDisposeOnSet: o = this.noDisposeOnSet, sizeCalculation: h = this.sizeCalculation, status: r } = i2, { noUpdateTTL: a2 = this.noUpdateTTL } = i2, w2 = this.#P(t, e, i2.size || 0, h);
    if (this.maxEntrySize && w2 > this.maxEntrySize) return r && (r.set = "miss", r.maxEntrySizeExceeded = true), this.#E(t, "set"), this;
    let f = this.#n === 0 ? void 0 : this.#s.get(t);
    if (f === void 0) f = this.#n === 0 ? this.#h : this.#b.length !== 0 ? this.#b.pop() : this.#n === this.#o ? this.#x(false) : this.#n, this.#i[f] = t, this.#t[f] = e, this.#s.set(t, f), this.#a[this.#h] = f, this.#u[f] = this.#h, this.#h = f, this.#n++, this.#M(f, w2, r), r && (r.set = "add"), a2 = false, this.#U && this.#C?.(e, t, "add");
    else {
      this.#D(f);
      let d2 = this.#t[f];
      if (e !== d2) {
        if (this.#v && this.#e(d2)) {
          d2.__abortController.abort(new Error("replaced"));
          let { __staleWhileFetching: g2 } = d2;
          g2 !== void 0 && !o && (this.#T && this.#w?.(g2, t, "set"), this.#f && this.#r?.push([g2, t, "set"]));
        } else o || (this.#T && this.#w?.(d2, t, "set"), this.#f && this.#r?.push([d2, t, "set"]));
        if (this.#W(f), this.#M(f, w2, r), this.#t[f] = e, r) {
          r.set = "replace";
          let g2 = d2 && this.#e(d2) ? d2.__staleWhileFetching : d2;
          g2 !== void 0 && (r.oldValue = g2);
        }
      } else r && (r.set = "update");
      this.#U && this.onInsert?.(e, t, e === d2 ? "update" : "replace");
    }
    if (s !== 0 && !this.#d && this.#j(), this.#d && (a2 || this.#N(f, s, n7), r && this.#z(r, f)), !o && this.#f && this.#r) {
      let d2 = this.#r, g2;
      for (; g2 = d2?.shift(); ) this.#S?.(...g2);
    }
    return this;
  }
  pop() {
    try {
      for (; this.#n; ) {
        let t = this.#t[this.#l];
        if (this.#x(true), this.#e(t)) {
          if (t.__staleWhileFetching) return t.__staleWhileFetching;
        } else if (t !== void 0) return t;
      }
    } finally {
      if (this.#f && this.#r) {
        let t = this.#r, e;
        for (; e = t?.shift(); ) this.#S?.(...e);
      }
    }
  }
  #x(t) {
    let e = this.#l, i2 = this.#i[e], s = this.#t[e];
    return this.#v && this.#e(s) ? s.__abortController.abort(new Error("evicted")) : (this.#T || this.#f) && (this.#T && this.#w?.(s, i2, "evict"), this.#f && this.#r?.push([s, i2, "evict"])), this.#W(e), this.#g?.[e] && (clearTimeout(this.#g[e]), this.#g[e] = void 0), t && (this.#i[e] = void 0, this.#t[e] = void 0, this.#b.push(e)), this.#n === 1 ? (this.#l = this.#h = 0, this.#b.length = 0) : this.#l = this.#a[e], this.#s.delete(i2), this.#n--, e;
  }
  has(t, e = {}) {
    let { updateAgeOnHas: i2 = this.updateAgeOnHas, status: s } = e, n7 = this.#s.get(t);
    if (n7 !== void 0) {
      let o = this.#t[n7];
      if (this.#e(o) && o.__staleWhileFetching === void 0) return false;
      if (this.#p(n7)) s && (s.has = "stale", this.#z(s, n7));
      else return i2 && this.#R(n7), s && (s.has = "hit", this.#z(s, n7)), true;
    } else s && (s.has = "miss");
    return false;
  }
  peek(t, e = {}) {
    let { allowStale: i2 = this.allowStale } = e, s = this.#s.get(t);
    if (s === void 0 || !i2 && this.#p(s)) return;
    let n7 = this.#t[s];
    return this.#e(n7) ? n7.__staleWhileFetching : n7;
  }
  #G(t, e, i2, s) {
    let n7 = e === void 0 ? void 0 : this.#t[e];
    if (this.#e(n7)) return n7;
    let o = new C(), { signal: h } = i2;
    h?.addEventListener("abort", () => o.abort(h.reason), { signal: o.signal });
    let r = { signal: o.signal, options: i2, context: s }, a2 = (p, _3 = false) => {
      let { aborted: l } = o.signal, S2 = i2.ignoreFetchAbort && p !== void 0, b = i2.ignoreFetchAbort || !!(i2.allowStaleOnFetchAbort && p !== void 0);
      if (i2.status && (l && !_3 ? (i2.status.fetchAborted = true, i2.status.fetchError = o.signal.reason, S2 && (i2.status.fetchAbortIgnored = true)) : i2.status.fetchResolved = true), l && !S2 && !_3) return f(o.signal.reason, b);
      let m2 = g2, u2 = this.#t[e];
      return (u2 === g2 || S2 && _3 && u2 === void 0) && (p === void 0 ? m2.__staleWhileFetching !== void 0 ? this.#t[e] = m2.__staleWhileFetching : this.#E(t, "fetch") : (i2.status && (i2.status.fetchUpdated = true), this.set(t, p, r.options))), p;
    }, w2 = (p) => (i2.status && (i2.status.fetchRejected = true, i2.status.fetchError = p), f(p, false)), f = (p, _3) => {
      let { aborted: l } = o.signal, S2 = l && i2.allowStaleOnFetchAbort, b = S2 || i2.allowStaleOnFetchRejection, m2 = b || i2.noDeleteOnFetchRejection, u2 = g2;
      if (this.#t[e] === g2 && (!m2 || !_3 && u2.__staleWhileFetching === void 0 ? this.#E(t, "fetch") : S2 || (this.#t[e] = u2.__staleWhileFetching)), b) return i2.status && u2.__staleWhileFetching !== void 0 && (i2.status.returnedStale = true), u2.__staleWhileFetching;
      if (u2.__returned === u2) throw p;
    }, d2 = (p, _3) => {
      let l = this.#L?.(t, n7, r);
      l && l instanceof Promise && l.then((S2) => p(S2 === void 0 ? void 0 : S2), _3), o.signal.addEventListener("abort", () => {
        (!i2.ignoreFetchAbort || i2.allowStaleOnFetchAbort) && (p(void 0), i2.allowStaleOnFetchAbort && (p = (S2) => a2(S2, true)));
      });
    };
    i2.status && (i2.status.fetchDispatched = true);
    let g2 = new Promise(d2).then(a2, w2), A3 = Object.assign(g2, { __abortController: o, __staleWhileFetching: n7, __returned: void 0 });
    return e === void 0 ? (this.set(t, A3, { ...r.options, status: void 0 }), e = this.#s.get(t)) : this.#t[e] = A3, A3;
  }
  #e(t) {
    if (!this.#v) return false;
    let e = t;
    return !!e && e instanceof Promise && e.hasOwnProperty("__staleWhileFetching") && e.__abortController instanceof C;
  }
  async fetch(t, e = {}) {
    let { allowStale: i2 = this.allowStale, updateAgeOnGet: s = this.updateAgeOnGet, noDeleteOnStaleGet: n7 = this.noDeleteOnStaleGet, ttl: o = this.ttl, noDisposeOnSet: h = this.noDisposeOnSet, size: r = 0, sizeCalculation: a2 = this.sizeCalculation, noUpdateTTL: w2 = this.noUpdateTTL, noDeleteOnFetchRejection: f = this.noDeleteOnFetchRejection, allowStaleOnFetchRejection: d2 = this.allowStaleOnFetchRejection, ignoreFetchAbort: g2 = this.ignoreFetchAbort, allowStaleOnFetchAbort: A3 = this.allowStaleOnFetchAbort, context: p, forceRefresh: _3 = false, status: l, signal: S2 } = e;
    if (!this.#v) return l && (l.fetch = "get"), this.get(t, { allowStale: i2, updateAgeOnGet: s, noDeleteOnStaleGet: n7, status: l });
    let b = { allowStale: i2, updateAgeOnGet: s, noDeleteOnStaleGet: n7, ttl: o, noDisposeOnSet: h, size: r, sizeCalculation: a2, noUpdateTTL: w2, noDeleteOnFetchRejection: f, allowStaleOnFetchRejection: d2, allowStaleOnFetchAbort: A3, ignoreFetchAbort: g2, status: l, signal: S2 }, m2 = this.#s.get(t);
    if (m2 === void 0) {
      l && (l.fetch = "miss");
      let u2 = this.#G(t, m2, b, p);
      return u2.__returned = u2;
    } else {
      let u2 = this.#t[m2];
      if (this.#e(u2)) {
        let E = i2 && u2.__staleWhileFetching !== void 0;
        return l && (l.fetch = "inflight", E && (l.returnedStale = true)), E ? u2.__staleWhileFetching : u2.__returned = u2;
      }
      let T3 = this.#p(m2);
      if (!_3 && !T3) return l && (l.fetch = "hit"), this.#D(m2), s && this.#R(m2), l && this.#z(l, m2), u2;
      let F3 = this.#G(t, m2, b, p), O2 = F3.__staleWhileFetching !== void 0 && i2;
      return l && (l.fetch = T3 ? "stale" : "refresh", O2 && T3 && (l.returnedStale = true)), O2 ? F3.__staleWhileFetching : F3.__returned = F3;
    }
  }
  async forceFetch(t, e = {}) {
    let i2 = await this.fetch(t, e);
    if (i2 === void 0) throw new Error("fetch() returned undefined");
    return i2;
  }
  memo(t, e = {}) {
    let i2 = this.#I;
    if (!i2) throw new Error("no memoMethod provided to constructor");
    let { context: s, forceRefresh: n7, ...o } = e, h = this.get(t, o);
    if (!n7 && h !== void 0) return h;
    let r = i2(t, h, { options: o, context: s });
    return this.set(t, r, o), r;
  }
  get(t, e = {}) {
    let { allowStale: i2 = this.allowStale, updateAgeOnGet: s = this.updateAgeOnGet, noDeleteOnStaleGet: n7 = this.noDeleteOnStaleGet, status: o } = e, h = this.#s.get(t);
    if (h !== void 0) {
      let r = this.#t[h], a2 = this.#e(r);
      return o && this.#z(o, h), this.#p(h) ? (o && (o.get = "stale"), a2 ? (o && i2 && r.__staleWhileFetching !== void 0 && (o.returnedStale = true), i2 ? r.__staleWhileFetching : void 0) : (n7 || this.#E(t, "expire"), o && i2 && (o.returnedStale = true), i2 ? r : void 0)) : (o && (o.get = "hit"), a2 ? r.__staleWhileFetching : (this.#D(h), s && this.#R(h), r));
    } else o && (o.get = "miss");
  }
  #k(t, e) {
    this.#u[e] = t, this.#a[t] = e;
  }
  #D(t) {
    t !== this.#h && (t === this.#l ? this.#l = this.#a[t] : this.#k(this.#u[t], this.#a[t]), this.#k(this.#h, t), this.#h = t);
  }
  delete(t) {
    return this.#E(t, "delete");
  }
  #E(t, e) {
    let i2 = false;
    if (this.#n !== 0) {
      let s = this.#s.get(t);
      if (s !== void 0) if (this.#g?.[s] && (clearTimeout(this.#g?.[s]), this.#g[s] = void 0), i2 = true, this.#n === 1) this.#V(e);
      else {
        this.#W(s);
        let n7 = this.#t[s];
        if (this.#e(n7) ? n7.__abortController.abort(new Error("deleted")) : (this.#T || this.#f) && (this.#T && this.#w?.(n7, t, e), this.#f && this.#r?.push([n7, t, e])), this.#s.delete(t), this.#i[s] = void 0, this.#t[s] = void 0, s === this.#h) this.#h = this.#u[s];
        else if (s === this.#l) this.#l = this.#a[s];
        else {
          let o = this.#u[s];
          this.#a[o] = this.#a[s];
          let h = this.#a[s];
          this.#u[h] = this.#u[s];
        }
        this.#n--, this.#b.push(s);
      }
    }
    if (this.#f && this.#r?.length) {
      let s = this.#r, n7;
      for (; n7 = s?.shift(); ) this.#S?.(...n7);
    }
    return i2;
  }
  clear() {
    return this.#V("delete");
  }
  #V(t) {
    for (let e of this.#O({ allowStale: true })) {
      let i2 = this.#t[e];
      if (this.#e(i2)) i2.__abortController.abort(new Error("deleted"));
      else {
        let s = this.#i[e];
        this.#T && this.#w?.(i2, s, t), this.#f && this.#r?.push([i2, s, t]);
      }
    }
    if (this.#s.clear(), this.#t.fill(void 0), this.#i.fill(void 0), this.#d && this.#A) {
      this.#d.fill(0), this.#A.fill(0);
      for (let e of this.#g ?? []) e !== void 0 && clearTimeout(e);
      this.#g?.fill(void 0);
    }
    if (this.#y && this.#y.fill(0), this.#l = 0, this.#h = 0, this.#b.length = 0, this.#_ = 0, this.#n = 0, this.#f && this.#r) {
      let e = this.#r, i2;
      for (; i2 = e?.shift(); ) this.#S?.(...i2);
    }
  }
};

// ../../src/promise-spawn/src/index.ts
import { spawn } from "node:child_process";
var isPipe = (stdio = "pipe", fd) => stdio === "pipe" || stdio === "overlapped" || stdio === null ? true : Array.isArray(stdio) ? isPipe(stdio[fd], fd) : false;
function stdioResult(stdout, stderr, o) {
  return {
    stdout: !isPipe(o.stdio, 1) ? null : o.stdioString !== false ? Buffer.concat(stdout).toString().trim() : Buffer.concat(stdout),
    stderr: !isPipe(o.stdio, 2) ? null : o.stdioString !== false ? Buffer.concat(stderr).toString().trim() : Buffer.concat(stderr)
  };
}
var SpawnPromise = class extends Promise {
  [Symbol.toStringTag] = "SpawnPromise";
  /** The spawned process this promise references */
  process;
  /** Expose the child process stdin, if available */
  stdin;
  /**
   * Set static `Symbol.species` back to the base Promise class so that
   * v8 doesn't get confused by the changed constructor signature.
   */
  static get [Symbol.species]() {
    return Promise;
  }
  constructor(command, args, opts, extra = {}) {
    let proc;
    super((res, rej) => {
      proc = spawn(command, args, opts);
      const stdout = [];
      const stderr = [];
      const reject = (er, status, signal) => {
        const stdio = stdioResult(stdout, stderr, opts);
        const errorResult = {
          command,
          args,
          stdout: stdio.stdout,
          stderr: stdio.stderr,
          cwd: opts.cwd?.toString() ?? process.cwd()
        };
        if (er !== void 0) {
          errorResult.cause = er;
        }
        if (status !== void 0) {
          errorResult.status = status;
        }
        if (signal !== void 0) {
          errorResult.signal = signal;
        }
        Object.assign(errorResult, extra);
        rej(error("command failed", errorResult));
      };
      const resolve = (status, signal) => {
        const stdio = stdioResult(stdout, stderr, opts);
        const successResult = {
          command,
          args,
          status,
          signal,
          stdout: stdio.stdout,
          stderr: stdio.stderr,
          cwd: opts.cwd?.toString() ?? process.cwd()
        };
        Object.assign(successResult, extra);
        res(successResult);
      };
      proc.on("error", reject);
      proc.stdout?.on("data", (c3) => stdout.push(c3)).on("error", reject);
      proc.stderr?.on("data", (c3) => stderr.push(c3)).on("error", reject);
      proc.on("close", (status, signal) => {
        if ((status || signal) && !opts.acceptFail) {
          reject(void 0, status, signal);
        } else {
          resolve(status, signal);
        }
      });
    });
    this.process = proc;
    this.stdin = proc.stdin;
  }
};
function promiseSpawn(command, args, opts = {}, extra = {}) {
  return new SpawnPromise(command, args, opts, extra);
}

// ../../node_modules/.vlt/~npm~isexe@3.1.5/node_modules/isexe/dist/esm/index.min.js
import { statSync as w } from "node:fs";
import { stat as S } from "node:fs/promises";
import { statSync as k } from "node:fs";
import { stat as I2 } from "node:fs/promises";
import { delimiter as _ } from "node:path";
var y2 = Object.defineProperty;
var u = (t, r) => {
  for (var e in r) y2(t, e, { get: r[e], enumerable: true });
};
var i = {};
u(i, { isexe: () => C2, sync: () => A });
var C2 = async (t, r = {}) => {
  let { ignoreErrors: e = false } = r;
  try {
    return d(await S(t), r);
  } catch (s) {
    let o = s;
    if (e || o.code === "EACCES") return false;
    throw o;
  }
};
var A = (t, r = {}) => {
  let { ignoreErrors: e = false } = r;
  try {
    return d(w(t), r);
  } catch (s) {
    let o = s;
    if (e || o.code === "EACCES") return false;
    throw o;
  }
};
var d = (t, r) => t.isFile() && T(t, r);
var T = (t, r) => {
  let e = r.uid ?? process.getuid?.(), s = r.groups ?? process.getgroups?.() ?? [], o = r.gid ?? process.getgid?.() ?? s[0];
  if (e === void 0 || o === void 0) throw new Error("cannot get uid or gid");
  let c3 = /* @__PURE__ */ new Set([o, ...s]), n7 = t.mode, l = t.uid, E = t.gid, f = parseInt("100", 8), p = parseInt("010", 8), x3 = parseInt("001", 8), h = f | p;
  return !!(n7 & x3 || n7 & p && c3.has(E) || n7 & f && l === e || n7 & h && e === 0);
};
var a = {};
u(a, { isexe: () => F, sync: () => L2 });
var F = async (t, r = {}) => {
  let { ignoreErrors: e = false } = r;
  try {
    return m(await I2(t), t, r);
  } catch (s) {
    let o = s;
    if (e || o.code === "EACCES") return false;
    throw o;
  }
};
var L2 = (t, r = {}) => {
  let { ignoreErrors: e = false } = r;
  try {
    return m(k(t), t, r);
  } catch (s) {
    let o = s;
    if (e || o.code === "EACCES") return false;
    throw o;
  }
};
var P = (t, r) => {
  let { pathExt: e = process.env.PATHEXT || "" } = r, s = e.split(_);
  if (s.indexOf("") !== -1) return true;
  for (let o of s) {
    let c3 = o.toLowerCase(), n7 = t.substring(t.length - c3.length).toLowerCase();
    if (c3 && n7 === c3) return true;
  }
  return false;
};
var m = (t, r, e) => t.isFile() && P(r, e);
var v = process.env._ISEXE_TEST_PLATFORM_ || process.platform;
var g = v === "win32" ? a : i;
var R2 = g.isexe;
var U2 = g.sync;

// ../../src/which/src/index.ts
import { delimiter, join, sep } from "node:path";
var isWindows = process.platform === "win32";
var rSlash = sep === "/" ? /\// : /[\\/]/;
var rRel = new RegExp(`^\\.${rSlash.source}`);
var getNotFoundError = (cmd) => Object.assign(new Error(`not found: ${cmd}`), { code: "ENOENT" });
var getPathInfo = (cmd, {
  path: optPath = process.env.PATH,
  pathExt: optPathExt = process.env.PATHEXT,
  delimiter: optDelimiter = delimiter
}) => {
  const pathEnv = cmd.match(rSlash) ? [""] : [
    // windows always checks the cwd first
    /* c8 ignore next - platform-specific */
    ...isWindows ? [process.cwd()] : [],
    ...(optPath ?? /* c8 ignore next - very unusual */
    "").split(
      optDelimiter
    )
  ];
  if (isWindows) {
    const pathExtExe = optPathExt || [".EXE", ".CMD", ".BAT", ".COM"].join(optDelimiter);
    const pathExt = pathExtExe.split(optDelimiter).flatMap((item) => [item, item.toLowerCase()]);
    if (cmd.includes(".") && pathExt[0] !== "") {
      pathExt.unshift("");
    }
    return { pathEnv, pathExt, pathExtExe };
  }
  return { pathEnv, pathExt: [""] };
};
var getPathPart = (raw, cmd) => {
  const pathPart = /^".*"$/.test(raw) ? raw.slice(1, -1) : raw;
  const prefix = !pathPart && rRel.test(cmd) ? cmd.slice(0, 2) : "";
  return prefix + join(pathPart, cmd);
};
async function which(cmd, opt = {}) {
  const { pathEnv, pathExt, pathExtExe } = getPathInfo(cmd, opt);
  const found = [];
  for (const envPart of pathEnv) {
    const p = getPathPart(envPart, cmd);
    for (const ext of pathExt) {
      const withExt = p + ext;
      const is2 = await R2(withExt, {
        pathExt: pathExtExe,
        ignoreErrors: true
      });
      if (is2) {
        if (!opt.all) {
          return withExt;
        }
        found.push(withExt);
      }
    }
  }
  if (opt.all && found.length) {
    return found;
  }
  if (opt.nothrow) {
    return null;
  }
  throw getNotFoundError(cmd);
}
function whichSync(cmd, opt = {}) {
  const { pathEnv, pathExt, pathExtExe } = getPathInfo(cmd, opt);
  const found = [];
  for (const pathEnvPart of pathEnv) {
    const p = getPathPart(pathEnvPart, cmd);
    for (const ext of pathExt) {
      const withExt = p + ext;
      const is2 = U2(withExt, {
        pathExt: pathExtExe,
        ignoreErrors: true
      });
      if (is2) {
        if (!opt.all) {
          return withExt;
        }
        found.push(withExt);
      }
    }
  }
  if (opt.all && found.length) {
    return found;
  }
  if (opt.nothrow) {
    return null;
  }
  throw getNotFoundError(cmd);
}

// ../../node_modules/.vlt/~npm~glob@13.0.6/node_modules/glob/dist/esm/index.min.js
import { fileURLToPath as Wi } from "node:url";
import { posix as mi, win32 as re } from "node:path";
import { fileURLToPath as gi } from "node:url";
import { lstatSync as wi, readdir as yi, readdirSync as bi, readlinkSync as Si, realpathSync as Ei } from "node:fs";
import * as xi from "node:fs";
import { lstat as Ci, readdir as Ti, readlink as Ai, realpath as ki } from "node:fs/promises";
import { EventEmitter as ee } from "node:events";
import Pe from "node:stream";
import { StringDecoder as ni } from "node:string_decoder";
var Gt = (n7, t, e) => {
  let s = n7 instanceof RegExp ? ce(n7, e) : n7, i2 = t instanceof RegExp ? ce(t, e) : t, r = s !== null && i2 != null && ss(s, i2, e);
  return r && { start: r[0], end: r[1], pre: e.slice(0, r[0]), body: e.slice(r[0] + s.length, r[1]), post: e.slice(r[1] + i2.length) };
};
var ce = (n7, t) => {
  let e = t.match(n7);
  return e ? e[0] : null;
};
var ss = (n7, t, e) => {
  let s, i2, r, o, h, a2 = e.indexOf(n7), l = e.indexOf(t, a2 + 1), u2 = a2;
  if (a2 >= 0 && l > 0) {
    if (n7 === t) return [a2, l];
    for (s = [], r = e.length; u2 >= 0 && !h; ) {
      if (u2 === a2) s.push(u2), a2 = e.indexOf(n7, u2 + 1);
      else if (s.length === 1) {
        let c3 = s.pop();
        c3 !== void 0 && (h = [c3, l]);
      } else i2 = s.pop(), i2 !== void 0 && i2 < r && (r = i2, o = l), l = e.indexOf(t, u2 + 1);
      u2 = a2 < l && a2 >= 0 ? a2 : l;
    }
    s.length && o !== void 0 && (h = [r, o]);
  }
  return h;
};
var fe = "\0SLASH" + Math.random() + "\0";
var ue = "\0OPEN" + Math.random() + "\0";
var qt = "\0CLOSE" + Math.random() + "\0";
var de = "\0COMMA" + Math.random() + "\0";
var pe = "\0PERIOD" + Math.random() + "\0";
var is = new RegExp(fe, "g");
var rs = new RegExp(ue, "g");
var ns = new RegExp(qt, "g");
var os = new RegExp(de, "g");
var hs = new RegExp(pe, "g");
var as = /\\\\/g;
var ls = /\\{/g;
var cs = /\\}/g;
var fs = /\\,/g;
var us = /\\./g;
var ds = 1e5;
function Ht(n7) {
  return isNaN(n7) ? n7.charCodeAt(0) : parseInt(n7, 10);
}
function ps(n7) {
  return n7.replace(as, fe).replace(ls, ue).replace(cs, qt).replace(fs, de).replace(us, pe);
}
function ms(n7) {
  return n7.replace(is, "\\").replace(rs, "{").replace(ns, "}").replace(os, ",").replace(hs, ".");
}
function me(n7) {
  if (!n7) return [""];
  let t = [], e = Gt("{", "}", n7);
  if (!e) return n7.split(",");
  let { pre: s, body: i2, post: r } = e, o = s.split(",");
  o[o.length - 1] += "{" + i2 + "}";
  let h = me(r);
  return r.length && (o[o.length - 1] += h.shift(), o.push.apply(o, h)), t.push.apply(t, o), t;
}
function ge(n7, t = {}) {
  if (!n7) return [];
  let { max: e = ds } = t;
  return n7.slice(0, 2) === "{}" && (n7 = "\\{\\}" + n7.slice(2)), ht(ps(n7), e, true).map(ms);
}
function gs(n7) {
  return "{" + n7 + "}";
}
function ws(n7) {
  return /^-?0\d/.test(n7);
}
function ys(n7, t) {
  return n7 <= t;
}
function bs(n7, t) {
  return n7 >= t;
}
function ht(n7, t, e) {
  let s = [], i2 = Gt("{", "}", n7);
  if (!i2) return [n7];
  let r = i2.pre, o = i2.post.length ? ht(i2.post, t, false) : [""];
  if (/\$$/.test(i2.pre)) for (let h = 0; h < o.length && h < t; h++) {
    let a2 = r + "{" + i2.body + "}" + o[h];
    s.push(a2);
  }
  else {
    let h = /^-?\d+\.\.-?\d+(?:\.\.-?\d+)?$/.test(i2.body), a2 = /^[a-zA-Z]\.\.[a-zA-Z](?:\.\.-?\d+)?$/.test(i2.body), l = h || a2, u2 = i2.body.indexOf(",") >= 0;
    if (!l && !u2) return i2.post.match(/,(?!,).*\}/) ? (n7 = i2.pre + "{" + i2.body + qt + i2.post, ht(n7, t, true)) : [n7];
    let c3;
    if (l) c3 = i2.body.split(/\.\./);
    else if (c3 = me(i2.body), c3.length === 1 && c3[0] !== void 0 && (c3 = ht(c3[0], t, false).map(gs), c3.length === 1)) return o.map((f) => i2.pre + c3[0] + f);
    let d2;
    if (l && c3[0] !== void 0 && c3[1] !== void 0) {
      let f = Ht(c3[0]), m2 = Ht(c3[1]), p = Math.max(c3[0].length, c3[1].length), w2 = c3.length === 3 && c3[2] !== void 0 ? Math.abs(Ht(c3[2])) : 1, g2 = ys;
      m2 < f && (w2 *= -1, g2 = bs);
      let E = c3.some(ws);
      d2 = [];
      for (let y3 = f; g2(y3, m2); y3 += w2) {
        let b;
        if (a2) b = String.fromCharCode(y3), b === "\\" && (b = "");
        else if (b = String(y3), E) {
          let z2 = p - b.length;
          if (z2 > 0) {
            let $ = new Array(z2 + 1).join("0");
            y3 < 0 ? b = "-" + $ + b.slice(1) : b = $ + b;
          }
        }
        d2.push(b);
      }
    } else {
      d2 = [];
      for (let f = 0; f < c3.length; f++) d2.push.apply(d2, ht(c3[f], t, false));
    }
    for (let f = 0; f < d2.length; f++) for (let m2 = 0; m2 < o.length && s.length < t; m2++) {
      let p = r + d2[f] + o[m2];
      (!e || l || p) && s.push(p);
    }
  }
  return s;
}
var at = (n7) => {
  if (typeof n7 != "string") throw new TypeError("invalid pattern");
  if (n7.length > 65536) throw new TypeError("pattern is too long");
};
var Ss = { "[:alnum:]": ["\\p{L}\\p{Nl}\\p{Nd}", true], "[:alpha:]": ["\\p{L}\\p{Nl}", true], "[:ascii:]": ["\\x00-\\x7f", false], "[:blank:]": ["\\p{Zs}\\t", true], "[:cntrl:]": ["\\p{Cc}", true], "[:digit:]": ["\\p{Nd}", true], "[:graph:]": ["\\p{Z}\\p{C}", true, true], "[:lower:]": ["\\p{Ll}", true], "[:print:]": ["\\p{C}", true], "[:punct:]": ["\\p{P}", true], "[:space:]": ["\\p{Z}\\t\\r\\n\\v\\f", true], "[:upper:]": ["\\p{Lu}", true], "[:word:]": ["\\p{L}\\p{Nl}\\p{Nd}\\p{Pc}", true], "[:xdigit:]": ["A-Fa-f0-9", false] };
var lt = (n7) => n7.replace(/[[\]\\-]/g, "\\$&");
var Es = (n7) => n7.replace(/[-[\]{}()*+?.,\\^$|#\s]/g, "\\$&");
var we = (n7) => n7.join("");
var ye = (n7, t) => {
  let e = t;
  if (n7.charAt(e) !== "[") throw new Error("not in a brace expression");
  let s = [], i2 = [], r = e + 1, o = false, h = false, a2 = false, l = false, u2 = e, c3 = "";
  t: for (; r < n7.length; ) {
    let p = n7.charAt(r);
    if ((p === "!" || p === "^") && r === e + 1) {
      l = true, r++;
      continue;
    }
    if (p === "]" && o && !a2) {
      u2 = r + 1;
      break;
    }
    if (o = true, p === "\\" && !a2) {
      a2 = true, r++;
      continue;
    }
    if (p === "[" && !a2) {
      for (let [w2, [g2, S2, E]] of Object.entries(Ss)) if (n7.startsWith(w2, r)) {
        if (c3) return ["$.", false, n7.length - e, true];
        r += w2.length, E ? i2.push(g2) : s.push(g2), h = h || S2;
        continue t;
      }
    }
    if (a2 = false, c3) {
      p > c3 ? s.push(lt(c3) + "-" + lt(p)) : p === c3 && s.push(lt(p)), c3 = "", r++;
      continue;
    }
    if (n7.startsWith("-]", r + 1)) {
      s.push(lt(p + "-")), r += 2;
      continue;
    }
    if (n7.startsWith("-", r + 1)) {
      c3 = p, r += 2;
      continue;
    }
    s.push(lt(p)), r++;
  }
  if (u2 < r) return ["", false, 0, false];
  if (!s.length && !i2.length) return ["$.", false, n7.length - e, true];
  if (i2.length === 0 && s.length === 1 && /^\\?.$/.test(s[0]) && !l) {
    let p = s[0].length === 2 ? s[0].slice(-1) : s[0];
    return [Es(p), false, u2 - e, false];
  }
  let d2 = "[" + (l ? "^" : "") + we(s) + "]", f = "[" + (l ? "" : "^") + we(i2) + "]";
  return [s.length && i2.length ? "(" + d2 + "|" + f + ")" : s.length ? d2 : f, h, u2 - e, true];
};
var W2 = (n7, { windowsPathsNoEscape: t = false, magicalBraces: e = true } = {}) => e ? t ? n7.replace(/\[([^\/\\])\]/g, "$1") : n7.replace(/((?!\\).|^)\[([^\/\\])\]/g, "$1$2").replace(/\\([^\/])/g, "$1") : t ? n7.replace(/\[([^\/\\{}])\]/g, "$1") : n7.replace(/((?!\\).|^)\[([^\/\\{}])\]/g, "$1$2").replace(/\\([^\/{}])/g, "$1");
var xs = /* @__PURE__ */ new Set(["!", "?", "+", "*", "@"]);
var be = (n7) => xs.has(n7);
var vs = "(?!(?:^|/)\\.\\.?(?:$|/))";
var Ct = "(?!\\.)";
var Cs = /* @__PURE__ */ new Set(["[", "."]);
var Ts = /* @__PURE__ */ new Set(["..", "."]);
var As = new Set("().*{}+?[]^$\\!");
var ks = (n7) => n7.replace(/[-[\]{}()*+?.,\\^$|#\s]/g, "\\$&");
var Kt = "[^/]";
var Se = Kt + "*?";
var Ee = Kt + "+?";
var Q = class n {
  type;
  #t;
  #s;
  #n = false;
  #r = [];
  #o;
  #S;
  #w;
  #c = false;
  #h;
  #u;
  #f = false;
  constructor(t, e, s = {}) {
    this.type = t, t && (this.#s = true), this.#o = e, this.#t = this.#o ? this.#o.#t : this, this.#h = this.#t === this ? s : this.#t.#h, this.#w = this.#t === this ? [] : this.#t.#w, t === "!" && !this.#t.#c && this.#w.push(this), this.#S = this.#o ? this.#o.#r.length : 0;
  }
  get hasMagic() {
    if (this.#s !== void 0) return this.#s;
    for (let t of this.#r) if (typeof t != "string" && (t.type || t.hasMagic)) return this.#s = true;
    return this.#s;
  }
  toString() {
    return this.#u !== void 0 ? this.#u : this.type ? this.#u = this.type + "(" + this.#r.map((t) => String(t)).join("|") + ")" : this.#u = this.#r.map((t) => String(t)).join("");
  }
  #a() {
    if (this !== this.#t) throw new Error("should only call on root");
    if (this.#c) return this;
    this.toString(), this.#c = true;
    let t;
    for (; t = this.#w.pop(); ) {
      if (t.type !== "!") continue;
      let e = t, s = e.#o;
      for (; s; ) {
        for (let i2 = e.#S + 1; !s.type && i2 < s.#r.length; i2++) for (let r of t.#r) {
          if (typeof r == "string") throw new Error("string part in extglob AST??");
          r.copyIn(s.#r[i2]);
        }
        e = s, s = e.#o;
      }
    }
    return this;
  }
  push(...t) {
    for (let e of t) if (e !== "") {
      if (typeof e != "string" && !(e instanceof n && e.#o === this)) throw new Error("invalid part: " + e);
      this.#r.push(e);
    }
  }
  toJSON() {
    let t = this.type === null ? this.#r.slice().map((e) => typeof e == "string" ? e : e.toJSON()) : [this.type, ...this.#r.map((e) => e.toJSON())];
    return this.isStart() && !this.type && t.unshift([]), this.isEnd() && (this === this.#t || this.#t.#c && this.#o?.type === "!") && t.push({}), t;
  }
  isStart() {
    if (this.#t === this) return true;
    if (!this.#o?.isStart()) return false;
    if (this.#S === 0) return true;
    let t = this.#o;
    for (let e = 0; e < this.#S; e++) {
      let s = t.#r[e];
      if (!(s instanceof n && s.type === "!")) return false;
    }
    return true;
  }
  isEnd() {
    if (this.#t === this || this.#o?.type === "!") return true;
    if (!this.#o?.isEnd()) return false;
    if (!this.type) return this.#o?.isEnd();
    let t = this.#o ? this.#o.#r.length : 0;
    return this.#S === t - 1;
  }
  copyIn(t) {
    typeof t == "string" ? this.push(t) : this.push(t.clone(this));
  }
  clone(t) {
    let e = new n(this.type, t);
    for (let s of this.#r) e.copyIn(s);
    return e;
  }
  static #i(t, e, s, i2) {
    let r = false, o = false, h = -1, a2 = false;
    if (e.type === null) {
      let f = s, m2 = "";
      for (; f < t.length; ) {
        let p = t.charAt(f++);
        if (r || p === "\\") {
          r = !r, m2 += p;
          continue;
        }
        if (o) {
          f === h + 1 ? (p === "^" || p === "!") && (a2 = true) : p === "]" && !(f === h + 2 && a2) && (o = false), m2 += p;
          continue;
        } else if (p === "[") {
          o = true, h = f, a2 = false, m2 += p;
          continue;
        }
        if (!i2.noext && be(p) && t.charAt(f) === "(") {
          e.push(m2), m2 = "";
          let w2 = new n(p, e);
          f = n.#i(t, w2, f, i2), e.push(w2);
          continue;
        }
        m2 += p;
      }
      return e.push(m2), f;
    }
    let l = s + 1, u2 = new n(null, e), c3 = [], d2 = "";
    for (; l < t.length; ) {
      let f = t.charAt(l++);
      if (r || f === "\\") {
        r = !r, d2 += f;
        continue;
      }
      if (o) {
        l === h + 1 ? (f === "^" || f === "!") && (a2 = true) : f === "]" && !(l === h + 2 && a2) && (o = false), d2 += f;
        continue;
      } else if (f === "[") {
        o = true, h = l, a2 = false, d2 += f;
        continue;
      }
      if (be(f) && t.charAt(l) === "(") {
        u2.push(d2), d2 = "";
        let m2 = new n(f, u2);
        u2.push(m2), l = n.#i(t, m2, l, i2);
        continue;
      }
      if (f === "|") {
        u2.push(d2), d2 = "", c3.push(u2), u2 = new n(null, e);
        continue;
      }
      if (f === ")") return d2 === "" && e.#r.length === 0 && (e.#f = true), u2.push(d2), d2 = "", e.push(...c3, u2), l;
      d2 += f;
    }
    return e.type = null, e.#s = void 0, e.#r = [t.substring(s - 1)], l;
  }
  static fromGlob(t, e = {}) {
    let s = new n(null, void 0, e);
    return n.#i(t, s, 0, e), s;
  }
  toMMPattern() {
    if (this !== this.#t) return this.#t.toMMPattern();
    let t = this.toString(), [e, s, i2, r] = this.toRegExpSource();
    if (!(i2 || this.#s || this.#h.nocase && !this.#h.nocaseMagicOnly && t.toUpperCase() !== t.toLowerCase())) return s;
    let h = (this.#h.nocase ? "i" : "") + (r ? "u" : "");
    return Object.assign(new RegExp(`^${e}$`, h), { _src: e, _glob: t });
  }
  get options() {
    return this.#h;
  }
  toRegExpSource(t) {
    let e = t ?? !!this.#h.dot;
    if (this.#t === this && this.#a(), !this.type) {
      let a2 = this.isStart() && this.isEnd() && !this.#r.some((f) => typeof f != "string"), l = this.#r.map((f) => {
        let [m2, p, w2, g2] = typeof f == "string" ? n.#E(f, this.#s, a2) : f.toRegExpSource(t);
        return this.#s = this.#s || w2, this.#n = this.#n || g2, m2;
      }).join(""), u2 = "";
      if (this.isStart() && typeof this.#r[0] == "string" && !(this.#r.length === 1 && Ts.has(this.#r[0]))) {
        let m2 = Cs, p = e && m2.has(l.charAt(0)) || l.startsWith("\\.") && m2.has(l.charAt(2)) || l.startsWith("\\.\\.") && m2.has(l.charAt(4)), w2 = !e && !t && m2.has(l.charAt(0));
        u2 = p ? vs : w2 ? Ct : "";
      }
      let c3 = "";
      return this.isEnd() && this.#t.#c && this.#o?.type === "!" && (c3 = "(?:$|\\/)"), [u2 + l + c3, W2(l), this.#s = !!this.#s, this.#n];
    }
    let s = this.type === "*" || this.type === "+", i2 = this.type === "!" ? "(?:(?!(?:" : "(?:", r = this.#d(e);
    if (this.isStart() && this.isEnd() && !r && this.type !== "!") {
      let a2 = this.toString();
      return this.#r = [a2], this.type = null, this.#s = void 0, [a2, W2(this.toString()), false, false];
    }
    let o = !s || t || e || !Ct ? "" : this.#d(true);
    o === r && (o = ""), o && (r = `(?:${r})(?:${o})*?`);
    let h = "";
    if (this.type === "!" && this.#f) h = (this.isStart() && !e ? Ct : "") + Ee;
    else {
      let a2 = this.type === "!" ? "))" + (this.isStart() && !e && !t ? Ct : "") + Se + ")" : this.type === "@" ? ")" : this.type === "?" ? ")?" : this.type === "+" && o ? ")" : this.type === "*" && o ? ")?" : `)${this.type}`;
      h = i2 + r + a2;
    }
    return [h, W2(r), this.#s = !!this.#s, this.#n];
  }
  #d(t) {
    return this.#r.map((e) => {
      if (typeof e == "string") throw new Error("string type in extglob ast??");
      let [s, i2, r, o] = e.toRegExpSource(t);
      return this.#n = this.#n || o, s;
    }).filter((e) => !(this.isStart() && this.isEnd()) || !!e).join("|");
  }
  static #E(t, e, s = false) {
    let i2 = false, r = "", o = false, h = false;
    for (let a2 = 0; a2 < t.length; a2++) {
      let l = t.charAt(a2);
      if (i2) {
        i2 = false, r += (As.has(l) ? "\\" : "") + l;
        continue;
      }
      if (l === "*") {
        if (h) continue;
        h = true, r += s && /^[*]+$/.test(t) ? Ee : Se, e = true;
        continue;
      } else h = false;
      if (l === "\\") {
        a2 === t.length - 1 ? r += "\\\\" : i2 = true;
        continue;
      }
      if (l === "[") {
        let [u2, c3, d2, f] = ye(t, a2);
        if (d2) {
          r += u2, o = o || c3, a2 += d2 - 1, e = e || f;
          continue;
        }
      }
      if (l === "?") {
        r += Kt, e = true;
        continue;
      }
      r += ks(l);
    }
    return [r, W2(t), !!e, o];
  }
};
var tt = (n7, { windowsPathsNoEscape: t = false, magicalBraces: e = false } = {}) => e ? t ? n7.replace(/[?*()[\]{}]/g, "[$&]") : n7.replace(/[?*()[\]\\{}]/g, "\\$&") : t ? n7.replace(/[?*()[\]]/g, "[$&]") : n7.replace(/[?*()[\]\\]/g, "\\$&");
var O = (n7, t, e = {}) => (at(t), !e.nocomment && t.charAt(0) === "#" ? false : new D2(t, e).match(n7));
var Rs = /^\*+([^+@!?\*\[\(]*)$/;
var Os = (n7) => (t) => !t.startsWith(".") && t.endsWith(n7);
var Fs = (n7) => (t) => t.endsWith(n7);
var Ds = (n7) => (n7 = n7.toLowerCase(), (t) => !t.startsWith(".") && t.toLowerCase().endsWith(n7));
var Ms = (n7) => (n7 = n7.toLowerCase(), (t) => t.toLowerCase().endsWith(n7));
var Ns = /^\*+\.\*+$/;
var _s = (n7) => !n7.startsWith(".") && n7.includes(".");
var Ls = (n7) => n7 !== "." && n7 !== ".." && n7.includes(".");
var Ws = /^\.\*+$/;
var Ps = (n7) => n7 !== "." && n7 !== ".." && n7.startsWith(".");
var js = /^\*+$/;
var Is = (n7) => n7.length !== 0 && !n7.startsWith(".");
var zs = (n7) => n7.length !== 0 && n7 !== "." && n7 !== "..";
var Bs = /^\?+([^+@!?\*\[\(]*)?$/;
var Us = ([n7, t = ""]) => {
  let e = Ce([n7]);
  return t ? (t = t.toLowerCase(), (s) => e(s) && s.toLowerCase().endsWith(t)) : e;
};
var $s = ([n7, t = ""]) => {
  let e = Te([n7]);
  return t ? (t = t.toLowerCase(), (s) => e(s) && s.toLowerCase().endsWith(t)) : e;
};
var Gs = ([n7, t = ""]) => {
  let e = Te([n7]);
  return t ? (s) => e(s) && s.endsWith(t) : e;
};
var Hs = ([n7, t = ""]) => {
  let e = Ce([n7]);
  return t ? (s) => e(s) && s.endsWith(t) : e;
};
var Ce = ([n7]) => {
  let t = n7.length;
  return (e) => e.length === t && !e.startsWith(".");
};
var Te = ([n7]) => {
  let t = n7.length;
  return (e) => e.length === t && e !== "." && e !== "..";
};
var Ae = typeof process == "object" && process ? typeof process.env == "object" && process.env && process.env.__MINIMATCH_TESTING_PLATFORM__ || process.platform : "posix";
var xe = { win32: { sep: "\\" }, posix: { sep: "/" } };
var qs = Ae === "win32" ? xe.win32.sep : xe.posix.sep;
O.sep = qs;
var A2 = /* @__PURE__ */ Symbol("globstar **");
O.GLOBSTAR = A2;
var Ks = "[^/]";
var Vs = Ks + "*?";
var Ys = "(?:(?!(?:\\/|^)(?:\\.{1,2})($|\\/)).)*?";
var Xs = "(?:(?!(?:\\/|^)\\.).)*?";
var Js = (n7, t = {}) => (e) => O(e, n7, t);
O.filter = Js;
var N = (n7, t = {}) => Object.assign({}, n7, t);
var Zs = (n7) => {
  if (!n7 || typeof n7 != "object" || !Object.keys(n7).length) return O;
  let t = O;
  return Object.assign((s, i2, r = {}) => t(s, i2, N(n7, r)), { Minimatch: class extends t.Minimatch {
    constructor(i2, r = {}) {
      super(i2, N(n7, r));
    }
    static defaults(i2) {
      return t.defaults(N(n7, i2)).Minimatch;
    }
  }, AST: class extends t.AST {
    constructor(i2, r, o = {}) {
      super(i2, r, N(n7, o));
    }
    static fromGlob(i2, r = {}) {
      return t.AST.fromGlob(i2, N(n7, r));
    }
  }, unescape: (s, i2 = {}) => t.unescape(s, N(n7, i2)), escape: (s, i2 = {}) => t.escape(s, N(n7, i2)), filter: (s, i2 = {}) => t.filter(s, N(n7, i2)), defaults: (s) => t.defaults(N(n7, s)), makeRe: (s, i2 = {}) => t.makeRe(s, N(n7, i2)), braceExpand: (s, i2 = {}) => t.braceExpand(s, N(n7, i2)), match: (s, i2, r = {}) => t.match(s, i2, N(n7, r)), sep: t.sep, GLOBSTAR: A2 });
};
O.defaults = Zs;
var ke = (n7, t = {}) => (at(n7), t.nobrace || !/\{(?:(?!\{).)*\}/.test(n7) ? [n7] : ge(n7, { max: t.braceExpandMax }));
O.braceExpand = ke;
var Qs = (n7, t = {}) => new D2(n7, t).makeRe();
O.makeRe = Qs;
var ti = (n7, t, e = {}) => {
  let s = new D2(t, e);
  return n7 = n7.filter((i2) => s.match(i2)), s.options.nonull && !n7.length && n7.push(t), n7;
};
O.match = ti;
var ve = /[?*]|[+@!]\(.*?\)|\[|\]/;
var ei = (n7) => n7.replace(/[-[\]{}()*+?.,\\^$|#\s]/g, "\\$&");
var D2 = class {
  options;
  set;
  pattern;
  windowsPathsNoEscape;
  nonegate;
  negate;
  comment;
  empty;
  preserveMultipleSlashes;
  partial;
  globSet;
  globParts;
  nocase;
  isWindows;
  platform;
  windowsNoMagicRoot;
  regexp;
  constructor(t, e = {}) {
    at(t), e = e || {}, this.options = e, this.pattern = t, this.platform = e.platform || Ae, this.isWindows = this.platform === "win32";
    let s = "allowWindowsEscape";
    this.windowsPathsNoEscape = !!e.windowsPathsNoEscape || e[s] === false, this.windowsPathsNoEscape && (this.pattern = this.pattern.replace(/\\/g, "/")), this.preserveMultipleSlashes = !!e.preserveMultipleSlashes, this.regexp = null, this.negate = false, this.nonegate = !!e.nonegate, this.comment = false, this.empty = false, this.partial = !!e.partial, this.nocase = !!this.options.nocase, this.windowsNoMagicRoot = e.windowsNoMagicRoot !== void 0 ? e.windowsNoMagicRoot : !!(this.isWindows && this.nocase), this.globSet = [], this.globParts = [], this.set = [], this.make();
  }
  hasMagic() {
    if (this.options.magicalBraces && this.set.length > 1) return true;
    for (let t of this.set) for (let e of t) if (typeof e != "string") return true;
    return false;
  }
  debug(...t) {
  }
  make() {
    let t = this.pattern, e = this.options;
    if (!e.nocomment && t.charAt(0) === "#") {
      this.comment = true;
      return;
    }
    if (!t) {
      this.empty = true;
      return;
    }
    this.parseNegate(), this.globSet = [...new Set(this.braceExpand())], e.debug && (this.debug = (...r) => console.error(...r)), this.debug(this.pattern, this.globSet);
    let s = this.globSet.map((r) => this.slashSplit(r));
    this.globParts = this.preprocess(s), this.debug(this.pattern, this.globParts);
    let i2 = this.globParts.map((r, o, h) => {
      if (this.isWindows && this.windowsNoMagicRoot) {
        let a2 = r[0] === "" && r[1] === "" && (r[2] === "?" || !ve.test(r[2])) && !ve.test(r[3]), l = /^[a-z]:/i.test(r[0]);
        if (a2) return [...r.slice(0, 4), ...r.slice(4).map((u2) => this.parse(u2))];
        if (l) return [r[0], ...r.slice(1).map((u2) => this.parse(u2))];
      }
      return r.map((a2) => this.parse(a2));
    });
    if (this.debug(this.pattern, i2), this.set = i2.filter((r) => r.indexOf(false) === -1), this.isWindows) for (let r = 0; r < this.set.length; r++) {
      let o = this.set[r];
      o[0] === "" && o[1] === "" && this.globParts[r][2] === "?" && typeof o[3] == "string" && /^[a-z]:$/i.test(o[3]) && (o[2] = "?");
    }
    this.debug(this.pattern, this.set);
  }
  preprocess(t) {
    if (this.options.noglobstar) for (let s = 0; s < t.length; s++) for (let i2 = 0; i2 < t[s].length; i2++) t[s][i2] === "**" && (t[s][i2] = "*");
    let { optimizationLevel: e = 1 } = this.options;
    return e >= 2 ? (t = this.firstPhasePreProcess(t), t = this.secondPhasePreProcess(t)) : e >= 1 ? t = this.levelOneOptimize(t) : t = this.adjascentGlobstarOptimize(t), t;
  }
  adjascentGlobstarOptimize(t) {
    return t.map((e) => {
      let s = -1;
      for (; (s = e.indexOf("**", s + 1)) !== -1; ) {
        let i2 = s;
        for (; e[i2 + 1] === "**"; ) i2++;
        i2 !== s && e.splice(s, i2 - s);
      }
      return e;
    });
  }
  levelOneOptimize(t) {
    return t.map((e) => (e = e.reduce((s, i2) => {
      let r = s[s.length - 1];
      return i2 === "**" && r === "**" ? s : i2 === ".." && r && r !== ".." && r !== "." && r !== "**" ? (s.pop(), s) : (s.push(i2), s);
    }, []), e.length === 0 ? [""] : e));
  }
  levelTwoFileOptimize(t) {
    Array.isArray(t) || (t = this.slashSplit(t));
    let e = false;
    do {
      if (e = false, !this.preserveMultipleSlashes) {
        for (let i2 = 1; i2 < t.length - 1; i2++) {
          let r = t[i2];
          i2 === 1 && r === "" && t[0] === "" || (r === "." || r === "") && (e = true, t.splice(i2, 1), i2--);
        }
        t[0] === "." && t.length === 2 && (t[1] === "." || t[1] === "") && (e = true, t.pop());
      }
      let s = 0;
      for (; (s = t.indexOf("..", s + 1)) !== -1; ) {
        let i2 = t[s - 1];
        i2 && i2 !== "." && i2 !== ".." && i2 !== "**" && (e = true, t.splice(s - 1, 2), s -= 2);
      }
    } while (e);
    return t.length === 0 ? [""] : t;
  }
  firstPhasePreProcess(t) {
    let e = false;
    do {
      e = false;
      for (let s of t) {
        let i2 = -1;
        for (; (i2 = s.indexOf("**", i2 + 1)) !== -1; ) {
          let o = i2;
          for (; s[o + 1] === "**"; ) o++;
          o > i2 && s.splice(i2 + 1, o - i2);
          let h = s[i2 + 1], a2 = s[i2 + 2], l = s[i2 + 3];
          if (h !== ".." || !a2 || a2 === "." || a2 === ".." || !l || l === "." || l === "..") continue;
          e = true, s.splice(i2, 1);
          let u2 = s.slice(0);
          u2[i2] = "**", t.push(u2), i2--;
        }
        if (!this.preserveMultipleSlashes) {
          for (let o = 1; o < s.length - 1; o++) {
            let h = s[o];
            o === 1 && h === "" && s[0] === "" || (h === "." || h === "") && (e = true, s.splice(o, 1), o--);
          }
          s[0] === "." && s.length === 2 && (s[1] === "." || s[1] === "") && (e = true, s.pop());
        }
        let r = 0;
        for (; (r = s.indexOf("..", r + 1)) !== -1; ) {
          let o = s[r - 1];
          if (o && o !== "." && o !== ".." && o !== "**") {
            e = true;
            let a2 = r === 1 && s[r + 1] === "**" ? ["."] : [];
            s.splice(r - 1, 2, ...a2), s.length === 0 && s.push(""), r -= 2;
          }
        }
      }
    } while (e);
    return t;
  }
  secondPhasePreProcess(t) {
    for (let e = 0; e < t.length - 1; e++) for (let s = e + 1; s < t.length; s++) {
      let i2 = this.partsMatch(t[e], t[s], !this.preserveMultipleSlashes);
      if (i2) {
        t[e] = [], t[s] = i2;
        break;
      }
    }
    return t.filter((e) => e.length);
  }
  partsMatch(t, e, s = false) {
    let i2 = 0, r = 0, o = [], h = "";
    for (; i2 < t.length && r < e.length; ) if (t[i2] === e[r]) o.push(h === "b" ? e[r] : t[i2]), i2++, r++;
    else if (s && t[i2] === "**" && e[r] === t[i2 + 1]) o.push(t[i2]), i2++;
    else if (s && e[r] === "**" && t[i2] === e[r + 1]) o.push(e[r]), r++;
    else if (t[i2] === "*" && e[r] && (this.options.dot || !e[r].startsWith(".")) && e[r] !== "**") {
      if (h === "b") return false;
      h = "a", o.push(t[i2]), i2++, r++;
    } else if (e[r] === "*" && t[i2] && (this.options.dot || !t[i2].startsWith(".")) && t[i2] !== "**") {
      if (h === "a") return false;
      h = "b", o.push(e[r]), i2++, r++;
    } else return false;
    return t.length === e.length && o;
  }
  parseNegate() {
    if (this.nonegate) return;
    let t = this.pattern, e = false, s = 0;
    for (let i2 = 0; i2 < t.length && t.charAt(i2) === "!"; i2++) e = !e, s++;
    s && (this.pattern = t.slice(s)), this.negate = e;
  }
  matchOne(t, e, s = false) {
    let i2 = this.options;
    if (this.isWindows) {
      let p = typeof t[0] == "string" && /^[a-z]:$/i.test(t[0]), w2 = !p && t[0] === "" && t[1] === "" && t[2] === "?" && /^[a-z]:$/i.test(t[3]), g2 = typeof e[0] == "string" && /^[a-z]:$/i.test(e[0]), S2 = !g2 && e[0] === "" && e[1] === "" && e[2] === "?" && typeof e[3] == "string" && /^[a-z]:$/i.test(e[3]), E = w2 ? 3 : p ? 0 : void 0, y3 = S2 ? 3 : g2 ? 0 : void 0;
      if (typeof E == "number" && typeof y3 == "number") {
        let [b, z2] = [t[E], e[y3]];
        b.toLowerCase() === z2.toLowerCase() && (e[y3] = b, y3 > E ? e = e.slice(y3) : E > y3 && (t = t.slice(E)));
      }
    }
    let { optimizationLevel: r = 1 } = this.options;
    r >= 2 && (t = this.levelTwoFileOptimize(t)), this.debug("matchOne", this, { file: t, pattern: e }), this.debug("matchOne", t.length, e.length);
    for (var o = 0, h = 0, a2 = t.length, l = e.length; o < a2 && h < l; o++, h++) {
      this.debug("matchOne loop");
      var u2 = e[h], c3 = t[o];
      if (this.debug(e, u2, c3), u2 === false) return false;
      if (u2 === A2) {
        this.debug("GLOBSTAR", [e, u2, c3]);
        var d2 = o, f = h + 1;
        if (f === l) {
          for (this.debug("** at the end"); o < a2; o++) if (t[o] === "." || t[o] === ".." || !i2.dot && t[o].charAt(0) === ".") return false;
          return true;
        }
        for (; d2 < a2; ) {
          var m2 = t[d2];
          if (this.debug(`
globstar while`, t, d2, e, f, m2), this.matchOne(t.slice(d2), e.slice(f), s)) return this.debug("globstar found match!", d2, a2, m2), true;
          if (m2 === "." || m2 === ".." || !i2.dot && m2.charAt(0) === ".") {
            this.debug("dot detected!", t, d2, e, f);
            break;
          }
          this.debug("globstar swallow a segment, and continue"), d2++;
        }
        return !!(s && (this.debug(`
>>> no match, partial?`, t, d2, e, f), d2 === a2));
      }
      let p;
      if (typeof u2 == "string" ? (p = c3 === u2, this.debug("string match", u2, c3, p)) : (p = u2.test(c3), this.debug("pattern match", u2, c3, p)), !p) return false;
    }
    if (o === a2 && h === l) return true;
    if (o === a2) return s;
    if (h === l) return o === a2 - 1 && t[o] === "";
    throw new Error("wtf?");
  }
  braceExpand() {
    return ke(this.pattern, this.options);
  }
  parse(t) {
    at(t);
    let e = this.options;
    if (t === "**") return A2;
    if (t === "") return "";
    let s, i2 = null;
    (s = t.match(js)) ? i2 = e.dot ? zs : Is : (s = t.match(Rs)) ? i2 = (e.nocase ? e.dot ? Ms : Ds : e.dot ? Fs : Os)(s[1]) : (s = t.match(Bs)) ? i2 = (e.nocase ? e.dot ? $s : Us : e.dot ? Gs : Hs)(s) : (s = t.match(Ns)) ? i2 = e.dot ? Ls : _s : (s = t.match(Ws)) && (i2 = Ps);
    let r = Q.fromGlob(t, this.options).toMMPattern();
    return i2 && typeof r == "object" && Reflect.defineProperty(r, "test", { value: i2 }), r;
  }
  makeRe() {
    if (this.regexp || this.regexp === false) return this.regexp;
    let t = this.set;
    if (!t.length) return this.regexp = false, this.regexp;
    let e = this.options, s = e.noglobstar ? Vs : e.dot ? Ys : Xs, i2 = new Set(e.nocase ? ["i"] : []), r = t.map((a2) => {
      let l = a2.map((c3) => {
        if (c3 instanceof RegExp) for (let d2 of c3.flags.split("")) i2.add(d2);
        return typeof c3 == "string" ? ei(c3) : c3 === A2 ? A2 : c3._src;
      });
      l.forEach((c3, d2) => {
        let f = l[d2 + 1], m2 = l[d2 - 1];
        c3 !== A2 || m2 === A2 || (m2 === void 0 ? f !== void 0 && f !== A2 ? l[d2 + 1] = "(?:\\/|" + s + "\\/)?" + f : l[d2] = s : f === void 0 ? l[d2 - 1] = m2 + "(?:\\/|\\/" + s + ")?" : f !== A2 && (l[d2 - 1] = m2 + "(?:\\/|\\/" + s + "\\/)" + f, l[d2 + 1] = A2));
      });
      let u2 = l.filter((c3) => c3 !== A2);
      if (this.partial && u2.length >= 1) {
        let c3 = [];
        for (let d2 = 1; d2 <= u2.length; d2++) c3.push(u2.slice(0, d2).join("/"));
        return "(?:" + c3.join("|") + ")";
      }
      return u2.join("/");
    }).join("|"), [o, h] = t.length > 1 ? ["(?:", ")"] : ["", ""];
    r = "^" + o + r + h + "$", this.partial && (r = "^(?:\\/|" + o + r.slice(1, -1) + h + ")$"), this.negate && (r = "^(?!" + r + ").+$");
    try {
      this.regexp = new RegExp(r, [...i2].join(""));
    } catch {
      this.regexp = false;
    }
    return this.regexp;
  }
  slashSplit(t) {
    return this.preserveMultipleSlashes ? t.split("/") : this.isWindows && /^\/\/[^\/]+/.test(t) ? ["", ...t.split(/\/+/)] : t.split(/\/+/);
  }
  match(t, e = this.partial) {
    if (this.debug("match", t, this.pattern), this.comment) return false;
    if (this.empty) return t === "";
    if (t === "/" && e) return true;
    let s = this.options;
    this.isWindows && (t = t.split("\\").join("/"));
    let i2 = this.slashSplit(t);
    this.debug(this.pattern, "split", i2);
    let r = this.set;
    this.debug(this.pattern, "set", r);
    let o = i2[i2.length - 1];
    if (!o) for (let h = i2.length - 2; !o && h >= 0; h--) o = i2[h];
    for (let h = 0; h < r.length; h++) {
      let a2 = r[h], l = i2;
      if (s.matchBase && a2.length === 1 && (l = [o]), this.matchOne(l, a2, e)) return s.flipNegate ? true : !this.negate;
    }
    return s.flipNegate ? false : this.negate;
  }
  static defaults(t) {
    return O.defaults(t).Minimatch;
  }
};
O.AST = Q;
O.Minimatch = D2;
O.escape = tt;
O.unescape = W2;
var si = typeof performance == "object" && performance && typeof performance.now == "function" ? performance : Date;
var Oe = /* @__PURE__ */ new Set();
var Vt = typeof process == "object" && process ? process : {};
var Fe = (n7, t, e, s) => {
  typeof Vt.emitWarning == "function" ? Vt.emitWarning(n7, t, e, s) : console.error(`[${e}] ${t}: ${n7}`);
};
var At = globalThis.AbortController;
var Re = globalThis.AbortSignal;
if (typeof At > "u") {
  Re = class {
    onabort;
    _onabort = [];
    reason;
    aborted = false;
    addEventListener(e, s) {
      this._onabort.push(s);
    }
  }, At = class {
    constructor() {
      t();
    }
    signal = new Re();
    abort(e) {
      if (!this.signal.aborted) {
        this.signal.reason = e, this.signal.aborted = true;
        for (let s of this.signal._onabort) s(e);
        this.signal.onabort?.(e);
      }
    }
  };
  let n7 = Vt.env?.LRU_CACHE_IGNORE_AC_WARNING !== "1", t = () => {
    n7 && (n7 = false, Fe("AbortController is not defined. If using lru-cache in node 14, load an AbortController polyfill from the `node-abort-controller` package. A minimal polyfill is provided for use by LRUCache.fetch(), but it should not be relied upon in other contexts (eg, passing it to other APIs that use AbortController/AbortSignal might have undesirable effects). You may disable this with LRU_CACHE_IGNORE_AC_WARNING=1 in the env.", "NO_ABORT_CONTROLLER", "ENOTSUP", t));
  };
}
var ii = (n7) => !Oe.has(n7);
var q = (n7) => n7 && n7 === Math.floor(n7) && n7 > 0 && isFinite(n7);
var De = (n7) => q(n7) ? n7 <= Math.pow(2, 8) ? Uint8Array : n7 <= Math.pow(2, 16) ? Uint16Array : n7 <= Math.pow(2, 32) ? Uint32Array : n7 <= Number.MAX_SAFE_INTEGER ? Tt : null : null;
var Tt = class extends Array {
  constructor(n7) {
    super(n7), this.fill(0);
  }
};
var ri = class ct {
  heap;
  length;
  static #t = false;
  static create(t) {
    let e = De(t);
    if (!e) return [];
    ct.#t = true;
    let s = new ct(t, e);
    return ct.#t = false, s;
  }
  constructor(t, e) {
    if (!ct.#t) throw new TypeError("instantiate Stack using Stack.create(n)");
    this.heap = new e(t), this.length = 0;
  }
  push(t) {
    this.heap[this.length++] = t;
  }
  pop() {
    return this.heap[--this.length];
  }
};
var ft = class Me {
  #t;
  #s;
  #n;
  #r;
  #o;
  #S;
  #w;
  #c;
  get perf() {
    return this.#c;
  }
  ttl;
  ttlResolution;
  ttlAutopurge;
  updateAgeOnGet;
  updateAgeOnHas;
  allowStale;
  noDisposeOnSet;
  noUpdateTTL;
  maxEntrySize;
  sizeCalculation;
  noDeleteOnFetchRejection;
  noDeleteOnStaleGet;
  allowStaleOnFetchAbort;
  allowStaleOnFetchRejection;
  ignoreFetchAbort;
  #h;
  #u;
  #f;
  #a;
  #i;
  #d;
  #E;
  #b;
  #p;
  #R;
  #m;
  #C;
  #T;
  #g;
  #y;
  #x;
  #A;
  #e;
  #_;
  static unsafeExposeInternals(t) {
    return { starts: t.#T, ttls: t.#g, autopurgeTimers: t.#y, sizes: t.#C, keyMap: t.#f, keyList: t.#a, valList: t.#i, next: t.#d, prev: t.#E, get head() {
      return t.#b;
    }, get tail() {
      return t.#p;
    }, free: t.#R, isBackgroundFetch: (e) => t.#l(e), backgroundFetch: (e, s, i2, r) => t.#U(e, s, i2, r), moveToTail: (e) => t.#W(e), indexes: (e) => t.#F(e), rindexes: (e) => t.#D(e), isStale: (e) => t.#v(e) };
  }
  get max() {
    return this.#t;
  }
  get maxSize() {
    return this.#s;
  }
  get calculatedSize() {
    return this.#u;
  }
  get size() {
    return this.#h;
  }
  get fetchMethod() {
    return this.#S;
  }
  get memoMethod() {
    return this.#w;
  }
  get dispose() {
    return this.#n;
  }
  get onInsert() {
    return this.#r;
  }
  get disposeAfter() {
    return this.#o;
  }
  constructor(t) {
    let { max: e = 0, ttl: s, ttlResolution: i2 = 1, ttlAutopurge: r, updateAgeOnGet: o, updateAgeOnHas: h, allowStale: a2, dispose: l, onInsert: u2, disposeAfter: c3, noDisposeOnSet: d2, noUpdateTTL: f, maxSize: m2 = 0, maxEntrySize: p = 0, sizeCalculation: w2, fetchMethod: g2, memoMethod: S2, noDeleteOnFetchRejection: E, noDeleteOnStaleGet: y3, allowStaleOnFetchRejection: b, allowStaleOnFetchAbort: z2, ignoreFetchAbort: $, perf: J } = t;
    if (J !== void 0 && typeof J?.now != "function") throw new TypeError("perf option must have a now() method if specified");
    if (this.#c = J ?? si, e !== 0 && !q(e)) throw new TypeError("max option must be a nonnegative integer");
    let Z = e ? De(e) : Array;
    if (!Z) throw new Error("invalid max value: " + e);
    if (this.#t = e, this.#s = m2, this.maxEntrySize = p || this.#s, this.sizeCalculation = w2, this.sizeCalculation) {
      if (!this.#s && !this.maxEntrySize) throw new TypeError("cannot set sizeCalculation without setting maxSize or maxEntrySize");
      if (typeof this.sizeCalculation != "function") throw new TypeError("sizeCalculation set to non-function");
    }
    if (S2 !== void 0 && typeof S2 != "function") throw new TypeError("memoMethod must be a function if defined");
    if (this.#w = S2, g2 !== void 0 && typeof g2 != "function") throw new TypeError("fetchMethod must be a function if specified");
    if (this.#S = g2, this.#A = !!g2, this.#f = /* @__PURE__ */ new Map(), this.#a = new Array(e).fill(void 0), this.#i = new Array(e).fill(void 0), this.#d = new Z(e), this.#E = new Z(e), this.#b = 0, this.#p = 0, this.#R = ri.create(e), this.#h = 0, this.#u = 0, typeof l == "function" && (this.#n = l), typeof u2 == "function" && (this.#r = u2), typeof c3 == "function" ? (this.#o = c3, this.#m = []) : (this.#o = void 0, this.#m = void 0), this.#x = !!this.#n, this.#_ = !!this.#r, this.#e = !!this.#o, this.noDisposeOnSet = !!d2, this.noUpdateTTL = !!f, this.noDeleteOnFetchRejection = !!E, this.allowStaleOnFetchRejection = !!b, this.allowStaleOnFetchAbort = !!z2, this.ignoreFetchAbort = !!$, this.maxEntrySize !== 0) {
      if (this.#s !== 0 && !q(this.#s)) throw new TypeError("maxSize must be a positive integer if specified");
      if (!q(this.maxEntrySize)) throw new TypeError("maxEntrySize must be a positive integer if specified");
      this.#G();
    }
    if (this.allowStale = !!a2, this.noDeleteOnStaleGet = !!y3, this.updateAgeOnGet = !!o, this.updateAgeOnHas = !!h, this.ttlResolution = q(i2) || i2 === 0 ? i2 : 1, this.ttlAutopurge = !!r, this.ttl = s || 0, this.ttl) {
      if (!q(this.ttl)) throw new TypeError("ttl must be a positive integer if specified");
      this.#M();
    }
    if (this.#t === 0 && this.ttl === 0 && this.#s === 0) throw new TypeError("At least one of max, maxSize, or ttl is required");
    if (!this.ttlAutopurge && !this.#t && !this.#s) {
      let $t = "LRU_CACHE_UNBOUNDED";
      ii($t) && (Oe.add($t), Fe("TTL caching without ttlAutopurge, max, or maxSize can result in unbounded memory consumption.", "UnboundedCacheWarning", $t, Me));
    }
  }
  getRemainingTTL(t) {
    return this.#f.has(t) ? 1 / 0 : 0;
  }
  #M() {
    let t = new Tt(this.#t), e = new Tt(this.#t);
    this.#g = t, this.#T = e;
    let s = this.ttlAutopurge ? new Array(this.#t) : void 0;
    this.#y = s, this.#j = (o, h, a2 = this.#c.now()) => {
      if (e[o] = h !== 0 ? a2 : 0, t[o] = h, s?.[o] && (clearTimeout(s[o]), s[o] = void 0), h !== 0 && s) {
        let l = setTimeout(() => {
          this.#v(o) && this.#O(this.#a[o], "expire");
        }, h + 1);
        l.unref && l.unref(), s[o] = l;
      }
    }, this.#k = (o) => {
      e[o] = t[o] !== 0 ? this.#c.now() : 0;
    }, this.#N = (o, h) => {
      if (t[h]) {
        let a2 = t[h], l = e[h];
        if (!a2 || !l) return;
        o.ttl = a2, o.start = l, o.now = i2 || r();
        let u2 = o.now - l;
        o.remainingTTL = a2 - u2;
      }
    };
    let i2 = 0, r = () => {
      let o = this.#c.now();
      if (this.ttlResolution > 0) {
        i2 = o;
        let h = setTimeout(() => i2 = 0, this.ttlResolution);
        h.unref && h.unref();
      }
      return o;
    };
    this.getRemainingTTL = (o) => {
      let h = this.#f.get(o);
      if (h === void 0) return 0;
      let a2 = t[h], l = e[h];
      if (!a2 || !l) return 1 / 0;
      let u2 = (i2 || r()) - l;
      return a2 - u2;
    }, this.#v = (o) => {
      let h = e[o], a2 = t[o];
      return !!a2 && !!h && (i2 || r()) - h > a2;
    };
  }
  #k = () => {
  };
  #N = () => {
  };
  #j = () => {
  };
  #v = () => false;
  #G() {
    let t = new Tt(this.#t);
    this.#u = 0, this.#C = t, this.#P = (e) => {
      this.#u -= t[e], t[e] = 0;
    }, this.#I = (e, s, i2, r) => {
      if (this.#l(s)) return 0;
      if (!q(i2)) if (r) {
        if (typeof r != "function") throw new TypeError("sizeCalculation must be a function");
        if (i2 = r(s, e), !q(i2)) throw new TypeError("sizeCalculation return invalid (expect positive integer)");
      } else throw new TypeError("invalid size value (must be positive integer). When maxSize or maxEntrySize is used, sizeCalculation or size must be set.");
      return i2;
    }, this.#L = (e, s, i2) => {
      if (t[e] = s, this.#s) {
        let r = this.#s - t[e];
        for (; this.#u > r; ) this.#B(true);
      }
      this.#u += t[e], i2 && (i2.entrySize = s, i2.totalCalculatedSize = this.#u);
    };
  }
  #P = (t) => {
  };
  #L = (t, e, s) => {
  };
  #I = (t, e, s, i2) => {
    if (s || i2) throw new TypeError("cannot set size without setting maxSize or maxEntrySize on cache");
    return 0;
  };
  *#F({ allowStale: t = this.allowStale } = {}) {
    if (this.#h) for (let e = this.#p; !(!this.#z(e) || ((t || !this.#v(e)) && (yield e), e === this.#b)); ) e = this.#E[e];
  }
  *#D({ allowStale: t = this.allowStale } = {}) {
    if (this.#h) for (let e = this.#b; !(!this.#z(e) || ((t || !this.#v(e)) && (yield e), e === this.#p)); ) e = this.#d[e];
  }
  #z(t) {
    return t !== void 0 && this.#f.get(this.#a[t]) === t;
  }
  *entries() {
    for (let t of this.#F()) this.#i[t] !== void 0 && this.#a[t] !== void 0 && !this.#l(this.#i[t]) && (yield [this.#a[t], this.#i[t]]);
  }
  *rentries() {
    for (let t of this.#D()) this.#i[t] !== void 0 && this.#a[t] !== void 0 && !this.#l(this.#i[t]) && (yield [this.#a[t], this.#i[t]]);
  }
  *keys() {
    for (let t of this.#F()) {
      let e = this.#a[t];
      e !== void 0 && !this.#l(this.#i[t]) && (yield e);
    }
  }
  *rkeys() {
    for (let t of this.#D()) {
      let e = this.#a[t];
      e !== void 0 && !this.#l(this.#i[t]) && (yield e);
    }
  }
  *values() {
    for (let t of this.#F()) this.#i[t] !== void 0 && !this.#l(this.#i[t]) && (yield this.#i[t]);
  }
  *rvalues() {
    for (let t of this.#D()) this.#i[t] !== void 0 && !this.#l(this.#i[t]) && (yield this.#i[t]);
  }
  [Symbol.iterator]() {
    return this.entries();
  }
  [Symbol.toStringTag] = "LRUCache";
  find(t, e = {}) {
    for (let s of this.#F()) {
      let i2 = this.#i[s], r = this.#l(i2) ? i2.__staleWhileFetching : i2;
      if (r !== void 0 && t(r, this.#a[s], this)) return this.get(this.#a[s], e);
    }
  }
  forEach(t, e = this) {
    for (let s of this.#F()) {
      let i2 = this.#i[s], r = this.#l(i2) ? i2.__staleWhileFetching : i2;
      r !== void 0 && t.call(e, r, this.#a[s], this);
    }
  }
  rforEach(t, e = this) {
    for (let s of this.#D()) {
      let i2 = this.#i[s], r = this.#l(i2) ? i2.__staleWhileFetching : i2;
      r !== void 0 && t.call(e, r, this.#a[s], this);
    }
  }
  purgeStale() {
    let t = false;
    for (let e of this.#D({ allowStale: true })) this.#v(e) && (this.#O(this.#a[e], "expire"), t = true);
    return t;
  }
  info(t) {
    let e = this.#f.get(t);
    if (e === void 0) return;
    let s = this.#i[e], i2 = this.#l(s) ? s.__staleWhileFetching : s;
    if (i2 === void 0) return;
    let r = { value: i2 };
    if (this.#g && this.#T) {
      let o = this.#g[e], h = this.#T[e];
      if (o && h) {
        let a2 = o - (this.#c.now() - h);
        r.ttl = a2, r.start = Date.now();
      }
    }
    return this.#C && (r.size = this.#C[e]), r;
  }
  dump() {
    let t = [];
    for (let e of this.#F({ allowStale: true })) {
      let s = this.#a[e], i2 = this.#i[e], r = this.#l(i2) ? i2.__staleWhileFetching : i2;
      if (r === void 0 || s === void 0) continue;
      let o = { value: r };
      if (this.#g && this.#T) {
        o.ttl = this.#g[e];
        let h = this.#c.now() - this.#T[e];
        o.start = Math.floor(Date.now() - h);
      }
      this.#C && (o.size = this.#C[e]), t.unshift([s, o]);
    }
    return t;
  }
  load(t) {
    this.clear();
    for (let [e, s] of t) {
      if (s.start) {
        let i2 = Date.now() - s.start;
        s.start = this.#c.now() - i2;
      }
      this.set(e, s.value, s);
    }
  }
  set(t, e, s = {}) {
    if (e === void 0) return this.delete(t), this;
    let { ttl: i2 = this.ttl, start: r, noDisposeOnSet: o = this.noDisposeOnSet, sizeCalculation: h = this.sizeCalculation, status: a2 } = s, { noUpdateTTL: l = this.noUpdateTTL } = s, u2 = this.#I(t, e, s.size || 0, h);
    if (this.maxEntrySize && u2 > this.maxEntrySize) return a2 && (a2.set = "miss", a2.maxEntrySizeExceeded = true), this.#O(t, "set"), this;
    let c3 = this.#h === 0 ? void 0 : this.#f.get(t);
    if (c3 === void 0) c3 = this.#h === 0 ? this.#p : this.#R.length !== 0 ? this.#R.pop() : this.#h === this.#t ? this.#B(false) : this.#h, this.#a[c3] = t, this.#i[c3] = e, this.#f.set(t, c3), this.#d[this.#p] = c3, this.#E[c3] = this.#p, this.#p = c3, this.#h++, this.#L(c3, u2, a2), a2 && (a2.set = "add"), l = false, this.#_ && this.#r?.(e, t, "add");
    else {
      this.#W(c3);
      let d2 = this.#i[c3];
      if (e !== d2) {
        if (this.#A && this.#l(d2)) {
          d2.__abortController.abort(new Error("replaced"));
          let { __staleWhileFetching: f } = d2;
          f !== void 0 && !o && (this.#x && this.#n?.(f, t, "set"), this.#e && this.#m?.push([f, t, "set"]));
        } else o || (this.#x && this.#n?.(d2, t, "set"), this.#e && this.#m?.push([d2, t, "set"]));
        if (this.#P(c3), this.#L(c3, u2, a2), this.#i[c3] = e, a2) {
          a2.set = "replace";
          let f = d2 && this.#l(d2) ? d2.__staleWhileFetching : d2;
          f !== void 0 && (a2.oldValue = f);
        }
      } else a2 && (a2.set = "update");
      this.#_ && this.onInsert?.(e, t, e === d2 ? "update" : "replace");
    }
    if (i2 !== 0 && !this.#g && this.#M(), this.#g && (l || this.#j(c3, i2, r), a2 && this.#N(a2, c3)), !o && this.#e && this.#m) {
      let d2 = this.#m, f;
      for (; f = d2?.shift(); ) this.#o?.(...f);
    }
    return this;
  }
  pop() {
    try {
      for (; this.#h; ) {
        let t = this.#i[this.#b];
        if (this.#B(true), this.#l(t)) {
          if (t.__staleWhileFetching) return t.__staleWhileFetching;
        } else if (t !== void 0) return t;
      }
    } finally {
      if (this.#e && this.#m) {
        let t = this.#m, e;
        for (; e = t?.shift(); ) this.#o?.(...e);
      }
    }
  }
  #B(t) {
    let e = this.#b, s = this.#a[e], i2 = this.#i[e];
    return this.#A && this.#l(i2) ? i2.__abortController.abort(new Error("evicted")) : (this.#x || this.#e) && (this.#x && this.#n?.(i2, s, "evict"), this.#e && this.#m?.push([i2, s, "evict"])), this.#P(e), this.#y?.[e] && (clearTimeout(this.#y[e]), this.#y[e] = void 0), t && (this.#a[e] = void 0, this.#i[e] = void 0, this.#R.push(e)), this.#h === 1 ? (this.#b = this.#p = 0, this.#R.length = 0) : this.#b = this.#d[e], this.#f.delete(s), this.#h--, e;
  }
  has(t, e = {}) {
    let { updateAgeOnHas: s = this.updateAgeOnHas, status: i2 } = e, r = this.#f.get(t);
    if (r !== void 0) {
      let o = this.#i[r];
      if (this.#l(o) && o.__staleWhileFetching === void 0) return false;
      if (this.#v(r)) i2 && (i2.has = "stale", this.#N(i2, r));
      else return s && this.#k(r), i2 && (i2.has = "hit", this.#N(i2, r)), true;
    } else i2 && (i2.has = "miss");
    return false;
  }
  peek(t, e = {}) {
    let { allowStale: s = this.allowStale } = e, i2 = this.#f.get(t);
    if (i2 === void 0 || !s && this.#v(i2)) return;
    let r = this.#i[i2];
    return this.#l(r) ? r.__staleWhileFetching : r;
  }
  #U(t, e, s, i2) {
    let r = e === void 0 ? void 0 : this.#i[e];
    if (this.#l(r)) return r;
    let o = new At(), { signal: h } = s;
    h?.addEventListener("abort", () => o.abort(h.reason), { signal: o.signal });
    let a2 = { signal: o.signal, options: s, context: i2 }, l = (p, w2 = false) => {
      let { aborted: g2 } = o.signal, S2 = s.ignoreFetchAbort && p !== void 0, E = s.ignoreFetchAbort || !!(s.allowStaleOnFetchAbort && p !== void 0);
      if (s.status && (g2 && !w2 ? (s.status.fetchAborted = true, s.status.fetchError = o.signal.reason, S2 && (s.status.fetchAbortIgnored = true)) : s.status.fetchResolved = true), g2 && !S2 && !w2) return c3(o.signal.reason, E);
      let y3 = f, b = this.#i[e];
      return (b === f || S2 && w2 && b === void 0) && (p === void 0 ? y3.__staleWhileFetching !== void 0 ? this.#i[e] = y3.__staleWhileFetching : this.#O(t, "fetch") : (s.status && (s.status.fetchUpdated = true), this.set(t, p, a2.options))), p;
    }, u2 = (p) => (s.status && (s.status.fetchRejected = true, s.status.fetchError = p), c3(p, false)), c3 = (p, w2) => {
      let { aborted: g2 } = o.signal, S2 = g2 && s.allowStaleOnFetchAbort, E = S2 || s.allowStaleOnFetchRejection, y3 = E || s.noDeleteOnFetchRejection, b = f;
      if (this.#i[e] === f && (!y3 || !w2 && b.__staleWhileFetching === void 0 ? this.#O(t, "fetch") : S2 || (this.#i[e] = b.__staleWhileFetching)), E) return s.status && b.__staleWhileFetching !== void 0 && (s.status.returnedStale = true), b.__staleWhileFetching;
      if (b.__returned === b) throw p;
    }, d2 = (p, w2) => {
      let g2 = this.#S?.(t, r, a2);
      g2 && g2 instanceof Promise && g2.then((S2) => p(S2 === void 0 ? void 0 : S2), w2), o.signal.addEventListener("abort", () => {
        (!s.ignoreFetchAbort || s.allowStaleOnFetchAbort) && (p(void 0), s.allowStaleOnFetchAbort && (p = (S2) => l(S2, true)));
      });
    };
    s.status && (s.status.fetchDispatched = true);
    let f = new Promise(d2).then(l, u2), m2 = Object.assign(f, { __abortController: o, __staleWhileFetching: r, __returned: void 0 });
    return e === void 0 ? (this.set(t, m2, { ...a2.options, status: void 0 }), e = this.#f.get(t)) : this.#i[e] = m2, m2;
  }
  #l(t) {
    if (!this.#A) return false;
    let e = t;
    return !!e && e instanceof Promise && e.hasOwnProperty("__staleWhileFetching") && e.__abortController instanceof At;
  }
  async fetch(t, e = {}) {
    let { allowStale: s = this.allowStale, updateAgeOnGet: i2 = this.updateAgeOnGet, noDeleteOnStaleGet: r = this.noDeleteOnStaleGet, ttl: o = this.ttl, noDisposeOnSet: h = this.noDisposeOnSet, size: a2 = 0, sizeCalculation: l = this.sizeCalculation, noUpdateTTL: u2 = this.noUpdateTTL, noDeleteOnFetchRejection: c3 = this.noDeleteOnFetchRejection, allowStaleOnFetchRejection: d2 = this.allowStaleOnFetchRejection, ignoreFetchAbort: f = this.ignoreFetchAbort, allowStaleOnFetchAbort: m2 = this.allowStaleOnFetchAbort, context: p, forceRefresh: w2 = false, status: g2, signal: S2 } = e;
    if (!this.#A) return g2 && (g2.fetch = "get"), this.get(t, { allowStale: s, updateAgeOnGet: i2, noDeleteOnStaleGet: r, status: g2 });
    let E = { allowStale: s, updateAgeOnGet: i2, noDeleteOnStaleGet: r, ttl: o, noDisposeOnSet: h, size: a2, sizeCalculation: l, noUpdateTTL: u2, noDeleteOnFetchRejection: c3, allowStaleOnFetchRejection: d2, allowStaleOnFetchAbort: m2, ignoreFetchAbort: f, status: g2, signal: S2 }, y3 = this.#f.get(t);
    if (y3 === void 0) {
      g2 && (g2.fetch = "miss");
      let b = this.#U(t, y3, E, p);
      return b.__returned = b;
    } else {
      let b = this.#i[y3];
      if (this.#l(b)) {
        let Z = s && b.__staleWhileFetching !== void 0;
        return g2 && (g2.fetch = "inflight", Z && (g2.returnedStale = true)), Z ? b.__staleWhileFetching : b.__returned = b;
      }
      let z2 = this.#v(y3);
      if (!w2 && !z2) return g2 && (g2.fetch = "hit"), this.#W(y3), i2 && this.#k(y3), g2 && this.#N(g2, y3), b;
      let $ = this.#U(t, y3, E, p), J = $.__staleWhileFetching !== void 0 && s;
      return g2 && (g2.fetch = z2 ? "stale" : "refresh", J && z2 && (g2.returnedStale = true)), J ? $.__staleWhileFetching : $.__returned = $;
    }
  }
  async forceFetch(t, e = {}) {
    let s = await this.fetch(t, e);
    if (s === void 0) throw new Error("fetch() returned undefined");
    return s;
  }
  memo(t, e = {}) {
    let s = this.#w;
    if (!s) throw new Error("no memoMethod provided to constructor");
    let { context: i2, forceRefresh: r, ...o } = e, h = this.get(t, o);
    if (!r && h !== void 0) return h;
    let a2 = s(t, h, { options: o, context: i2 });
    return this.set(t, a2, o), a2;
  }
  get(t, e = {}) {
    let { allowStale: s = this.allowStale, updateAgeOnGet: i2 = this.updateAgeOnGet, noDeleteOnStaleGet: r = this.noDeleteOnStaleGet, status: o } = e, h = this.#f.get(t);
    if (h !== void 0) {
      let a2 = this.#i[h], l = this.#l(a2);
      return o && this.#N(o, h), this.#v(h) ? (o && (o.get = "stale"), l ? (o && s && a2.__staleWhileFetching !== void 0 && (o.returnedStale = true), s ? a2.__staleWhileFetching : void 0) : (r || this.#O(t, "expire"), o && s && (o.returnedStale = true), s ? a2 : void 0)) : (o && (o.get = "hit"), l ? a2.__staleWhileFetching : (this.#W(h), i2 && this.#k(h), a2));
    } else o && (o.get = "miss");
  }
  #$(t, e) {
    this.#E[e] = t, this.#d[t] = e;
  }
  #W(t) {
    t !== this.#p && (t === this.#b ? this.#b = this.#d[t] : this.#$(this.#E[t], this.#d[t]), this.#$(this.#p, t), this.#p = t);
  }
  delete(t) {
    return this.#O(t, "delete");
  }
  #O(t, e) {
    let s = false;
    if (this.#h !== 0) {
      let i2 = this.#f.get(t);
      if (i2 !== void 0) if (this.#y?.[i2] && (clearTimeout(this.#y?.[i2]), this.#y[i2] = void 0), s = true, this.#h === 1) this.#H(e);
      else {
        this.#P(i2);
        let r = this.#i[i2];
        if (this.#l(r) ? r.__abortController.abort(new Error("deleted")) : (this.#x || this.#e) && (this.#x && this.#n?.(r, t, e), this.#e && this.#m?.push([r, t, e])), this.#f.delete(t), this.#a[i2] = void 0, this.#i[i2] = void 0, i2 === this.#p) this.#p = this.#E[i2];
        else if (i2 === this.#b) this.#b = this.#d[i2];
        else {
          let o = this.#E[i2];
          this.#d[o] = this.#d[i2];
          let h = this.#d[i2];
          this.#E[h] = this.#E[i2];
        }
        this.#h--, this.#R.push(i2);
      }
    }
    if (this.#e && this.#m?.length) {
      let i2 = this.#m, r;
      for (; r = i2?.shift(); ) this.#o?.(...r);
    }
    return s;
  }
  clear() {
    return this.#H("delete");
  }
  #H(t) {
    for (let e of this.#D({ allowStale: true })) {
      let s = this.#i[e];
      if (this.#l(s)) s.__abortController.abort(new Error("deleted"));
      else {
        let i2 = this.#a[e];
        this.#x && this.#n?.(s, i2, t), this.#e && this.#m?.push([s, i2, t]);
      }
    }
    if (this.#f.clear(), this.#i.fill(void 0), this.#a.fill(void 0), this.#g && this.#T) {
      this.#g.fill(0), this.#T.fill(0);
      for (let e of this.#y ?? []) e !== void 0 && clearTimeout(e);
      this.#y?.fill(void 0);
    }
    if (this.#C && this.#C.fill(0), this.#b = 0, this.#p = 0, this.#R.length = 0, this.#u = 0, this.#h = 0, this.#e && this.#m) {
      let e = this.#m, s;
      for (; s = e?.shift(); ) this.#o?.(...s);
    }
  }
};
var Ne = typeof process == "object" && process ? process : { stdout: null, stderr: null };
var oi = (n7) => !!n7 && typeof n7 == "object" && (n7 instanceof V || n7 instanceof Pe || hi(n7) || ai(n7));
var hi = (n7) => !!n7 && typeof n7 == "object" && n7 instanceof ee && typeof n7.pipe == "function" && n7.pipe !== Pe.Writable.prototype.pipe;
var ai = (n7) => !!n7 && typeof n7 == "object" && n7 instanceof ee && typeof n7.write == "function" && typeof n7.end == "function";
var G2 = /* @__PURE__ */ Symbol("EOF");
var H = /* @__PURE__ */ Symbol("maybeEmitEnd");
var K = /* @__PURE__ */ Symbol("emittedEnd");
var kt = /* @__PURE__ */ Symbol("emittingEnd");
var ut = /* @__PURE__ */ Symbol("emittedError");
var Rt = /* @__PURE__ */ Symbol("closed");
var _e = /* @__PURE__ */ Symbol("read");
var Ot = /* @__PURE__ */ Symbol("flush");
var Le = /* @__PURE__ */ Symbol("flushChunk");
var P2 = /* @__PURE__ */ Symbol("encoding");
var et = /* @__PURE__ */ Symbol("decoder");
var v2 = /* @__PURE__ */ Symbol("flowing");
var dt = /* @__PURE__ */ Symbol("paused");
var st = /* @__PURE__ */ Symbol("resume");
var C3 = /* @__PURE__ */ Symbol("buffer");
var F2 = /* @__PURE__ */ Symbol("pipes");
var T2 = /* @__PURE__ */ Symbol("bufferLength");
var Yt = /* @__PURE__ */ Symbol("bufferPush");
var Ft = /* @__PURE__ */ Symbol("bufferShift");
var k2 = /* @__PURE__ */ Symbol("objectMode");
var x2 = /* @__PURE__ */ Symbol("destroyed");
var Xt = /* @__PURE__ */ Symbol("error");
var Jt = /* @__PURE__ */ Symbol("emitData");
var We = /* @__PURE__ */ Symbol("emitEnd");
var Zt = /* @__PURE__ */ Symbol("emitEnd2");
var B = /* @__PURE__ */ Symbol("async");
var Qt = /* @__PURE__ */ Symbol("abort");
var Dt = /* @__PURE__ */ Symbol("aborted");
var pt = /* @__PURE__ */ Symbol("signal");
var Y = /* @__PURE__ */ Symbol("dataListeners");
var M2 = /* @__PURE__ */ Symbol("discarded");
var mt = (n7) => Promise.resolve().then(n7);
var li = (n7) => n7();
var ci = (n7) => n7 === "end" || n7 === "finish" || n7 === "prefinish";
var fi = (n7) => n7 instanceof ArrayBuffer || !!n7 && typeof n7 == "object" && n7.constructor && n7.constructor.name === "ArrayBuffer" && n7.byteLength >= 0;
var ui = (n7) => !Buffer.isBuffer(n7) && ArrayBuffer.isView(n7);
var Mt = class {
  src;
  dest;
  opts;
  ondrain;
  constructor(t, e, s) {
    this.src = t, this.dest = e, this.opts = s, this.ondrain = () => t[st](), this.dest.on("drain", this.ondrain);
  }
  unpipe() {
    this.dest.removeListener("drain", this.ondrain);
  }
  proxyErrors(t) {
  }
  end() {
    this.unpipe(), this.opts.end && this.dest.end();
  }
};
var te = class extends Mt {
  unpipe() {
    this.src.removeListener("error", this.proxyErrors), super.unpipe();
  }
  constructor(t, e, s) {
    super(t, e, s), this.proxyErrors = (i2) => this.dest.emit("error", i2), t.on("error", this.proxyErrors);
  }
};
var di = (n7) => !!n7.objectMode;
var pi = (n7) => !n7.objectMode && !!n7.encoding && n7.encoding !== "buffer";
var V = class extends ee {
  [v2] = false;
  [dt] = false;
  [F2] = [];
  [C3] = [];
  [k2];
  [P2];
  [B];
  [et];
  [G2] = false;
  [K] = false;
  [kt] = false;
  [Rt] = false;
  [ut] = null;
  [T2] = 0;
  [x2] = false;
  [pt];
  [Dt] = false;
  [Y] = 0;
  [M2] = false;
  writable = true;
  readable = true;
  constructor(...t) {
    let e = t[0] || {};
    if (super(), e.objectMode && typeof e.encoding == "string") throw new TypeError("Encoding and objectMode may not be used together");
    di(e) ? (this[k2] = true, this[P2] = null) : pi(e) ? (this[P2] = e.encoding, this[k2] = false) : (this[k2] = false, this[P2] = null), this[B] = !!e.async, this[et] = this[P2] ? new ni(this[P2]) : null, e && e.debugExposeBuffer === true && Object.defineProperty(this, "buffer", { get: () => this[C3] }), e && e.debugExposePipes === true && Object.defineProperty(this, "pipes", { get: () => this[F2] });
    let { signal: s } = e;
    s && (this[pt] = s, s.aborted ? this[Qt]() : s.addEventListener("abort", () => this[Qt]()));
  }
  get bufferLength() {
    return this[T2];
  }
  get encoding() {
    return this[P2];
  }
  set encoding(t) {
    throw new Error("Encoding must be set at instantiation time");
  }
  setEncoding(t) {
    throw new Error("Encoding must be set at instantiation time");
  }
  get objectMode() {
    return this[k2];
  }
  set objectMode(t) {
    throw new Error("objectMode must be set at instantiation time");
  }
  get async() {
    return this[B];
  }
  set async(t) {
    this[B] = this[B] || !!t;
  }
  [Qt]() {
    this[Dt] = true, this.emit("abort", this[pt]?.reason), this.destroy(this[pt]?.reason);
  }
  get aborted() {
    return this[Dt];
  }
  set aborted(t) {
  }
  write(t, e, s) {
    if (this[Dt]) return false;
    if (this[G2]) throw new Error("write after end");
    if (this[x2]) return this.emit("error", Object.assign(new Error("Cannot call write after a stream was destroyed"), { code: "ERR_STREAM_DESTROYED" })), true;
    typeof e == "function" && (s = e, e = "utf8"), e || (e = "utf8");
    let i2 = this[B] ? mt : li;
    if (!this[k2] && !Buffer.isBuffer(t)) {
      if (ui(t)) t = Buffer.from(t.buffer, t.byteOffset, t.byteLength);
      else if (fi(t)) t = Buffer.from(t);
      else if (typeof t != "string") throw new Error("Non-contiguous data written to non-objectMode stream");
    }
    return this[k2] ? (this[v2] && this[T2] !== 0 && this[Ot](true), this[v2] ? this.emit("data", t) : this[Yt](t), this[T2] !== 0 && this.emit("readable"), s && i2(s), this[v2]) : t.length ? (typeof t == "string" && !(e === this[P2] && !this[et]?.lastNeed) && (t = Buffer.from(t, e)), Buffer.isBuffer(t) && this[P2] && (t = this[et].write(t)), this[v2] && this[T2] !== 0 && this[Ot](true), this[v2] ? this.emit("data", t) : this[Yt](t), this[T2] !== 0 && this.emit("readable"), s && i2(s), this[v2]) : (this[T2] !== 0 && this.emit("readable"), s && i2(s), this[v2]);
  }
  read(t) {
    if (this[x2]) return null;
    if (this[M2] = false, this[T2] === 0 || t === 0 || t && t > this[T2]) return this[H](), null;
    this[k2] && (t = null), this[C3].length > 1 && !this[k2] && (this[C3] = [this[P2] ? this[C3].join("") : Buffer.concat(this[C3], this[T2])]);
    let e = this[_e](t || null, this[C3][0]);
    return this[H](), e;
  }
  [_e](t, e) {
    if (this[k2]) this[Ft]();
    else {
      let s = e;
      t === s.length || t === null ? this[Ft]() : typeof s == "string" ? (this[C3][0] = s.slice(t), e = s.slice(0, t), this[T2] -= t) : (this[C3][0] = s.subarray(t), e = s.subarray(0, t), this[T2] -= t);
    }
    return this.emit("data", e), !this[C3].length && !this[G2] && this.emit("drain"), e;
  }
  end(t, e, s) {
    return typeof t == "function" && (s = t, t = void 0), typeof e == "function" && (s = e, e = "utf8"), t !== void 0 && this.write(t, e), s && this.once("end", s), this[G2] = true, this.writable = false, (this[v2] || !this[dt]) && this[H](), this;
  }
  [st]() {
    this[x2] || (!this[Y] && !this[F2].length && (this[M2] = true), this[dt] = false, this[v2] = true, this.emit("resume"), this[C3].length ? this[Ot]() : this[G2] ? this[H]() : this.emit("drain"));
  }
  resume() {
    return this[st]();
  }
  pause() {
    this[v2] = false, this[dt] = true, this[M2] = false;
  }
  get destroyed() {
    return this[x2];
  }
  get flowing() {
    return this[v2];
  }
  get paused() {
    return this[dt];
  }
  [Yt](t) {
    this[k2] ? this[T2] += 1 : this[T2] += t.length, this[C3].push(t);
  }
  [Ft]() {
    return this[k2] ? this[T2] -= 1 : this[T2] -= this[C3][0].length, this[C3].shift();
  }
  [Ot](t = false) {
    do
      ;
    while (this[Le](this[Ft]()) && this[C3].length);
    !t && !this[C3].length && !this[G2] && this.emit("drain");
  }
  [Le](t) {
    return this.emit("data", t), this[v2];
  }
  pipe(t, e) {
    if (this[x2]) return t;
    this[M2] = false;
    let s = this[K];
    return e = e || {}, t === Ne.stdout || t === Ne.stderr ? e.end = false : e.end = e.end !== false, e.proxyErrors = !!e.proxyErrors, s ? e.end && t.end() : (this[F2].push(e.proxyErrors ? new te(this, t, e) : new Mt(this, t, e)), this[B] ? mt(() => this[st]()) : this[st]()), t;
  }
  unpipe(t) {
    let e = this[F2].find((s) => s.dest === t);
    e && (this[F2].length === 1 ? (this[v2] && this[Y] === 0 && (this[v2] = false), this[F2] = []) : this[F2].splice(this[F2].indexOf(e), 1), e.unpipe());
  }
  addListener(t, e) {
    return this.on(t, e);
  }
  on(t, e) {
    let s = super.on(t, e);
    if (t === "data") this[M2] = false, this[Y]++, !this[F2].length && !this[v2] && this[st]();
    else if (t === "readable" && this[T2] !== 0) super.emit("readable");
    else if (ci(t) && this[K]) super.emit(t), this.removeAllListeners(t);
    else if (t === "error" && this[ut]) {
      let i2 = e;
      this[B] ? mt(() => i2.call(this, this[ut])) : i2.call(this, this[ut]);
    }
    return s;
  }
  removeListener(t, e) {
    return this.off(t, e);
  }
  off(t, e) {
    let s = super.off(t, e);
    return t === "data" && (this[Y] = this.listeners("data").length, this[Y] === 0 && !this[M2] && !this[F2].length && (this[v2] = false)), s;
  }
  removeAllListeners(t) {
    let e = super.removeAllListeners(t);
    return (t === "data" || t === void 0) && (this[Y] = 0, !this[M2] && !this[F2].length && (this[v2] = false)), e;
  }
  get emittedEnd() {
    return this[K];
  }
  [H]() {
    !this[kt] && !this[K] && !this[x2] && this[C3].length === 0 && this[G2] && (this[kt] = true, this.emit("end"), this.emit("prefinish"), this.emit("finish"), this[Rt] && this.emit("close"), this[kt] = false);
  }
  emit(t, ...e) {
    let s = e[0];
    if (t !== "error" && t !== "close" && t !== x2 && this[x2]) return false;
    if (t === "data") return !this[k2] && !s ? false : this[B] ? (mt(() => this[Jt](s)), true) : this[Jt](s);
    if (t === "end") return this[We]();
    if (t === "close") {
      if (this[Rt] = true, !this[K] && !this[x2]) return false;
      let r = super.emit("close");
      return this.removeAllListeners("close"), r;
    } else if (t === "error") {
      this[ut] = s, super.emit(Xt, s);
      let r = !this[pt] || this.listeners("error").length ? super.emit("error", s) : false;
      return this[H](), r;
    } else if (t === "resume") {
      let r = super.emit("resume");
      return this[H](), r;
    } else if (t === "finish" || t === "prefinish") {
      let r = super.emit(t);
      return this.removeAllListeners(t), r;
    }
    let i2 = super.emit(t, ...e);
    return this[H](), i2;
  }
  [Jt](t) {
    for (let s of this[F2]) s.dest.write(t) === false && this.pause();
    let e = this[M2] ? false : super.emit("data", t);
    return this[H](), e;
  }
  [We]() {
    return this[K] ? false : (this[K] = true, this.readable = false, this[B] ? (mt(() => this[Zt]()), true) : this[Zt]());
  }
  [Zt]() {
    if (this[et]) {
      let e = this[et].end();
      if (e) {
        for (let s of this[F2]) s.dest.write(e);
        this[M2] || super.emit("data", e);
      }
    }
    for (let e of this[F2]) e.end();
    let t = super.emit("end");
    return this.removeAllListeners("end"), t;
  }
  async collect() {
    let t = Object.assign([], { dataLength: 0 });
    this[k2] || (t.dataLength = 0);
    let e = this.promise();
    return this.on("data", (s) => {
      t.push(s), this[k2] || (t.dataLength += s.length);
    }), await e, t;
  }
  async concat() {
    if (this[k2]) throw new Error("cannot concat in objectMode");
    let t = await this.collect();
    return this[P2] ? t.join("") : Buffer.concat(t, t.dataLength);
  }
  async promise() {
    return new Promise((t, e) => {
      this.on(x2, () => e(new Error("stream destroyed"))), this.on("error", (s) => e(s)), this.on("end", () => t());
    });
  }
  [Symbol.asyncIterator]() {
    this[M2] = false;
    let t = false, e = async () => (this.pause(), t = true, { value: void 0, done: true });
    return { next: () => {
      if (t) return e();
      let i2 = this.read();
      if (i2 !== null) return Promise.resolve({ done: false, value: i2 });
      if (this[G2]) return e();
      let r, o, h = (c3) => {
        this.off("data", a2), this.off("end", l), this.off(x2, u2), e(), o(c3);
      }, a2 = (c3) => {
        this.off("error", h), this.off("end", l), this.off(x2, u2), this.pause(), r({ value: c3, done: !!this[G2] });
      }, l = () => {
        this.off("error", h), this.off("data", a2), this.off(x2, u2), e(), r({ done: true, value: void 0 });
      }, u2 = () => h(new Error("stream destroyed"));
      return new Promise((c3, d2) => {
        o = d2, r = c3, this.once(x2, u2), this.once("error", h), this.once("end", l), this.once("data", a2);
      });
    }, throw: e, return: e, [Symbol.asyncIterator]() {
      return this;
    }, [Symbol.asyncDispose]: async () => {
    } };
  }
  [Symbol.iterator]() {
    this[M2] = false;
    let t = false, e = () => (this.pause(), this.off(Xt, e), this.off(x2, e), this.off("end", e), t = true, { done: true, value: void 0 }), s = () => {
      if (t) return e();
      let i2 = this.read();
      return i2 === null ? e() : { done: false, value: i2 };
    };
    return this.once("end", e), this.once(Xt, e), this.once(x2, e), { next: s, throw: e, return: e, [Symbol.iterator]() {
      return this;
    }, [Symbol.dispose]: () => {
    } };
  }
  destroy(t) {
    if (this[x2]) return t ? this.emit("error", t) : this.emit(x2), this;
    this[x2] = true, this[M2] = true, this[C3].length = 0, this[T2] = 0;
    let e = this;
    return typeof e.close == "function" && !this[Rt] && e.close(), t ? this.emit("error", t) : this.emit(x2), this;
  }
  static get isStream() {
    return oi;
  }
};
var vi = Ei.native;
var wt = { lstatSync: wi, readdir: yi, readdirSync: bi, readlinkSync: Si, realpathSync: vi, promises: { lstat: Ci, readdir: Ti, readlink: Ai, realpath: ki } };
var Ue = (n7) => !n7 || n7 === wt || n7 === xi ? wt : { ...wt, ...n7, promises: { ...wt.promises, ...n7.promises || {} } };
var $e = /^\\\\\?\\([a-z]:)\\?$/i;
var Ri = (n7) => n7.replace(/\//g, "\\").replace($e, "$1\\");
var Oi = /[\\\/]/;
var L3 = 0;
var Ge = 1;
var He = 2;
var U3 = 4;
var qe = 6;
var Ke = 8;
var X = 10;
var Ve = 12;
var _2 = 15;
var gt = ~_2;
var se = 16;
var je = 32;
var yt = 64;
var j = 128;
var Nt = 256;
var Lt = 512;
var Ie = yt | j | Lt;
var Fi = 1023;
var ie = (n7) => n7.isFile() ? Ke : n7.isDirectory() ? U3 : n7.isSymbolicLink() ? X : n7.isCharacterDevice() ? He : n7.isBlockDevice() ? qe : n7.isSocket() ? Ve : n7.isFIFO() ? Ge : L3;
var ze = new ft({ max: 2 ** 12 });
var bt = (n7) => {
  let t = ze.get(n7);
  if (t) return t;
  let e = n7.normalize("NFKD");
  return ze.set(n7, e), e;
};
var Be = new ft({ max: 2 ** 12 });
var _t = (n7) => {
  let t = Be.get(n7);
  if (t) return t;
  let e = bt(n7.toLowerCase());
  return Be.set(n7, e), e;
};
var Wt = class extends ft {
  constructor() {
    super({ max: 256 });
  }
};
var ne = class extends ft {
  constructor(t = 16 * 1024) {
    super({ maxSize: t, sizeCalculation: (e) => e.length + 1 });
  }
};
var Ye = /* @__PURE__ */ Symbol("PathScurry setAsCwd");
var R3 = class {
  name;
  root;
  roots;
  parent;
  nocase;
  isCWD = false;
  #t;
  #s;
  get dev() {
    return this.#s;
  }
  #n;
  get mode() {
    return this.#n;
  }
  #r;
  get nlink() {
    return this.#r;
  }
  #o;
  get uid() {
    return this.#o;
  }
  #S;
  get gid() {
    return this.#S;
  }
  #w;
  get rdev() {
    return this.#w;
  }
  #c;
  get blksize() {
    return this.#c;
  }
  #h;
  get ino() {
    return this.#h;
  }
  #u;
  get size() {
    return this.#u;
  }
  #f;
  get blocks() {
    return this.#f;
  }
  #a;
  get atimeMs() {
    return this.#a;
  }
  #i;
  get mtimeMs() {
    return this.#i;
  }
  #d;
  get ctimeMs() {
    return this.#d;
  }
  #E;
  get birthtimeMs() {
    return this.#E;
  }
  #b;
  get atime() {
    return this.#b;
  }
  #p;
  get mtime() {
    return this.#p;
  }
  #R;
  get ctime() {
    return this.#R;
  }
  #m;
  get birthtime() {
    return this.#m;
  }
  #C;
  #T;
  #g;
  #y;
  #x;
  #A;
  #e;
  #_;
  #M;
  #k;
  get parentPath() {
    return (this.parent || this).fullpath();
  }
  get path() {
    return this.parentPath;
  }
  constructor(t, e = L3, s, i2, r, o, h) {
    this.name = t, this.#C = r ? _t(t) : bt(t), this.#e = e & Fi, this.nocase = r, this.roots = i2, this.root = s || this, this.#_ = o, this.#g = h.fullpath, this.#x = h.relative, this.#A = h.relativePosix, this.parent = h.parent, this.parent ? this.#t = this.parent.#t : this.#t = Ue(h.fs);
  }
  depth() {
    return this.#T !== void 0 ? this.#T : this.parent ? this.#T = this.parent.depth() + 1 : this.#T = 0;
  }
  childrenCache() {
    return this.#_;
  }
  resolve(t) {
    if (!t) return this;
    let e = this.getRootString(t), i2 = t.substring(e.length).split(this.splitSep);
    return e ? this.getRoot(e).#N(i2) : this.#N(i2);
  }
  #N(t) {
    let e = this;
    for (let s of t) e = e.child(s);
    return e;
  }
  children() {
    let t = this.#_.get(this);
    if (t) return t;
    let e = Object.assign([], { provisional: 0 });
    return this.#_.set(this, e), this.#e &= ~se, e;
  }
  child(t, e) {
    if (t === "" || t === ".") return this;
    if (t === "..") return this.parent || this;
    let s = this.children(), i2 = this.nocase ? _t(t) : bt(t);
    for (let a2 of s) if (a2.#C === i2) return a2;
    let r = this.parent ? this.sep : "", o = this.#g ? this.#g + r + t : void 0, h = this.newChild(t, L3, { ...e, parent: this, fullpath: o });
    return this.canReaddir() || (h.#e |= j), s.push(h), h;
  }
  relative() {
    if (this.isCWD) return "";
    if (this.#x !== void 0) return this.#x;
    let t = this.name, e = this.parent;
    if (!e) return this.#x = this.name;
    let s = e.relative();
    return s + (!s || !e.parent ? "" : this.sep) + t;
  }
  relativePosix() {
    if (this.sep === "/") return this.relative();
    if (this.isCWD) return "";
    if (this.#A !== void 0) return this.#A;
    let t = this.name, e = this.parent;
    if (!e) return this.#A = this.fullpathPosix();
    let s = e.relativePosix();
    return s + (!s || !e.parent ? "" : "/") + t;
  }
  fullpath() {
    if (this.#g !== void 0) return this.#g;
    let t = this.name, e = this.parent;
    if (!e) return this.#g = this.name;
    let i2 = e.fullpath() + (e.parent ? this.sep : "") + t;
    return this.#g = i2;
  }
  fullpathPosix() {
    if (this.#y !== void 0) return this.#y;
    if (this.sep === "/") return this.#y = this.fullpath();
    if (!this.parent) {
      let i2 = this.fullpath().replace(/\\/g, "/");
      return /^[a-z]:\//i.test(i2) ? this.#y = `//?/${i2}` : this.#y = i2;
    }
    let t = this.parent, e = t.fullpathPosix(), s = e + (!e || !t.parent ? "" : "/") + this.name;
    return this.#y = s;
  }
  isUnknown() {
    return (this.#e & _2) === L3;
  }
  isType(t) {
    return this[`is${t}`]();
  }
  getType() {
    return this.isUnknown() ? "Unknown" : this.isDirectory() ? "Directory" : this.isFile() ? "File" : this.isSymbolicLink() ? "SymbolicLink" : this.isFIFO() ? "FIFO" : this.isCharacterDevice() ? "CharacterDevice" : this.isBlockDevice() ? "BlockDevice" : this.isSocket() ? "Socket" : "Unknown";
  }
  isFile() {
    return (this.#e & _2) === Ke;
  }
  isDirectory() {
    return (this.#e & _2) === U3;
  }
  isCharacterDevice() {
    return (this.#e & _2) === He;
  }
  isBlockDevice() {
    return (this.#e & _2) === qe;
  }
  isFIFO() {
    return (this.#e & _2) === Ge;
  }
  isSocket() {
    return (this.#e & _2) === Ve;
  }
  isSymbolicLink() {
    return (this.#e & X) === X;
  }
  lstatCached() {
    return this.#e & je ? this : void 0;
  }
  readlinkCached() {
    return this.#M;
  }
  realpathCached() {
    return this.#k;
  }
  readdirCached() {
    let t = this.children();
    return t.slice(0, t.provisional);
  }
  canReadlink() {
    if (this.#M) return true;
    if (!this.parent) return false;
    let t = this.#e & _2;
    return !(t !== L3 && t !== X || this.#e & Nt || this.#e & j);
  }
  calledReaddir() {
    return !!(this.#e & se);
  }
  isENOENT() {
    return !!(this.#e & j);
  }
  isNamed(t) {
    return this.nocase ? this.#C === _t(t) : this.#C === bt(t);
  }
  async readlink() {
    let t = this.#M;
    if (t) return t;
    if (this.canReadlink() && this.parent) try {
      let e = await this.#t.promises.readlink(this.fullpath()), s = (await this.parent.realpath())?.resolve(e);
      if (s) return this.#M = s;
    } catch (e) {
      this.#D(e.code);
      return;
    }
  }
  readlinkSync() {
    let t = this.#M;
    if (t) return t;
    if (this.canReadlink() && this.parent) try {
      let e = this.#t.readlinkSync(this.fullpath()), s = this.parent.realpathSync()?.resolve(e);
      if (s) return this.#M = s;
    } catch (e) {
      this.#D(e.code);
      return;
    }
  }
  #j(t) {
    this.#e |= se;
    for (let e = t.provisional; e < t.length; e++) {
      let s = t[e];
      s && s.#v();
    }
  }
  #v() {
    this.#e & j || (this.#e = (this.#e | j) & gt, this.#G());
  }
  #G() {
    let t = this.children();
    t.provisional = 0;
    for (let e of t) e.#v();
  }
  #P() {
    this.#e |= Lt, this.#L();
  }
  #L() {
    if (this.#e & yt) return;
    let t = this.#e;
    (t & _2) === U3 && (t &= gt), this.#e = t | yt, this.#G();
  }
  #I(t = "") {
    t === "ENOTDIR" || t === "EPERM" ? this.#L() : t === "ENOENT" ? this.#v() : this.children().provisional = 0;
  }
  #F(t = "") {
    t === "ENOTDIR" ? this.parent.#L() : t === "ENOENT" && this.#v();
  }
  #D(t = "") {
    let e = this.#e;
    e |= Nt, t === "ENOENT" && (e |= j), (t === "EINVAL" || t === "UNKNOWN") && (e &= gt), this.#e = e, t === "ENOTDIR" && this.parent && this.parent.#L();
  }
  #z(t, e) {
    return this.#U(t, e) || this.#B(t, e);
  }
  #B(t, e) {
    let s = ie(t), i2 = this.newChild(t.name, s, { parent: this }), r = i2.#e & _2;
    return r !== U3 && r !== X && r !== L3 && (i2.#e |= yt), e.unshift(i2), e.provisional++, i2;
  }
  #U(t, e) {
    for (let s = e.provisional; s < e.length; s++) {
      let i2 = e[s];
      if ((this.nocase ? _t(t.name) : bt(t.name)) === i2.#C) return this.#l(t, i2, s, e);
    }
  }
  #l(t, e, s, i2) {
    let r = e.name;
    return e.#e = e.#e & gt | ie(t), r !== t.name && (e.name = t.name), s !== i2.provisional && (s === i2.length - 1 ? i2.pop() : i2.splice(s, 1), i2.unshift(e)), i2.provisional++, e;
  }
  async lstat() {
    if ((this.#e & j) === 0) try {
      return this.#$(await this.#t.promises.lstat(this.fullpath())), this;
    } catch (t) {
      this.#F(t.code);
    }
  }
  lstatSync() {
    if ((this.#e & j) === 0) try {
      return this.#$(this.#t.lstatSync(this.fullpath())), this;
    } catch (t) {
      this.#F(t.code);
    }
  }
  #$(t) {
    let { atime: e, atimeMs: s, birthtime: i2, birthtimeMs: r, blksize: o, blocks: h, ctime: a2, ctimeMs: l, dev: u2, gid: c3, ino: d2, mode: f, mtime: m2, mtimeMs: p, nlink: w2, rdev: g2, size: S2, uid: E } = t;
    this.#b = e, this.#a = s, this.#m = i2, this.#E = r, this.#c = o, this.#f = h, this.#R = a2, this.#d = l, this.#s = u2, this.#S = c3, this.#h = d2, this.#n = f, this.#p = m2, this.#i = p, this.#r = w2, this.#w = g2, this.#u = S2, this.#o = E;
    let y3 = ie(t);
    this.#e = this.#e & gt | y3 | je, y3 !== L3 && y3 !== U3 && y3 !== X && (this.#e |= yt);
  }
  #W = [];
  #O = false;
  #H(t) {
    this.#O = false;
    let e = this.#W.slice();
    this.#W.length = 0, e.forEach((s) => s(null, t));
  }
  readdirCB(t, e = false) {
    if (!this.canReaddir()) {
      e ? t(null, []) : queueMicrotask(() => t(null, []));
      return;
    }
    let s = this.children();
    if (this.calledReaddir()) {
      let r = s.slice(0, s.provisional);
      e ? t(null, r) : queueMicrotask(() => t(null, r));
      return;
    }
    if (this.#W.push(t), this.#O) return;
    this.#O = true;
    let i2 = this.fullpath();
    this.#t.readdir(i2, { withFileTypes: true }, (r, o) => {
      if (r) this.#I(r.code), s.provisional = 0;
      else {
        for (let h of o) this.#z(h, s);
        this.#j(s);
      }
      this.#H(s.slice(0, s.provisional));
    });
  }
  #q;
  async readdir() {
    if (!this.canReaddir()) return [];
    let t = this.children();
    if (this.calledReaddir()) return t.slice(0, t.provisional);
    let e = this.fullpath();
    if (this.#q) await this.#q;
    else {
      let s = () => {
      };
      this.#q = new Promise((i2) => s = i2);
      try {
        for (let i2 of await this.#t.promises.readdir(e, { withFileTypes: true })) this.#z(i2, t);
        this.#j(t);
      } catch (i2) {
        this.#I(i2.code), t.provisional = 0;
      }
      this.#q = void 0, s();
    }
    return t.slice(0, t.provisional);
  }
  readdirSync() {
    if (!this.canReaddir()) return [];
    let t = this.children();
    if (this.calledReaddir()) return t.slice(0, t.provisional);
    let e = this.fullpath();
    try {
      for (let s of this.#t.readdirSync(e, { withFileTypes: true })) this.#z(s, t);
      this.#j(t);
    } catch (s) {
      this.#I(s.code), t.provisional = 0;
    }
    return t.slice(0, t.provisional);
  }
  canReaddir() {
    if (this.#e & Ie) return false;
    let t = _2 & this.#e;
    return t === L3 || t === U3 || t === X;
  }
  shouldWalk(t, e) {
    return (this.#e & U3) === U3 && !(this.#e & Ie) && !t.has(this) && (!e || e(this));
  }
  async realpath() {
    if (this.#k) return this.#k;
    if (!((Lt | Nt | j) & this.#e)) try {
      let t = await this.#t.promises.realpath(this.fullpath());
      return this.#k = this.resolve(t);
    } catch {
      this.#P();
    }
  }
  realpathSync() {
    if (this.#k) return this.#k;
    if (!((Lt | Nt | j) & this.#e)) try {
      let t = this.#t.realpathSync(this.fullpath());
      return this.#k = this.resolve(t);
    } catch {
      this.#P();
    }
  }
  [Ye](t) {
    if (t === this) return;
    t.isCWD = false, this.isCWD = true;
    let e = /* @__PURE__ */ new Set([]), s = [], i2 = this;
    for (; i2 && i2.parent; ) e.add(i2), i2.#x = s.join(this.sep), i2.#A = s.join("/"), i2 = i2.parent, s.push("..");
    for (i2 = t; i2 && i2.parent && !e.has(i2); ) i2.#x = void 0, i2.#A = void 0, i2 = i2.parent;
  }
};
var Pt = class n2 extends R3 {
  sep = "\\";
  splitSep = Oi;
  constructor(t, e = L3, s, i2, r, o, h) {
    super(t, e, s, i2, r, o, h);
  }
  newChild(t, e = L3, s = {}) {
    return new n2(t, e, this.root, this.roots, this.nocase, this.childrenCache(), s);
  }
  getRootString(t) {
    return re.parse(t).root;
  }
  getRoot(t) {
    if (t = Ri(t.toUpperCase()), t === this.root.name) return this.root;
    for (let [e, s] of Object.entries(this.roots)) if (this.sameRoot(t, e)) return this.roots[t] = s;
    return this.roots[t] = new it(t, this).root;
  }
  sameRoot(t, e = this.root.name) {
    return t = t.toUpperCase().replace(/\//g, "\\").replace($e, "$1\\"), t === e;
  }
};
var jt = class n3 extends R3 {
  splitSep = "/";
  sep = "/";
  constructor(t, e = L3, s, i2, r, o, h) {
    super(t, e, s, i2, r, o, h);
  }
  getRootString(t) {
    return t.startsWith("/") ? "/" : "";
  }
  getRoot(t) {
    return this.root;
  }
  newChild(t, e = L3, s = {}) {
    return new n3(t, e, this.root, this.roots, this.nocase, this.childrenCache(), s);
  }
};
var It = class {
  root;
  rootPath;
  roots;
  cwd;
  #t;
  #s;
  #n;
  nocase;
  #r;
  constructor(t = process.cwd(), e, s, { nocase: i2, childrenCacheSize: r = 16 * 1024, fs: o = wt } = {}) {
    this.#r = Ue(o), (t instanceof URL || t.startsWith("file://")) && (t = gi(t));
    let h = e.resolve(t);
    this.roots = /* @__PURE__ */ Object.create(null), this.rootPath = this.parseRootPath(h), this.#t = new Wt(), this.#s = new Wt(), this.#n = new ne(r);
    let a2 = h.substring(this.rootPath.length).split(s);
    if (a2.length === 1 && !a2[0] && a2.pop(), i2 === void 0) throw new TypeError("must provide nocase setting to PathScurryBase ctor");
    this.nocase = i2, this.root = this.newRoot(this.#r), this.roots[this.rootPath] = this.root;
    let l = this.root, u2 = a2.length - 1, c3 = e.sep, d2 = this.rootPath, f = false;
    for (let m2 of a2) {
      let p = u2--;
      l = l.child(m2, { relative: new Array(p).fill("..").join(c3), relativePosix: new Array(p).fill("..").join("/"), fullpath: d2 += (f ? "" : c3) + m2 }), f = true;
    }
    this.cwd = l;
  }
  depth(t = this.cwd) {
    return typeof t == "string" && (t = this.cwd.resolve(t)), t.depth();
  }
  childrenCache() {
    return this.#n;
  }
  resolve(...t) {
    let e = "";
    for (let r = t.length - 1; r >= 0; r--) {
      let o = t[r];
      if (!(!o || o === ".") && (e = e ? `${o}/${e}` : o, this.isAbsolute(o))) break;
    }
    let s = this.#t.get(e);
    if (s !== void 0) return s;
    let i2 = this.cwd.resolve(e).fullpath();
    return this.#t.set(e, i2), i2;
  }
  resolvePosix(...t) {
    let e = "";
    for (let r = t.length - 1; r >= 0; r--) {
      let o = t[r];
      if (!(!o || o === ".") && (e = e ? `${o}/${e}` : o, this.isAbsolute(o))) break;
    }
    let s = this.#s.get(e);
    if (s !== void 0) return s;
    let i2 = this.cwd.resolve(e).fullpathPosix();
    return this.#s.set(e, i2), i2;
  }
  relative(t = this.cwd) {
    return typeof t == "string" && (t = this.cwd.resolve(t)), t.relative();
  }
  relativePosix(t = this.cwd) {
    return typeof t == "string" && (t = this.cwd.resolve(t)), t.relativePosix();
  }
  basename(t = this.cwd) {
    return typeof t == "string" && (t = this.cwd.resolve(t)), t.name;
  }
  dirname(t = this.cwd) {
    return typeof t == "string" && (t = this.cwd.resolve(t)), (t.parent || t).fullpath();
  }
  async readdir(t = this.cwd, e = { withFileTypes: true }) {
    typeof t == "string" ? t = this.cwd.resolve(t) : t instanceof R3 || (e = t, t = this.cwd);
    let { withFileTypes: s } = e;
    if (t.canReaddir()) {
      let i2 = await t.readdir();
      return s ? i2 : i2.map((r) => r.name);
    } else return [];
  }
  readdirSync(t = this.cwd, e = { withFileTypes: true }) {
    typeof t == "string" ? t = this.cwd.resolve(t) : t instanceof R3 || (e = t, t = this.cwd);
    let { withFileTypes: s = true } = e;
    return t.canReaddir() ? s ? t.readdirSync() : t.readdirSync().map((i2) => i2.name) : [];
  }
  async lstat(t = this.cwd) {
    return typeof t == "string" && (t = this.cwd.resolve(t)), t.lstat();
  }
  lstatSync(t = this.cwd) {
    return typeof t == "string" && (t = this.cwd.resolve(t)), t.lstatSync();
  }
  async readlink(t = this.cwd, { withFileTypes: e } = { withFileTypes: false }) {
    typeof t == "string" ? t = this.cwd.resolve(t) : t instanceof R3 || (e = t.withFileTypes, t = this.cwd);
    let s = await t.readlink();
    return e ? s : s?.fullpath();
  }
  readlinkSync(t = this.cwd, { withFileTypes: e } = { withFileTypes: false }) {
    typeof t == "string" ? t = this.cwd.resolve(t) : t instanceof R3 || (e = t.withFileTypes, t = this.cwd);
    let s = t.readlinkSync();
    return e ? s : s?.fullpath();
  }
  async realpath(t = this.cwd, { withFileTypes: e } = { withFileTypes: false }) {
    typeof t == "string" ? t = this.cwd.resolve(t) : t instanceof R3 || (e = t.withFileTypes, t = this.cwd);
    let s = await t.realpath();
    return e ? s : s?.fullpath();
  }
  realpathSync(t = this.cwd, { withFileTypes: e } = { withFileTypes: false }) {
    typeof t == "string" ? t = this.cwd.resolve(t) : t instanceof R3 || (e = t.withFileTypes, t = this.cwd);
    let s = t.realpathSync();
    return e ? s : s?.fullpath();
  }
  async walk(t = this.cwd, e = {}) {
    typeof t == "string" ? t = this.cwd.resolve(t) : t instanceof R3 || (e = t, t = this.cwd);
    let { withFileTypes: s = true, follow: i2 = false, filter: r, walkFilter: o } = e, h = [];
    (!r || r(t)) && h.push(s ? t : t.fullpath());
    let a2 = /* @__PURE__ */ new Set(), l = (c3, d2) => {
      a2.add(c3), c3.readdirCB((f, m2) => {
        if (f) return d2(f);
        let p = m2.length;
        if (!p) return d2();
        let w2 = () => {
          --p === 0 && d2();
        };
        for (let g2 of m2) (!r || r(g2)) && h.push(s ? g2 : g2.fullpath()), i2 && g2.isSymbolicLink() ? g2.realpath().then((S2) => S2?.isUnknown() ? S2.lstat() : S2).then((S2) => S2?.shouldWalk(a2, o) ? l(S2, w2) : w2()) : g2.shouldWalk(a2, o) ? l(g2, w2) : w2();
      }, true);
    }, u2 = t;
    return new Promise((c3, d2) => {
      l(u2, (f) => {
        if (f) return d2(f);
        c3(h);
      });
    });
  }
  walkSync(t = this.cwd, e = {}) {
    typeof t == "string" ? t = this.cwd.resolve(t) : t instanceof R3 || (e = t, t = this.cwd);
    let { withFileTypes: s = true, follow: i2 = false, filter: r, walkFilter: o } = e, h = [];
    (!r || r(t)) && h.push(s ? t : t.fullpath());
    let a2 = /* @__PURE__ */ new Set([t]);
    for (let l of a2) {
      let u2 = l.readdirSync();
      for (let c3 of u2) {
        (!r || r(c3)) && h.push(s ? c3 : c3.fullpath());
        let d2 = c3;
        if (c3.isSymbolicLink()) {
          if (!(i2 && (d2 = c3.realpathSync()))) continue;
          d2.isUnknown() && d2.lstatSync();
        }
        d2.shouldWalk(a2, o) && a2.add(d2);
      }
    }
    return h;
  }
  [Symbol.asyncIterator]() {
    return this.iterate();
  }
  iterate(t = this.cwd, e = {}) {
    return typeof t == "string" ? t = this.cwd.resolve(t) : t instanceof R3 || (e = t, t = this.cwd), this.stream(t, e)[Symbol.asyncIterator]();
  }
  [Symbol.iterator]() {
    return this.iterateSync();
  }
  *iterateSync(t = this.cwd, e = {}) {
    typeof t == "string" ? t = this.cwd.resolve(t) : t instanceof R3 || (e = t, t = this.cwd);
    let { withFileTypes: s = true, follow: i2 = false, filter: r, walkFilter: o } = e;
    (!r || r(t)) && (yield s ? t : t.fullpath());
    let h = /* @__PURE__ */ new Set([t]);
    for (let a2 of h) {
      let l = a2.readdirSync();
      for (let u2 of l) {
        (!r || r(u2)) && (yield s ? u2 : u2.fullpath());
        let c3 = u2;
        if (u2.isSymbolicLink()) {
          if (!(i2 && (c3 = u2.realpathSync()))) continue;
          c3.isUnknown() && c3.lstatSync();
        }
        c3.shouldWalk(h, o) && h.add(c3);
      }
    }
  }
  stream(t = this.cwd, e = {}) {
    typeof t == "string" ? t = this.cwd.resolve(t) : t instanceof R3 || (e = t, t = this.cwd);
    let { withFileTypes: s = true, follow: i2 = false, filter: r, walkFilter: o } = e, h = new V({ objectMode: true });
    (!r || r(t)) && h.write(s ? t : t.fullpath());
    let a2 = /* @__PURE__ */ new Set(), l = [t], u2 = 0, c3 = () => {
      let d2 = false;
      for (; !d2; ) {
        let f = l.shift();
        if (!f) {
          u2 === 0 && h.end();
          return;
        }
        u2++, a2.add(f);
        let m2 = (w2, g2, S2 = false) => {
          if (w2) return h.emit("error", w2);
          if (i2 && !S2) {
            let E = [];
            for (let y3 of g2) y3.isSymbolicLink() && E.push(y3.realpath().then((b) => b?.isUnknown() ? b.lstat() : b));
            if (E.length) {
              Promise.all(E).then(() => m2(null, g2, true));
              return;
            }
          }
          for (let E of g2) E && (!r || r(E)) && (h.write(s ? E : E.fullpath()) || (d2 = true));
          u2--;
          for (let E of g2) {
            let y3 = E.realpathCached() || E;
            y3.shouldWalk(a2, o) && l.push(y3);
          }
          d2 && !h.flowing ? h.once("drain", c3) : p || c3();
        }, p = true;
        f.readdirCB(m2, true), p = false;
      }
    };
    return c3(), h;
  }
  streamSync(t = this.cwd, e = {}) {
    typeof t == "string" ? t = this.cwd.resolve(t) : t instanceof R3 || (e = t, t = this.cwd);
    let { withFileTypes: s = true, follow: i2 = false, filter: r, walkFilter: o } = e, h = new V({ objectMode: true }), a2 = /* @__PURE__ */ new Set();
    (!r || r(t)) && h.write(s ? t : t.fullpath());
    let l = [t], u2 = 0, c3 = () => {
      let d2 = false;
      for (; !d2; ) {
        let f = l.shift();
        if (!f) {
          u2 === 0 && h.end();
          return;
        }
        u2++, a2.add(f);
        let m2 = f.readdirSync();
        for (let p of m2) (!r || r(p)) && (h.write(s ? p : p.fullpath()) || (d2 = true));
        u2--;
        for (let p of m2) {
          let w2 = p;
          if (p.isSymbolicLink()) {
            if (!(i2 && (w2 = p.realpathSync()))) continue;
            w2.isUnknown() && w2.lstatSync();
          }
          w2.shouldWalk(a2, o) && l.push(w2);
        }
      }
      d2 && !h.flowing && h.once("drain", c3);
    };
    return c3(), h;
  }
  chdir(t = this.cwd) {
    let e = this.cwd;
    this.cwd = typeof t == "string" ? this.cwd.resolve(t) : t, this.cwd[Ye](e);
  }
};
var it = class extends It {
  sep = "\\";
  constructor(t = process.cwd(), e = {}) {
    let { nocase: s = true } = e;
    super(t, re, "\\", { ...e, nocase: s }), this.nocase = s;
    for (let i2 = this.cwd; i2; i2 = i2.parent) i2.nocase = this.nocase;
  }
  parseRootPath(t) {
    return re.parse(t).root.toUpperCase();
  }
  newRoot(t) {
    return new Pt(this.rootPath, U3, void 0, this.roots, this.nocase, this.childrenCache(), { fs: t });
  }
  isAbsolute(t) {
    return t.startsWith("/") || t.startsWith("\\") || /^[a-z]:(\/|\\)/i.test(t);
  }
};
var rt = class extends It {
  sep = "/";
  constructor(t = process.cwd(), e = {}) {
    let { nocase: s = false } = e;
    super(t, mi, "/", { ...e, nocase: s }), this.nocase = s;
  }
  parseRootPath(t) {
    return "/";
  }
  newRoot(t) {
    return new jt(this.rootPath, U3, void 0, this.roots, this.nocase, this.childrenCache(), { fs: t });
  }
  isAbsolute(t) {
    return t.startsWith("/");
  }
};
var St = class extends rt {
  constructor(t = process.cwd(), e = {}) {
    let { nocase: s = true } = e;
    super(t, { ...e, nocase: s });
  }
};
var Cr = process.platform === "win32" ? Pt : jt;
var Xe = process.platform === "win32" ? it : process.platform === "darwin" ? St : rt;
var Di = (n7) => n7.length >= 1;
var Mi = (n7) => n7.length >= 1;
var Ni = /* @__PURE__ */ Symbol.for("nodejs.util.inspect.custom");
var nt = class n4 {
  #t;
  #s;
  #n;
  length;
  #r;
  #o;
  #S;
  #w;
  #c;
  #h;
  #u = true;
  constructor(t, e, s, i2) {
    if (!Di(t)) throw new TypeError("empty pattern list");
    if (!Mi(e)) throw new TypeError("empty glob list");
    if (e.length !== t.length) throw new TypeError("mismatched pattern list and glob list lengths");
    if (this.length = t.length, s < 0 || s >= this.length) throw new TypeError("index out of range");
    if (this.#t = t, this.#s = e, this.#n = s, this.#r = i2, this.#n === 0) {
      if (this.isUNC()) {
        let [r, o, h, a2, ...l] = this.#t, [u2, c3, d2, f, ...m2] = this.#s;
        l[0] === "" && (l.shift(), m2.shift());
        let p = [r, o, h, a2, ""].join("/"), w2 = [u2, c3, d2, f, ""].join("/");
        this.#t = [p, ...l], this.#s = [w2, ...m2], this.length = this.#t.length;
      } else if (this.isDrive() || this.isAbsolute()) {
        let [r, ...o] = this.#t, [h, ...a2] = this.#s;
        o[0] === "" && (o.shift(), a2.shift());
        let l = r + "/", u2 = h + "/";
        this.#t = [l, ...o], this.#s = [u2, ...a2], this.length = this.#t.length;
      }
    }
  }
  [Ni]() {
    return "Pattern <" + this.#s.slice(this.#n).join("/") + ">";
  }
  pattern() {
    return this.#t[this.#n];
  }
  isString() {
    return typeof this.#t[this.#n] == "string";
  }
  isGlobstar() {
    return this.#t[this.#n] === A2;
  }
  isRegExp() {
    return this.#t[this.#n] instanceof RegExp;
  }
  globString() {
    return this.#S = this.#S || (this.#n === 0 ? this.isAbsolute() ? this.#s[0] + this.#s.slice(1).join("/") : this.#s.join("/") : this.#s.slice(this.#n).join("/"));
  }
  hasMore() {
    return this.length > this.#n + 1;
  }
  rest() {
    return this.#o !== void 0 ? this.#o : this.hasMore() ? (this.#o = new n4(this.#t, this.#s, this.#n + 1, this.#r), this.#o.#h = this.#h, this.#o.#c = this.#c, this.#o.#w = this.#w, this.#o) : this.#o = null;
  }
  isUNC() {
    let t = this.#t;
    return this.#c !== void 0 ? this.#c : this.#c = this.#r === "win32" && this.#n === 0 && t[0] === "" && t[1] === "" && typeof t[2] == "string" && !!t[2] && typeof t[3] == "string" && !!t[3];
  }
  isDrive() {
    let t = this.#t;
    return this.#w !== void 0 ? this.#w : this.#w = this.#r === "win32" && this.#n === 0 && this.length > 1 && typeof t[0] == "string" && /^[a-z]:$/i.test(t[0]);
  }
  isAbsolute() {
    let t = this.#t;
    return this.#h !== void 0 ? this.#h : this.#h = t[0] === "" && t.length > 1 || this.isDrive() || this.isUNC();
  }
  root() {
    let t = this.#t[0];
    return typeof t == "string" && this.isAbsolute() && this.#n === 0 ? t : "";
  }
  checkFollowGlobstar() {
    return !(this.#n === 0 || !this.isGlobstar() || !this.#u);
  }
  markFollowGlobstar() {
    return this.#n === 0 || !this.isGlobstar() || !this.#u ? false : (this.#u = false, true);
  }
};
var _i = typeof process == "object" && process && typeof process.platform == "string" ? process.platform : "linux";
var ot = class {
  relative;
  relativeChildren;
  absolute;
  absoluteChildren;
  platform;
  mmopts;
  constructor(t, { nobrace: e, nocase: s, noext: i2, noglobstar: r, platform: o = _i }) {
    this.relative = [], this.absolute = [], this.relativeChildren = [], this.absoluteChildren = [], this.platform = o, this.mmopts = { dot: true, nobrace: e, nocase: s, noext: i2, noglobstar: r, optimizationLevel: 2, platform: o, nocomment: true, nonegate: true };
    for (let h of t) this.add(h);
  }
  add(t) {
    let e = new D2(t, this.mmopts);
    for (let s = 0; s < e.set.length; s++) {
      let i2 = e.set[s], r = e.globParts[s];
      if (!i2 || !r) throw new Error("invalid pattern object");
      for (; i2[0] === "." && r[0] === "."; ) i2.shift(), r.shift();
      let o = new nt(i2, r, 0, this.platform), h = new D2(o.globString(), this.mmopts), a2 = r[r.length - 1] === "**", l = o.isAbsolute();
      l ? this.absolute.push(h) : this.relative.push(h), a2 && (l ? this.absoluteChildren.push(h) : this.relativeChildren.push(h));
    }
  }
  ignored(t) {
    let e = t.fullpath(), s = `${e}/`, i2 = t.relative() || ".", r = `${i2}/`;
    for (let o of this.relative) if (o.match(i2) || o.match(r)) return true;
    for (let o of this.absolute) if (o.match(e) || o.match(s)) return true;
    return false;
  }
  childrenIgnored(t) {
    let e = t.fullpath() + "/", s = (t.relative() || ".") + "/";
    for (let i2 of this.relativeChildren) if (i2.match(s)) return true;
    for (let i2 of this.absoluteChildren) if (i2.match(e)) return true;
    return false;
  }
};
var oe = class n5 {
  store;
  constructor(t = /* @__PURE__ */ new Map()) {
    this.store = t;
  }
  copy() {
    return new n5(new Map(this.store));
  }
  hasWalked(t, e) {
    return this.store.get(t.fullpath())?.has(e.globString());
  }
  storeWalked(t, e) {
    let s = t.fullpath(), i2 = this.store.get(s);
    i2 ? i2.add(e.globString()) : this.store.set(s, /* @__PURE__ */ new Set([e.globString()]));
  }
};
var he = class {
  store = /* @__PURE__ */ new Map();
  add(t, e, s) {
    let i2 = (e ? 2 : 0) | (s ? 1 : 0), r = this.store.get(t);
    this.store.set(t, r === void 0 ? i2 : i2 & r);
  }
  entries() {
    return [...this.store.entries()].map(([t, e]) => [t, !!(e & 2), !!(e & 1)]);
  }
};
var ae = class {
  store = /* @__PURE__ */ new Map();
  add(t, e) {
    if (!t.canReaddir()) return;
    let s = this.store.get(t);
    s ? s.find((i2) => i2.globString() === e.globString()) || s.push(e) : this.store.set(t, [e]);
  }
  get(t) {
    let e = this.store.get(t);
    if (!e) throw new Error("attempting to walk unknown path");
    return e;
  }
  entries() {
    return this.keys().map((t) => [t, this.store.get(t)]);
  }
  keys() {
    return [...this.store.keys()].filter((t) => t.canReaddir());
  }
};
var Et = class n6 {
  hasWalkedCache;
  matches = new he();
  subwalks = new ae();
  patterns;
  follow;
  dot;
  opts;
  constructor(t, e) {
    this.opts = t, this.follow = !!t.follow, this.dot = !!t.dot, this.hasWalkedCache = e ? e.copy() : new oe();
  }
  processPatterns(t, e) {
    this.patterns = e;
    let s = e.map((i2) => [t, i2]);
    for (let [i2, r] of s) {
      this.hasWalkedCache.storeWalked(i2, r);
      let o = r.root(), h = r.isAbsolute() && this.opts.absolute !== false;
      if (o) {
        i2 = i2.resolve(o === "/" && this.opts.root !== void 0 ? this.opts.root : o);
        let c3 = r.rest();
        if (c3) r = c3;
        else {
          this.matches.add(i2, true, false);
          continue;
        }
      }
      if (i2.isENOENT()) continue;
      let a2, l, u2 = false;
      for (; typeof (a2 = r.pattern()) == "string" && (l = r.rest()); ) i2 = i2.resolve(a2), r = l, u2 = true;
      if (a2 = r.pattern(), l = r.rest(), u2) {
        if (this.hasWalkedCache.hasWalked(i2, r)) continue;
        this.hasWalkedCache.storeWalked(i2, r);
      }
      if (typeof a2 == "string") {
        let c3 = a2 === ".." || a2 === "" || a2 === ".";
        this.matches.add(i2.resolve(a2), h, c3);
        continue;
      } else if (a2 === A2) {
        (!i2.isSymbolicLink() || this.follow || r.checkFollowGlobstar()) && this.subwalks.add(i2, r);
        let c3 = l?.pattern(), d2 = l?.rest();
        if (!l || (c3 === "" || c3 === ".") && !d2) this.matches.add(i2, h, c3 === "" || c3 === ".");
        else if (c3 === "..") {
          let f = i2.parent || i2;
          d2 ? this.hasWalkedCache.hasWalked(f, d2) || this.subwalks.add(f, d2) : this.matches.add(f, h, true);
        }
      } else a2 instanceof RegExp && this.subwalks.add(i2, r);
    }
    return this;
  }
  subwalkTargets() {
    return this.subwalks.keys();
  }
  child() {
    return new n6(this.opts, this.hasWalkedCache);
  }
  filterEntries(t, e) {
    let s = this.subwalks.get(t), i2 = this.child();
    for (let r of e) for (let o of s) {
      let h = o.isAbsolute(), a2 = o.pattern(), l = o.rest();
      a2 === A2 ? i2.testGlobstar(r, o, l, h) : a2 instanceof RegExp ? i2.testRegExp(r, a2, l, h) : i2.testString(r, a2, l, h);
    }
    return i2;
  }
  testGlobstar(t, e, s, i2) {
    if ((this.dot || !t.name.startsWith(".")) && (e.hasMore() || this.matches.add(t, i2, false), t.canReaddir() && (this.follow || !t.isSymbolicLink() ? this.subwalks.add(t, e) : t.isSymbolicLink() && (s && e.checkFollowGlobstar() ? this.subwalks.add(t, s) : e.markFollowGlobstar() && this.subwalks.add(t, e)))), s) {
      let r = s.pattern();
      if (typeof r == "string" && r !== ".." && r !== "" && r !== ".") this.testString(t, r, s.rest(), i2);
      else if (r === "..") {
        let o = t.parent || t;
        this.subwalks.add(o, s);
      } else r instanceof RegExp && this.testRegExp(t, r, s.rest(), i2);
    }
  }
  testRegExp(t, e, s, i2) {
    e.test(t.name) && (s ? this.subwalks.add(t, s) : this.matches.add(t, i2, false));
  }
  testString(t, e, s, i2) {
    t.isNamed(e) && (s ? this.subwalks.add(t, s) : this.matches.add(t, i2, false));
  }
};
var Li = (n7, t) => typeof n7 == "string" ? new ot([n7], t) : Array.isArray(n7) ? new ot(n7, t) : n7;
var zt = class {
  path;
  patterns;
  opts;
  seen = /* @__PURE__ */ new Set();
  paused = false;
  aborted = false;
  #t = [];
  #s;
  #n;
  signal;
  maxDepth;
  includeChildMatches;
  constructor(t, e, s) {
    if (this.patterns = t, this.path = e, this.opts = s, this.#n = !s.posix && s.platform === "win32" ? "\\" : "/", this.includeChildMatches = s.includeChildMatches !== false, (s.ignore || !this.includeChildMatches) && (this.#s = Li(s.ignore ?? [], s), !this.includeChildMatches && typeof this.#s.add != "function")) {
      let i2 = "cannot ignore child matches, ignore lacks add() method.";
      throw new Error(i2);
    }
    this.maxDepth = s.maxDepth || 1 / 0, s.signal && (this.signal = s.signal, this.signal.addEventListener("abort", () => {
      this.#t.length = 0;
    }));
  }
  #r(t) {
    return this.seen.has(t) || !!this.#s?.ignored?.(t);
  }
  #o(t) {
    return !!this.#s?.childrenIgnored?.(t);
  }
  pause() {
    this.paused = true;
  }
  resume() {
    if (this.signal?.aborted) return;
    this.paused = false;
    let t;
    for (; !this.paused && (t = this.#t.shift()); ) t();
  }
  onResume(t) {
    this.signal?.aborted || (this.paused ? this.#t.push(t) : t());
  }
  async matchCheck(t, e) {
    if (e && this.opts.nodir) return;
    let s;
    if (this.opts.realpath) {
      if (s = t.realpathCached() || await t.realpath(), !s) return;
      t = s;
    }
    let r = t.isUnknown() || this.opts.stat ? await t.lstat() : t;
    if (this.opts.follow && this.opts.nodir && r?.isSymbolicLink()) {
      let o = await r.realpath();
      o && (o.isUnknown() || this.opts.stat) && await o.lstat();
    }
    return this.matchCheckTest(r, e);
  }
  matchCheckTest(t, e) {
    return t && (this.maxDepth === 1 / 0 || t.depth() <= this.maxDepth) && (!e || t.canReaddir()) && (!this.opts.nodir || !t.isDirectory()) && (!this.opts.nodir || !this.opts.follow || !t.isSymbolicLink() || !t.realpathCached()?.isDirectory()) && !this.#r(t) ? t : void 0;
  }
  matchCheckSync(t, e) {
    if (e && this.opts.nodir) return;
    let s;
    if (this.opts.realpath) {
      if (s = t.realpathCached() || t.realpathSync(), !s) return;
      t = s;
    }
    let r = t.isUnknown() || this.opts.stat ? t.lstatSync() : t;
    if (this.opts.follow && this.opts.nodir && r?.isSymbolicLink()) {
      let o = r.realpathSync();
      o && (o?.isUnknown() || this.opts.stat) && o.lstatSync();
    }
    return this.matchCheckTest(r, e);
  }
  matchFinish(t, e) {
    if (this.#r(t)) return;
    if (!this.includeChildMatches && this.#s?.add) {
      let r = `${t.relativePosix()}/**`;
      this.#s.add(r);
    }
    let s = this.opts.absolute === void 0 ? e : this.opts.absolute;
    this.seen.add(t);
    let i2 = this.opts.mark && t.isDirectory() ? this.#n : "";
    if (this.opts.withFileTypes) this.matchEmit(t);
    else if (s) {
      let r = this.opts.posix ? t.fullpathPosix() : t.fullpath();
      this.matchEmit(r + i2);
    } else {
      let r = this.opts.posix ? t.relativePosix() : t.relative(), o = this.opts.dotRelative && !r.startsWith(".." + this.#n) ? "." + this.#n : "";
      this.matchEmit(r ? o + r + i2 : "." + i2);
    }
  }
  async match(t, e, s) {
    let i2 = await this.matchCheck(t, s);
    i2 && this.matchFinish(i2, e);
  }
  matchSync(t, e, s) {
    let i2 = this.matchCheckSync(t, s);
    i2 && this.matchFinish(i2, e);
  }
  walkCB(t, e, s) {
    this.signal?.aborted && s(), this.walkCB2(t, e, new Et(this.opts), s);
  }
  walkCB2(t, e, s, i2) {
    if (this.#o(t)) return i2();
    if (this.signal?.aborted && i2(), this.paused) {
      this.onResume(() => this.walkCB2(t, e, s, i2));
      return;
    }
    s.processPatterns(t, e);
    let r = 1, o = () => {
      --r === 0 && i2();
    };
    for (let [h, a2, l] of s.matches.entries()) this.#r(h) || (r++, this.match(h, a2, l).then(() => o()));
    for (let h of s.subwalkTargets()) {
      if (this.maxDepth !== 1 / 0 && h.depth() >= this.maxDepth) continue;
      r++;
      let a2 = h.readdirCached();
      h.calledReaddir() ? this.walkCB3(h, a2, s, o) : h.readdirCB((l, u2) => this.walkCB3(h, u2, s, o), true);
    }
    o();
  }
  walkCB3(t, e, s, i2) {
    s = s.filterEntries(t, e);
    let r = 1, o = () => {
      --r === 0 && i2();
    };
    for (let [h, a2, l] of s.matches.entries()) this.#r(h) || (r++, this.match(h, a2, l).then(() => o()));
    for (let [h, a2] of s.subwalks.entries()) r++, this.walkCB2(h, a2, s.child(), o);
    o();
  }
  walkCBSync(t, e, s) {
    this.signal?.aborted && s(), this.walkCB2Sync(t, e, new Et(this.opts), s);
  }
  walkCB2Sync(t, e, s, i2) {
    if (this.#o(t)) return i2();
    if (this.signal?.aborted && i2(), this.paused) {
      this.onResume(() => this.walkCB2Sync(t, e, s, i2));
      return;
    }
    s.processPatterns(t, e);
    let r = 1, o = () => {
      --r === 0 && i2();
    };
    for (let [h, a2, l] of s.matches.entries()) this.#r(h) || this.matchSync(h, a2, l);
    for (let h of s.subwalkTargets()) {
      if (this.maxDepth !== 1 / 0 && h.depth() >= this.maxDepth) continue;
      r++;
      let a2 = h.readdirSync();
      this.walkCB3Sync(h, a2, s, o);
    }
    o();
  }
  walkCB3Sync(t, e, s, i2) {
    s = s.filterEntries(t, e);
    let r = 1, o = () => {
      --r === 0 && i2();
    };
    for (let [h, a2, l] of s.matches.entries()) this.#r(h) || this.matchSync(h, a2, l);
    for (let [h, a2] of s.subwalks.entries()) r++, this.walkCB2Sync(h, a2, s.child(), o);
    o();
  }
};
var xt = class extends zt {
  matches = /* @__PURE__ */ new Set();
  constructor(t, e, s) {
    super(t, e, s);
  }
  matchEmit(t) {
    this.matches.add(t);
  }
  async walk() {
    if (this.signal?.aborted) throw this.signal.reason;
    return this.path.isUnknown() && await this.path.lstat(), await new Promise((t, e) => {
      this.walkCB(this.path, this.patterns, () => {
        this.signal?.aborted ? e(this.signal.reason) : t(this.matches);
      });
    }), this.matches;
  }
  walkSync() {
    if (this.signal?.aborted) throw this.signal.reason;
    return this.path.isUnknown() && this.path.lstatSync(), this.walkCBSync(this.path, this.patterns, () => {
      if (this.signal?.aborted) throw this.signal.reason;
    }), this.matches;
  }
};
var vt = class extends zt {
  results;
  constructor(t, e, s) {
    super(t, e, s), this.results = new V({ signal: this.signal, objectMode: true }), this.results.on("drain", () => this.resume()), this.results.on("resume", () => this.resume());
  }
  matchEmit(t) {
    this.results.write(t), this.results.flowing || this.pause();
  }
  stream() {
    let t = this.path;
    return t.isUnknown() ? t.lstat().then(() => {
      this.walkCB(t, this.patterns, () => this.results.end());
    }) : this.walkCB(t, this.patterns, () => this.results.end()), this.results;
  }
  streamSync() {
    return this.path.isUnknown() && this.path.lstatSync(), this.walkCBSync(this.path, this.patterns, () => this.results.end()), this.results;
  }
};
var Pi = typeof process == "object" && process && typeof process.platform == "string" ? process.platform : "linux";
var I3 = class {
  absolute;
  cwd;
  root;
  dot;
  dotRelative;
  follow;
  ignore;
  magicalBraces;
  mark;
  matchBase;
  maxDepth;
  nobrace;
  nocase;
  nodir;
  noext;
  noglobstar;
  pattern;
  platform;
  realpath;
  scurry;
  stat;
  signal;
  windowsPathsNoEscape;
  withFileTypes;
  includeChildMatches;
  opts;
  patterns;
  constructor(t, e) {
    if (!e) throw new TypeError("glob options required");
    if (this.withFileTypes = !!e.withFileTypes, this.signal = e.signal, this.follow = !!e.follow, this.dot = !!e.dot, this.dotRelative = !!e.dotRelative, this.nodir = !!e.nodir, this.mark = !!e.mark, e.cwd ? (e.cwd instanceof URL || e.cwd.startsWith("file://")) && (e.cwd = Wi(e.cwd)) : this.cwd = "", this.cwd = e.cwd || "", this.root = e.root, this.magicalBraces = !!e.magicalBraces, this.nobrace = !!e.nobrace, this.noext = !!e.noext, this.realpath = !!e.realpath, this.absolute = e.absolute, this.includeChildMatches = e.includeChildMatches !== false, this.noglobstar = !!e.noglobstar, this.matchBase = !!e.matchBase, this.maxDepth = typeof e.maxDepth == "number" ? e.maxDepth : 1 / 0, this.stat = !!e.stat, this.ignore = e.ignore, this.withFileTypes && this.absolute !== void 0) throw new Error("cannot set absolute and withFileTypes:true");
    if (typeof t == "string" && (t = [t]), this.windowsPathsNoEscape = !!e.windowsPathsNoEscape || e.allowWindowsEscape === false, this.windowsPathsNoEscape && (t = t.map((a2) => a2.replace(/\\/g, "/"))), this.matchBase) {
      if (e.noglobstar) throw new TypeError("base matching requires globstar");
      t = t.map((a2) => a2.includes("/") ? a2 : `./**/${a2}`);
    }
    if (this.pattern = t, this.platform = e.platform || Pi, this.opts = { ...e, platform: this.platform }, e.scurry) {
      if (this.scurry = e.scurry, e.nocase !== void 0 && e.nocase !== e.scurry.nocase) throw new Error("nocase option contradicts provided scurry option");
    } else {
      let a2 = e.platform === "win32" ? it : e.platform === "darwin" ? St : e.platform ? rt : Xe;
      this.scurry = new a2(this.cwd, { nocase: e.nocase, fs: e.fs });
    }
    this.nocase = this.scurry.nocase;
    let s = this.platform === "darwin" || this.platform === "win32", i2 = { braceExpandMax: 1e4, ...e, dot: this.dot, matchBase: this.matchBase, nobrace: this.nobrace, nocase: this.nocase, nocaseMagicOnly: s, nocomment: true, noext: this.noext, nonegate: true, optimizationLevel: 2, platform: this.platform, windowsPathsNoEscape: this.windowsPathsNoEscape, debug: !!this.opts.debug }, r = this.pattern.map((a2) => new D2(a2, i2)), [o, h] = r.reduce((a2, l) => (a2[0].push(...l.set), a2[1].push(...l.globParts), a2), [[], []]);
    this.patterns = o.map((a2, l) => {
      let u2 = h[l];
      if (!u2) throw new Error("invalid pattern object");
      return new nt(a2, u2, 0, this.platform);
    });
  }
  async walk() {
    return [...await new xt(this.patterns, this.scurry.cwd, { ...this.opts, maxDepth: this.maxDepth !== 1 / 0 ? this.maxDepth + this.scurry.cwd.depth() : 1 / 0, platform: this.platform, nocase: this.nocase, includeChildMatches: this.includeChildMatches }).walk()];
  }
  walkSync() {
    return [...new xt(this.patterns, this.scurry.cwd, { ...this.opts, maxDepth: this.maxDepth !== 1 / 0 ? this.maxDepth + this.scurry.cwd.depth() : 1 / 0, platform: this.platform, nocase: this.nocase, includeChildMatches: this.includeChildMatches }).walkSync()];
  }
  stream() {
    return new vt(this.patterns, this.scurry.cwd, { ...this.opts, maxDepth: this.maxDepth !== 1 / 0 ? this.maxDepth + this.scurry.cwd.depth() : 1 / 0, platform: this.platform, nocase: this.nocase, includeChildMatches: this.includeChildMatches }).stream();
  }
  streamSync() {
    return new vt(this.patterns, this.scurry.cwd, { ...this.opts, maxDepth: this.maxDepth !== 1 / 0 ? this.maxDepth + this.scurry.cwd.depth() : 1 / 0, platform: this.platform, nocase: this.nocase, includeChildMatches: this.includeChildMatches }).streamSync();
  }
  iterateSync() {
    return this.streamSync()[Symbol.iterator]();
  }
  [Symbol.iterator]() {
    return this.iterateSync();
  }
  iterate() {
    return this.stream()[Symbol.asyncIterator]();
  }
  [Symbol.asyncIterator]() {
    return this.iterate();
  }
};
var le = (n7, t = {}) => {
  Array.isArray(n7) || (n7 = [n7]);
  for (let e of n7) if (new D2(e, t).hasMagic()) return true;
  return false;
};
function Bt(n7, t = {}) {
  return new I3(n7, t).streamSync();
}
function Qe(n7, t = {}) {
  return new I3(n7, t).stream();
}
function ts(n7, t = {}) {
  return new I3(n7, t).walkSync();
}
async function Je(n7, t = {}) {
  return new I3(n7, t).walk();
}
function Ut(n7, t = {}) {
  return new I3(n7, t).iterateSync();
}
function es(n7, t = {}) {
  return new I3(n7, t).iterate();
}
var ji = Bt;
var Ii = Object.assign(Qe, { sync: Bt });
var zi = Ut;
var Bi = Object.assign(es, { sync: Ut });
var Ui = Object.assign(ts, { stream: Bt, iterate: Ut });
var Ze = Object.assign(Je, { glob: Je, globSync: ts, sync: Ui, globStream: Qe, stream: Ii, globStreamSync: Bt, streamSync: ji, globIterate: es, iterate: Bi, globIterateSync: Ut, iterateSync: zi, Glob: I3, hasMagic: le, escape: tt, unescape: W2 });
Ze.glob = Ze;

export {
  L,
  promiseSpawn,
  which,
  whichSync,
  ts,
  Ze
};
