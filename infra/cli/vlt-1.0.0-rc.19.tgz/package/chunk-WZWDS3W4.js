var global = globalThis;
import {Buffer} from "node:buffer";
import {setTimeout as _vlt_setTimeout,clearTimeout as _vlt_clearTimeout,setImmediate as _vlt_setImmediate,clearImmediate as _vlt_clearImmediate,setInterval as _vlt_setInterval,clearInterval as _vlt_clearInterval} from "node:timers";
globalThis.setTimeout = _vlt_setTimeout;
globalThis.clearTimeout = _vlt_clearTimeout;
globalThis.setImmediate = _vlt_setImmediate;
globalThis.clearImmediate = _vlt_clearImmediate;
globalThis.setInterval = _vlt_setInterval;
globalThis.clearInterval = _vlt_clearInterval;
import {createRequire as _vlt_createRequire} from "node:module";
var require = _vlt_createRequire(import.meta.filename);

// ../../src/error-cause/src/index.ts
var { captureStackTrace } = Error;
function create(cls, defaultFrom, message, cause, from = defaultFrom) {
  const er = new cls(message, cause ? { cause } : void 0);
  captureStackTrace?.(er, from);
  return er;
}
function error(message, cause, from) {
  return create(Error, error, message, cause, from);
}
function typeError(message, cause, from) {
  return create(TypeError, typeError, message, cause, from);
}
function syntaxError(message, cause, from) {
  return create(
    SyntaxError,
    syntaxError,
    message,
    cause,
    from
  );
}

export {
  error,
  typeError,
  syntaxError
};
