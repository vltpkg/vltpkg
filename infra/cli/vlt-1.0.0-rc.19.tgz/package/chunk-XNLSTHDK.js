var global = globalThis;
import {Buffer} from "node:buffer";
import {setTimeout as _vlt_setTimeout,clearTimeout as _vlt_clearTimeout,setImmediate as _vlt_setImmediate,clearImmediate as _vlt_clearImmediate,setInterval as _vlt_setInterval,clearInterval as _vlt_clearInterval} from "node:timers";
globalThis.setTimeout = _vlt_setTimeout;
globalThis.clearTimeout = _vlt_clearTimeout;
globalThis.setImmediate = _vlt_setImmediate;
globalThis.clearImmediate = _vlt_clearImmediate;
globalThis.setInterval = _vlt_setInterval;
globalThis.clearInterval = _vlt_clearInterval;
import {createRequire as _vlt_createRequire} from "node:module";
var require = _vlt_createRequire(import.meta.filename);

// ../../src/xdg/src/index.ts
import { homedir, tmpdir } from "node:os";
import { resolve } from "node:path";
var root = homedir();
var path = (p) => resolve(root, p);
var defaults = process.platform === "darwin" ? (which) => {
  switch (which) {
    case "config":
      return path("Library/Preferences");
    case "cache":
      return path("Library/Caches");
    case "data":
      return path("Library/Application Support");
    case "state":
      return path("Library/State");
    case "runtime":
      return resolve(
        tmpdir(),
        /* c8 ignore next */
        String(process.getuid?.() ?? ""),
        ".run"
      );
  }
} : process.platform === "win32" ? (which) => {
  const ad = process.env.APPDATA ?? path("AppData/Roaming");
  const lad = process.env.LOCALAPPDATA ?? path("AppData/Local");
  switch (which) {
    case "config":
      return resolve(ad, "xdg.config");
    case "cache":
      return resolve(lad, "xdg.cache");
    case "data":
      return resolve(ad, "xdg.data");
    case "state":
      return resolve(lad, "xdg.state");
    case "runtime":
      return resolve(tmpdir(), "xdg.run");
  }
} : (which) => {
  switch (which) {
    case "config":
      return path(".config");
    case "cache":
      return path(".cache");
    case "data":
      return path(".local/share");
    case "state":
      return path(".local/state");
    case "runtime":
      return resolve(
        tmpdir(),
        /* c8 ignore next */
        String(process.getuid?.() ?? ""),
        ".run"
      );
  }
};
var {
  XDG_CONFIG_HOME = defaults("config"),
  XDG_CACHE_HOME = defaults("cache"),
  XDG_DATA_HOME = defaults("data"),
  XDG_STATE_HOME = defaults("state"),
  XDG_RUNTIME_DIR = defaults("runtime")
} = process.env;
var XDG = class {
  name;
  base = {
    config: XDG_CONFIG_HOME,
    cache: XDG_CACHE_HOME,
    data: XDG_DATA_HOME,
    state: XDG_STATE_HOME,
    runtime: XDG_RUNTIME_DIR
  };
  constructor(name) {
    this.name = name;
  }
  config(p = "") {
    return resolve(this.base.config, this.name, p);
  }
  cache(p = "") {
    return resolve(this.base.cache, this.name, p);
  }
  data(p = "") {
    return resolve(this.base.data, this.name, p);
  }
  state(p = "") {
    return resolve(this.base.state, this.name, p);
  }
  runtime(p = "") {
    return resolve(this.base.runtime, this.name, p);
  }
};

export {
  XDG
};
