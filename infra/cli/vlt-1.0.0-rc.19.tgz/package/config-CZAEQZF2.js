var global = globalThis;
import {Buffer} from "node:buffer";
import {setTimeout as _vlt_setTimeout,clearTimeout as _vlt_clearTimeout,setImmediate as _vlt_setImmediate,clearImmediate as _vlt_clearImmediate,setInterval as _vlt_setInterval,clearInterval as _vlt_clearInterval} from "node:timers";
globalThis.setTimeout = _vlt_setTimeout;
globalThis.clearTimeout = _vlt_clearTimeout;
globalThis.setImmediate = _vlt_setImmediate;
globalThis.clearImmediate = _vlt_clearImmediate;
globalThis.setInterval = _vlt_setInterval;
globalThis.clearInterval = _vlt_clearInterval;
import {createRequire as _vlt_createRequire} from "node:module";
var require = _vlt_createRequire(import.meta.filename);
import {
  get,
  set
} from "./chunk-DBANBIL2.js";
import {
  asRootError
} from "./chunk-5WHVV7CQ.js";
import {
  pairsToRecords,
  recordsToPairs
} from "./chunk-Y4AEKTU6.js";
import {
  commandUsage
} from "./chunk-5E5GX4G6.js";
import "./chunk-5ZY2OA3F.js";
import "./chunk-FI5TUER7.js";
import "./chunk-JQKBSJDB.js";
import "./chunk-D7U7KDEM.js";
import "./chunk-2TOZR3L2.js";
import "./chunk-BGQCUUCA.js";
import "./chunk-E74WGW5C.js";
import "./chunk-FEV5BCW7.js";
import "./chunk-VCSVHRCS.js";
import {
  getSortedKeys,
  isRecordField
} from "./chunk-D27QPHKI.js";
import "./chunk-JLJKOF75.js";
import {
  isObject
} from "./chunk-KXBF4HVG.js";
import {
  find,
  load
} from "./chunk-HTOTG4TS.js";
import "./chunk-XNLSTHDK.js";
import {
  error
} from "./chunk-WZWDS3W4.js";
import "./chunk-PZLD7RTK.js";

// ../../src/cli-sdk/src/commands/config.ts
import assert from "node:assert";

// ../../src/config/src/index.ts
import { spawnSync } from "node:child_process";
var list = (conf) => {
  return recordsToPairs(conf.options);
};
var del = async (conf) => {
  const fields = conf.positionals.slice(1);
  if (!fields.length) {
    throw error("At least one key is required", {
      code: "EUSAGE"
    });
  }
  const configOption = conf.get("config");
  const whichConfig = configOption === "all" ? "project" : configOption;
  await conf.deleteConfigKeys(whichConfig, fields);
};
var get2 = async (conf) => {
  const keys = conf.positionals.slice(1);
  const k = keys[0];
  if (!k || keys.length > 1) {
    throw error("Exactly one key is required", {
      code: "EUSAGE"
    });
  }
  if (k.includes(".")) {
    const [field, ...rest] = k.split(".");
    const subKey = rest.join(".");
    if (!field || !subKey) {
      throw error("Could not read property", {
        found: k
      });
    }
    const record = conf.getRecord(field);
    return get(record, subKey);
  }
  return isRecordField(k) ? conf.getRecord(k) : conf.get(k);
};
var edit = async (conf) => {
  const [command2, ...args] = conf.get("editor").split(" ");
  if (!command2) {
    throw error(`editor is empty`);
  }
  const configOption = conf.get("config");
  const whichConfig = configOption === "all" ? "project" : configOption;
  await conf.editConfigFile(whichConfig, (file) => {
    args.push(file);
    const res = spawnSync(command2, args, {
      stdio: "inherit"
    });
    if (res.status !== 0) {
      throw error(`${command2} command failed`, {
        ...res,
        command: command2,
        args
      });
    }
  });
};
var set2 = async (conf) => {
  const pairs = conf.positionals.slice(1);
  if (!pairs.length) {
    const configOption2 = conf.get("config");
    const whichConfig = configOption2 === "all" ? "project" : configOption2;
    await conf.addConfigToFile(whichConfig, {});
    return;
  }
  const configOption = conf.get("config");
  const which = configOption === "all" ? "project" : configOption;
  const dotPropPairs = [];
  const simplePairs = [];
  for (const pair of pairs) {
    const eq = pair.indexOf("=");
    if (eq === -1) {
      throw error("Set arguments must contain `=`", {
        code: "EUSAGE"
      });
    }
    const key = pair.substring(0, eq);
    const value = pair.substring(eq + 1);
    if (key.includes(".")) {
      const [field, ...rest] = key.split(".");
      const subKey = rest.join(".");
      if (field && subKey) {
        dotPropPairs.push({ key, field, subKey, value });
      } else {
        throw error("Could not read property", {
          found: pair
        });
      }
    } else {
      simplePairs.push(pair);
    }
  }
  if (simplePairs.length > 0) {
    try {
      const parsed = conf.jack.parseRaw(
        simplePairs.map((kv) => `--${kv}`)
      ).values;
      await conf.addConfigToFile(which, pairsToRecords(parsed));
    } catch (err) {
      handleSetError(simplePairs, err);
    }
  }
  if (dotPropPairs.length > 0) {
    const recordPairs = [];
    const nestedProps = [];
    for (const { key, field, subKey, value } of dotPropPairs) {
      if (isRecordField(field)) {
        recordPairs.push({ field, subKey, value });
      } else {
        nestedProps.push({ key, value });
      }
    }
    for (const { field, subKey, value } of recordPairs) {
      const recordPair = `${field}=${subKey}=${value}`;
      try {
        const parsed = conf.jack.parseRaw([`--${recordPair}`]).values;
        await conf.addConfigToFile(which, pairsToRecords(parsed));
      } catch (err) {
        handleSetError([recordPair], err);
      }
    }
    if (nestedProps.length > 0) {
      const nested = {};
      for (const { key, value } of nestedProps) {
        set(nested, key, value);
      }
      await conf.addConfigToFile(which, nested);
    }
  }
};
var handleSetError = (simplePairs, err) => {
  const { name, found, validOptions } = asRootError(err).cause;
  if (isObject(found) && typeof found.name === "string" && typeof found.value === "string") {
    const { name: name2, value } = found;
    throw error(
      `Boolean flag must be "${name2}" or "no-${name2}", not a value`,
      {
        code: "ECONFIG",
        name: name2,
        found: `${name2}=${value}`
      }
    );
  }
  if (Array.isArray(validOptions)) {
    throw error(`Invalid value provided for ${name}`, {
      code: "ECONFIG",
      found,
      validOptions
    });
  }
  throw error("Invalid config keys", {
    code: "ECONFIG",
    found: simplePairs.map((kv) => kv.split("=")[0]),
    validOptions: getSortedKeys()
  });
};

// ../../src/cli-sdk/src/commands/config.ts
var views = {
  human: (results) => {
    if (Array.isArray(results) && typeof results[0] === "string") {
      return results.join("\n");
    }
    return JSON.stringify(results, null, 2);
  }
};
var usage = () => commandUsage({
  command: "config",
  usage: "[<command>] [<args>]",
  description: "Get or manipulate vlt configuration values",
  options: {
    config: {
      value: "<all | user | project>",
      description: "Specify which configuration to show or operate on."
    }
  },
  subcommands: {
    get: {
      usage: "[<key>] [--config=<all | user | project>]",
      description: "Get a single config value. Use --config to specify which config to read from."
    },
    pick: {
      usage: "[<key> [<key> ...]] [--config=<all | user | project>]",
      description: "Get multiple config values or all configuration. Use --config to specify which config to read from."
    },
    list: {
      usage: "[--config=<all | user | project>]",
      description: "Print configuration settings. --config=all shows merged config (default), --config=user shows only user config, --config=project shows only project config."
    },
    set: {
      usage: "<key>=<value> [<key>=<value> ...] [--config=<all | user | project>]",
      description: `Set config values. By default (or with --config=all), these are
                      written to the project config file, \`vlt.json\`
                      in the root of the project. To set things for all
                      projects, run with \`--config=user\`.`
    },
    delete: {
      usage: "<key> [<key> ...] [--config=<all | user | project>]",
      description: `Delete the named config fields. If no values remain in
                      the config file, delete the file as well. By default
                      (or with --config=all), operates on the \`vlt.json\` file in
                      the root of the current project. To delete a config field from
                      the user config file, specify \`--config=user\`.`
    },
    edit: {
      usage: "[--config=<all | user | project>]",
      description: "Edit the configuration file. By default (or with --config=all), edits the project config file."
    },
    location: {
      usage: "[--config=<user | project>]",
      description: "Show the file path of the configuration file. Defaults to project config."
    }
  }
});
var command = async (conf) => {
  const [sub] = conf.positionals;
  assert(
    sub,
    error("config command requires a subcommand", {
      code: "EUSAGE",
      validOptions: [
        "get",
        "pick",
        "set",
        "delete",
        "list",
        "edit",
        "location"
      ]
    })
  );
  switch (sub) {
    case "set":
      return configSet(conf);
    case "get":
      return configGet(conf);
    case "pick":
      return configPick(conf);
    case "ls":
    case "list":
      return configList(conf);
    case "edit":
      return configEdit(conf);
    case "location":
      return configLocation(conf);
    case "del":
    case "delete":
    case "rm":
    case "remove":
    case "unset":
      return configDelete(conf);
    default: {
      throw error("Unrecognized config command", {
        code: "EUSAGE",
        found: sub,
        validOptions: [
          "get",
          "pick",
          "set",
          "delete",
          "list",
          "edit",
          "location"
        ]
      });
    }
  }
};
var configGet = async (conf) => {
  const keys = conf.positionals.slice(1);
  const configOption = conf.get("config");
  if (keys.length === 0) {
    return configPick(conf);
  }
  if (keys.length === 1) {
    const key = keys[0];
    if (!key) {
      throw error("Key is required", { code: "EUSAGE" });
    }
    switch (configOption) {
      case "all": {
        const result = await get2(conf);
        return result;
      }
      case "user": {
        return getUserConfigValue(key);
      }
      case "project": {
        return getProjectConfigValue(key);
      }
      default: {
        const result = await get2(conf);
        return result;
      }
    }
  }
  return configPick(conf);
};
var configPick = async (conf) => {
  const keys = conf.positionals.slice(1);
  const configOption = conf.get("config");
  if (keys.length === 0) {
    switch (configOption) {
      case "all":
        return getSerializableConfig(conf);
      case "user": {
        const userConfig = getUserConfigObject();
        return userConfig ?? {};
      }
      case "project": {
        const projectConfig = getProjectConfigObject();
        return projectConfig ?? {};
      }
    }
  }
  const result = {};
  for (const key of keys) {
    if (!key) continue;
    switch (configOption) {
      case "all":
        result[key] = await get2(
          Object.assign(
            Object.create(Object.getPrototypeOf(conf)),
            conf,
            {
              positionals: ["get", key]
            }
          )
        );
        break;
      case "user":
        result[key] = getUserConfigValue(key);
        break;
      case "project":
        result[key] = getProjectConfigValue(key);
        break;
    }
  }
  return result;
};
var configList = (conf) => {
  const configOption = conf.get("config");
  switch (configOption) {
    case "all":
      return list(conf);
    case "user":
      return getUserConfigList();
    case "project":
      return getProjectConfigList();
    default:
      return list(conf);
  }
};
var configToStringArray = (config) => {
  const result = [];
  for (const [key, value] of Object.entries(config)) {
    if (value === void 0 || value === null) {
      continue;
    }
    if (Array.isArray(value)) {
      for (const item of value) {
        if (typeof item === "string") {
          result.push(`${key}=${item}`);
        }
      }
    } else if (typeof value === "object") {
      for (const [subKey, subValue] of Object.entries(value)) {
        if (subValue !== void 0 && subValue !== null) {
          result.push(`${key}.${subKey}=${String(subValue)}`);
        }
      }
    } else {
      let stringValue;
      if (typeof value === "string") {
        stringValue = value;
      } else if (typeof value === "number" || typeof value === "boolean") {
        stringValue = String(value);
      } else {
        stringValue = "[object]";
      }
      result.push(`${key}=${stringValue}`);
    }
  }
  return result.sort();
};
var getUserConfigList = () => {
  try {
    const userConfig = load(
      "config",
      (x, file) => {
        if (x !== null && typeof x === "object" && !Array.isArray(x)) {
          return;
        }
        throw new Error(`Invalid config in ${file}`);
      },
      "user"
    );
    if (!userConfig) return (
      /* c8 ignore next */
      []
    );
    return configToStringArray(userConfig);
  } catch (_err) {
    return [];
  }
};
var getProjectConfigList = () => {
  try {
    const projectConfig = load(
      "config",
      (x, file) => {
        if (x !== null && typeof x === "object" && !Array.isArray(x)) {
          return;
        }
        throw new Error(`Invalid config in ${file}`);
      },
      "project"
    );
    if (!projectConfig) return (
      /* c8 ignore next */
      []
    );
    return configToStringArray(projectConfig);
  } catch (_err) {
    return [];
  }
};
var getUserConfigObject = () => {
  try {
    const userConfig = load(
      "config",
      (x, file) => {
        if (x !== null && typeof x === "object" && !Array.isArray(x)) {
          return;
        }
        throw new Error(`Invalid config in ${file}`);
      },
      "user"
    );
    if (!userConfig || typeof userConfig !== "object")
      return;
    return userConfig;
  } catch (_err) {
    return;
  }
};
var getUserConfigValue = (key) => {
  const userConfig = getUserConfigObject();
  if (!userConfig) return;
  return get(userConfig, key);
};
var getProjectConfigObject = () => {
  try {
    const projectConfig = load(
      "config",
      (x, file) => {
        if (x !== null && typeof x === "object" && !Array.isArray(x)) {
          return;
        }
        throw new Error(`Invalid config in ${file}`);
      },
      "project"
    );
    if (!projectConfig || typeof projectConfig !== "object")
      return;
    return projectConfig;
  } catch (_err) {
    return;
  }
};
var getProjectConfigValue = (key) => {
  const projectConfig = getProjectConfigObject();
  if (!projectConfig) return;
  return get(
    projectConfig,
    key
  );
};
var getWriteConfigOption = (conf) => {
  const configOption = conf.get("config");
  if (configOption === "all") {
    return "project";
  }
  return configOption;
};
var configSet = async (conf) => {
  const effectiveConfig = getWriteConfigOption(conf);
  const originalGet = conf.get;
  conf.get = ((key) => {
    if (key === "config") {
      return effectiveConfig;
    }
    return originalGet.call(conf, key);
  });
  try {
    return await set2(conf);
  } finally {
    conf.get = originalGet;
  }
};
var configDelete = async (conf) => {
  const effectiveConfig = getWriteConfigOption(conf);
  const originalGet = conf.get;
  conf.get = ((key) => {
    if (key === "config") {
      return effectiveConfig;
    }
    return originalGet.call(conf, key);
  });
  try {
    return await del(conf);
  } finally {
    conf.get = originalGet;
  }
};
var configEdit = async (conf) => {
  const effectiveConfig = getWriteConfigOption(conf);
  const originalGet = conf.get;
  conf.get = ((key) => {
    if (key === "config") {
      return effectiveConfig;
    }
    return originalGet.call(conf, key);
  });
  try {
    return await edit(conf);
  } finally {
    conf.get = originalGet;
  }
};
var getSerializableConfig = (conf) => {
  return list(conf);
};
var configLocation = (conf) => {
  const configOption = conf.get("config");
  const effectiveConfig = configOption === "all" ? "project" : configOption;
  const configPath = find(effectiveConfig);
  return configPath;
};
export {
  command,
  usage,
  views
};
