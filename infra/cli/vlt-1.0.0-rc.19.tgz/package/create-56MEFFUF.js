var global = globalThis;
import {Buffer} from "node:buffer";
import {setTimeout as _vlt_setTimeout,clearTimeout as _vlt_clearTimeout,setImmediate as _vlt_setImmediate,clearImmediate as _vlt_clearImmediate,setInterval as _vlt_setInterval,clearInterval as _vlt_clearInterval} from "node:timers";
globalThis.setTimeout = _vlt_setTimeout;
globalThis.clearTimeout = _vlt_clearTimeout;
globalThis.setImmediate = _vlt_setImmediate;
globalThis.clearImmediate = _vlt_clearImmediate;
globalThis.setInterval = _vlt_setInterval;
globalThis.clearInterval = _vlt_clearInterval;
import {createRequire as _vlt_createRequire} from "node:module";
var require = _vlt_createRequire(import.meta.filename);
import {
  vlxResolve
} from "./chunk-FK43DC3Q.js";
import {
  ExecCommand,
  views
} from "./chunk-ELHX2DD4.js";
import "./chunk-RIYFGX27.js";
import {
  styleTextStdout
} from "./chunk-2M5IL56T.js";
import "./chunk-TDTJOKF2.js";
import "./chunk-VTEFO2FT.js";
import "./chunk-RXNA2XCX.js";
import "./chunk-WGDTG44V.js";
import "./chunk-5WHVV7CQ.js";
import "./chunk-BWDOHM7J.js";
import {
  exec,
  execFG
} from "./chunk-EHD7YJKI.js";
import "./chunk-K4X2TU3S.js";
import "./chunk-VVTZN4QQ.js";
import {
  commandUsage
} from "./chunk-5E5GX4G6.js";
import "./chunk-DIBXMKZH.js";
import "./chunk-FI5TUER7.js";
import "./chunk-YOCFBK4Y.js";
import "./chunk-D7U7KDEM.js";
import "./chunk-Z76BQOEV.js";
import "./chunk-BGQCUUCA.js";
import "./chunk-E74WGW5C.js";
import "./chunk-FEV5BCW7.js";
import "./chunk-VCSVHRCS.js";
import "./chunk-D27QPHKI.js";
import "./chunk-JLJKOF75.js";
import "./chunk-KXBF4HVG.js";
import "./chunk-HTOTG4TS.js";
import "./chunk-XNLSTHDK.js";
import "./chunk-WZWDS3W4.js";
import "./chunk-PZLD7RTK.js";

// ../../src/cli-sdk/src/commands/create.ts
import { homedir } from "node:os";
import { createInterface } from "node:readline/promises";
var usage = () => commandUsage({
  command: "create",
  usage: "<initializer> [args...]",
  description: `Initialize a new project from a template package.

                  Works like \`npm create\` and \`bun create\`, automatically
                  prepending "create-" to the package name and executing it.

                  For example, \`vlt create react-app my-app\` will fetch and
                  execute the \`create-react-app\` package with the arguments
                  \`my-app\`.

                  If a satisfying instance of the create package exists in the
                  local \`node_modules\` folder, then that will be used.

                  At no point will \`vlt create\` change the locally installed
                  dependencies. Any installs it performs is done in vlt's XDG
                  data directory.
    `,
  examples: {
    "react-app my-app": {
      description: "Create a new React app using create-react-app"
    },
    "vite my-project": {
      description: "Create a new Vite project using create-vite"
    },
    "@scope/template my-app": {
      description: "Create a new project using @scope/create-template"
    }
  },
  options: {
    "allow-scripts": {
      value: "<query>",
      description: "Filter which packages are allowed to run lifecycle scripts using DSS query syntax."
    },
    yes: {
      description: "Skip interactive prompts and accept defaults."
    }
  }
});
var HOME = homedir();
var prettyPath = (path) => path.startsWith(HOME) ? `~${path.substring(HOME.length)}` : path;
var promptFn = async (pkgSpec, path, resolution) => {
  const response = await createInterface(
    process.stdin,
    process.stdout
  ).question(
    `About to install: ${styleTextStdout(
      ["bgWhiteBright", "black", "bold"],
      String(pkgSpec)
    )}
from: ${styleTextStdout(
      ["bgWhiteBright", "black", "bold"],
      resolution
    )}
into: ${styleTextStdout(
      ["bgWhiteBright", "black", "bold"],
      prettyPath(path)
    )}
Is this ok? (y) `
  );
  process.stdin.pause();
  return response;
};
var command = async (conf) => {
  const [initializer, ...args] = conf.positionals;
  if (!initializer) {
    throw new Error(
      "Missing required argument: <initializer>\n\nUsage: vlt create <initializer> [args...]"
    );
  }
  let packageName;
  if (initializer.startsWith("@")) {
    const [scope, name] = initializer.split("/");
    packageName = name ? `${scope}/create-${name}` : `${scope}/create`;
  } else {
    packageName = `create-${initializer}`;
  }
  const allowScripts = conf.get("allow-scripts") ? String(conf.get("allow-scripts")) : ":not(*)";
  const yesFlag = conf.get("yes");
  const arg0 = await vlxResolve(
    [packageName],
    {
      ...conf.options,
      query: void 0,
      allowScripts
    },
    yesFlag ? async () => "y" : promptFn
  );
  if (arg0) {
    conf.positionals = [arg0, ...args];
  } else {
    throw new Error(
      `Could not resolve executable for package "${packageName}"`
    );
  }
  delete conf.options["script-shell"];
  return await new ExecCommand(conf, exec, execFG).run();
};
export {
  command,
  prettyPath,
  promptFn,
  usage,
  views
};
