var global = globalThis;
import {Buffer} from "node:buffer";
import {setTimeout as _vlt_setTimeout,clearTimeout as _vlt_clearTimeout,setImmediate as _vlt_setImmediate,clearImmediate as _vlt_clearImmediate,setInterval as _vlt_setInterval,clearInterval as _vlt_clearInterval} from "node:timers";
globalThis.setTimeout = _vlt_setTimeout;
globalThis.clearTimeout = _vlt_clearTimeout;
globalThis.setImmediate = _vlt_setImmediate;
globalThis.clearImmediate = _vlt_clearImmediate;
globalThis.setInterval = _vlt_setInterval;
globalThis.clearInterval = _vlt_clearInterval;
import {createRequire as _vlt_createRequire} from "node:module";
var require = _vlt_createRequire(import.meta.filename);
import {
  vlxResolve
} from "./chunk-FK43DC3Q.js";
import {
  ExecCommand,
  views
} from "./chunk-ELHX2DD4.js";
import "./chunk-RIYFGX27.js";
import {
  styleTextStdout
} from "./chunk-2M5IL56T.js";
import "./chunk-TDTJOKF2.js";
import "./chunk-VTEFO2FT.js";
import "./chunk-RXNA2XCX.js";
import "./chunk-WGDTG44V.js";
import "./chunk-5WHVV7CQ.js";
import "./chunk-BWDOHM7J.js";
import {
  exec,
  execFG
} from "./chunk-EHD7YJKI.js";
import "./chunk-K4X2TU3S.js";
import "./chunk-VVTZN4QQ.js";
import {
  commandUsage
} from "./chunk-5E5GX4G6.js";
import "./chunk-DIBXMKZH.js";
import "./chunk-FI5TUER7.js";
import "./chunk-YOCFBK4Y.js";
import "./chunk-D7U7KDEM.js";
import "./chunk-Z76BQOEV.js";
import "./chunk-BGQCUUCA.js";
import "./chunk-E74WGW5C.js";
import "./chunk-FEV5BCW7.js";
import "./chunk-VCSVHRCS.js";
import "./chunk-D27QPHKI.js";
import "./chunk-JLJKOF75.js";
import "./chunk-KXBF4HVG.js";
import "./chunk-HTOTG4TS.js";
import "./chunk-XNLSTHDK.js";
import "./chunk-WZWDS3W4.js";
import "./chunk-PZLD7RTK.js";

// ../../src/cli-sdk/src/commands/exec.ts
import { homedir } from "node:os";
import { env, platform } from "node:process";
import { createInterface } from "node:readline/promises";
var usage = () => commandUsage({
  command: "exec",
  usage: "[--package=<pkg>] [--call=<cmd>] [command...]",
  description: `Run a command defined by a package, installing it
                  if necessary.

                  If the package specifier is provided explicitly via the
                  \`--package\` config, then that is what will be used. If
                  a satisfying instance of the named package exists in the
                  local \`node_modules\` folder, then that will be used.

                  If \`--package\` is not set, then vlt will attempt to infer
                  the package to be installed if necessary, in the following
                  manner:

                  - If the first argument is an executable found in the
                    \`node_modules/.bin\` folder (ie, provided by an
                    installed direct dependency), then that will be used.
                    The search stops, and nothing will be installed.
                  - Otherwise, vlt attempts to resolve the first argument
                    as if it was a \`--package\` option, and then swap it
                    out with the "default" executable provided by that
                    package.

                  The "default" executable provided by a package is:

                  - If the package provides a single executable string in the
                    \`bin\` field, then that is the executable to use.
                  - Otherwise, if there is a \`bin\` with the same name
                    as the package (or just the portion after the \`/\` in
                    the case of scoped packages), then that will be used.

                  If the appropriate excutable cannot be determined, then
                  an error will be raised.

                  At no point will \`vlt exec\` change the locally installed
                  dependencies. Any installs it performs is done in vlt's XDG
                  data directory.
    `,
  examples: {
    "--package typescript@5 tsc": {
      description: "Run tsc provided by typescript version 5"
    },
    "eslint src/file.js": {
      description: "Run the default bin provided by eslint"
    },
    "eslint@9.24 src/file.js": {
      description: "Run the default bin provided by eslint version 9.24"
    },
    'create-react-app --call="echo $PWD"': {
      description: "Install create-react-app and run an arbitrary command with its bins in PATH"
    },
    '--call="echo $PWD" --scope=":workspace"': {
      description: "Run an arbitrary command in the context of each workspace"
    }
  },
  options: {
    package: {
      value: "<specifier>",
      description: "Explicitly set the package to search for bins."
    },
    call: {
      value: "<cmd>",
      description: "Run an arbitrary command string after installing any specified package and adding its bins to PATH."
    },
    "allow-scripts": {
      value: "<query>",
      description: "Filter which packages are allowed to run lifecycle scripts using DSS query syntax."
    },
    scope: {
      value: "<query>",
      description: "Filter execution targets using a DSS query."
    },
    workspace: {
      value: "<path|glob>",
      description: "Limit execution to matching workspace paths or globs."
    },
    "workspace-group": {
      value: "<name>",
      description: "Limit execution to named workspace groups."
    },
    recursive: {
      description: "Run across all selected workspaces."
    },
    "if-present": {
      description: "When running across multiple packages, only include packages with matching scripts."
    },
    bail: {
      description: "When running across multiple workspaces, stop on first failure."
    },
    "script-shell": {
      value: "<shell>",
      description: "The shell to use for --call commands and script execution."
    }
  }
});
var HOME = homedir();
var prettyPath = (path) => path.startsWith(HOME) ? `~${path.substring(HOME.length)}` : path;
var promptFn = async (pkgSpec, path, resolution) => {
  const response = await createInterface(
    process.stdin,
    process.stdout
  ).question(
    `About to install: ${styleTextStdout(
      ["bgWhiteBright", "black", "bold"],
      String(pkgSpec)
    )}
from: ${styleTextStdout(
      ["bgWhiteBright", "black", "bold"],
      resolution
    )}
into: ${styleTextStdout(
      ["bgWhiteBright", "black", "bold"],
      prettyPath(path)
    )}
Is this ok? (y) `
  );
  process.stdin.pause();
  return response;
};
var command = async (conf) => {
  const allowScripts = conf.get("allow-scripts") ? String(conf.get("allow-scripts")) : ":not(*)";
  const callOption = conf.get("call");
  if (callOption) {
    const pkgOption = conf.get("package") ?? conf.positionals[0];
    if (pkgOption) {
      await vlxResolve(
        [],
        {
          ...conf.options,
          package: pkgOption,
          query: void 0,
          allowScripts
        }
        // no promptFn: install silently since --call implies user consent
      );
    }
    const shell = conf.get("script-shell") ?? env.SHELL ?? /* c8 ignore next */
    (platform === "win32" ? "cmd.exe" : "/bin/sh");
    const shellFlag = shell === "cmd.exe" ? "/c" : "-c";
    conf.positionals.splice(
      0,
      conf.positionals.length,
      shell,
      shellFlag,
      callOption
    );
  } else {
    const arg0 = await vlxResolve(
      conf.positionals,
      {
        ...conf.options,
        query: void 0,
        allowScripts
      },
      promptFn
    );
    if (arg0) conf.positionals[0] = arg0;
  }
  delete conf.options["script-shell"];
  return await new ExecCommand(conf, exec, execFG).run();
};
export {
  command,
  prettyPath,
  promptFn,
  usage,
  views
};
