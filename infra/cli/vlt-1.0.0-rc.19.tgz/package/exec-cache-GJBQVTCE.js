var global = globalThis;
import {Buffer} from "node:buffer";
import {setTimeout as _vlt_setTimeout,clearTimeout as _vlt_clearTimeout,setImmediate as _vlt_setImmediate,clearImmediate as _vlt_clearImmediate,setInterval as _vlt_setInterval,clearInterval as _vlt_clearInterval} from "node:timers";
globalThis.setTimeout = _vlt_setTimeout;
globalThis.clearTimeout = _vlt_clearTimeout;
globalThis.setImmediate = _vlt_setImmediate;
globalThis.clearImmediate = _vlt_clearImmediate;
globalThis.setInterval = _vlt_setInterval;
globalThis.clearInterval = _vlt_clearInterval;
import {createRequire as _vlt_createRequire} from "node:module";
var require = _vlt_createRequire(import.meta.filename);
import {
  vlxDelete,
  vlxInfo,
  vlxInstall,
  vlxList
} from "./chunk-2RKPHQUT.js";
import {
  stdout
} from "./chunk-2M5IL56T.js";
import "./chunk-TDTJOKF2.js";
import {
  ViewClass
} from "./chunk-RXNA2XCX.js";
import "./chunk-WGDTG44V.js";
import "./chunk-5WHVV7CQ.js";
import {
  RollbackRemove
} from "./chunk-3Y3TZ5SX.js";
import "./chunk-K4X2TU3S.js";
import "./chunk-EXVKZ662.js";
import {
  commandUsage
} from "./chunk-5E5GX4G6.js";
import "./chunk-5ZY2OA3F.js";
import "./chunk-FI5TUER7.js";
import "./chunk-JQKBSJDB.js";
import "./chunk-D7U7KDEM.js";
import "./chunk-2TOZR3L2.js";
import "./chunk-BGQCUUCA.js";
import "./chunk-E74WGW5C.js";
import "./chunk-FEV5BCW7.js";
import "./chunk-VCSVHRCS.js";
import "./chunk-D27QPHKI.js";
import "./chunk-JLJKOF75.js";
import "./chunk-KXBF4HVG.js";
import "./chunk-HTOTG4TS.js";
import "./chunk-XNLSTHDK.js";
import {
  error
} from "./chunk-WZWDS3W4.js";
import "./chunk-PZLD7RTK.js";

// ../../src/cli-sdk/src/commands/exec-cache.ts
import { basename } from "node:path";
var view;
var ExecCacheView = class extends ViewClass {
  constructor(options, conf) {
    super(options, conf);
    view = this;
  }
  stdout(...args) {
    stdout(...args);
  }
};
var views = {
  human: ExecCacheView
};
var usageDef = {
  command: "exec-cache",
  usage: "<command> [flags]",
  description: "Work with vlt exec-cache folders",
  subcommands: {
    ls: {
      usage: "",
      description: `Show previously installed packages used for \`vlt exec\`.
                    Key provided can be either the package name, or the full
                    key.`
    },
    delete: {
      usage: "[<key>...]",
      description: `Delete previously installed packages used for
                    \`vlt exec\`. If no keys are provided, then all entries
                    will be deleted.`
    },
    info: {
      usage: "<key>",
      description: `Show extended information about a given \`vlt exec\`
                    installation.`
    },
    install: {
      usage: "<spec>...",
      description: `Install the specified package(s) in the \`vlt exec\`
                    central cache location. Metadata info about each
                    installation will be printed.`
    }
  },
  examples: {
    ls: {
      description: `Show all the keys for the installations in the \`vlt exec\`
                    cache.`
    },
    "delete typescript": {
      description: `Delete all versions of typescript installed for vlt exec`
    },
    "info typescript-695bf962": {
      description: `Show extended info about a specific version of typescript`
    }
  }
};
var usage = () => commandUsage(usageDef);
var command = async (conf) => {
  const [sub, ...args] = conf.positionals;
  switch (sub) {
    case "ls":
      return ls(conf, args, view);
    case "info":
      return info(conf, args, view);
    case "install":
      return install(conf, args, view);
    case "delete":
      return deleteEntries(conf, args, view);
    default: {
      throw error("Unrecognized exec-cache command", {
        code: "EUSAGE",
        found: sub,
        validOptions: Object.keys(usageDef.subcommands)
      });
    }
  }
};
var install = async (conf, keys, view2) => {
  if (!keys.length) {
    throw error("Must supply a package spec to install", {
      code: "EUSAGE"
    });
  }
  const allowScripts = conf.get("allow-scripts") ? String(conf.get("allow-scripts")) : ":not(*)";
  return Promise.all(
    keys.map(async (key) => {
      const info2 = await vlxInstall(key, {
        ...conf.options,
        query: void 0,
        allowScripts
      });
      view2?.stdout(info2);
      return info2.path;
    })
  );
};
var ls = async (_conf, args, view2) => {
  const results = [];
  for await (const path of vlxList()) {
    const key = basename(path);
    if (args.length && !args.some((a) => key.includes(a))) continue;
    results.push(key);
    view2?.stdout(key);
  }
  return results;
};
var info = async (conf, keys, view2) => {
  const allowScripts = conf.get("allow-scripts") ? String(conf.get("allow-scripts")) : ":not(*)";
  const results = [];
  for await (const key of keys.length ? keys : vlxList()) {
    const info2 = vlxInfo(key, {
      ...conf.options,
      query: void 0,
      allowScripts
    });
    results.push(info2);
    view2?.stdout(info2);
  }
  return results;
};
var deleteEntries = async (conf, keys, view2) => {
  const allowScripts = conf.get("allow-scripts") ? String(conf.get("allow-scripts")) : ":not(*)";
  const remover = new RollbackRemove();
  const removed = (await vlxDelete(keys, remover, {
    ...conf.options,
    query: void 0,
    allowScripts
  })).map((path) => {
    view2?.stdout(`- ${basename(path)}`);
    return path;
  });
  remover.confirm();
  return removed;
};
export {
  ExecCacheView,
  command,
  usage,
  views
};
