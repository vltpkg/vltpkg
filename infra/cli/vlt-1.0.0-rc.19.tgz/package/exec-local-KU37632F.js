var global = globalThis;
import {Buffer} from "node:buffer";
import {setTimeout as _vlt_setTimeout,clearTimeout as _vlt_clearTimeout,setImmediate as _vlt_setImmediate,clearImmediate as _vlt_clearImmediate,setInterval as _vlt_setInterval,clearInterval as _vlt_clearInterval} from "node:timers";
globalThis.setTimeout = _vlt_setTimeout;
globalThis.clearTimeout = _vlt_clearTimeout;
globalThis.setImmediate = _vlt_setImmediate;
globalThis.clearImmediate = _vlt_clearImmediate;
globalThis.setInterval = _vlt_setInterval;
globalThis.clearInterval = _vlt_clearInterval;
import {createRequire as _vlt_createRequire} from "node:module";
var require = _vlt_createRequire(import.meta.filename);
import {
  ExecCommand,
  views
} from "./chunk-ELHX2DD4.js";
import "./chunk-RIYFGX27.js";
import "./chunk-2M5IL56T.js";
import "./chunk-TDTJOKF2.js";
import "./chunk-VTEFO2FT.js";
import "./chunk-RXNA2XCX.js";
import "./chunk-WGDTG44V.js";
import "./chunk-5WHVV7CQ.js";
import "./chunk-BWDOHM7J.js";
import {
  exec,
  execFG
} from "./chunk-EHD7YJKI.js";
import "./chunk-K4X2TU3S.js";
import "./chunk-VVTZN4QQ.js";
import {
  commandUsage
} from "./chunk-5E5GX4G6.js";
import "./chunk-Z76BQOEV.js";
import "./chunk-BGQCUUCA.js";
import "./chunk-E74WGW5C.js";
import "./chunk-FEV5BCW7.js";
import "./chunk-VCSVHRCS.js";
import "./chunk-D27QPHKI.js";
import "./chunk-JLJKOF75.js";
import "./chunk-KXBF4HVG.js";
import "./chunk-HTOTG4TS.js";
import "./chunk-XNLSTHDK.js";
import "./chunk-WZWDS3W4.js";
import "./chunk-PZLD7RTK.js";

// ../../src/cli-sdk/src/commands/exec-local.ts
var usage = () => commandUsage({
  command: "exec-local",
  usage: "[command]",
  description: `Run an arbitrary command, with the local installed packages
                  first in the PATH. Ie, this will run your locally installed
                  package bins.

                  If no command is provided, then a shell is spawned in the
                  current working directory, with the locally installed package
                  bins first in the PATH.

                  Note that any vlt configs must be specified *before* the
                  command, as the remainder of the command line options are
                  provided to the exec process.`,
  options: {
    scope: {
      value: "<query>",
      description: "Filter execution targets using a DSS query."
    },
    workspace: {
      value: "<path|glob>",
      description: "Limit execution to matching workspace paths or globs."
    },
    "workspace-group": {
      value: "<name>",
      description: "Limit execution to named workspace groups."
    },
    recursive: {
      description: "Run across all selected workspaces."
    },
    "if-present": {
      description: "When running across multiple packages, only include packages with matching scripts."
    },
    bail: {
      description: "When running across multiple workspaces, stop on first failure."
    }
  }
});
var command = async (conf) => {
  delete conf.options["script-shell"];
  return await new ExecCommand(conf, exec, execFG).run();
};
export {
  command,
  usage,
  views
};
