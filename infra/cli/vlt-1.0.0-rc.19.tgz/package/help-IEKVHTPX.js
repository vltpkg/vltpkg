var global = globalThis;
import {Buffer} from "node:buffer";
import {setTimeout as _vlt_setTimeout,clearTimeout as _vlt_clearTimeout,setImmediate as _vlt_setImmediate,clearImmediate as _vlt_clearImmediate,setInterval as _vlt_setInterval,clearInterval as _vlt_clearInterval} from "node:timers";
globalThis.setTimeout = _vlt_setTimeout;
globalThis.clearTimeout = _vlt_clearTimeout;
globalThis.setImmediate = _vlt_setImmediate;
globalThis.clearImmediate = _vlt_clearImmediate;
globalThis.setInterval = _vlt_setInterval;
globalThis.clearInterval = _vlt_clearInterval;
import {createRequire as _vlt_createRequire} from "node:module";
var require = _vlt_createRequire(import.meta.filename);
import {
  loadCommand
} from "./chunk-QBIESX6J.js";
import {
  generateDefaultHelp,
  generateFullHelp
} from "./chunk-TDTJOKF2.js";
import "./chunk-WGDTG44V.js";
import {
  commandUsage
} from "./chunk-5E5GX4G6.js";
import "./chunk-E74WGW5C.js";
import {
  getCommand
} from "./chunk-D27QPHKI.js";
import "./chunk-XNLSTHDK.js";
import {
  error
} from "./chunk-WZWDS3W4.js";
import "./chunk-PZLD7RTK.js";

// ../../src/cli-sdk/src/commands/help.ts
var usage = () => commandUsage({
  command: "help",
  usage: "[<command>]",
  description: "Print the full help output for the CLI, or help for a specific command",
  examples: {
    "": { description: "Show general CLI help" },
    install: { description: "Show help for the install command" },
    run: { description: "Show help for the run command" }
  },
  options: {
    all: {
      description: "Show all commands, bins, and flags."
    }
  }
});
var command = async (conf) => {
  if (conf.positionals.length === 0) {
    const colors = conf.values.color ?? process.stdout.isTTY;
    if (conf.values.all) {
      return generateFullHelp(colors);
    }
    return generateDefaultHelp(colors);
  }
  const cmdName = conf.positionals[0];
  const canonicalCmd = getCommand(cmdName);
  if (!canonicalCmd) {
    throw error(`Unknown command: ${cmdName}`, {
      found: cmdName,
      code: "EUSAGE"
    });
  }
  const command2 = await loadCommand(canonicalCmd);
  return command2.usage().usage();
};
export {
  command,
  usage
};
