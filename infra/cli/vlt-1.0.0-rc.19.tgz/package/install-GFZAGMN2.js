var global = globalThis;
import {Buffer} from "node:buffer";
import {setTimeout as _vlt_setTimeout,clearTimeout as _vlt_clearTimeout,setImmediate as _vlt_setImmediate,clearImmediate as _vlt_clearImmediate,setInterval as _vlt_setInterval,clearInterval as _vlt_clearInterval} from "node:timers";
globalThis.setTimeout = _vlt_setTimeout;
globalThis.clearTimeout = _vlt_clearTimeout;
globalThis.setImmediate = _vlt_setImmediate;
globalThis.clearImmediate = _vlt_clearImmediate;
globalThis.setInterval = _vlt_setInterval;
globalThis.clearInterval = _vlt_clearInterval;
import {createRequire as _vlt_createRequire} from "node:module";
var require = _vlt_createRequire(import.meta.filename);
import {
  parseAddArgs
} from "./chunk-JCOHZUJ6.js";
import {
  InstallReporter
} from "./chunk-FPRLLVBW.js";
import "./chunk-VTEFO2FT.js";
import "./chunk-RXNA2XCX.js";
import "./chunk-WGDTG44V.js";
import {
  install
} from "./chunk-3Y3TZ5SX.js";
import "./chunk-K4X2TU3S.js";
import "./chunk-EXVKZ662.js";
import {
  commandUsage
} from "./chunk-5E5GX4G6.js";
import "./chunk-2TOZR3L2.js";
import "./chunk-BGQCUUCA.js";
import "./chunk-E74WGW5C.js";
import "./chunk-FEV5BCW7.js";
import "./chunk-VCSVHRCS.js";
import "./chunk-D27QPHKI.js";
import "./chunk-JLJKOF75.js";
import "./chunk-KXBF4HVG.js";
import "./chunk-HTOTG4TS.js";
import "./chunk-XNLSTHDK.js";
import "./chunk-WZWDS3W4.js";
import "./chunk-PZLD7RTK.js";

// ../../src/cli-sdk/src/commands/install.ts
var usage = () => commandUsage({
  command: "install",
  usage: "[packages ...]",
  description: `Install the specified packages, updating package.json and
                  vlt-lock.json appropriately.`,
  options: {
    "save-dev": {
      description: "Save installed packages to package.json as devDependencies."
    },
    "save-optional": {
      description: "Save installed packages to package.json as optionalDependencies."
    },
    "save-peer": {
      description: "Save installed packages to package.json as peerDependencies."
    },
    "save-prod": {
      description: "Save installed packages to package.json as dependencies."
    },
    workspace: {
      value: "<path|glob>",
      description: "Limit installation targets to matching workspaces."
    },
    "workspace-group": {
      value: "<name>",
      description: "Limit installation targets to workspace groups."
    },
    "expect-lockfile": {
      description: "Fail if lockfile is missing or out of date."
    },
    "frozen-lockfile": {
      description: "Fail if lockfile is missing or out of sync with package.json."
    },
    "lockfile-only": {
      description: "Only update lockfile and package.json files; skip node_modules operations."
    },
    "allow-scripts": {
      value: "<query>",
      description: "Filter which packages are allowed to run lifecycle scripts using DSS query syntax."
    }
  }
});
var views = {
  json: (i) => ({
    ...i.buildQueue?.length ? {
      buildQueue: i.buildQueue,
      message: `${i.buildQueue.length} packages that will need to be built, run "vlt build" to complete the install.`
    } : null,
    graph: i.graph.toJSON()
  }),
  human: InstallReporter
};
var command = async (conf) => {
  const monorepo = conf.options.monorepo;
  const scurry = conf.options.scurry;
  const { add } = parseAddArgs(conf, scurry, monorepo);
  const frozenLockfile = conf.options["frozen-lockfile"];
  const expectLockfile = conf.options["expect-lockfile"];
  const lockfileOnly = conf.options["lockfile-only"];
  const allowScripts = conf.get("allow-scripts") ? String(conf.get("allow-scripts")) : ":not(*)";
  const { buildQueue, graph } = await install(
    {
      ...conf.options,
      frozenLockfile,
      expectLockfile,
      allowScripts,
      lockfileOnly
    },
    add
  );
  return { buildQueue, graph };
};
export {
  command,
  usage,
  views
};
