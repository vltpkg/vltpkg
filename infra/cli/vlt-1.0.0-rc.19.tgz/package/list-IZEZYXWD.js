var global = globalThis;
import {Buffer} from "node:buffer";
import {setTimeout as _vlt_setTimeout,clearTimeout as _vlt_clearTimeout,setImmediate as _vlt_setImmediate,clearImmediate as _vlt_clearImmediate,setInterval as _vlt_setInterval,clearInterval as _vlt_clearInterval} from "node:timers";
globalThis.setTimeout = _vlt_setTimeout;
globalThis.clearTimeout = _vlt_clearTimeout;
globalThis.setImmediate = _vlt_setImmediate;
globalThis.clearImmediate = _vlt_clearImmediate;
globalThis.setInterval = _vlt_setInterval;
globalThis.clearInterval = _vlt_clearInterval;
import {createRequire as _vlt_createRequire} from "node:module";
var require = _vlt_createRequire(import.meta.filename);
import {
  MermaidImageView
} from "./chunk-KEQFTVVD.js";
import "./chunk-2M5IL56T.js";
import "./chunk-TDTJOKF2.js";
import "./chunk-RXNA2XCX.js";
import "./chunk-WGDTG44V.js";
import "./chunk-5WHVV7CQ.js";
import {
  createHostContextsMap
} from "./chunk-BWDOHM7J.js";
import {
  GraphModifier,
  Query,
  actual,
  asNode,
  humanReadableOutput,
  jsonOutput,
  mermaidOutput
} from "./chunk-EHD7YJKI.js";
import {
  SecurityArchive
} from "./chunk-K4X2TU3S.js";
import "./chunk-VVTZN4QQ.js";
import {
  commandUsage
} from "./chunk-5E5GX4G6.js";
import "./chunk-D7U7KDEM.js";
import "./chunk-Z76BQOEV.js";
import "./chunk-BGQCUUCA.js";
import "./chunk-E74WGW5C.js";
import "./chunk-FEV5BCW7.js";
import "./chunk-VCSVHRCS.js";
import "./chunk-D27QPHKI.js";
import "./chunk-JLJKOF75.js";
import "./chunk-KXBF4HVG.js";
import "./chunk-HTOTG4TS.js";
import "./chunk-XNLSTHDK.js";
import {
  error
} from "./chunk-WZWDS3W4.js";
import "./chunk-PZLD7RTK.js";

// ../../src/cli-sdk/src/commands/list.ts
var usage = () => commandUsage({
  command: "ls",
  usage: [
    "",
    "[package-names...] [--view=human | json | mermaid | svg | png | count]",
    "[--scope=<query>] [--target=<query>] [--view=human | json | mermaid | svg | png | count]"
  ],
  description: `List installed dependencies matching given package names or query selectors.

      Package names provided as positional arguments will be used to filter
      the results to show only dependencies with those names.

      The --scope and --target options accepts DSS query selectors to filter
      packages. Using --scope, you can specify which packages to treat as the
      top-level items in the output graph. The --target option allows you to
      filter what dependencies to include in the output. Using both options
      allows you to render subgraphs of the dependency graph.

      Defaults to listing direct dependencies of a project and any configured
      workspace.`,
  examples: {
    "": {
      description: "List direct dependencies of the current project / workspace"
    },
    "foo bar baz": {
      description: `List all dependencies named 'foo', 'bar', or 'baz'`
    },
    '--scope=":root > #dependency-name"': {
      description: "Defines a direct dependency as the output top-level scope"
    },
    '--target="*"': {
      description: "List all dependencies using a query selector"
    },
    '--target=":workspace > *:peer"': {
      description: "List all peer dependencies of all workspaces"
    }
  },
  options: {
    scope: {
      value: "<query>",
      description: "Query selector to select top-level packages using the DSS query language syntax."
    },
    target: {
      value: "<query>",
      description: "Query selector to filter packages using the DSS query language syntax."
    },
    view: {
      value: "[human | json | mermaid | svg | png | count]",
      description: "Output format. Defaults to human-readable or json if no tty. Use svg or png to render the dependency graph as an image and open it. Count outputs the number of dependency relationships in the result."
    }
  }
});
var views = {
  json: jsonOutput,
  mermaid: mermaidOutput,
  human: humanReadableOutput,
  count: (result) => result.edges.length,
  svg: MermaidImageView,
  png: MermaidImageView
};
var command = async (conf) => {
  const modifiers = GraphModifier.maybeLoad(conf.options);
  const monorepo = conf.options.monorepo;
  const mainManifest = conf.options.packageJson.maybeRead(
    conf.options.projectRoot
  );
  let graph;
  let securityArchive;
  if (mainManifest) {
    graph = actual.load({
      ...conf.options,
      mainManifest,
      modifiers,
      monorepo,
      loadManifests: true
    });
    securityArchive = await SecurityArchive.start({
      nodes: [...graph.nodes.values()]
    });
  }
  for (const arg of conf.positionals) {
    if (!/^[@\w-]/.test(arg)) {
      throw error(
        `Direct queries are not supported as positional arguments. Use package names only.`,
        {
          code: "EUSAGE",
          cause: `Argument '${arg}' appears to be a query syntax. Only package names are allowed as positional arguments.`
        }
      );
    }
  }
  const positionalQueryString = conf.positionals.map((k) => `#${k.replace(/\//, "\\/")}`).join(", ");
  const targetQueryString = conf.get("target");
  const scopeQueryString = conf.get("scope");
  const queryString = targetQueryString || positionalQueryString;
  const projectQueryString = ":workspace, :project > *";
  const selectImporters = [];
  const hostContexts = await createHostContextsMap(conf);
  const importers = /* @__PURE__ */ new Set();
  const scopeIDs = [];
  let scopeNodes;
  if (scopeQueryString) {
    const edges2 = graph?.edges ?? /* @__PURE__ */ new Set();
    const nodes2 = graph?.nodes ? new Set(graph.nodes.values()) : /* @__PURE__ */ new Set();
    const importers2 = graph?.importers ?? /* @__PURE__ */ new Set();
    const scopeQuery = new Query({
      nodes: nodes2,
      edges: edges2,
      importers: importers2,
      securityArchive,
      hostContexts
    });
    const { nodes: resultNodes } = await scopeQuery.search(
      scopeQueryString,
      {
        signal: new AbortController().signal
      }
    );
    scopeNodes = resultNodes;
  }
  if (scopeQueryString && scopeNodes) {
    for (const queryNode of scopeNodes) {
      importers.add(asNode(queryNode));
    }
  } else if ("workspace" in conf.values) {
    if (monorepo && graph) {
      for (const workspace of monorepo.filter(conf.values)) {
        const w = graph.nodes.get(workspace.id);
        if (w) {
          importers.add(w);
          selectImporters.push(`[name="${w.name}"]`);
          selectImporters.push(`[name="${w.name}"] > *`);
          scopeIDs.push(workspace.id);
        }
      }
    }
  }
  const selectImportersQueryString = selectImporters.join(", ");
  const defaultProjectQueryString = graph && selectImporters.length && selectImporters.length < graph.importers.size ? selectImportersQueryString : projectQueryString;
  const defaultLocalScopeQueryString = ":host(local) :root > *";
  const edges_ = graph?.edges ?? /* @__PURE__ */ new Set();
  const nodes_ = graph?.nodes ? new Set(graph.nodes.values()) : /* @__PURE__ */ new Set();
  const importers_ = importers.size === 0 && graph ? /* @__PURE__ */ new Set([graph.mainImporter]) : importers;
  const q = new Query({
    nodes: nodes_,
    edges: edges_,
    importers: importers_,
    securityArchive,
    hostContexts
  });
  const query = queryString || /* c8 ignore next */
  (graph ? defaultProjectQueryString : defaultLocalScopeQueryString);
  const {
    edges,
    nodes,
    importers: queryResultImporters
  } = await q.search(query, {
    signal: new AbortController().signal,
    scopeIDs: scopeIDs.length > 0 ? scopeIDs : void 0
  });
  return {
    importers: importers.size === 0 ? new Set(queryResultImporters) : importers,
    edges,
    nodes,
    highlightSelection: !!(targetQueryString || positionalQueryString),
    queryString: queryString || (graph ? (
      /* c8 ignore next 2 */
      defaultProjectQueryString
    ) : defaultLocalScopeQueryString)
  };
};
export {
  command,
  usage,
  views
};
