var global = globalThis;
import {Buffer} from "node:buffer";
import {setTimeout as _vlt_setTimeout,clearTimeout as _vlt_clearTimeout,setImmediate as _vlt_setImmediate,clearImmediate as _vlt_clearImmediate,setInterval as _vlt_setInterval,clearInterval as _vlt_clearInterval} from "node:timers";
globalThis.setTimeout = _vlt_setTimeout;
globalThis.clearTimeout = _vlt_clearTimeout;
globalThis.setImmediate = _vlt_setImmediate;
globalThis.clearImmediate = _vlt_clearImmediate;
globalThis.setInterval = _vlt_setInterval;
globalThis.clearInterval = _vlt_clearInterval;
import {createRequire as _vlt_createRequire} from "node:module";
var require = _vlt_createRequire(import.meta.filename);
import {
  packTarball
} from "./chunk-GPMMOLUR.js";
import {
  prettyBytes
} from "./chunk-LRPTCGTW.js";
import {
  createHostContextsMap
} from "./chunk-BMAXCPGM.js";
import {
  Query,
  actual,
  run
} from "./chunk-3Y3TZ5SX.js";
import "./chunk-K4X2TU3S.js";
import "./chunk-EXVKZ662.js";
import {
  commandUsage
} from "./chunk-5E5GX4G6.js";
import "./chunk-FI5TUER7.js";
import {
  minimatch
} from "./chunk-2TOZR3L2.js";
import "./chunk-BGQCUUCA.js";
import "./chunk-E74WGW5C.js";
import "./chunk-FEV5BCW7.js";
import "./chunk-VCSVHRCS.js";
import "./chunk-D27QPHKI.js";
import "./chunk-JLJKOF75.js";
import "./chunk-KXBF4HVG.js";
import "./chunk-HTOTG4TS.js";
import "./chunk-XNLSTHDK.js";
import {
  error
} from "./chunk-WZWDS3W4.js";
import "./chunk-PZLD7RTK.js";

// ../../src/cli-sdk/src/commands/pack.ts
import { writeFile } from "node:fs/promises";
import { dirname, join, relative, resolve } from "node:path";
import assert from "node:assert";
var usage = () => commandUsage({
  command: "pack",
  usage: "",
  description: `Create a tarball from a package in the current directory or specified folder.
    
    The tarball will be saved to the current directory with the name
    <name>-<version>.tgz.`,
  options: {
    "dry-run": {
      description: "Show what would be packed without creating a tarball"
    },
    scope: {
      value: "<query>",
      description: "Filter packages to pack using a DSS query selector."
    },
    workspace: {
      value: "<path|glob>",
      description: "Limit pack targets to matching workspaces."
    },
    "workspace-group": {
      value: "<name>",
      description: "Limit pack targets to workspace groups."
    },
    recursive: {
      description: "Pack all workspaces in the monorepo."
    }
  }
});
var views = {
  human: (results) => {
    const item = (r) => {
      const lines = [
        `\u{1F4E6} Package: ${r.id}`,
        `\u{1F4C4} File: ${r.filename}`,
        `\u{1F4C1} ${r.files.length} Files`,
        ...r.files.map((f) => `  - ${f}`),
        `\u{1F4CA} Package Size: ${prettyBytes(r.size)}`,
        `\u{1F4C2} Unpacked Size: ${prettyBytes(r.unpackedSize)}`
      ];
      if (r.shasum) lines.push(`\u{1F512} Shasum: ${r.shasum}`);
      if (r.integrity) lines.push(`\u{1F510} Integrity: ${r.integrity}`);
      return lines.join("\n");
    };
    return Array.isArray(results) ? results.map(item).join("\n\n") : item(results);
  },
  json: (r) => r
};
var scopeLocations = async (queryString, conf) => {
  const { options, projectRoot } = conf;
  const mainManifest = options.packageJson.maybeRead(projectRoot);
  let graph;
  if (mainManifest) {
    graph = actual.load({
      ...options,
      mainManifest,
      monorepo: options.monorepo,
      loadManifests: false
    });
  }
  const hostContexts = await createHostContextsMap(conf);
  const query = new Query({
    /* c8 ignore next */
    nodes: graph ? new Set(graph.nodes.values()) : /* @__PURE__ */ new Set(),
    edges: graph?.edges ?? /* @__PURE__ */ new Set(),
    importers: graph?.importers ?? /* @__PURE__ */ new Set(),
    securityArchive: void 0,
    hostContexts
  });
  const { nodes } = await query.search(queryString, {
    signal: new AbortController().signal
  });
  const locations = [];
  for (const node of nodes) {
    const { location } = node.toJSON();
    assert(
      location,
      error(`node ${node.id} has no location`, {
        found: node
      })
    );
    locations.push(resolve(projectRoot, location));
  }
  return locations;
};
var command = async (conf) => {
  const { options, projectRoot } = conf;
  const queryString = conf.get("scope");
  const paths = conf.get("workspace");
  const groups = conf.get("workspace-group");
  const recursive = conf.get("recursive");
  const locations = [];
  let single = null;
  if (queryString) {
    locations.push(...await scopeLocations(queryString, conf));
  } else if (paths?.length || groups?.length || recursive) {
    for (const workspace of options.monorepo ?? []) {
      if (paths?.length) {
        const matches = paths.some(
          (p) => workspace.path === p || workspace.name === p || workspace.fullpath === p || resolve(projectRoot, p) === workspace.fullpath || minimatch(workspace.path, p)
        );
        if (!matches) continue;
      }
      locations.push(workspace.fullpath);
    }
  } else if (options.monorepo) {
    const cwd = process.cwd();
    if (cwd === projectRoot) {
      for (const workspace of options.monorepo) {
        locations.push(workspace.fullpath);
      }
    } else {
      const ws = options.monorepo.get(cwd);
      if (ws) {
        locations.push(ws.fullpath);
      } else {
        const rel = relative(projectRoot, cwd).replaceAll("\\", "/");
        locations.push(
          ...await scopeLocations(`:path("${rel}")`, conf)
        );
      }
    }
  } else {
    single = options.packageJson.find(process.cwd()) ?? projectRoot;
  }
  if (single) {
    return commandSingle(single, conf);
  }
  assert(
    locations.length > 0,
    error("No workspaces or query results found")
  );
  const results = [];
  for (const location of locations) {
    results.push(await commandSingle(location, conf));
  }
  return results;
};
var commandSingle = async (location, conf) => {
  const manifestPath = conf.options.packageJson.find(location);
  assert(manifestPath, "No package.json found");
  const manifestDir = dirname(manifestPath);
  const manifest = conf.options.packageJson.read(manifestDir);
  const isDryRun = conf.options["dry-run"];
  const runOptions = {
    cwd: manifestDir,
    projectRoot: conf.projectRoot,
    packageJson: conf.options.packageJson,
    manifest,
    ignoreMissing: true,
    ignorePrePost: true
  };
  await run({
    ...runOptions,
    arg0: "prepack"
  });
  await run({
    ...runOptions,
    arg0: "prepare"
  });
  const {
    name,
    version,
    filename,
    tarballData,
    unpackedSize,
    files,
    integrity,
    shasum
  } = await packTarball(manifest, manifestDir, conf);
  if (!isDryRun) {
    await writeFile(join(manifestDir, filename), tarballData);
  }
  await run({
    ...runOptions,
    arg0: "postpack"
  });
  return {
    id: `${name}@${version}`,
    name,
    version,
    filename,
    files,
    size: tarballData.length,
    unpackedSize,
    shasum,
    integrity
  };
};
export {
  command,
  commandSingle,
  usage,
  views
};
