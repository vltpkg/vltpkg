var global = globalThis;
import {Buffer} from "node:buffer";
import {setTimeout as _vlt_setTimeout,clearTimeout as _vlt_clearTimeout,setImmediate as _vlt_setImmediate,clearImmediate as _vlt_clearImmediate,setInterval as _vlt_setInterval,clearInterval as _vlt_clearInterval} from "node:timers";
globalThis.setTimeout = _vlt_setTimeout;
globalThis.clearTimeout = _vlt_clearTimeout;
globalThis.setImmediate = _vlt_setImmediate;
globalThis.clearImmediate = _vlt_clearImmediate;
globalThis.setInterval = _vlt_setInterval;
globalThis.clearInterval = _vlt_clearInterval;
import {createRequire as _vlt_createRequire} from "node:module";
var require = _vlt_createRequire(import.meta.filename);
import {
  packTarball
} from "./chunk-I3WY6N4R.js";
import {
  prettyBytes
} from "./chunk-LRPTCGTW.js";
import {
  createHostContextsMap
} from "./chunk-BWDOHM7J.js";
import {
  Query,
  actual,
  run
} from "./chunk-EHD7YJKI.js";
import "./chunk-K4X2TU3S.js";
import "./chunk-VVTZN4QQ.js";
import {
  commandUsage
} from "./chunk-5E5GX4G6.js";
import "./chunk-FI5TUER7.js";
import {
  RegistryClient
} from "./chunk-YOCFBK4Y.js";
import "./chunk-D7U7KDEM.js";
import {
  minimatch
} from "./chunk-Z76BQOEV.js";
import "./chunk-BGQCUUCA.js";
import "./chunk-E74WGW5C.js";
import "./chunk-FEV5BCW7.js";
import "./chunk-VCSVHRCS.js";
import "./chunk-D27QPHKI.js";
import "./chunk-JLJKOF75.js";
import {
  asError
} from "./chunk-KXBF4HVG.js";
import "./chunk-HTOTG4TS.js";
import "./chunk-XNLSTHDK.js";
import {
  error
} from "./chunk-WZWDS3W4.js";
import "./chunk-PZLD7RTK.js";

// ../../src/cli-sdk/src/commands/publish.ts
import assert from "node:assert";
import { dirname, resolve } from "node:path";
var usage = () => commandUsage({
  command: "publish",
  usage: "",
  description: `Create a tarball from a package and publish it to the configured registry.
    
    This command will pack the package in the current directory or specified folder,
    and then upload it to the configured registry.`,
  options: {
    tag: {
      description: "Publish the package with the given tag",
      value: "<tag>"
    },
    access: {
      description: "Set access level (public or restricted)",
      value: "<level>"
    },
    otp: {
      description: `Provide an OTP to use when publishing a package.`,
      value: "<otp>"
    },
    "publish-directory": {
      description: `Directory to use for pack and publish operations instead of the current directory.
                    The directory must exist and nothing will be copied to it.`,
      value: "<path>"
    },
    "dry-run": {
      description: "Show what would be published without actually publishing."
    },
    scope: {
      value: "<query>",
      description: "Filter packages to publish using a DSS query selector."
    },
    workspace: {
      value: "<path|glob>",
      description: "Limit publish targets to matching workspaces."
    },
    "workspace-group": {
      value: "<name>",
      description: "Limit publish targets to workspace groups."
    },
    recursive: {
      description: "Publish all workspaces in the monorepo."
    }
  }
});
var views = {
  human: (results) => {
    const item = (r) => {
      const lines = [
        `\u{1F4E6} Package: ${r.id}`,
        `\u{1F3F7}\uFE0F Tag: ${r.tag}`,
        `\u{1F4E1} Registry: ${r.registry}`,
        `\u{1F4C1} ${r.files.length} Files`,
        ...r.files.map((f) => `  - ${f}`),
        `\u{1F4CA} Package Size: ${prettyBytes(r.size)}`,
        `\u{1F4C2} Unpacked Size: ${prettyBytes(r.unpackedSize)}`
      ];
      if (r.shasum) lines.push(`\u{1F512} Shasum: ${r.shasum}`);
      if (r.integrity) lines.push(`\u{1F510} Integrity: ${r.integrity}`);
      return lines.join("\n");
    };
    return Array.isArray(results) ? results.map(item).join("\n\n") : item(results);
  },
  json: (r) => r
};
var command = async (conf) => {
  const { options, projectRoot } = conf;
  const queryString = conf.get("scope");
  const paths = conf.get("workspace");
  const groups = conf.get("workspace-group");
  const recursive = conf.get("recursive");
  const locations = [];
  let single = null;
  if (queryString) {
    const mainManifest = options.packageJson.maybeRead(projectRoot);
    let graph;
    if (mainManifest) {
      graph = actual.load({
        ...options,
        mainManifest,
        monorepo: options.monorepo,
        loadManifests: false
      });
    }
    const hostContexts = await createHostContextsMap(conf);
    const query = new Query({
      /* c8 ignore next */
      nodes: graph ? new Set(graph.nodes.values()) : /* @__PURE__ */ new Set(),
      edges: graph?.edges ?? /* @__PURE__ */ new Set(),
      importers: graph?.importers ?? /* @__PURE__ */ new Set(),
      securityArchive: void 0,
      hostContexts
    });
    const { nodes } = await query.search(queryString, {
      signal: new AbortController().signal
    });
    for (const node of nodes) {
      const { location } = node.toJSON();
      assert(
        location,
        error(`node ${node.id} has no location`, {
          found: node
        })
      );
      locations.push(resolve(projectRoot, location));
    }
  } else if (paths?.length || groups?.length || recursive) {
    for (const workspace of options.monorepo ?? []) {
      if (paths?.length) {
        const matches = paths.some(
          (p) => workspace.path === p || workspace.name === p || workspace.fullpath === p || resolve(projectRoot, p) === workspace.fullpath || minimatch(workspace.path, p)
        );
        if (!matches) continue;
      }
      locations.push(workspace.fullpath);
    }
  } else {
    single = options.packageJson.find(process.cwd()) ?? projectRoot;
  }
  if (single) {
    return commandSingle(single, conf);
  }
  assert(
    locations.length > 0,
    error("No workspaces or query results found")
  );
  const results = [];
  for (const location of locations) {
    results.push(await commandSingle(location, conf));
  }
  return results;
};
var commandSingle = async (location, conf) => {
  const manifestPath = conf.options.packageJson.find(location);
  assert(manifestPath, "No package.json found");
  const manifestDir = dirname(manifestPath);
  const manifest = conf.options.packageJson.read(manifestDir);
  assert(
    !manifest.private,
    error("Package has been marked as private")
  );
  const {
    tag,
    access,
    registry,
    "dry-run": dry = false,
    otp
  } = conf.options;
  const registryUrl = new URL(registry);
  const runOptions = {
    cwd: manifestDir,
    projectRoot: conf.projectRoot,
    packageJson: conf.options.packageJson,
    manifest,
    ignoreMissing: true,
    ignorePrePost: true
  };
  await run({
    ...runOptions,
    arg0: "prepublishOnly"
  });
  await run({
    ...runOptions,
    arg0: "prepublish"
  });
  await run({
    ...runOptions,
    arg0: "prepack"
  });
  await run({
    ...runOptions,
    arg0: "prepare"
  });
  const {
    name,
    version,
    tarballName,
    tarballData,
    unpackedSize,
    files,
    integrity,
    shasum
  } = await packTarball(manifest, manifestDir, conf);
  await run({
    ...runOptions,
    arg0: "postpack"
  });
  await run({
    ...runOptions,
    arg0: "publish"
  });
  const publishMetadata = {
    _id: name,
    name,
    description: manifest.description || "",
    "dist-tags": {
      [tag]: version
    },
    versions: {
      [version]: {
        ...manifest,
        _id: `${name}@${version}`,
        _nodeVersion: process.versions.node,
        dist: {
          ...manifest.dist,
          integrity,
          shasum,
          tarball: new URL(`${name}/-/${tarballName}`, registryUrl).href
        }
      }
    },
    ...access ? { access } : {},
    _attachments: {
      [tarballName]: {
        content_type: "application/octet-stream",
        data: tarballData.toString("base64"),
        length: tarballData.length
      }
    }
  };
  const rc = new RegistryClient(conf.options);
  const publishUrl = new URL(
    name.startsWith("@") ? name.replace("/", "%2F") : name,
    registryUrl
  );
  if (!dry) {
    let response;
    try {
      response = await rc.request(publishUrl, {
        method: "PUT",
        headers: {
          "content-type": "application/json",
          // These control what type of OTP auth flow is used
          "npm-auth-type": "web",
          "npm-command": "publish"
        },
        body: JSON.stringify(publishMetadata),
        otp
      });
    } catch (err) {
      throw error("Failed to publish package", {
        cause: asError(err)
      });
    }
    if (response.statusCode !== 200 && response.statusCode !== 201) {
      let extraMsg = "";
      if (response.statusCode === 404) {
        extraMsg = ".\n\u26A0\uFE0F Make sure you're logged in and have access to publish the package.";
      }
      throw error(`Failed to publish package${extraMsg}`, {
        url: publishUrl,
        response
      });
    }
  }
  await run({
    ...runOptions,
    arg0: "postpublish"
  });
  return {
    id: `${name}@${version}`,
    name,
    version,
    tag,
    ...access ? { access } : {},
    registry: registryUrl.origin,
    integrity,
    shasum,
    size: tarballData.length,
    unpackedSize,
    files
  };
};
export {
  command,
  usage,
  views
};
