var global = globalThis;
import {Buffer} from "node:buffer";
import {setTimeout as _vlt_setTimeout,clearTimeout as _vlt_clearTimeout,setImmediate as _vlt_setImmediate,clearImmediate as _vlt_clearImmediate,setInterval as _vlt_setInterval,clearInterval as _vlt_clearInterval} from "node:timers";
globalThis.setTimeout = _vlt_setTimeout;
globalThis.clearTimeout = _vlt_clearTimeout;
globalThis.setImmediate = _vlt_setImmediate;
globalThis.clearImmediate = _vlt_clearImmediate;
globalThis.setInterval = _vlt_setInterval;
globalThis.clearInterval = _vlt_clearInterval;
import {createRequire as _vlt_createRequire} from "node:module";
var require = _vlt_createRequire(import.meta.filename);
import {
  ExecCommand,
  views
} from "./chunk-USYACVKH.js";
import "./chunk-RIYFGX27.js";
import "./chunk-2M5IL56T.js";
import "./chunk-TDTJOKF2.js";
import "./chunk-VTEFO2FT.js";
import "./chunk-RXNA2XCX.js";
import "./chunk-WGDTG44V.js";
import "./chunk-5WHVV7CQ.js";
import "./chunk-BMAXCPGM.js";
import {
  run,
  runFG
} from "./chunk-3Y3TZ5SX.js";
import "./chunk-K4X2TU3S.js";
import "./chunk-EXVKZ662.js";
import {
  commandUsage
} from "./chunk-5E5GX4G6.js";
import "./chunk-2TOZR3L2.js";
import "./chunk-BGQCUUCA.js";
import "./chunk-E74WGW5C.js";
import "./chunk-FEV5BCW7.js";
import "./chunk-VCSVHRCS.js";
import "./chunk-D27QPHKI.js";
import "./chunk-JLJKOF75.js";
import "./chunk-KXBF4HVG.js";
import "./chunk-HTOTG4TS.js";
import "./chunk-XNLSTHDK.js";
import "./chunk-WZWDS3W4.js";
import "./chunk-PZLD7RTK.js";

// ../../src/cli-sdk/src/commands/run.ts
var usage = () => commandUsage({
  command: "run",
  usage: "<script> [args ...]",
  description: `Run a script defined in 'package.json', passing along any extra
                  arguments. Note that vlt config values must be specified *before*
                  the script name, because everything after that is handed off to
                  the script process.`,
  options: {
    scope: {
      value: "<query>",
      description: "Filter execution targets using a DSS query."
    },
    workspace: {
      value: "<path|glob>",
      description: "Limit execution to matching workspace paths or globs."
    },
    "workspace-group": {
      value: "<name>",
      description: "Limit execution to named workspace groups."
    },
    recursive: {
      description: "Run across all selected workspaces."
    },
    "if-present": {
      description: "When running across multiple packages, only include packages with matching scripts."
    },
    bail: {
      description: "When running across multiple workspaces, stop on first failure."
    },
    "script-shell": {
      value: "<program>",
      description: "Shell to use when executing package.json scripts."
    }
  }
});
var RunCommand = class extends ExecCommand {
  constructor(conf) {
    super(conf, run, runFG);
  }
  // do not provide the interactive shell arg, just do nothing
  // so that it falls back up to the noArgsSingle() method
  defaultArg0() {
  }
  noArgsSingle() {
    const cwd = this.getCwd();
    const { scripts = {} } = this.conf.options.packageJson.read(cwd);
    return scripts;
  }
  noArgsMulti() {
    const scripts = {};
    for (const { label, manifest } of this.getTargets()) {
      if (manifest.scripts) scripts[label] = manifest.scripts;
    }
    return scripts;
  }
};
var command = async (conf) => await new RunCommand(conf).run();
export {
  command,
  usage,
  views
};
