var global = globalThis;
import {Buffer} from "node:buffer";
import {setTimeout as _vlt_setTimeout,clearTimeout as _vlt_clearTimeout,setImmediate as _vlt_setImmediate,clearImmediate as _vlt_clearImmediate,setInterval as _vlt_setInterval,clearInterval as _vlt_clearInterval} from "node:timers";
globalThis.setTimeout = _vlt_setTimeout;
globalThis.clearTimeout = _vlt_clearTimeout;
globalThis.setImmediate = _vlt_setImmediate;
globalThis.clearImmediate = _vlt_clearImmediate;
globalThis.setInterval = _vlt_setInterval;
globalThis.clearInterval = _vlt_clearInterval;
import {createRequire as _vlt_createRequire} from "node:module";
var require = _vlt_createRequire(import.meta.filename);
import {
  ExecCommand,
  views
} from "./chunk-ELHX2DD4.js";
import "./chunk-RIYFGX27.js";
import "./chunk-2M5IL56T.js";
import "./chunk-TDTJOKF2.js";
import "./chunk-VTEFO2FT.js";
import "./chunk-RXNA2XCX.js";
import "./chunk-WGDTG44V.js";
import "./chunk-5WHVV7CQ.js";
import "./chunk-BWDOHM7J.js";
import {
  runExec,
  runExecFG
} from "./chunk-EHD7YJKI.js";
import "./chunk-K4X2TU3S.js";
import "./chunk-VVTZN4QQ.js";
import {
  commandUsage
} from "./chunk-5E5GX4G6.js";
import "./chunk-Z76BQOEV.js";
import "./chunk-BGQCUUCA.js";
import "./chunk-E74WGW5C.js";
import "./chunk-FEV5BCW7.js";
import "./chunk-VCSVHRCS.js";
import "./chunk-D27QPHKI.js";
import "./chunk-JLJKOF75.js";
import "./chunk-KXBF4HVG.js";
import "./chunk-HTOTG4TS.js";
import "./chunk-XNLSTHDK.js";
import "./chunk-WZWDS3W4.js";
import "./chunk-PZLD7RTK.js";

// ../../src/cli-sdk/src/commands/run-exec.ts
var usage = () => commandUsage({
  command: "run-exec",
  usage: "[command ...]",
  description: `If the first argument is a defined script in package.json, then this is
                  equivalent to \`vlt run\`.

                  If not, then this is equivalent to \`vlt exec\`.`,
  options: {
    scope: {
      value: "<query>",
      description: "Filter execution targets using a DSS query."
    },
    workspace: {
      value: "<path|glob>",
      description: "Limit execution to matching workspace paths or globs."
    },
    "workspace-group": {
      value: "<name>",
      description: "Limit execution to named workspace groups."
    },
    recursive: {
      description: "Run across all selected workspaces."
    },
    "if-present": {
      description: "When running across multiple packages, only include packages with matching scripts."
    },
    bail: {
      description: "When running across multiple workspaces, stop on first failure."
    },
    "script-shell": {
      value: "<program>",
      description: "Shell to use when executing package.json scripts."
    }
  }
});
var command = async (conf) => await new ExecCommand(conf, runExec, runExecFG).run();
export {
  command,
  usage,
  views
};
