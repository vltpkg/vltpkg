var global = globalThis;
import {Buffer} from "node:buffer";
import {setTimeout as _vlt_setTimeout,clearTimeout as _vlt_clearTimeout,setImmediate as _vlt_setImmediate,clearImmediate as _vlt_clearImmediate,setInterval as _vlt_setInterval,clearInterval as _vlt_clearInterval} from "node:timers";
globalThis.setTimeout = _vlt_setTimeout;
globalThis.clearTimeout = _vlt_clearTimeout;
globalThis.setImmediate = _vlt_setImmediate;
globalThis.clearImmediate = _vlt_clearImmediate;
globalThis.setInterval = _vlt_setInterval;
globalThis.clearInterval = _vlt_clearInterval;
import {createRequire as _vlt_createRequire} from "node:module";
var require = _vlt_createRequire(import.meta.filename);
import {
  loadCommand
} from "./chunk-IPXBIPJW.js";
import {
  indent,
  outputCommand,
  stderr,
  stdout
} from "./chunk-2M5IL56T.js";
import "./chunk-TDTJOKF2.js";
import "./chunk-RXNA2XCX.js";
import "./chunk-WGDTG44V.js";
import {
  asRootError
} from "./chunk-5WHVV7CQ.js";
import {
  Config
} from "./chunk-SXOE2MKV.js";
import "./chunk-DIBXMKZH.js";
import "./chunk-FI5TUER7.js";
import "./chunk-YOCFBK4Y.js";
import "./chunk-D7U7KDEM.js";
import "./chunk-Z76BQOEV.js";
import "./chunk-BGQCUUCA.js";
import {
  loadPackageJson
} from "./chunk-E74WGW5C.js";
import "./chunk-FEV5BCW7.js";
import "./chunk-VCSVHRCS.js";
import {
  getSortedCliOptions,
  getSortedKeys
} from "./chunk-D27QPHKI.js";
import "./chunk-JLJKOF75.js";
import "./chunk-KXBF4HVG.js";
import "./chunk-HTOTG4TS.js";
import "./chunk-XNLSTHDK.js";
import "./chunk-WZWDS3W4.js";
import "./chunk-PZLD7RTK.js";

// ../../src/cli-sdk/src/index.ts
import { format } from "node:util";
var { version } = loadPackageJson(
  import.meta.filename,
  "cli-package.json"
);
var loadVlt = async (cwd, argv) => {
  try {
    return await Config.load(cwd, argv);
  } catch (e) {
    const err = asRootError(e, { code: "JACKSPEAK" });
    const { found, path, wanted, name } = err.cause;
    const isConfigFile = typeof path === "string";
    const msg = isConfigFile ? `Problem in Config File ${path}` : "Invalid Option Flag";
    const validOptions = wanted ? void 0 : isConfigFile ? getSortedKeys() : getSortedCliOptions();
    stderr(msg);
    stderr(err.message);
    if (name) stderr(indent(`Field: ${format(name)}`));
    if (found) {
      stderr(
        indent(
          `Found: ${isConfigFile ? JSON.stringify(found) : format(found)}`
        )
      );
    }
    if (wanted) stderr(indent(`Wanted: ${format(wanted)}`));
    if (validOptions) {
      stderr(indent("Valid Options:"));
      stderr(indent(validOptions.join("\n"), 4));
    }
    stderr(
      indent(
        `Run 'vlt help' for more information about available options.`
      )
    );
    return process.exit(process.exitCode || 1);
  }
};
var run = async () => {
  const start = Date.now();
  const cwd = process.cwd();
  const vlt = await loadVlt(cwd, process.argv);
  if (vlt.get("version")) {
    return stdout(version);
  }
  const { monorepo } = vlt.options;
  if (vlt.get("workspace") === void 0) {
    const ws = monorepo?.get(cwd);
    if (ws) {
      vlt.values.workspace = [ws.path];
      vlt.options.workspace = [ws.path];
    }
  }
  if (vlt.command !== "init" && (vlt.get("workspace") || vlt.get("workspace-group")) && ![...monorepo?.values() ?? []].length) {
    stderr(
      `Error: No matching workspaces found. Make sure the vlt.json config contains the correct workspaces.`
    );
    if (vlt.get("workspace")) {
      stderr(indent(`Workspace: ${format(vlt.get("workspace"))}`));
    }
    if (vlt.get("workspace-group")) {
      stderr(
        indent(
          `Workspace Group: ${format(vlt.get("workspace-group"))}`
        )
      );
    }
    return process.exit(process.exitCode || 1);
  }
  const command = await loadCommand(vlt.command);
  await outputCommand(command, vlt, { start });
};
var src_default = run;
export {
  src_default as default
};
