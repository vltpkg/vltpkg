var global = globalThis;
import {Buffer} from "node:buffer";
import {setTimeout as _vlt_setTimeout,clearTimeout as _vlt_clearTimeout,setImmediate as _vlt_setImmediate,clearImmediate as _vlt_clearImmediate,setInterval as _vlt_setInterval,clearInterval as _vlt_clearInterval} from "node:timers";
globalThis.setTimeout = _vlt_setTimeout;
globalThis.clearTimeout = _vlt_clearTimeout;
globalThis.setImmediate = _vlt_setImmediate;
globalThis.clearImmediate = _vlt_clearImmediate;
globalThis.setInterval = _vlt_setInterval;
globalThis.clearInterval = _vlt_clearInterval;
import {createRequire as _vlt_createRequire} from "node:module";
var require = _vlt_createRequire(import.meta.filename);
import {
  commandUsage
} from "./chunk-5E5GX4G6.js";
import {
  deleteToken,
  setToken
} from "./chunk-YOCFBK4Y.js";
import "./chunk-D7U7KDEM.js";
import "./chunk-BGQCUUCA.js";
import "./chunk-E74WGW5C.js";
import "./chunk-VCSVHRCS.js";
import "./chunk-D27QPHKI.js";
import "./chunk-JLJKOF75.js";
import "./chunk-KXBF4HVG.js";
import "./chunk-XNLSTHDK.js";
import {
  error
} from "./chunk-WZWDS3W4.js";
import "./chunk-PZLD7RTK.js";

// ../../src/cli-sdk/src/read-password.ts
var readPassword = async (prompt, { stdin, stdout } = process) => {
  let input = "";
  stdout.write(prompt);
  stdin.setRawMode(true);
  await new Promise((res, rej) => {
    stdin.on("data", (c) => {
      if (c.length === 1 && c[0] === 127) {
        input = input.substring(0, input.length - 1);
        stdout.write("\x1B[1D \x1B[1D");
        return;
      }
      input += String(c);
      if (/\r|\n|\x04|\x03/.test(input)) {
        input = input.replace(/(\r|\n|\x04|\x03)/g, "");
        stdin.setRawMode(false);
        stdin.pause();
        if (c[c.length - 1] === 3) {
          rej(error("canceled", { signal: "SIGINT" }));
        } else res();
      } else {
        stdout.write("*".repeat(c.length));
      }
    });
  });
  return input;
};

// ../../src/cli-sdk/src/commands/token.ts
var usage = () => commandUsage({
  command: "token",
  usage: ["add", "rm"],
  description: `Explicitly add or remove tokens in the vlt keychain`,
  options: {
    registry: {
      value: "<url>",
      description: "Registry URL to manage tokens for."
    },
    identity: {
      value: "<name>",
      description: "Identity namespace used to store auth tokens."
    }
  }
});
var command = async (conf) => {
  const reg = new URL(conf.options.registry).origin;
  switch (conf.positionals[0]) {
    case "add": {
      await setToken(
        reg,
        `Bearer ${await readPassword("Paste bearer token: ")}`,
        conf.options.identity
      );
      break;
    }
    case "rm": {
      await deleteToken(reg, conf.options.identity);
      break;
    }
    default: {
      throw error("Invalid token subcommand", {
        found: conf.positionals[0],
        validOptions: ["add", "rm"],
        code: "EUSAGE"
      });
    }
  }
};
export {
  command,
  usage
};
