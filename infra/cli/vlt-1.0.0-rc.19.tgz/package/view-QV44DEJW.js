var global = globalThis;
import {Buffer} from "node:buffer";
import {setTimeout as _vlt_setTimeout,clearTimeout as _vlt_clearTimeout,setImmediate as _vlt_setImmediate,clearImmediate as _vlt_clearImmediate,setInterval as _vlt_setInterval,clearInterval as _vlt_clearInterval} from "node:timers";
globalThis.setTimeout = _vlt_setTimeout;
globalThis.clearTimeout = _vlt_clearTimeout;
globalThis.setImmediate = _vlt_setImmediate;
globalThis.clearImmediate = _vlt_clearImmediate;
globalThis.setInterval = _vlt_setInterval;
globalThis.clearInterval = _vlt_clearInterval;
import {createRequire as _vlt_createRequire} from "node:module";
var require = _vlt_createRequire(import.meta.filename);
import {
  get
} from "./chunk-DBANBIL2.js";
import {
  SecurityArchive
} from "./chunk-K4X2TU3S.js";
import {
  commandUsage
} from "./chunk-5E5GX4G6.js";
import {
  PackageInfoClient
} from "./chunk-5ZY2OA3F.js";
import "./chunk-FI5TUER7.js";
import "./chunk-JQKBSJDB.js";
import "./chunk-D7U7KDEM.js";
import "./chunk-2TOZR3L2.js";
import "./chunk-BGQCUUCA.js";
import "./chunk-E74WGW5C.js";
import {
  Spec2 as Spec,
  joinDepIDTuple
} from "./chunk-FEV5BCW7.js";
import "./chunk-VCSVHRCS.js";
import "./chunk-D27QPHKI.js";
import "./chunk-JLJKOF75.js";
import "./chunk-KXBF4HVG.js";
import "./chunk-HTOTG4TS.js";
import "./chunk-XNLSTHDK.js";
import {
  error
} from "./chunk-WZWDS3W4.js";
import "./chunk-PZLD7RTK.js";

// ../../src/cli-sdk/src/commands/view.ts
var usage = () => commandUsage({
  command: "view",
  usage: [
    "<pkg>[@<version>] [<field>]",
    "<pkg>[@<version>] [--view=human | json]"
  ],
  description: `View registry information about a package.

      Fetches and displays packument and manifest data for a given
      package from the registry.

      When a specific field is provided, only that field value is
      displayed. Use dot-prop syntax to access nested fields
      (e.g., \`dist-tags.latest\`, \`dependencies.lodash\`).

      Security data from the vlt security archive is shown when
      available, including scores and alerts.`,
  examples: {
    express: {
      description: "View info about the latest version of express"
    },
    "express@4.18.2": {
      description: "View info about a specific version"
    },
    "express versions": {
      description: "List all published versions"
    },
    "express dist-tags": {
      description: "Show all dist-tags"
    },
    "express dependencies": {
      description: "Show dependencies of the latest version"
    },
    "express dist-tags.latest": {
      description: "Show the latest dist-tag value"
    }
  },
  options: {
    view: {
      value: "[human | json]",
      description: "Output format. Defaults to human-readable or json if no tty."
    }
  }
});
var formatScore = (score) => `${Math.round(score * 100)}/100`;
var formatAlertSeverity = (severity) => {
  switch (severity) {
    case "critical":
      return "[CRITICAL]";
    case "high":
      return "[HIGH]";
    case "medium":
      return "[MEDIUM]";
    case "low":
      return "[LOW]";
    /* c8 ignore next 2 */
    default:
      return `[${String(severity).toUpperCase()}]`;
  }
};
var formatSecurity = (report) => {
  const lines = [];
  const { score, alerts } = report;
  lines.push("");
  lines.push("security:");
  lines.push(`  score: ${formatScore(score.overall)}`);
  lines.push(`    license: ${formatScore(score.license)}`);
  lines.push(`    maintenance: ${formatScore(score.maintenance)}`);
  lines.push(`    quality: ${formatScore(score.quality)}`);
  lines.push(`    supply chain: ${formatScore(score.supplyChain)}`);
  lines.push(`    vulnerability: ${formatScore(score.vulnerability)}`);
  if (alerts.length > 0) {
    lines.push(`  alerts: ${alerts.length}`);
    for (const alert of alerts) {
      lines.push(
        `    ${formatAlertSeverity(alert.severity)} ${alert.type}: ${alert.key} (${alert.category})`
      );
    }
  } else {
    lines.push("  alerts: none");
  }
  return lines.join("\n");
};
var formatDependencyCount = (manifest) => {
  const lines = [];
  const deps = Object.keys(manifest.dependencies ?? {}).length;
  const devDeps = Object.keys(manifest.devDependencies ?? {}).length;
  const optDeps = Object.keys(
    manifest.optionalDependencies ?? {}
  ).length;
  const peerDeps = Object.keys(manifest.peerDependencies ?? {}).length;
  const parts = [];
  if (deps > 0) parts.push(`${deps} dependencies`);
  if (devDeps > 0) parts.push(`${devDeps} dev`);
  if (optDeps > 0) parts.push(`${optDeps} optional`);
  if (peerDeps > 0) parts.push(`${peerDeps} peer`);
  if (parts.length > 0) {
    lines.push(`deps: ${parts.join(", ")}`);
  }
  return lines;
};
var formatHuman = (result) => {
  const { packument, manifest, security } = result;
  const lines = [];
  const name = manifest.name ?? packument.name;
  const version = manifest.version ?? "";
  lines.push(`${name}@${version}`);
  if (manifest.description) {
    lines.push(manifest.description);
  }
  lines.push("");
  if (manifest.license) {
    lines.push(`license: ${manifest.license}`);
  }
  if (manifest.homepage) {
    lines.push(`homepage: ${manifest.homepage}`);
  }
  if (manifest.repository) {
    const repo = typeof manifest.repository === "string" ? manifest.repository : manifest.repository.url;
    if (repo) {
      lines.push(`repository: ${repo}`);
    }
  }
  if (manifest.author) {
    const author = typeof manifest.author === "string" ? manifest.author : manifest.author.name;
    if (author) {
      lines.push(`author: ${author}`);
    }
  }
  if (manifest.keywords) {
    const kw = Array.isArray(manifest.keywords) ? manifest.keywords : [manifest.keywords];
    if (kw.length > 0) {
      lines.push(`keywords: ${kw.join(", ")}`);
    }
  }
  const tagEntries = Object.entries(packument["dist-tags"]);
  if (tagEntries.length > 0) {
    lines.push("");
    lines.push("dist-tags:");
    for (const [tag, ver] of tagEntries) {
      lines.push(`  ${tag}: ${ver}`);
    }
  }
  const depLines = formatDependencyCount(manifest);
  if (depLines.length > 0) {
    lines.push("");
    lines.push(...depLines);
  }
  if (packument.maintainers && packument.maintainers.length > 0) {
    lines.push("");
    lines.push("maintainers:");
    for (const m of packument.maintainers) {
      const mName = typeof m === "string" ? m : m.name;
      lines.push(`  - ${mName}`);
    }
  }
  if (packument.time && version && packument.time[version]) {
    lines.push("");
    lines.push(`published: ${packument.time[version]}`);
  }
  if (security) {
    lines.push(formatSecurity(security));
  }
  const versionCount = Object.keys(packument.versions).length;
  if (versionCount > 0) {
    lines.push("");
    lines.push(`versions: ${versionCount} total`);
  }
  return lines.join("\n");
};
var views = {
  human: (result, _options, _conf) => {
    if (result.fieldPath !== void 0) {
      const val = result.fieldValue;
      if (Array.isArray(val)) {
        return val.join("\n");
      }
      if (typeof val === "object" && val !== null) {
        return JSON.stringify(val, null, 2);
      }
      if (val === void 0 || val === null) return "";
      return typeof val === "string" ? val : JSON.stringify(val);
    }
    return formatHuman(result);
  },
  json: (result, _options, _conf) => {
    if (result.fieldPath !== void 0) {
      return result.fieldValue;
    }
    return {
      ...result.manifest,
      "dist-tags": result.packument["dist-tags"],
      time: result.packument.time,
      maintainers: result.packument.maintainers,
      ...result.security ? { security: result.security } : {}
    };
  }
};
var createFakeNode = (name, version) => ({
  id: joinDepIDTuple(["registry", "", `${name}@${version}`]),
  name,
  version,
  confused: false,
  edgesIn: /* @__PURE__ */ new Set(),
  edgesOut: /* @__PURE__ */ new Map(),
  workspaces: void 0,
  importer: false,
  mainImporter: false,
  projectRoot: "",
  dev: false,
  optional: false,
  graph: {},
  options: {},
  /* c8 ignore next 5 - stub methods for NodeLike interface */
  toJSON: () => ({}),
  toString: () => `${name}@${version}`,
  setResolved: () => {
  },
  setConfusedManifest: () => {
  },
  maybeSetConfusedManifest: () => {
  }
});
var lookupField = (result, path) => {
  const packumentFields = [
    "dist-tags",
    "versions",
    "time",
    "readme",
    "maintainers",
    "modified",
    "contributors"
  ];
  const topLevel = path.split(".")[0] ?? path;
  if (packumentFields.includes(topLevel)) {
    return get(result.packument, path);
  }
  if (topLevel === "security" && result.security) {
    const subPath = path.slice("security.".length);
    if (subPath === "" || path === "security") {
      return result.security;
    }
    return get(result.security, subPath);
  }
  return get(result.manifest, path);
};
var command = async (conf) => {
  const specArg = conf.positionals[0];
  if (!specArg) {
    throw error("view requires a package spec argument", {
      code: "EUSAGE"
    });
  }
  const fieldPath = conf.positionals[1];
  const spec = Spec.parseArgs(specArg, conf.options);
  const pic = new PackageInfoClient(conf.options);
  const [packument, resolvedManifest] = await Promise.all([
    pic.packument(spec),
    pic.manifest(spec)
  ]);
  const manifest = resolvedManifest;
  let security;
  const name = manifest.name ?? packument.name;
  const version = manifest.version;
  if (name && version) {
    try {
      const node = createFakeNode(name, version);
      const archive = await SecurityArchive.start({
        nodes: [node]
      });
      security = archive.get(node.id);
    } catch {
    }
  }
  const result = {
    packument,
    manifest,
    security
  };
  if (fieldPath !== void 0) {
    result.fieldPath = fieldPath;
    result.fieldValue = lookupField(result, fieldPath);
  }
  return result;
};
export {
  command,
  usage,
  views
};
